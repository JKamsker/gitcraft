# Owner handoff: receipt-only8bca observer v5

Implementer record only; root's independent review and actual observation remain pending. Script `watch-owned-8bca-worker-v5.py`, SHA256 `29ba91f48b64267b26283641f2e61612ddcd0acc3f6a9636cebfda36b8830888`,284 physical lines including the original seven recording tests.

V5 is an exact approved-substitution rebind of frozen `watch-owned-421-worker-v4.py`, verified before/after at SHA256 `97aa421e7291fd94695222a7b33c00bfda5e2fe9c9e56d518b96bd46e636819d`. Full-source comparison asserted equality after changing only HEAD/tree, runner filename/hash, receipt filename, run-prefix, synthetic proof output names and39→42 in the two gate-count comparisons plus synthetic manifest range. The preserved unified diff shows these exact changes. No observation/control feature or CLI flag changed. All earlier source/proof/review/observation artifacts remain untouched.

Binding:

- HEAD `8bca2a9a1e2e75bb94ca0f6be4044e92a93f119d`; tree `5330c9b12a3b67cf296f7a0efdb93ca9382d7bc7`, resolved with an immutable native Git object read.
- Runner `/mnt/e/private/gitcraft-build/run-final-candidate-v6.py`, source hash verified as `5871d710ff9493a450b6e20f55e858a42079dfa31030419a0f6b52173ffad376`.
- Exact argv `python3 /mnt/e/private/gitcraft-build/run-final-candidate-v6.py 8bca2a9a1e2e75bb94ca0f6be4044e92a93f119d`.
- Cwd `/mnt/e/private/gitcraft-worktrees/final-maintainability`; all four Linux UID fields equal observer UID.
- Owned receipt `/mnt/e/private/gitcraft-build/final-8bca-worker.pid`.
- Caller-selected results directory must resolve to a direct E-build-root child with prefix `validation-8bca2a9a-`.
- Final verdict requires42 unique checks, typed integer-zero exits, exact clean HEAD/tree before/after every check, exact top-level source/tree/runner, passed status and nonempty finished string.

The same receipt-only contract remains: read `/proc` for that PID only; stable starttime/argv/UID/cwd across pidfd binding; exact receipt bytes across binding/final success; runner hash before/after binding/final success. No enumeration, signals, spawn, cleanup commands, application execution or process-control additions. Pidfd completion is a read-only readiness event, not a recovered child exit status; output explicitly gives `child_exit_code_available=false` and `child_exit_code=null`. Observer exit0 reports its manifest verdict only.

Executed only `--self-test`: seven tests passed, zero failures/errors/skips. All snapshots/manifests/receipt data are synthetic; pidfd/poll are recordings. No real receipt, process, pidfd or current-run results were observed. The tests preserve exact identity/receipt checks, stable binding/recheck/descriptor-close behavior, run-directory restriction, final manifest refusal/progress/completion, unavailable child status and poll-error refusal. No app build/test or CI action occurred.

Frozen proof:

- `watch-owned-8bca-v5-selftests.json`: `6b1c35586abd5c526db03741915ab88301f04bb9aecf754bd0d9c7002482ff23`.
- `watch-owned-8bca-v5-selftests.log`: `53fb78c9ea38d233f7c66a1e09bbc9a635b670c5c76c9fe09ecf23aab7b4b70e`.
- `watch-owned-8bca-v5-rebind.diff`: `27ef4d3b2712211654bf7330fb5cbb1b2bffa86b8899c11b72fa44704328d338`.

After independent review, root owns any actual launch:

    python3 /mnt/e/private/gitcraft-build/watch-owned-8bca-worker-v5.py --watch RUN_DIRECTORY

This command has not been executed by the implementer. Use the exact new run directory after the owned worker has exec'd Python. Redirect observer stdout/stderr INSIDE Linux to a new E-drive log so output persists if a Windows wrapper ends. The separately root-owned worker progress file `final-8bca2a9a-progress.log` was not read or changed. No shared app worktree/index/status or Git metadata write occurred; the only Git action was the immutable tree read. All new writes are E-only supplementary artifacts. V5 is frozen and ownership returns to root for source review and runtime observation.
