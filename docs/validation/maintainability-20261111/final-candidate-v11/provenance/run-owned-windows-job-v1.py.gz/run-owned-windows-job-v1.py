"""Launch one explicit native executable in a verified, owned Windows job.

No shell, PID discovery, OpenProcess, breakaway flags, or host-wide signals.
Read a JSON specification; stdout/stderr go to an exclusively created log.
The module is inert on import. Native APIs are instantiated only by main().
"""
import ctypes as C
from ctypes import wintypes as W
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

WAIT_OBJECT_0 = 0
WAIT_TIMEOUT = 258
TERMINATED_EXIT = 124
CLEANUP_WAIT_MS = 5000
CREATE_SUSPENDED = 0x00000004
CREATE_NO_WINDOW = 0x08000000
CREATE_UNICODE_ENVIRONMENT = 0x00000400
EXTENDED_STARTUPINFO_PRESENT = 0x00080000
CREATION_FLAGS = CREATE_SUSPENDED | CREATE_NO_WINDOW | CREATE_UNICODE_ENVIRONMENT | EXTENDED_STARTUPINFO_PRESENT


def run_owned(api, spec):
    """Actual lifecycle, shared unchanged by recording tests and native execution."""
    handles = dict(job=None, log=None, stdin=None, process=None, thread=None)
    result = dict(status='error', containment_verified=False, resumed=False,
                  timed_out=False, child_exit_code=None, events=[], cleanup_errors=[])
    completed = False

    def event(name):
        result['events'].append(name)

    try:
        handles['job'] = api.create_job()
        event('created-unnamed-owned-job')
        api.kill_on_job_close(handles['job'])
        event('configured-kill-on-last-job-close-without-breakaway')
        handles['log'] = api.open_log(spec['log'])
        handles['stdin'] = api.open_stdin_null()
        api.create_suspended(spec, handles['log'], handles['stdin'], handles)
        process, thread = handles['process'], handles['thread']
        event('created-owned-process-suspended-no-window-restricted-inherited-handles')
        api.assign(handles['job'], process)
        event('assigned-owned-process-to-owned-job')
        if api.is_in_job(process, handles['job']) is not True:
            raise RuntimeError('Specific owned-job membership was not established')
        result['containment_verified'] = True
        event('verified-specific-owned-job-before-resume')
        if api.resume(thread) != 1:
            raise RuntimeError('Expected exactly one suspended primary-thread count')
        result['resumed'] = True
        event('resumed-after-containment-verification')
        wait = api.wait(process, spec['timeout_ms'])
        if wait == WAIT_TIMEOUT:
            result['timed_out'] = True
            event('deadline-expired')
            api.terminate_job(handles['job'], TERMINATED_EXIT)
            event('terminated-only-verified-owned-job')
            if api.wait(process, CLEANUP_WAIT_MS) != WAIT_OBJECT_0:
                raise RuntimeError('Owned primary did not finish within cleanup deadline')
        elif wait != WAIT_OBJECT_0:
            raise RuntimeError('Unexpected owned-process wait result')
        completed = True
        result['child_exit_code'] = api.exit_code(process)
        result['status'] = 'timeout' if result['timed_out'] else 'completed'
    except BaseException as error:
        result['error'] = type(error).__name__ + ': ' + str(error)
    finally:
        if handles['process'] is not None and not completed:
            try:
                if result['containment_verified']:
                    api.terminate_job(handles['job'], TERMINATED_EXIT)
                    event('error-cleanup-terminated-only-verified-owned-job')
                else:
                    # This handle came only from our suspended CreateProcessW.
                    # No thread has been resumed; failed assignment must not leak it.
                    api.terminate_process(handles['process'], TERMINATED_EXIT)
                    event('pre-resume-cleanup-terminated-only-created-process-handle')
                if api.wait(handles['process'], CLEANUP_WAIT_MS) != WAIT_OBJECT_0:
                    raise RuntimeError('Owned-process cleanup wait timed out')
            except BaseException as error:
                result['cleanup_errors'].append(type(error).__name__ + ': ' + str(error))
        # Closing our non-inherited last job handle also kills any remaining
        # associated descendants. A job handle is never inherited by the child.
        for name in ['thread', 'job', 'process', 'stdin', 'log']:
            if handles[name] is not None:
                try:
                    api.close(handles[name])
                    event('closed-owned-' + name + '-handle')
                except BaseException as error:
                    result['cleanup_errors'].append(name + ': ' + str(error))
        if result['cleanup_errors']:
            result['status'] = 'error'
    return result


class SECURITY_ATTRIBUTES(C.Structure):
    _fields_ = [('nLength', W.DWORD), ('lpSecurityDescriptor', W.LPVOID), ('bInheritHandle', W.BOOL)]


class STARTUPINFOW(C.Structure):
    _fields_ = [('cb', W.DWORD), ('lpReserved', W.LPWSTR), ('lpDesktop', W.LPWSTR),
        ('lpTitle', W.LPWSTR), ('dwX', W.DWORD), ('dwY', W.DWORD),
        ('dwXSize', W.DWORD), ('dwYSize', W.DWORD), ('dwXCountChars', W.DWORD),
        ('dwYCountChars', W.DWORD), ('dwFillAttribute', W.DWORD), ('dwFlags', W.DWORD),
        ('wShowWindow', W.WORD), ('cbReserved2', W.WORD), ('lpReserved2', C.POINTER(W.BYTE)),
        ('hStdInput', W.HANDLE), ('hStdOutput', W.HANDLE), ('hStdError', W.HANDLE)]


class STARTUPINFOEXW(C.Structure):
    _fields_ = [('StartupInfo', STARTUPINFOW), ('lpAttributeList', W.LPVOID)]


class PROCESS_INFORMATION(C.Structure):
    _fields_ = [('hProcess', W.HANDLE), ('hThread', W.HANDLE),
                ('dwProcessId', W.DWORD), ('dwThreadId', W.DWORD)]


class JOBOBJECT_BASIC_LIMIT_INFORMATION(C.Structure):
    _fields_ = [('PerProcessUserTimeLimit', C.c_longlong), ('PerJobUserTimeLimit', C.c_longlong),
        ('LimitFlags', W.DWORD), ('MinimumWorkingSetSize', C.c_size_t),
        ('MaximumWorkingSetSize', C.c_size_t), ('ActiveProcessLimit', W.DWORD),
        ('Affinity', C.c_size_t), ('PriorityClass', W.DWORD), ('SchedulingClass', W.DWORD)]


class IO_COUNTERS(C.Structure):
    _fields_ = [(name, C.c_ulonglong) for name in ['ReadOperationCount', 'WriteOperationCount',
        'OtherOperationCount', 'ReadTransferCount', 'WriteTransferCount', 'OtherTransferCount']]


class JOBOBJECT_EXTENDED_LIMIT_INFORMATION(C.Structure):
    _fields_ = [('BasicLimitInformation', JOBOBJECT_BASIC_LIMIT_INFORMATION),
        ('IoInfo', IO_COUNTERS), ('ProcessMemoryLimit', C.c_size_t),
        ('JobMemoryLimit', C.c_size_t), ('PeakProcessMemoryUsed', C.c_size_t),
        ('PeakJobMemoryUsed', C.c_size_t)]


class WindowsAPI:
    def __init__(self):
        if os.name != 'nt':
            raise RuntimeError('Native Windows execution is required')
        self.k = C.WinDLL('kernel32', use_last_error=True)
        signatures = {
            'CreateJobObjectW': (W.HANDLE, [W.LPVOID, W.LPCWSTR]),
            'SetInformationJobObject': (W.BOOL, [W.HANDLE, C.c_int, W.LPVOID, W.DWORD]),
            'CreateFileW': (W.HANDLE, [W.LPCWSTR, W.DWORD, W.DWORD, C.POINTER(SECURITY_ATTRIBUTES), W.DWORD, W.DWORD, W.HANDLE]),
            'InitializeProcThreadAttributeList': (W.BOOL, [W.LPVOID, W.DWORD, W.DWORD, C.POINTER(C.c_size_t)]),
            'UpdateProcThreadAttribute': (W.BOOL, [W.LPVOID, W.DWORD, C.c_size_t, W.LPVOID, C.c_size_t, W.LPVOID, W.LPVOID]),
            'DeleteProcThreadAttributeList': (None, [W.LPVOID]),
            'CreateProcessW': (W.BOOL, [W.LPCWSTR, W.LPWSTR, W.LPVOID, W.LPVOID, W.BOOL, W.DWORD, W.LPVOID, W.LPCWSTR, C.POINTER(STARTUPINFOW), C.POINTER(PROCESS_INFORMATION)]),
            'AssignProcessToJobObject': (W.BOOL, [W.HANDLE, W.HANDLE]),
            'IsProcessInJob': (W.BOOL, [W.HANDLE, W.HANDLE, C.POINTER(W.BOOL)]),
            'ResumeThread': (W.DWORD, [W.HANDLE]),
            'WaitForSingleObject': (W.DWORD, [W.HANDLE, W.DWORD]),
            'GetExitCodeProcess': (W.BOOL, [W.HANDLE, C.POINTER(W.DWORD)]),
            'TerminateJobObject': (W.BOOL, [W.HANDLE, W.UINT]),
            'TerminateProcess': (W.BOOL, [W.HANDLE, W.UINT]),
            'CloseHandle': (W.BOOL, [W.HANDLE]),
        }
        for name, (restype, argtypes) in signatures.items():
            function = getattr(self.k, name)
            function.restype, function.argtypes = restype, argtypes

    @staticmethod
    def check(value):
        if not value:
            raise C.WinError(C.get_last_error())
        return value

    def create_job(self):
        return self.check(self.k.CreateJobObjectW(None, None))

    def kill_on_job_close(self, job):
        limits = JOBOBJECT_EXTENDED_LIMIT_INFORMATION()
        limits.BasicLimitInformation.LimitFlags = 0x00002000
        self.check(self.k.SetInformationJobObject(job, 9, C.byref(limits), C.sizeof(limits)))

    def open_file(self, path, disposition):
        attributes = SECURITY_ATTRIBUTES(C.sizeof(SECURITY_ATTRIBUTES), None, True)
        handle = self.k.CreateFileW(str(path), 0x40000000 if disposition == 1 else 0x80000000,
            0x00000001, C.byref(attributes), disposition, 0x00000080, None)
        if handle == C.c_void_p(-1).value:
            raise C.WinError(C.get_last_error())
        return handle

    def open_log(self, path):
        return self.open_file(path, 1)  # CREATE_NEW, never replace an existing log.

    def open_stdin_null(self):
        return self.open_file('NUL', 3)  # OPEN_EXISTING

    def create_suspended(self, spec, log, stdin, owned):
        size = C.c_size_t()
        sized = self.k.InitializeProcThreadAttributeList(None, 1, 0, C.byref(size))
        if sized or C.get_last_error() != 122 or size.value == 0:
            raise RuntimeError('Unexpected attribute-list sizing result')
        attributes = C.create_string_buffer(size.value)
        self.check(self.k.InitializeProcThreadAttributeList(attributes, 1, 0, C.byref(size)))
        info = PROCESS_INFORMATION()
        try:
            inherited = (W.HANDLE * 2)(log, stdin)
            self.check(self.k.UpdateProcThreadAttribute(attributes, 0, 0x00020002,
                inherited, C.sizeof(inherited), None, None))
            startup = STARTUPINFOEXW()
            startup.StartupInfo.cb = C.sizeof(startup)
            startup.StartupInfo.dwFlags = 0x00000100
            startup.StartupInfo.hStdInput = stdin
            startup.StartupInfo.hStdOutput = startup.StartupInfo.hStdError = log
            startup.lpAttributeList = C.cast(attributes, W.LPVOID)
            command = C.create_unicode_buffer(subprocess.list2cmdline(spec['argv']))
            environment = C.create_unicode_buffer(spec['environment_block'])
            self.check(self.k.CreateProcessW(spec['argv'][0], command, None, None, True,
                CREATION_FLAGS, environment, spec['cwd'],
                C.cast(C.byref(startup), C.POINTER(STARTUPINFOW)), C.byref(info)))
            # Transfer directly into the executor's ownership ledger before
            # returning: an exception cannot strand a suspended process.
            owned.update(process=info.hProcess, thread=info.hThread)
        finally:
            try:
                if info.hProcess and owned['process'] != info.hProcess:
                    try:
                        self.terminate_process(info.hProcess, TERMINATED_EXIT)
                        self.wait(info.hProcess, CLEANUP_WAIT_MS)
                    finally:
                        self.close(info.hProcess)
            finally:
                try:
                    if info.hThread and owned['thread'] != info.hThread:
                        self.close(info.hThread)
                finally:
                    self.k.DeleteProcThreadAttributeList(attributes)

    def assign(self, job, process):
        self.check(self.k.AssignProcessToJobObject(job, process))

    def is_in_job(self, process, job):
        answer = W.BOOL()
        self.check(self.k.IsProcessInJob(process, job, C.byref(answer)))
        return bool(answer.value)

    def resume(self, thread):
        count = self.k.ResumeThread(thread)
        if count == 0xFFFFFFFF:
            raise C.WinError(C.get_last_error())
        return count

    def wait(self, process, milliseconds):
        value = self.k.WaitForSingleObject(process, milliseconds)
        if value == 0xFFFFFFFF:
            raise C.WinError(C.get_last_error())
        return value

    def exit_code(self, process):
        value = W.DWORD()
        self.check(self.k.GetExitCodeProcess(process, C.byref(value)))
        return value.value

    def terminate_job(self, job, code):
        self.check(self.k.TerminateJobObject(job, code))

    def terminate_process(self, process, code):
        self.check(self.k.TerminateProcess(process, code))

    def close(self, handle):
        self.check(self.k.CloseHandle(handle))


def validate_config(value, output_root):
    allowed = {'argv', 'cwd', 'env', 'log', 'report', 'timeout_seconds'}
    if set(value) != allowed:
        raise ValueError('Exactly argv/cwd/env/log/report/timeout_seconds are required')
    argv = value['argv']
    if not isinstance(argv, list) or not argv or any(not isinstance(arg, str) or '\0' in arg for arg in argv):
        raise ValueError('argv must contain NUL-free strings')
    application = Path(argv[0])
    cwd = Path(value['cwd'])
    if not application.is_absolute() or not application.is_file() or application.suffix.lower() != '.exe':
        raise ValueError('argv[0] must identify an existing absolute .exe path')
    if not cwd.is_absolute() or not cwd.is_dir():
        raise ValueError('cwd must be an existing absolute directory')
    timeout = value['timeout_seconds']
    if type(timeout) is not int or not 1 <= timeout <= 3600:
        raise ValueError('timeout_seconds must be an integer from 1 to 3600')
    if any(not Path(value[key]).is_absolute() for key in ['log', 'report']):
        raise ValueError('log and report must be absolute paths')
    paths = [Path(value[key]).resolve() for key in ['log', 'report']]
    if paths[0] == paths[1]:
        raise ValueError('log and report must differ')
    for path in paths:
        if not path.is_relative_to(output_root.resolve()) or not path.parent.is_dir() or path.exists():
            raise ValueError('Each output must be a fresh path under the helper directory')
    overrides = value['env']
    if not isinstance(overrides, dict):
        raise ValueError('env must be an object of explicit string overrides')
    environment = dict(os.environ)
    seen = set()
    for key, item in overrides.items():
        if not isinstance(key, str) or not key or '=' in key or '\0' in key or not isinstance(item, str) or '\0' in item or key.casefold() in seen:
            raise ValueError('Invalid or case-ambiguous environment override')
        seen.add(key.casefold())
        for inherited in list(environment):
            if inherited.casefold() == key.casefold():
                del environment[inherited]
        environment[key] = item
    block = '\0'.join(key + '=' + environment[key] for key in sorted(environment, key=str.casefold)) + '\0\0'
    return dict(argv=argv, cwd=str(cwd), log=str(paths[0]), report=str(paths[1]),
                timeout_ms=timeout * 1000, environment_block=block,
                environment_override_keys=sorted(overrides))


def main():
    if len(sys.argv) != 2:
        raise SystemExit('Usage: python run-owned-windows-job-v1.py ABSOLUTE-SPEC.json')
    source = Path(__file__).resolve()
    config_path = Path(sys.argv[1])
    if not config_path.is_absolute():
        raise ValueError('The JSON specification path must be absolute')
    config_raw = config_path.read_bytes()
    spec = validate_config(json.loads(config_raw), source.parent)
    # Reserve the report before any native process action; never overwrite one.
    with Path(spec['report']).open('x', encoding='utf-8') as report:
        started = time.monotonic()
        result = run_owned(WindowsAPI(), spec)
        result.update(source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
            spec_sha256=hashlib.sha256(config_raw).hexdigest(), elapsed_seconds=time.monotonic() - started,
            argv=spec['argv'], cwd=spec['cwd'], log=spec['log'], timeout_ms=spec['timeout_ms'],
            environment_override_keys=spec['environment_override_keys'])
        report.write(json.dumps(result, indent=2) + '\n')
    print(json.dumps(dict(status=result['status'], report=spec['report'], child_exit_code=result['child_exit_code'])))
    return 124 if result['status'] == 'timeout' else 0 if result['status'] == 'completed' and result['child_exit_code'] == 0 else 1


if __name__ == '__main__':
    raise SystemExit(main())
