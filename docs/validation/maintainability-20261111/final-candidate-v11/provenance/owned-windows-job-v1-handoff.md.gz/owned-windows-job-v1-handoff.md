# Owned Windows Job runner v1

Frozen helper: `run-owned-windows-job-v1.py`, SHA256
`9c6b9ea0f0f22df80c21f68bbbaf779b7094d96c6cf95930a5ec814a01e07632`.
Proof: `test_owned_windows_job_v1.py`, SHA256
`08b79f922e1d0db4009829a441c9efaa9297edce4b6fe06a61f84b167430b9c0`.
Results/log: `owned-windows-job-v1-proof.json` and `.log`; log SHA256
`c4e8992e671cb04cde90313a9c5266e746c546537276dd14cc6f6f2215996a0d`.

Thirteen recording-only tests covering50 scenarios passed, zero failures/errors.
Both the shared lifecycle and actual ctypes adapter were exercised against fake
APIs. No WindowsAPI constructor, WinDLL, native kernel call, actual child, PID
discovery, signal, repository mutation, application build or CI action ran.
Only standalone E-drive helper/proof files were written.

## Ownership contract

The runner creates one unnamed, non-inherited job, configures only
KILL_ON_JOB_CLOSE, and opens a new output log plus NUL stdin. CreateProcessW uses
an explicit absolute executable, quoted argv, explicit cwd, a Unicode environment,
CREATE_SUSPENDED, CREATE_NO_WINDOW and STARTUPINFOEX's explicit inherited handle
list containing only the log and stdin handles. Neither the job nor process/thread
handles is inherited. Breakaway limits/creation flags are never enabled.

The process is assigned to that job while its primary thread remains suspended.
IsProcessInJob must return success and true for those exact owned handles before
ResumeThread runs. ResumeThread must report the expected suspension count of1.
The primary-process wait is bounded by the configured deadline. Timeout calls
TerminateJobObject only on this verified owned job, followed by a bounded wait.
Normal completion records the actual primary-process exit code. Closing the last
owned job handle also terminates any remaining associated descendants; a primary
exit does not imply all its descendants completed successfully.

Assignment/verification failures never resume the child. Their cleanup uses only
the process handle returned by this runner's suspended CreateProcessW, then closes
the owned job. A native creation/handle-transfer interruption has the same owned
handle cleanup. Post-verification failures use only the verified owned job.
All other owned handles are closed even if one cleanup operation fails; errors
are reported instead of claiming success. No PID-based open, process enumeration,
host-wide selector, external cleanup command or signal exists in the helper.

## Root execution after review

Review these frozen bytes first. Root should run a benign successful child and
a benign timed-out child before invoking the downloaded CI executable. This
handoff author has run neither test nor the CI executable.

The JSON object requires exactly these keys:

```json
{
  "argv": ["C:/absolute/path/to/python.exe", "-c", "print('benign')"],
  "cwd": "E:/private/gitcraft-build",
  "env": {},
  "log": "E:/private/gitcraft-build/UNIQUE-benign.log",
  "report": "E:/private/gitcraft-build/UNIQUE-benign.json",
  "timeout_seconds": 10
}
```

Invoke native Python with the helper and an absolute specification path; no shell
command is accepted by the helper. argv[0] must be an existing absolute `.exe`,
cwd must exist, outputs must be fresh absolute paths below the helper directory
with existing parents, and timeout_seconds must be an integer from1 to3600.
Environment entries are string overrides of the inherited environment; invalid
names, NUL values and case-ambiguous overrides are rejected. The parent process's
environment is not changed. The report is exclusively reserved before native
process actions, and the log is CREATE_NEW. The JSON report records helper/spec
hashes, argv/cwd, override key names, deadline, lifecycle events, containment,
child exit code and cleanup failures. The runner returns124 for a contained
timeout,0 for completed child success, and1 for child failure/runner error.

Native Python available on this machine:
`C:/Users/JonasKamsker/AppData/Local/Programs/Rider/plugins/cidr-debugger-plugin/bin/lldb/win/x64/bin/python.exe`.

## API references

The design follows Microsoft's documented suspended CreateProcessW and explicit
handle inheritance contract, job assignment/membership and kill-on-close behavior:

- https://learn.microsoft.com/en-us/windows/win32/api/processthreadsapi/nf-processthreadsapi-createprocessw
- https://learn.microsoft.com/en-us/windows/win32/api/processthreadsapi/nf-processthreadsapi-updateprocthreadattribute
- https://learn.microsoft.com/en-us/windows/win32/api/jobapi2/nf-jobapi2-assignprocesstojobobject
- https://learn.microsoft.com/en-us/windows/win32/procthread/job-objects

No native-runtime containment claim is made by the synthetic proof alone.
