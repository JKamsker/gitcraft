"""Test actual imported pure guards/output planner; never invoke main or any subprocess."""
import ast
import builtins
import copy
import gzip
import hashlib
import importlib.util
import io
import json
from pathlib import Path, PurePosixPath
import unittest

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / 'preserve-final-candidate-v11-v2.py'
PIN = '9146c34cd00a10e6d628b87d5edb55f3a19cf342077c5736d02fd893d5d2c8fa'
assert hashlib.sha256(SOURCE.read_bytes()).hexdigest() == PIN
loader = importlib.util.spec_from_file_location('archive_v11', SOURCE)
writer = importlib.util.module_from_spec(loader)
loader.loader.exec_module(writer)
SCENARIOS = []
RUN = writer.LINUX_ROOT + '/validation-8bca2a9a-synthetic'
# tempfile's exact eight-character suffix is part of the canonical-path guard.
RUN = RUN.replace('synthetic', 'abcdefgh')


def encoded(value):
    return (json.dumps(value, indent=2) + '\n').encode()


def summary(passed, ignored=0, filtered=0):
    return f'test result: ok. {passed} passed; 0 failed; {ignored} ignored; 0 measured; {filtered} filtered out; finished in 1s\n'


def fixture():
    artifacts = []
    for index, (name, kind, source) in enumerate(sorted(writer.ARTIFACTS)):
        executable = writer.LINUX_ROOT + '/linux/test-' + str(index)
        artifacts.append(dict(name=name, kind=list(kind), source=source, executable=executable, sha256=writer.sha(executable.encode())))
    app_exe, rec_exe = writer.LINUX_ROOT + '/linux/gitcraft', RUN + '/recovery-target/checks'
    app = dict(executable=app_exe, sha256=writer.sha(app_exe.encode()))
    rec = dict(executable=rec_exe, sha256=writer.sha(rec_exe.encode()), source='src/resolver/park/checks/lib.rs', tests=['recovery_test_' + str(i) for i in range(19)])
    shells = {'ci/synthetic.sh': writer.sha(b'#!/bin/sh\n')}
    state = dict(head=writer.HEAD, tree=writer.TREE, status='', shell_assets=shells)
    result = dict(commit=writer.HEAD, tree=writer.TREE, runner_sha256=writer.RUNNER,
        status='passed', finished='2026-11-12T05:00:00+00:00', artifacts=artifacts,
        application=app, recovery_recording=rec, shell_assets=[dict(path=p, sha256=s) for p, s in shells.items()],
        final_state=copy.deepcopy(state), namespace_probe=dict(host='pid:[host]', child='pid:[child]'))
    commands, _, _ = writer.commands(result)
    logs = {label: b'' for label in commands}
    for label, test in writer.EXACT.items():
        logs[label] = ('test ' + test + ' ... ok\n' + summary(1)).encode()
    for label, (_, count) in writer.RECORDING.items():
        logs[label] = summary(count).encode()
    for label in commands:
        if label.startswith('runtime-'):
            logs[label] = summary(0 if label == 'runtime-gitcraft-main' else 1).encode()
    logs['runtime-gitcraft-lib'] = ('\n'.join('test ' + writer.EXACT[label] + ' ... ok' for label in ['keymap-context-source', 'keymap-context-viewports', 'stack-update-refs']) + '\n' + summary(5236, 27, 4)).encode()
    logs['tooling-regressions'] = b'Ran 61 tests in 1.234s\nOK\n'
    for label in ['clippy-packages', 'windows-cross-clippy-packages']:
        logs[label] = b'Clippy packages: 3 checked.\n'
    logs['doc-tests'] = (summary(0) * 2).encode()
    logs['list-recovery-recording'] = ('\n'.join(test + ': test' for test in rec['tests']) + '\n').encode()
    logs['recovery-recording'] = summary(19).encode()
    def compiler(name, kind, source, executable, test):
        return dict(reason='compiler-artifact', executable=executable, profile=dict(test=test), target=dict(name=name, kind=kind, src_path=writer.LINUX_REPO + '/' + source))
    built = [compiler(item['name'], item['kind'], item['source'], item['executable'], True) for item in artifacts]
    built.append(compiler('gitcraft', ['bin'], 'src/main.rs', app_exe, False))
    logs['build-tests'] = ('\n'.join(json.dumps(item) for item in built) + '\n').encode()
    logs['build-recovery-recording'] = (json.dumps(compiler('gitcraft_recovery_recording', ['lib'], rec['source'], rec_exe, True)) + '\n').encode()
    result['checks'] = []
    for label, command in commands.items():
        scratch_label = 'recovery-recording' if label == 'list-recovery-recording' else label
        environment = dict(CARGO_BUILD_TARGET=None, TMPDIR='/tmp/gitcraft-maintainability-runtime-' + scratch_label)
        for key, suffix in [('XDG_CONFIG_HOME', '/config'), ('XDG_DATA_HOME', '/data'), ('XDG_CACHE_HOME', '/cache')]:
            environment[key] = environment['TMPDIR'] + suffix
        if label == 'build-recovery-recording':
            environment['RUSTFLAGS'] = '--cfg recovery_recording'
        if label == 'windows-cross-clippy-packages':
            environment['CARGO_BUILD_TARGET'] = 'x86_64-pc-windows-gnu'
        entry = dict(label=label, command=command, exit=0, before=copy.deepcopy(state), after=copy.deepcopy(state),
            log=RUN + '/' + label + '.log', sha256=writer.sha(logs[label]), test_summaries=writer.summaries(logs[label].decode()), environment=environment)
        if label not in writer.STATIC:
            binary = rec_exe if label in ['list-recovery-recording', 'recovery-recording'] else command[0] if label in ['acl-save', 'acl-index'] else command[11]
            entry.update(binary_sha256_before=writer.sha(binary.encode()), binary_sha256_after=writer.sha(binary.encode()),
                application_sha256_before=app['sha256'], application_sha256_after=app['sha256'])
        if label == 'tooling-regressions':
            entry['python_test_count'] = 61
        result['checks'].append(entry)
    hashes = {item['executable']: item['sha256'] for item in [*artifacts, app, rec]}
    return result, logs, hashes, shells


def entry(result, label):
    return next(item for item in result['checks'] if item['label'] == label)


def change_log(result, logs, label, raw):
    logs[label] = raw
    check = entry(result, label)
    check['sha256'] = writer.sha(raw)
    check['test_summaries'] = writer.summaries(raw.decode())


class RunGuards(unittest.TestCase):
    def test_workspace_doctests_require_exactly_two_zero_summaries(self):
        args = fixture()
        self.assertEqual(len(writer.summaries(args[1]['doc-tests'].decode())), 2)
        writer.validate_run(args[0], args[1], RUN, args[2], args[3])
        cases = {
            'zero_targets': '',
            'one_target': summary(0),
            'three_targets': summary(0) * 3,
            'nonzero_target': summary(0) + summary(1),
            'failed_target': summary(0) + 'test result: FAILED. 0 passed; 1 failed; 0 ignored; 0 measured; 0 filtered out; finished in 1s\n',
        }
        for label, text in cases.items():
            args = fixture()
            change_log(args[0], args[1], 'doc-tests', text.encode())
            with self.assertRaises(AssertionError):
                writer.validate_run(args[0], args[1], RUN, args[2], args[3])
            SCENARIOS.append('workspace_doctest_rejection:' + label)
        SCENARIOS.append('workspace_doctest:exact_two_zero_targets')

    def test_valid_complete_fixture_and_independent_42_label_inventory(self):
        result, logs, hashes, shells = fixture()
        observed = writer.validate_run(result, logs, RUN, hashes, shells)
        self.assertEqual(observed['gates'], 42)
        expected = {'rust_file_size-working', 'rust_file_size-index', 'rust_file_size-revision',
            'complexity_policy-working', 'complexity_policy-index', 'complexity_policy-revision',
            'tooling-regressions', 'fmt', 'check', 'clippy-packages', 'windows-cross-clippy-packages',
            'build-tests', 'frame-font-readiness', 'frame-accessibility', 'frame-layout-profile', 'frame-settings-profile',
            'keymap-context-source', 'keymap-context-viewports', 'stack-update-refs', 'recording-pipes',
            'recording-outcomes', 'recording-resolver', 'nav-recording-manual-history', 'nav-recording-user-selection',
            'nav-recording-forward-history', 'nav-history-walk', 'nav-history-selection', 'nav-history-links',
            'build-recovery-recording', 'list-recovery-recording', 'recovery-recording', 'runtime-gitcraft_os-lib',
            'runtime-gitcraft-lib', 'runtime-gitcraft-main', 'runtime-checkpoint_cli-checkpoint_cli',
            'runtime-mcp_stdio-mcp_stdio', 'runtime-standalone_cli-standalone_cli', 'bisect-isolated',
            'acl-save', 'acl-index', 'palette-isolated', 'doc-tests'}
        self.assertEqual(set(logs), expected)
        self.assertEqual(len(writer.INPUT_NAMES), len(set(writer.INPUT_NAMES)))
        SCENARIOS.append('run:valid_exact42')

    def test_metadata_source_log_command_binary_and_environment_mutations_fail(self):
        changes = {
            'commit': lambda r, l, h, s: r.update(commit='wrong'),
            'tree': lambda r, l, h, s: r.update(tree='wrong'),
            'runner': lambda r, l, h, s: r.update(runner_sha256='wrong'),
            'failed_status': lambda r, l, h, s: r.update(status='failed'),
            'fatal': lambda r, l, h, s: r.update(fatal='failed'),
            'unfinished': lambda r, l, h, s: r.update(finished=''),
            'missing_gate': lambda r, l, h, s: r['checks'].pop(),
            'duplicate_gate': lambda r, l, h, s: r['checks'].append(r['checks'][0]),
            'missing_log': lambda r, l, h, s: l.pop('fmt'),
            'extra_log': lambda r, l, h, s: l.update(extra=b'extra'),
            'bool_exit': lambda r, l, h, s: entry(r, 'fmt').update(exit=False),
            'nonzero_exit': lambda r, l, h, s: entry(r, 'fmt').update(exit=1),
            'before_dirty': lambda r, l, h, s: entry(r, 'fmt')['before'].update(status='M source'),
            'after_changed': lambda r, l, h, s: entry(r, 'fmt')['after'].update(head='wrong'),
            'final_changed': lambda r, l, h, s: r['final_state'].update(tree='wrong'),
            'shell_bytes_changed': lambda r, l, h, s: s.update({'ci/synthetic.sh': 'wrong'}),
            'missing_shell': lambda r, l, h, s: s.clear(),
            'same_namespace': lambda r, l, h, s: r['namespace_probe'].update(child='pid:[host]'),
            'command_loosened': lambda r, l, h, s: entry(r, 'stack-update-refs')['command'].remove('--exact'),
            'missing_skip': lambda r, l, h, s: entry(r, 'runtime-gitcraft-lib')['command'].pop(),
            'wrong_log_path': lambda r, l, h, s: entry(r, 'fmt').update(log='/unbound.log'),
            'raw_log_changed': lambda r, l, h, s: l.update(fmt=b'changed'),
            'entry_log_digest': lambda r, l, h, s: entry(r, 'fmt').update(sha256='wrong'),
            'missing_artifact': lambda r, l, h, s: r['artifacts'].pop(),
            'duplicate_artifact': lambda r, l, h, s: r['artifacts'].append(r['artifacts'][0]),
            'binary_changed_before': lambda r, l, h, s: entry(r, 'stack-update-refs').update(binary_sha256_before='wrong'),
            'app_changed_after': lambda r, l, h, s: entry(r, 'stack-update-refs').update(application_sha256_after='wrong'),
            'fresh_binary_drift': lambda r, l, h, s: h.update({next(iter(h)): 'a' * 64}),
            'missing_fresh_binary': lambda r, l, h, s: h.pop(next(iter(h))),
            'cross_target_removed': lambda r, l, h, s: entry(r, 'windows-cross-clippy-packages')['environment'].update(CARGO_BUILD_TARGET=None),
            'compiler_override': lambda r, l, h, s: entry(r, 'check')['environment'].update(RUSTC_WRAPPER='unreviewed'),
            'nonisolated_runtime': lambda r, l, h, s: entry(r, 'stack-update-refs')['environment'].update(TMPDIR='/shared'),
            'xdg_context_mismatch': lambda r, l, h, s: entry(r, 'stack-update-refs')['environment'].update(XDG_CONFIG_HOME='/shared/config'),
            'python_count': lambda r, l, h, s: entry(r, 'tooling-regressions').update(python_test_count=60),
            'recovery_source': lambda r, l, h, s: r['recovery_recording'].update(source='wrong'),
            'recovery_inventory': lambda r, l, h, s: r['recovery_recording']['tests'].pop(),
        }
        for name, mutate in changes.items():
            with self.subTest(name=name):
                args = fixture()
                mutate(*args)
                with self.assertRaises((AssertionError, KeyError, ValueError, IndexError)):
                    writer.validate_run(args[0], args[1], RUN, args[2], args[3])
                SCENARIOS.append('run_rejection:' + name)

    def test_log_semantics_are_checked_after_rebinding_the_raw_digest(self):
        cases = [
            ('clippy-packages', b'Clippy packages: 2 checked.\n'),
            ('tooling-regressions', b'Ran 60 tests in 1s\nOK\n'),
            ('tooling-regressions', b'Ran 61 tests in 1s\nOK (skipped=1)\n'),
            ('runtime-gitcraft-lib', summary(5235, 27, 4).encode()),
            ('recording-pipes', summary(5).encode()),
            ('runtime-gitcraft_os-lib', b'no test execution\n'),
            ('runtime-checkpoint_cli-checkpoint_cli', summary(0).encode()),
            ('doc-tests', b'no doctest summary\n'),
            ('keymap-context-source', ('test wrong ... ok\n' + summary(1)).encode()),
            ('stack-update-refs', summary(0).encode()),
            ('build-tests', b'no compiler inventory\n'),
            ('build-recovery-recording', b'no recovery compiler inventory\n'),
            ('list-recovery-recording', b'only_one: test\n'),
            ('recovery-recording', summary(18).encode()),
        ]
        for label, raw in cases:
            args = fixture()
            change_log(args[0], args[1], label, raw)
            with self.assertRaises((AssertionError, KeyError, ValueError)):
                writer.validate_run(args[0], args[1], RUN, args[2], args[3])
            SCENARIOS.append('log_semantic_rejection:' + label)
        for label in ['keymap-context-source', 'keymap-context-viewports', 'stack-update-refs']:
            args = fixture()
            raw = args[1]['runtime-gitcraft-lib'].replace(writer.EXACT[label].encode(), b'missing')
            change_log(args[0], args[1], 'runtime-gitcraft-lib', raw)
            with self.assertRaises(AssertionError):
                writer.validate_run(args[0], args[1], RUN, args[2], args[3])
            SCENARIOS.append('full_library_missing_exact:' + label)

    def test_noncanonical_run_paths_are_rejected(self):
        for path in [RUN + '/nested', RUN.replace('8bca2a9a', 'wronghead'), '/tmp/' + PurePosixPath(RUN).name, RUN + '-extra']:
            args = fixture()
            with self.assertRaises(AssertionError):
                writer.validate_run(args[0], args[1], path, args[2], args[3])
            SCENARIOS.append('run_path_rejection:' + path)


def completion_fixture():
    events = [dict(event='owned-receipt-worker-bound', results=RUN + '/results.json', child_exit_code_available=False),
        dict(event='pidfd-completed', child_exit_code_available=False, child_exit_code=None, final_manifest_passed=True)]
    receipt = dict(candidate=writer.HEAD, tree=writer.TREE, runner_sha256=writer.RUNNER, run=PurePosixPath(RUN).name,
        launcher_wrapper_exit=0, observer_wrapper_exit=0, owned_pidfd_completion=True, non_child_exit_code=None)
    return events, receipt


def observer_bytes(events):
    return ('\n'.join(json.dumps(item) for item in events) + '\n').encode()


class CompletionGuards(unittest.TestCase):
    def test_actual_owned_completion_requires_both_wrappers_and_honest_pidfd_event(self):
        events, receipt = completion_fixture()
        writer.validate_completion(observer_bytes(events), encoded(receipt), RUN)
        for key, value in [('candidate', 'wrong'), ('tree', 'wrong'), ('runner_sha256', 'wrong'), ('run', 'wrong'),
            ('launcher_wrapper_exit', 1), ('observer_wrapper_exit', 1), ('launcher_wrapper_exit', False),
            ('owned_pidfd_completion', False), ('non_child_exit_code', 0)]:
            changed = dict(receipt, **{key: value})
            with self.assertRaises(AssertionError):
                writer.validate_completion(observer_bytes(events), encoded(changed), RUN)
            SCENARIOS.append('completion_rejection:' + key + ':' + repr(value))
        for index, key, value in [(0, 'results', '/wrong/results.json'), (1, 'final_manifest_passed', False), (1, 'child_exit_code', 0), (1, 'event', 'running')]:
            changed = copy.deepcopy(events)
            changed[index][key] = value
            with self.assertRaises(AssertionError):
                writer.validate_completion(observer_bytes(changed), encoded(receipt), RUN)
            SCENARIOS.append('observer_rejection:' + key)


def host_fixture():
    old = 'c3d6fccf79429ec5d46419c0db3151516d549011'
    ci = dict(id=43148655434, head_sha=old, run_attempt=1, status='completed', conclusion='failure')
    jobs = [dict(name='green' + str(i), conclusion='success') for i in range(13)]
    jobs += [dict(name='optional forge', conclusion='skipped'), dict(name='test (windows-latest)', conclusion='failure'), dict(name='windows-tests / Windows tests (repo-s)', conclusion='failure')]
    for job in jobs:
        job.update(run_id=ci['id'], head_sha=old, status='completed', run_attempt=1)
    inputs = {'ci-43148655434-final-run.json': encoded(ci), 'ci-43148655434-final-jobs.json': encoded(dict(jobs=jobs)),
        'ci-43148655434-final-artifacts.json': encoded(dict(artifacts=[dict(id=13913231491, name='windows-test-binaries', expired=False,
            digest='sha256:8909635df5de52e0bea73aaae12780ddc856446f84ed7a0e3c89b2d850b53912', workflow_run=dict(id=ci['id'], head_sha=old))])),
        'windows-stack-repro-c3-binary.json': encoded(dict(Hash='8c02f15b69b238b0e3d562fd134902f4b72db7457cf5ff074d5e54ca5918bd85', Path='E:/old-ci/old.exe'))}
    for prefix in ['owned-windows-job-v1-benign-success', 'owned-windows-job-v1-benign-timeout', 'windows-stack-repro-c3-a', 'windows-stack-repro-c3-b']:
        timeout = prefix.endswith('timeout')
        argv = ['E:/old-ci/old.exe', writer.STACK, '--exact'] if prefix.startswith('windows-stack') else ['E:/python.exe', '-c', 'synthetic']
        if prefix.endswith('-a'):
            argv += ['--test-threads=1']
        spec = dict(argv=argv, timeout_seconds=120)
        inputs[prefix + '-spec.json'] = encoded(spec)
        inputs[prefix + '.json'] = encoded(dict(status='timeout' if timeout else 'completed',
            containment_verified=True, resumed=True, timed_out=timeout, child_exit_code=124 if timeout else 0,
            cleanup_errors=[], source_sha256=writer.PINS['run-owned-windows-job-v1.py'],
            spec_sha256=writer.sha(inputs[prefix + '-spec.json']), argv=argv, timeout_ms=120000))
        inputs[prefix + '.log'] = ('test ' + writer.STACK + ' ... ok\n' + summary(1, 0, 4985)).encode()
    return inputs


class HistoricalGuards(unittest.TestCase):
    def test_downloaded_artifact_association_is_exact(self):
        for key, value in [('id', 1), ('name', 'wrong'), ('expired', True), ('digest', 'wrong')]:
            inputs = host_fixture()
            metadata = json.loads(inputs['ci-43148655434-final-artifacts.json'])
            metadata['artifacts'][0][key] = value
            inputs['ci-43148655434-final-artifacts.json'] = encoded(metadata)
            with self.assertRaises(AssertionError):
                writer.validate_host(inputs)
            SCENARIOS.append('artifact_association_rejection:' + key)
        for key in ['id', 'head_sha']:
            inputs = host_fixture()
            metadata = json.loads(inputs['ci-43148655434-final-artifacts.json'])
            metadata['artifacts'][0]['workflow_run'][key] = 'wrong'
            inputs['ci-43148655434-final-artifacts.json'] = encoded(metadata)
            with self.assertRaises(AssertionError):
                writer.validate_host(inputs)
            SCENARIOS.append('artifact_run_rejection:' + key)

    def test_ci_failure_and_old_binary_passes_remain_different_statuses(self):
        writer.validate_host(host_fixture())
        for file, key, value in [('ci-43148655434-final-run.json', 'conclusion', 'success'),
            ('ci-43148655434-final-run.json', 'run_attempt', 2),
            ('windows-stack-repro-c3-a.json', 'child_exit_code', 1),
            ('windows-stack-repro-c3-b.json', 'containment_verified', False),
            ('owned-windows-job-v1-benign-timeout.json', 'timed_out', False),
            ('windows-stack-repro-c3-a.json', 'source_sha256', 'wrong'),
            ('windows-stack-repro-c3-binary.json', 'Hash', 'wrong')]:
            inputs = host_fixture()
            value_dict = json.loads(inputs[file])
            value_dict[key] = value
            inputs[file] = encoded(value_dict)
            with self.assertRaises(AssertionError):
                writer.validate_host(inputs)
            SCENARIOS.append('historical_rejection:' + file + ':' + key)


class RecordingDestination:
    files = {}
    events = []
    collision = False

    def __init__(self, value):
        self.value = str(PurePosixPath(value))

    def __truediv__(self, name):
        return RecordingDestination(str(PurePosixPath(self.value) / name))

    @property
    def parent(self):
        return RecordingDestination(str(PurePosixPath(self.value).parent))

    def exists(self):
        self.events.append(('exists', self.value))
        return self.collision or self.value in self.files

    def mkdir(self, **kwargs):
        self.events.append(('mkdir', self.value, kwargs))

    def open(self, mode):
        assert mode == 'xb' and self.value not in self.files
        self.events.append(('open', self.value))
        path = self.value

        class Output:
            def __enter__(self):
                return self

            def __exit__(self, *args):
                return False

            def write(self, raw):
                RecordingDestination.files[path] = raw
                RecordingDestination.events.append(('write', path))

        return Output()


class ArchiveBoundary(unittest.TestCase):
    def setUp(self):
        RecordingDestination.files, RecordingDestination.events, RecordingDestination.collision = {}, [], False

    def test_actual_plan_contains_all_bytes_before_exclusive_publication(self):
        destination = RecordingDestination('/archive')
        manifest = dict(artifacts=[])
        sources = [('recorded/source', 'logs/one', b'one'), ('recorded/source2', 'logs/two', b'two')]
        outputs = writer.prepare_archive(sources, 'Prepared factual README', manifest, destination)
        self.assertFalse([event for event in destination.events if event[0] in ['mkdir', 'write']])
        writer.publish_archive(outputs, destination)
        self.assertEqual(next(event for event in destination.events if event[0] == 'mkdir'), ('mkdir', '/archive', dict(parents=True, exist_ok=False)))
        for item in manifest['artifacts']:
            packed = destination.files['/archive/' + item['path']]
            raw = gzip.decompress(packed)
            self.assertEqual((writer.sha(raw), len(raw), writer.sha(packed), len(packed)), (item['sha256'], item['bytes'], item['gzip_sha256'], item['gzip_bytes']))
        self.assertEqual(json.loads(destination.files['/archive/manifest.json']), manifest)
        SCENARIOS.append('archive:fully_prepared_exclusive_publication')

    def test_duplicate_escape_and_collision_fail_before_any_write(self):
        for name in ['../escape', '/absolute', 'C:/absolute', 'logs\\escape', '', '.', 'logs//normalized']:
            with self.assertRaises(AssertionError):
                writer.prepare_archive([('source', name, b'raw')], 'README', dict(artifacts=[]), RecordingDestination('/archive'))
            SCENARIOS.append('archive_path_rejection:' + name)
        with self.assertRaises(AssertionError):
            writer.prepare_archive([('a', 'same', b'a'), ('b', 'same', b'b')], 'README', dict(artifacts=[]), RecordingDestination('/archive'))
        RecordingDestination.collision = True
        with self.assertRaises(AssertionError):
            writer.prepare_archive([('a', 'name', b'a')], 'README', dict(artifacts=[]), RecordingDestination('/archive'))
        self.assertFalse([event for event in RecordingDestination.events if event[0] in ['mkdir', 'write']])
        SCENARIOS.extend(['archive:duplicate', 'archive:existing_destination'])


class OptimizationGuard(unittest.TestCase):
    def test_actual_full_module_rejects_optimization_before_import_or_native_action(self):
        raw = SOURCE.read_bytes()
        parsed = ast.parse(raw)
        guard = parsed.body[1]
        self.assertIsInstance(guard, ast.If)
        self.assertEqual(ast.unparse(guard.test), 'not __debug__')
        for level in [1, 2]:
            imports = []
            def blocked_import(name, *args, **kwargs):
                imports.append(name)
                raise AssertionError('Execution reached imports before blocking optimization')
            safe_builtins = dict(vars(builtins), __import__=blocked_import)
            with self.assertRaisesRegex(RuntimeError, 'Evidence assertions are required'):
                exec(compile(copy.deepcopy(parsed), str(SOURCE), 'exec', optimize=level), {'__name__': 'synthetic_optimized_guard', '__builtins__': safe_builtins})
            self.assertEqual(imports, [])
            SCENARIOS.append('optimization_guard:actual_full_module_level' + str(level))
        mutated = copy.deepcopy(parsed)
        del mutated.body[1]
        imports = []
        def detect_missing_guard(name, *args, **kwargs):
            imports.append(name)
            raise AssertionError('Negative control reached imports')
        with self.assertRaisesRegex(AssertionError, 'Negative control reached imports'):
            exec(compile(mutated, str(SOURCE), 'exec', optimize=1), {'__name__': 'synthetic_negative_control', '__builtins__': dict(vars(builtins), __import__=detect_missing_guard)})
        self.assertEqual(imports, ['gzip'])
        SCENARIOS.append('optimization_guard:removed_guard_negative_control')


if __name__ == '__main__':
    output = io.StringIO()
    result = unittest.TextTestRunner(stream=output, verbosity=2).run(unittest.defaultTestLoader.loadTestsFromModule(__import__(__name__)))
    log = output.getvalue().encode()
    (ROOT / 'final-candidate-v11-archive-proof-v2.log').write_bytes(log)
    summary_data = dict(source_sha256=PIN, proof_sha256=writer.sha(Path(__file__).read_bytes()),
        tests=result.testsRun, failures=len(result.failures), errors=len(result.errors),
        scenarios=len(SCENARIOS), scenario_names=SCENARIOS, log_sha256=writer.sha(log),
        required_static_inputs=writer.INPUT_NAMES,
        dynamic_inputs=['canonical-run/results.json', 'canonical-run/each-of-the-exact42-labels.log', 'fresh hash reads of six test executables, application and recovery binary', 'prior-v10/manifest.json reference only', 'all tracked LF shell assets and immutable Git source/history metadata'],
        boundary='Actual imported pure guards/output planner with synthetic data and recording destination; no main, subprocess, Git, application, CI, active output read or repository mutation')
    (ROOT / 'final-candidate-v11-archive-proof-v2.json').write_text(json.dumps(summary_data, indent=2) + '\n', encoding='utf-8')
    print(output.getvalue())
    print(json.dumps(summary_data, indent=2))
    raise SystemExit(not result.wasSuccessful())
