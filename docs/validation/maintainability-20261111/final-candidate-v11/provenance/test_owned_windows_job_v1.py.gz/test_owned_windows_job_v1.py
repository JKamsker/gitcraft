"""Recording-only proof: no WindowsAPI construction and no real child/process API."""
import ctypes as C
import hashlib
import importlib.util
import io
import json
from pathlib import Path, PureWindowsPath
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / 'run-owned-windows-job-v1.py'
PIN = '9c6b9ea0f0f22df80c21f68bbbaf779b7094d96c6cf95930a5ec814a01e07632'
assert hashlib.sha256(SOURCE.read_bytes()).hexdigest() == PIN
loader = importlib.util.spec_from_file_location('owned_windows_runner', SOURCE)
runner = importlib.util.module_from_spec(loader)
loader.loader.exec_module(runner)  # Definitions only; __main__ and WinDLL are not invoked.
SCENARIOS = []
SPEC = dict(argv=['E:/synthetic/bin.exe', 'space argument', 'quote"slash\\'],
    cwd='E:/synthetic', log='E:/synthetic/new.log', timeout_ms=1234,
    environment_block='A=1\0\0')


class RecordingAPI:
    def __init__(self, failure=None, member=True, waits=None, resume=1):
        self.calls, self.owned, self.closed = [], set(), set()
        self.failure, self.member = failure, member
        self.waits = list(waits or [runner.WAIT_OBJECT_0])
        self.resume_count = resume

    def call(self, name, *args):
        self.calls.append((name, *args))
        if self.failure == name:
            self.failure = None
            raise OSError('synthetic ' + name)

    def handle(self, name):
        self.owned.add(name)
        return name

    def require(self, *handles):
        assert all(handle in self.owned and handle not in self.closed for handle in handles)

    def create_job(self):
        self.call('create_job')
        return self.handle('job')

    def kill_on_job_close(self, job):
        self.require(job)
        self.call('kill_on_job_close', job)

    def open_log(self, path):
        self.call('open_log', path)
        return self.handle('log')

    def open_stdin_null(self):
        self.call('open_stdin_null')
        return self.handle('stdin')

    def create_suspended(self, spec, log, stdin, owned):
        self.require(log, stdin)
        self.call('create_suspended', log, stdin)
        owned.update(process=self.handle('process'), thread=self.handle('thread'))
        self.call('transferred_created_handles')

    def assign(self, job, process):
        self.require(job, process)
        self.call('assign', job, process)

    def is_in_job(self, process, job):
        self.require(process, job)
        self.call('is_in_job', process, job)
        return self.member

    def resume(self, thread):
        self.require(thread)
        self.call('resume', thread)
        return self.resume_count

    def wait(self, process, milliseconds):
        self.require(process)
        assert type(milliseconds) is int and 0 < milliseconds <= 3600000
        self.call('wait', process, milliseconds)
        return self.waits.pop(0) if self.waits else runner.WAIT_OBJECT_0

    def exit_code(self, process):
        self.require(process)
        self.call('exit_code', process)
        return 7

    def terminate_job(self, job, code):
        self.require(job)
        self.call('terminate_job', job, code)
        assert any(call[0] == 'is_in_job' for call in self.calls) and self.member is True

    def terminate_process(self, process, code):
        self.require(process)
        self.call('terminate_process', process, code)
        assert not any(call[0] == 'resume' for call in self.calls)

    def close(self, handle):
        self.require(handle)
        self.call('close', handle)
        self.closed.add(handle)


class LifecycleTests(unittest.TestCase):
    def test_success_configures_job_and_verifies_specific_containment_before_resume(self):
        api = RecordingAPI()
        result = runner.run_owned(api, SPEC)
        self.assertEqual((result['status'], result['child_exit_code']), ('completed', 7))
        self.assertEqual([call[0] for call in api.calls[:10]], [
            'create_job', 'kill_on_job_close', 'open_log', 'open_stdin_null',
            'create_suspended', 'transferred_created_handles', 'assign',
            'is_in_job', 'resume', 'wait'])
        self.assertEqual(api.closed, api.owned)
        self.assertFalse([call for call in api.calls if call[0].startswith('terminate')])
        SCENARIOS.append('lifecycle:success_exact_order')

    def test_every_setup_failure_prevents_resume_and_cleans_only_created_handles(self):
        for failure in ['create_job', 'kill_on_job_close', 'open_log', 'open_stdin_null',
                        'create_suspended', 'transferred_created_handles', 'assign', 'is_in_job']:
            api = RecordingAPI(failure=failure)
            result = runner.run_owned(api, SPEC)
            self.assertEqual(result['status'], 'error')
            self.assertFalse([call for call in api.calls if call[0] == 'resume'])
            self.assertFalse([call for call in api.calls if call[0] == 'terminate_job'])
            self.assertEqual(api.closed, api.owned)
            SCENARIOS.append('setup_failure:' + failure)

    def test_false_or_non_boolean_membership_prevents_resume(self):
        for member in [False, None, 1]:
            api = RecordingAPI(member=member)
            result = runner.run_owned(api, SPEC)
            self.assertEqual(result['status'], 'error')
            self.assertFalse([call for call in api.calls if call[0] == 'resume'])
            self.assertIn(('terminate_process', 'process', 124), api.calls)
            self.assertEqual(api.closed, api.owned)
            SCENARIOS.append('membership_rejection:' + repr(member))

    def test_timeout_terminates_only_verified_owned_job_and_waits_bounded(self):
        api = RecordingAPI(waits=[runner.WAIT_TIMEOUT, runner.WAIT_OBJECT_0])
        result = runner.run_owned(api, SPEC)
        self.assertEqual(result['status'], 'timeout')
        self.assertTrue(result['containment_verified'] and result['timed_out'])
        self.assertIn(('terminate_job', 'job', 124), api.calls)
        self.assertIn(('wait', 'process', runner.CLEANUP_WAIT_MS), api.calls)
        self.assertFalse([call for call in api.calls if call[0] == 'terminate_process'])
        self.assertEqual(api.closed, api.owned)
        SCENARIOS.append('lifecycle:verified_job_timeout')

    def test_post_verification_failures_use_only_owned_job_cleanup(self):
        for failure in ['resume', 'wait', 'exit_code']:
            api = RecordingAPI(failure=failure)
            result = runner.run_owned(api, SPEC)
            self.assertEqual(result['status'], 'error')
            if failure != 'exit_code':
                self.assertIn(('terminate_job', 'job', 124), api.calls)
            self.assertFalse([call for call in api.calls if call[0] == 'terminate_process'])
            self.assertEqual(api.closed, api.owned)
            SCENARIOS.append('post_verification_failure:' + failure)
        for previous_count in [0, 2, 0xFFFFFFFF]:
            api = RecordingAPI(resume=previous_count)
            result = runner.run_owned(api, SPEC)
            self.assertEqual(result['status'], 'error')
            self.assertIn(('terminate_job', 'job', 124), api.calls)
            SCENARIOS.append('unexpected_suspend_count:' + str(previous_count))

    def test_cleanup_failures_still_close_job_and_other_owned_handles(self):
        api = RecordingAPI(failure='terminate_job', waits=[runner.WAIT_TIMEOUT])
        result = runner.run_owned(api, SPEC)
        self.assertEqual(result['status'], 'error')
        self.assertIn(('close', 'job'), api.calls)
        self.assertEqual(api.closed, api.owned)
        api = RecordingAPI(failure='close')
        result = runner.run_owned(api, SPEC)
        self.assertEqual(result['status'], 'error')
        self.assertTrue(result['cleanup_errors'])
        self.assertIn(('close', 'job'), api.calls)
        self.assertIn(('close', 'log'), api.calls)
        SCENARIOS.extend(['cleanup:termination_failure', 'cleanup:close_failure_continues'])


class RecordingKernel:
    def __init__(self, fail=None):
        self.calls, self.fail = [], fail

    def InitializeProcThreadAttributeList(self, pointer, count, flags, size):
        self.calls.append('initialize_size' if pointer is None else 'initialize')
        if pointer is None:
            C.cast(size, C.POINTER(C.c_size_t)).contents.value = 64
            C.set_last_error(122)
            return 0
        return 1

    def UpdateProcThreadAttribute(self, attributes, flags, key, values, size, previous, returned):
        self.calls.append('update_handles')
        assert key == 0x00020002 and size == C.sizeof(runner.W.HANDLE) * 2
        assert list(values) == [101, 102]
        return 0 if self.fail == 'update' else 1

    def DeleteProcThreadAttributeList(self, pointer):
        self.calls.append('delete_attributes')

    def CreateProcessW(self, application, command, process_sa, thread_sa, inherit, flags, env, cwd, startup, info):
        self.calls.append('CreateProcessW')
        assert application == SPEC['argv'][0] and cwd == SPEC['cwd']
        assert command.value == runner.subprocess.list2cmdline(SPEC['argv'])
        assert inherit is True and process_sa is None and thread_sa is None
        assert flags == 0x08080404
        assert (startup.contents.hStdInput, startup.contents.hStdOutput, startup.contents.hStdError) == (102, 101, 101)
        assert startup.contents.dwFlags == 0x100
        assert startup.contents.cb == C.sizeof(runner.STARTUPINFOEXW)
        if self.fail == 'create':
            return 0
        native = C.cast(info, C.POINTER(runner.PROCESS_INFORMATION)).contents
        native.hProcess, native.hThread = 201, 202
        if self.fail == 'interrupt_after_create':
            raise KeyboardInterrupt('synthetic interruption after native process creation')
        return 1

    def TerminateProcess(self, process, code):
        assert process == 201 and code == 124
        self.calls.append('TerminateProcess-owned-created-handle')
        return 1

    def WaitForSingleObject(self, process, timeout):
        assert process == 201 and timeout == 5000
        self.calls.append('Wait-owned-created-handle')
        return 0

    def CloseHandle(self, handle):
        assert handle in [201, 202]
        self.calls.append('Close-owned-created-' + str(handle))
        return 1


class NativeAdapterRecordingTests(unittest.TestCase):
    def test_owned_log_is_create_new_and_only_its_explicit_handles_are_inheritable(self):
        class Kernel:
            def __init__(self):
                self.calls = []

            def CreateFileW(self, name, access, share, attributes, disposition, flags, template):
                security = C.cast(attributes, C.POINTER(runner.SECURITY_ATTRIBUTES)).contents
                assert security.bInheritHandle and security.lpSecurityDescriptor is None
                self.calls.append((name, access, share, disposition))
                return 100 + len(self.calls)
        api = runner.WindowsAPI.__new__(runner.WindowsAPI)
        api.k = Kernel()
        self.assertEqual(api.open_log('E:/synthetic/fresh.log'), 101)
        self.assertEqual(api.open_stdin_null(), 102)
        self.assertEqual(api.k.calls, [('E:/synthetic/fresh.log', 0x40000000, 1, 1), ('NUL', 0x80000000, 1, 3)])
        SCENARIOS.append('ctypes:exclusive_owned_log_and_null_input')

    def test_actual_ctypes_adapter_restricts_handles_and_creation_flags(self):
        api = runner.WindowsAPI.__new__(runner.WindowsAPI)
        api.k = RecordingKernel()
        owned = dict(process=None, thread=None)
        api.create_suspended(SPEC, 101, 102, owned)
        self.assertEqual(owned, dict(process=201, thread=202))
        self.assertEqual(api.k.calls, ['initialize_size', 'initialize', 'update_handles', 'CreateProcessW', 'delete_attributes'])
        SCENARIOS.append('ctypes:actual_adapter_handle_list_flags_command_and_transfer')

    def test_actual_adapter_deletes_attributes_on_update_and_create_failure(self):
        for failure in ['update', 'create']:
            api = runner.WindowsAPI.__new__(runner.WindowsAPI)
            api.k = RecordingKernel(fail=failure)
            with self.assertRaises(OSError):
                api.create_suspended(SPEC, 101, 102, dict(process=None, thread=None))
            self.assertEqual(api.k.calls[-1], 'delete_attributes')
            self.assertFalse([item for item in api.k.calls if 'Terminate' in item])
            SCENARIOS.append('ctypes:failure:' + failure)

    def test_interruption_after_native_creation_terminates_untransferred_owned_handle(self):
        api = runner.WindowsAPI.__new__(runner.WindowsAPI)
        api.k = RecordingKernel(fail='interrupt_after_create')
        with self.assertRaises(KeyboardInterrupt):
            api.create_suspended(SPEC, 101, 102, dict(process=None, thread=None))
        self.assertEqual(api.k.calls[-5:], ['TerminateProcess-owned-created-handle',
            'Wait-owned-created-handle', 'Close-owned-created-201', 'Close-owned-created-202', 'delete_attributes'])
        SCENARIOS.append('ctypes:interrupted_handle_transfer_cleanup')

    def test_job_limit_is_kill_on_close_with_no_breakaway_and_noninherited(self):
        class Kernel:
            def CreateJobObjectW(self, attributes, name):
                self.noninherited_unnamed = attributes is None and name is None
                return 300

            def SetInformationJobObject(self, job, kind, limits, size):
                assert job == 300 and kind == 9
                assert size == C.sizeof(runner.JOBOBJECT_EXTENDED_LIMIT_INFORMATION)
                self.flags = C.cast(limits, C.POINTER(runner.JOBOBJECT_EXTENDED_LIMIT_INFORMATION)).contents.BasicLimitInformation.LimitFlags
                return 1
        api = runner.WindowsAPI.__new__(runner.WindowsAPI)
        api.k = Kernel()
        api.kill_on_job_close(api.create_job())
        self.assertTrue(api.k.noninherited_unnamed)
        self.assertEqual(api.k.flags, 0x2000)
        SCENARIOS.append('ctypes:noninherited_unnamed_job_kill_on_close_only')


class SyntheticPath:
    def __init__(self, value):
        self.value = PureWindowsPath(value)

    def __str__(self):
        return str(self.value)

    def __eq__(self, other):
        return self.value == other.value

    @property
    def suffix(self):
        return self.value.suffix

    @property
    def parent(self):
        return SyntheticPath(self.value.parent)

    def resolve(self):
        return self

    def is_absolute(self):
        return self.value.is_absolute()

    def is_file(self):
        return self.suffix == '.exe' and 'missing' not in str(self.value)

    def is_dir(self):
        return 'missing' not in str(self.value)

    def exists(self):
        return 'exists' in str(self.value)

    def is_relative_to(self, other):
        return self.value.is_relative_to(other.value)


class ConfigTests(unittest.TestCase):
    def fixture(self):
        return dict(argv=['E:/recording/child.exe', 'space and quote"argument'],
            cwd='E:/recording', env={'Path': 'explicit replacement', 'TRACE': '1'},
            log='E:/recording/output/fresh.log', report='E:/recording/output/fresh.json', timeout_seconds=120)

    def test_config_builds_unicode_environment_and_bounded_timeout_without_shell(self):
        with patch.object(runner, 'Path', SyntheticPath), patch.dict(runner.os.environ, {'PATH': 'old', 'A': '1'}, clear=True):
            result = runner.validate_config(self.fixture(), SyntheticPath('E:/recording'))
        self.assertEqual(result['timeout_ms'], 120000)
        self.assertEqual(result['argv'], self.fixture()['argv'])
        self.assertEqual(result['environment_block'], 'A=1\0Path=explicit replacement\0TRACE=1\0\0')
        SCENARIOS.append('config:explicit_argv_casefold_env_and_timeout')

    def test_invalid_configuration_is_rejected_without_native_api_creation(self):
        mutations = {
            'unknown_key': lambda x: x.update(shell=True),
            'empty_argv': lambda x: x.update(argv=[]),
            'nul_argument': lambda x: x.update(argv=['E:/recording/child.exe', 'bad\0arg']),
            'shell_string': lambda x: x.update(argv='child.exe --flag'),
            'relative_executable': lambda x: x.update(argv=['child.exe']),
            'missing_executable': lambda x: x.update(argv=['E:/recording/missing.exe']),
            'batch_file': lambda x: x.update(argv=['E:/recording/child.cmd']),
            'relative_cwd': lambda x: x.update(cwd='relative'),
            'missing_cwd': lambda x: x.update(cwd='E:/missing'),
            'bool_timeout': lambda x: x.update(timeout_seconds=True),
            'zero_timeout': lambda x: x.update(timeout_seconds=0),
            'unbounded_timeout': lambda x: x.update(timeout_seconds=3601),
            'relative_log': lambda x: x.update(log='fresh.log'),
            'existing_log': lambda x: x.update(log='E:/recording/output/exists.log'),
            'existing_report': lambda x: x.update(report='E:/recording/output/exists.json'),
            'outside_log': lambda x: x.update(log='E:/elsewhere/new.log'),
            'same_outputs': lambda x: x.update(report=x['log']),
            'missing_parent': lambda x: x.update(log='E:/recording/missing/new.log'),
            'env_list': lambda x: x.update(env=[]),
            'env_bad_name': lambda x: x.update(env={'A=B': 'bad'}),
            'env_nul_value': lambda x: x.update(env={'A': 'bad\0value'}),
            'env_case_collision': lambda x: x.update(env={'Path': 'one', 'PATH': 'two'}),
        }
        for name, mutate in mutations.items():
            value = self.fixture()
            mutate(value)
            with patch.object(runner, 'Path', SyntheticPath), self.assertRaises((ValueError, TypeError)):
                runner.validate_config(value, SyntheticPath('E:/recording'))
            SCENARIOS.append('config_rejection:' + name)


if __name__ == '__main__':
    output = io.StringIO()
    result = unittest.TextTestRunner(stream=output, verbosity=2).run(unittest.defaultTestLoader.loadTestsFromModule(__import__(__name__)))
    log = output.getvalue().encode()
    (ROOT / 'owned-windows-job-v1-proof.log').write_bytes(log)
    summary = dict(source_sha256=PIN, proof_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        tests=result.testsRun, failures=len(result.failures), errors=len(result.errors),
        scenarios=len(SCENARIOS), scenario_names=SCENARIOS, log_sha256=hashlib.sha256(log).hexdigest(),
        boundary='Recording fake APIs, including actual ctypes adapter; no WinDLL construction, real process, native kernel call, PID discovery or signals')
    (ROOT / 'owned-windows-job-v1-proof.json').write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8')
    print(output.getvalue())
    print(json.dumps(summary, indent=2))
    raise SystemExit(not result.wasSuccessful())
