# Read-only Windows rebase hang scout

Immutable source: `c3d6fccf79429ec5d46419c0db3151516d549011`, tree `c41e6b89e7474bc9d25cd6306dc5ee507980e5a1`. Supplied failed log `ci-43148655434-failed.log` SHA256 `3d3925cfc1cb0848c1ffe60169ae5f186d2b4960a3f9bf2f68fd07a7f6fdad4e`. Source/configuration scout only; process lifecycle is independently assigned elsewhere.

**Conclusion:** the supplied source/log do not establish the exact blocking call. An ordinary interactive editor or credential prompt is unsupported by this trace. Increasing a timeout has no source justification. The useful next evidence is owned phase/process tracing, not assuming slow rebase progress.

The log shows103 tests passing in40.38s, then the isolated `repo::stack::tests::undoing_a_rebase_that_updated_dependent_branches_puts_them_back` starts at03:42:53.7058640Z. Libtest prints its60-second notice. There is no subsequent test-phase, Git stderr or panic diagnostic before the shard step's20-minute timeout at04:02:11.9641192Z. The timeout interrupts Python's wait; it is not a completed Rust assertion or evidence that a particular Git editor waited. The log identifies Git2.56.0.windows.4 and Windows Server2025; workflow metadata names a merge ref, so this report binds its source inspection to the requested immutable head without independently claiming binary-to-head provenance.

## Editor and prompt path

- `git::command::GIT_ENV` sets `GIT_EDITOR=true` and `GIT_TERMINAL_PROMPT=0`; inherited `GIT_SEQUENCE_EDITOR` is explicitly removed by `git_cmd`.
- `RebaseEditor::rebase_args` supplies `-c sequence.editor=cp <quoted todo file>` for the actual interactive rebase. `sh_path` changes Windows backslashes to forward slashes and escapes embedded single quotes for Git's shell. This is an explicit noninteractive editor command, not an implicit fallback to Vim.
- This fixture leaves every entry at Pick and enables update_refs; its generated todo has picks and update-ref records. It introduces no intentional edit stop, reword, squash-message request or external network operation.
- `TestRepo::new` sets repository-local `commit.gpgSign=false`; fixture commits provide messages explicitly. Credential prompting is therefore not a supported explanation for the described local history rewrite.
- `processes::execution::execute` sets stdin to null when no input is supplied. It does not pass the test console through to these commands.

## Why ordinary polling cannot explain the duration

`stack::tests::settle` has a30-second deadline, and `review_rebase_for_test` separately has a30-second deadline. An asynchronously pending tab state should return/panic at those boundaries when control returns to the loop. A19-minute silent wait instead requires a blocking call, inability to return from polling, a later blocking segment, or teardown/lifecycle behavior. This report does not choose among them without evidence.

Useful phase boundaries in this exact fixture are: repository setup complete; initial tab open; rebase editor read; confirmation preview ready; confirmation harness built/run/clicked; action emitted; rebase execution complete; undo complete; redo complete; final undo complete; teardown entered/completed. Direct fixture Git calls and confirmation harness operations are synchronous and have no test-level phase diagnostics in the supplied source. Both confirmation preview and acceptance call the real helper; `accept_rebase_for_test` invokes `Harness::run` and a real button click. A pure UI deadlock remains a distinct possibility from a native Git/process wait. No such possibility is proven by this log.

## Generalized fixture improvements worth validating

1. `git::stack::test_repo::TestRepo::new` initializes without `--template=` and does not set a fixture-local empty `core.hooksPath`. Thus an inherited template or global hook path can add post-checkout/post-commit/post-rewrite behavior absent from the fixture's declared intent. This is a real isolation gap, but this run contains no hook evidence; it is not presented as the root cause. Any correction should cover a hostile template/global hook configuration using recording or inert sentinel fixtures, preserving all actual update-ref/undo/redo assertions.
2. Capture phase/progress evidence at the synchronous boundaries above and the process service's existing owned trace stages. A regression should identify whether execution, publication, pipe drain or teardown stopped; a larger outer timeout merely conceals the same failure.
3. Recording regressions can assert the effective command environment clears inherited sequence editors, keeps the fixed no-op message editor and prompt suppression, and produces one correctly quoted todo path for Windows paths containing spaces/apostrophes. These controls already exist in production source; tests should protect them rather than invent a different editor implementation for this single fixture.
4. Any eventual real process reproduction must follow the repository's synthetic/recording-first ownership rules and the owner's explicit test authorization. This scout did not start one.

No app source/index/status changes, build, runtime test, CI operation, process discovery/control, signal or cleanup was performed. Only immutable Git object reads and supplied log reads were used; this E-only note is the sole added artifact. This is a scoped diagnostic report, not a root-cause claim or source/runtime approval.
