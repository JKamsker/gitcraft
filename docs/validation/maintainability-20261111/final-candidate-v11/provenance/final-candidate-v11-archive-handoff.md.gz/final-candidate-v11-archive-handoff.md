# Frozen v11 archive writer handoff

Candidate: `8bca2a9a1e2e75bb94ca0f6be4044e92a93f119d`.
Tree: `5330c9b12a3b67cf296f7a0efdb93ca9382d7bc7`.
Destination: `docs/validation/maintainability-20261111/final-candidate-v11`.

The complete writer has not been executed. No active candidate result/progress/
observer output was read, no repository file/index/branch was changed, and no
build, application, CI or process-control action occurred. Only E-drive source,
proof and handoff files were written. Root execution must wait for successful
exact42 gates, both owned handles, and both source reviews.

## Frozen files

- `preserve-final-candidate-v11.py`: SHA256
  `1e692af69990a5345932bfae129e02bc52b574348238854e44a5143454c9f5d3`
- `test_final_candidate_v11_archive.py`: SHA256
  `316002d1a6bd4e32491ca7bc2cc32293530c7bd23ffc82dfd20e626f7a049066`
- `final-candidate-v11-archive-proof.json`: SHA256
  `81c2fb4149dc20c25b72e36148adf29f3495cdfc506edc092491c489273c91c4`
- `final-candidate-v11-archive-proof.log`: SHA256
  `05bd48bf1f66a80137934f08c2b327d260699d9ea31d889f9b843ae7241f1962`

Nine tests /94 synthetic scenarios passed with zero failures/errors. Tests import
the inert definitions and call the actual pure guards/output planner using
synthetic manifests/logs/metadata and a recording destination. They never call
main, Git, subprocesses or application code. The exact59 static input filenames
are listed in the proof JSON under `required_static_inputs`; dynamic inputs are
listed separately. The eventual archive has43 run inputs (raw results and42 logs)
plus those59 provenance inputs, each compressed with raw/compressed hashes and
lengths. README and manifest are generated only after all validation succeeds.

## Guards and input contract

The canonical run must be a direct child of the E-build directory named
`validation-8bca2a9a-` plus the standard eight-character tempfile suffix. Current
HEAD/tree/parent/branch and30 exact Jonas author/committer single-parent units
after dev are checked before archival. The reviewed runner SHA is pinned, as
are its independent source review and the combined-source review.

All42 labels are unique and every command is exact. Each log must have its exact
run-local path, matching digest, matching parsed test summaries, typed integer
exit0 and unchanged clean source/LF-shell snapshots. All six compiler-produced
test artifacts, application and recovery target are verified against their build
JSON, fresh file hashes and runtime before/after hashes. Runtime command and
environment checks retain namespace containment and fresh scratch contexts;
recovery listing and execution intentionally share the one reviewed recovery
runtime context. Tooling61, Linux/cross Clippy three-package coverage, full5236/
zero-failure/27-ignored/four-filtered library result, all new exact early/full
keymap/stack names and recovery inventory/count are mandatory.

The writer requires `final-8bca-owned-completion.json` containing candidate,
tree, runner_sha256, run directory basename, typed launcher_wrapper_exit0,
typed observer_wrapper_exit0, owned_pidfd_completion=true and
non_child_exit_code=null. The independent v5 observer log must separately bind
that exact results path and conclude pidfd-completed/final_manifest_passed=true.
Neither wrapper completion nor a pidfd event alone establishes application pass.

Both review inputs must exist before writing:
`review-final-candidate-v11-archive-root.md` and
`review-final-candidate-v11-archive-adversarial.md`.

The existing v10 archive is only referenced by its unchanged manifest SHA256
`72a1e4fb1bb14d6dc3458f2783b079208e6f74f1b8d32d036663f55d8080cf9c`.
Its files are not copied or rewritten. Historical CI43148655434 attempt1 remains
failed on c3: repo-s and aggregate fail,13 jobs succeed, optional forge is skipped.
The downloaded artifact13913231491 is bound to that run/head, exact artifact
digest and nonexpired state. The old native executable's exact SHA and both
repro argv/spec/result/log associations are checked. Old-binary successful
reproductions remain separate from this new candidate's application execution;
the lock correction is not attributed as the cause of the old CI timeout.

All validated bytes are preloaded once and the same bytes feed compression and
the manifest; they are never reopened after validation. Every output byte,
including generated README and serialized manifest, is prepared before any
destination mutation. The destination must be fresh; relative names are unique,
canonical and reject traversal, Windows drives, backslashes and NULs. The root
uses exist_ok=False and files use exclusive `xb` creation. A partial failure is
never silently overwritten or relabeled as completed evidence.

The writer can run under native Windows Python or WSL Python. Native Windows
execution reads/hash-checks E-resident binaries directly and converts recorded
/mnt/e paths without running those binaries. An invocation accepts only the
canonical run directory path. Root must verify these frozen bytes and actual
completion evidence before invoking it.
