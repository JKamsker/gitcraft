"""Append a fresh v11 archive only after exact42 gates and owned completion.

Inert on import. No process control, application execution, CI or builds.
"""
import gzip
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import subprocess
import sys

HEAD = '8bca2a9a1e2e75bb94ca0f6be4044e92a93f119d'
TREE = '5330c9b12a3b67cf296f7a0efdb93ca9382d7bc7'
PARENT = '1dc1247e749d3b32aefab43729c643c5404b13eb'
DEV = '57d7395bce9e187ff9f2a3ce9b96dc0d65715600'
IDENTITY = 'Jonas Kamsker <11245306+JKamsker@users.noreply.github.com>'
RUNNER = '5871d710ff9493a450b6e20f55e858a42079dfa31030419a0f6b52173ffad376'
LINUX_ROOT = '/mnt/e/private/gitcraft-build'
LINUX_REPO = '/mnt/e/private/gitcraft-worktrees/final-maintainability'
ROOT = Path('E:/private/gitcraft-build') if os.name == 'nt' else Path(LINUX_ROOT)
REPO = Path('E:/private/gitcraft-worktrees/final-maintainability') if os.name == 'nt' else Path(LINUX_REPO)
DEST = REPO / 'docs/validation/maintainability-20261111/final-candidate-v11'
PRIOR = REPO / 'docs/validation/maintainability-20261111/final-candidate-v10/manifest.json'
PRIOR_SHA = '72a1e4fb1bb14d6dc3458f2783b079208e6f74f1b8d32d036663f55d8080cf9c'
STACK = 'repo::stack::tests::undoing_a_rebase_that_updated_dependent_branches_puts_them_back'
EXACT = dict(zip(['frame-font-readiness', 'frame-accessibility', 'frame-layout-profile', 'frame-settings-profile',
    'keymap-context-source', 'keymap-context-viewports', 'stack-update-refs',
    'nav-recording-manual-history', 'nav-recording-user-selection', 'nav-recording-forward-history',
    'nav-history-walk', 'nav-history-selection', 'nav-history-links',
    'bisect-isolated', 'acl-save', 'acl-index', 'palette-isolated'], [
    'a11y::tests::repo_view::first_frame_fonts_support_ready_and_pending_repository_content',
    'a11y::tests::repo_view::the_graph_is_reached_with_tab_and_read_aloud',
    'repo::diff_split::tests::history_reveal_and_explicit_layout_choices_do_not_reapply_the_profile',
    'settings::view_preferences::tests::repository_layout_choices_preserve_unrelated_preferences_and_applied_zoom',
    'keymap::resolver::context_tests::resolver_lock_closures_do_not_reenter_context_through_identifier_helpers',
    'keymap::resolver::context_tests::permission_and_chord_overlay_queries_preserve_scope_and_viewport_ownership', STACK,
    'repo::navigation::tests::manual_history::manual_graph_diff_file_history_is_independent_of_detail_readiness',
    'repo::navigation::tests::manual_history::user_selection_and_explicit_same_file_toggle_keep_their_distinct_meanings',
    'repo::navigation::tests::manual_history::manual_graph_refinement_and_diff_selection_do_not_depend_on_cached_details',
    'repo::navigation::tests::back_and_forward_through_a_repository',
    'repo::navigation::tests::back_to_a_diff_selects_its_commit_again',
    'repo::navigation::tests::following_links_to_commits_are_steps',
    'parallel_bisect::tests::a_test_past_its_limit_is_stopped_and_skipped',
    'standalone::save::tests::acl_only_tightening_during_each_save_boundary_refuses_stale_policy_and_retains_recovery',
    'git::file_comparison::index_transaction::tests::index_owner_comparison_and_real_group_drift_refuse_stale_publication',
    'app::palette::tests::thousands_of_branches_open_and_filter_quickly']))
ARTIFACTS = {('gitcraft_os', ('lib',), 'crates/gitcraft-os/src/lib.rs'),
    ('gitcraft', ('lib',), 'src/lib.rs'), ('gitcraft', ('bin',), 'src/main.rs'),
    ('checkpoint_cli', ('test',), 'tests/checkpoint_cli.rs'),
    ('mcp_stdio', ('test',), 'tests/mcp_stdio.rs'), ('standalone_cli', ('test',), 'tests/standalone_cli.rs')}
RECORDING = {'recording-pipes': ('processes::execution::pipe_io::tests', 6),
    'recording-outcomes': ('processes::recording_outcomes', 3),
    'recording-resolver': ('resolver::process::tests::recording_failure_mapping_and_join_proof_fail_closed', 1)}
SPECIAL = ['bisect-isolated', 'acl-save', 'acl-index', 'palette-isolated']
STATIC = {f'{script}-{mode}' for script in ['rust_file_size', 'complexity_policy'] for mode in ['working', 'index', 'revision']}
STATIC |= {'tooling-regressions', 'fmt', 'check', 'clippy-packages', 'windows-cross-clippy-packages',
           'build-tests', 'build-recovery-recording', 'doc-tests'}
PINS = {
    'run-final-candidate-v6.py': RUNNER,
    'review-final-runner-v6-5871d710.md': 'af7b9ae49ed633e5b8c430e4ef057dbc2bbe689a3379593dfc0ef22e09b4da6b',
    'review-combined-source-8bca2a9a.md': '243099b80f3d4f740ef0e3ff5f7313a8c3a241920107ae6ffa4dbf583dccba0c',
    'ci-43148655434-final-run.json': '9ff4eecd7ae0abb428f934727a6196bfd821578f7b2c7269fd5d4b8a44340c9d',
    'ci-43148655434-final-jobs.json': '79ab19182e93a7eac70ce1c6e1cf4c4b518099170e645d3f4e68a5e774c4dd90',
    'ci-43148655434-final.log': '36d44688f167c9691174b95bf8356af585d4ceb9ef6ba9258391f8eb877fd623',
    'ci-43148655434-final-artifacts.json': '46fd560ffaea09b3fb33b4fffa86768a0f9e2f504855e31b7206e75eeffc2007',
    'run-owned-windows-job-v1.py': '9c6b9ea0f0f22df80c21f68bbbaf779b7094d96c6cf95930a5ec814a01e07632',
    'test_owned_windows_job_v1.py': '08b79f922e1d0db4009829a441c9efaa9297edce4b6fe06a61f84b167430b9c0',
    'watch-owned-8bca-worker-v5.py': '29ba91f48b64267b26283641f2e61612ddcd0acc3f6a9636cebfda36b8830888',
}
INPUT_NAMES = list(PINS) + [
    'ci-43148655434-failed.log', 'ci-43148655434-watch.log',
    'review-ci-windows-stack-timeout-c3d6fccf.md', 'scout-windows-rebase-43148655434-nav.md',
    'review-windows-stack-trace-1dc1247e.md', 'windows-stack-trace-remote.json',
    'windows-stack-trace-size-working.log', 'windows-stack-trace-size-index.log',
    'review-keymap-context-lock-3af3288b.md', 'keymap-context-lock-owner-note.md',
    'keymap-context-lock-remote.txt', 'keymap-context-size-native-working.log', 'keymap-context-size-native-staged.log',
    'final-v11-size-working.log', 'final-v11-size-index.log', 'final-v11-source-remote.json',
    'launch-final-8bca-linux.sh', 'final-8bca-worker.pid', 'final-8bca2a9a-progress.log',
    'watch-owned-8bca-worker-v5.log', 'watch-owned-8bca-v5-owner-note.md',
    'watch-owned-8bca-v5-rebind.diff', 'watch-owned-8bca-v5-selftests.json', 'watch-owned-8bca-v5-selftests.log',
    'review-watch-owned-8bca-v5-root.md', 'final-8bca-owned-completion.json',
    'owned-windows-job-v1-handoff.md', 'owned-windows-job-v1-proof.json', 'owned-windows-job-v1-proof.log',
    'review-owned-windows-job-v1-root.md', 'windows-stack-repro-c3-binary.json',
    'preserve-final-candidate-v11.py', 'test_final_candidate_v11_archive.py',
    'final-candidate-v11-archive-proof.json', 'final-candidate-v11-archive-proof.log',
    'review-final-candidate-v11-archive-root.md', 'review-final-candidate-v11-archive-adversarial.md',
]
for prefix in ['owned-windows-job-v1-benign-success', 'owned-windows-job-v1-benign-timeout',
               'windows-stack-repro-c3-a', 'windows-stack-repro-c3-b']:
    INPUT_NAMES += [prefix + suffix for suffix in ['-spec.json', '.json', '.log']]


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def native(path):
    path = PurePosixPath(path)
    if os.name == 'nt' and path.is_relative_to('/mnt/e'):
        return Path('E:/') / Path(*path.relative_to('/mnt/e').parts)
    return Path(path)


def summaries(text):
    return [dict(zip(['passed', 'failed', 'ignored', 'measured', 'filtered'], map(int, item)))
        for item in re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;', text)]


def contained(args):
    return ['bwrap', '--unshare-pid', '--die-with-parent', '--bind', '/', '/', '--dev', '/dev', '--proc', '/proc', '--', *args]


def commands(result):
    artifacts = result['artifacts']
    assert len(artifacts) == 6 and {(a['name'], tuple(a['kind']), a['source']) for a in artifacts} == ARTIFACTS
    assert len({a['executable'] for a in artifacts}) == 6
    library = next(a['executable'] for a in artifacts if a['source'] == 'src/lib.rs')
    recovery = result['recovery_recording']['executable']
    expected = {}
    for script in ['rust_file_size', 'complexity_policy']:
        for mode, args in [('working', []), ('index', ['--staged']), ('revision', ['--revision', 'HEAD'])]:
            expected[f'{script}-{mode}'] = ['python3', f'ci/{script}.py', *args]
    expected.update({'tooling-regressions': ['python3', '-m', 'unittest', 'discover', '-s', 'ci', '-p', 'test_*.py', '-v'],
        'fmt': ['cargo', 'fmt', '--all', '--', '--check'], 'check': ['cargo', 'check', '--locked', '--all-targets'],
        'clippy-packages': ['python3', 'ci/clippy_packages.py'], 'windows-cross-clippy-packages': ['python3', 'ci/clippy_packages.py'],
        'build-tests': ['cargo', 'test', '--locked', '--no-run', '--message-format=json'],
        'build-recovery-recording': ['cargo', 'test', '--locked', '--manifest-path', 'src/resolver/park/checks/Cargo.toml', '--no-run', '--message-format=json'],
        'doc-tests': ['cargo', 'test', '--locked', '--doc']})
    for label, test in EXACT.items():
        args = [library, test, '--exact', '--test-threads=1']
        expected[label] = args if label in ['acl-save', 'acl-index'] else contained(args)
    for label, (test, _) in RECORDING.items():
        expected[label] = contained([library, test, '--test-threads=1'])
    expected['list-recovery-recording'] = contained([recovery, '--list'])
    expected['recovery-recording'] = contained([recovery, '--test-threads=1', '--nocapture'])
    for item in artifacts:
        label = 'runtime-' + item['name'] + ('-lib' if item['source'].endswith('/lib.rs') else '-' + PurePosixPath(item['source']).stem)
        args = [item['executable'], '--test-threads=4']
        if item['executable'] == library:
            for special in SPECIAL:
                args += ['--skip', EXACT[special]]
        expected[label] = contained(args)
    assert len(expected) == 42
    return expected, library, recovery


def validate_run(result, logs, run_path, binary_hashes, shell_assets):
    assert result['commit'] == HEAD and result['tree'] == TREE and result['runner_sha256'] == RUNNER
    assert result['status'] == 'passed' and isinstance(result['finished'], str) and result['finished'] and 'fatal' not in result
    assert re.fullmatch(re.escape(LINUX_ROOT) + r'/validation-8bca2a9a-[a-z0-9_]{8}', run_path)
    expected, library, recovery = commands(result)
    checks = result['checks']
    assert len(checks) == 42 and len({c['label'] for c in checks}) == 42
    assert {c['label'] for c in checks} == set(expected) == set(logs)
    assert shell_assets and result['shell_assets'] == [dict(path=path, sha256=value) for path, value in shell_assets.items()]
    state = dict(head=HEAD, tree=TREE, status='', shell_assets=shell_assets)
    assert result['final_state'] == state
    assert result['namespace_probe']['host'] != result['namespace_probe']['child']
    binaries = {a['executable']: a['sha256'] for a in result['artifacts']}
    app, rec = result['application'], result['recovery_recording']
    assert rec['source'] == 'src/resolver/park/checks/lib.rs'
    binaries[rec['executable']] = rec['sha256']
    assert len(binaries) == 7 and app['executable'] not in binaries
    assert {**binaries, app['executable']: app['sha256']} == binary_hashes
    assert all(re.fullmatch(r'[0-9a-f]{64}', value) for value in binary_hashes.values())
    assert all(path.startswith(LINUX_ROOT + '/') for path in binary_hashes)
    def compiler_records(label):
        records = []
        for line in logs[label].decode('utf-8').splitlines():
            try:
                item = json.loads(line)
            except ValueError:
                continue
            if item.get('reason') == 'compiler-artifact' and item.get('executable'):
                records.append(item)
        return records
    built = compiler_records('build-tests')
    test_records = [item for item in built if item.get('profile', {}).get('test')]
    assert len(test_records) == 6
    assert {(i['target']['name'], tuple(i['target']['kind']), str(PurePosixPath(i['target']['src_path']).relative_to(LINUX_REPO)), i['executable']) for i in test_records} == {
        (i['name'], tuple(i['kind']), i['source'], i['executable']) for i in result['artifacts']}
    applications = [i for i in built if not i.get('profile', {}).get('test') and i['target']['name'] == 'gitcraft' and i['target']['kind'] == ['bin'] and i['target']['src_path'] == LINUX_REPO + '/src/main.rs']
    assert len(applications) == 1 and applications[0]['executable'] == app['executable']
    recovery_built = [i for i in compiler_records('build-recovery-recording') if i.get('profile', {}).get('test')]
    assert len(recovery_built) == 1 and recovery_built[0]['executable'] == recovery
    assert recovery_built[0]['target']['name'] == 'gitcraft_recovery_recording' and recovery_built[0]['target']['kind'] == ['lib']
    assert recovery_built[0]['target']['src_path'] == LINUX_REPO + '/src/resolver/park/checks/lib.rs'
    scratches = []
    for check in checks:
        label = check['label']
        assert type(check['exit']) is int and check['exit'] == 0
        assert check['before'] == check['after'] == state
        assert check['command'] == expected[label]
        assert check['log'] == run_path + '/' + label + '.log' and sha(logs[label]) == check['sha256']
        text = logs[label].decode('utf-8')
        parsed = summaries(text)
        assert check['test_summaries'] == parsed
        assert all(type(value) is int for count in check['test_summaries'] for value in count.values())
        assert all(count['failed'] == 0 for count in parsed)
        for name in ['RUSTFLAGS', 'CARGO_ENCODED_RUSTFLAGS', 'RUSTC_WRAPPER', 'RUSTC_WORKSPACE_WRAPPER', 'CLIPPY_CONF_DIR', 'CLIPPY_ARGS']:
            assert check['environment'].get(name) == ('--cfg recovery_recording' if label == 'build-recovery-recording' and name == 'RUSTFLAGS' else None)
        if label not in STATIC:
            binary = recovery if label in ['list-recovery-recording', 'recovery-recording'] else expected[label][0] if label in ['acl-save', 'acl-index'] else expected[label][11]
            assert check['binary_sha256_before'] == check['binary_sha256_after'] == binaries[binary]
            assert check['application_sha256_before'] == check['application_sha256_after'] == app['sha256']
            assert str(check['environment']['TMPDIR']).startswith('/tmp/gitcraft-maintainability-runtime-')
            scratches.append((label, check['environment']['TMPDIR']))
            for key, suffix in [('XDG_CONFIG_HOME', '/config'), ('XDG_DATA_HOME', '/data'), ('XDG_CACHE_HOME', '/cache')]:
                assert check['environment'][key] == check['environment']['TMPDIR'] + suffix
        if label in EXACT:
            assert len(parsed) == 1 and parsed[0]['passed'] == 1 and parsed[0]['ignored'] == 0
            assert re.search(r'^test ' + re.escape(EXACT[label]) + r' \.\.\. ok$', text, re.M)
        if label in RECORDING:
            assert len(parsed) == 1 and parsed[0]['passed'] == RECORDING[label][1] and parsed[0]['ignored'] == 0
        if label.startswith('runtime-'):
            assert len(parsed) == 1 and parsed[0]['passed'] >= (0 if label == 'runtime-gitcraft-main' else 1)
        if label == 'doc-tests':
            assert parsed == [dict(passed=0, failed=0, ignored=0, measured=0, filtered=0)]
        if label == 'tooling-regressions':
            assert type(check['python_test_count']) is int and check['python_test_count'] == 61
            assert re.search(r'^Ran 61 tests in [\d.]+s$', text, re.M) and re.search(r'^OK$', text, re.M)
            assert not any(value in text for value in ['skipped=', 'expected failures=', 'unexpected successes='])
        if label in ['clippy-packages', 'windows-cross-clippy-packages']:
            assert 'Clippy packages: 3 checked.' in text
            assert check['environment']['CARGO_BUILD_TARGET'] == ('x86_64-pc-windows-gnu' if label.startswith('windows-') else None)
    scratch_by_label = dict(scratches)
    assert scratch_by_label['list-recovery-recording'] == scratch_by_label['recovery-recording']
    runtime_scratches = [scratch for label, scratch in scratches if label != 'list-recovery-recording']
    assert len(runtime_scratches) == len(set(runtime_scratches))
    library_log = logs['runtime-gitcraft-lib'].decode('utf-8')
    assert summaries(library_log) == [dict(passed=5236, failed=0, ignored=27, measured=0, filtered=4)]
    for label in ['keymap-context-source', 'keymap-context-viewports', 'stack-update-refs']:
        assert re.search(r'^test ' + re.escape(EXACT[label]) + r' \.\.\. ok$', library_log, re.M)
    listed = re.findall(r'^(.+): test$', logs['list-recovery-recording'].decode('utf-8'), re.M)
    assert listed == rec['tests'] and len(listed) >= 19 and len(set(listed)) == len(listed)
    assert summaries(logs['recovery-recording'].decode('utf-8')) == [dict(passed=len(listed), failed=0, ignored=0, measured=0, filtered=0)]
    return dict(gates=42, library=summaries(library_log)[0], shell_assets=len(shell_assets))


def validate_completion(observer_raw, receipt_raw, run_path):
    events = [json.loads(line) for line in observer_raw.decode('utf-8').splitlines()]
    assert events[0] == dict(event='owned-receipt-worker-bound', results=run_path + '/results.json', child_exit_code_available=False)
    assert events[-1] == dict(event='pidfd-completed', child_exit_code_available=False, child_exit_code=None, final_manifest_passed=True)
    receipt = json.loads(receipt_raw)
    assert receipt['candidate'] == HEAD and receipt['tree'] == TREE and receipt['runner_sha256'] == RUNNER
    assert receipt['run'] == PurePosixPath(run_path).name
    assert type(receipt['launcher_wrapper_exit']) is int and receipt['launcher_wrapper_exit'] == 0
    assert type(receipt['observer_wrapper_exit']) is int and receipt['observer_wrapper_exit'] == 0
    assert receipt['owned_pidfd_completion'] is True and receipt['non_child_exit_code'] is None


def validate_host(inputs):
    ci, jobs = [json.loads(inputs[name]) for name in ['ci-43148655434-final-run.json', 'ci-43148655434-final-jobs.json']]
    old = 'c3d6fccf79429ec5d46419c0db3151516d549011'
    assert ci['id'] == 43148655434 and ci['head_sha'] == old and ci['run_attempt'] == 1
    assert ci['status'] == 'completed' and ci['conclusion'] == 'failure'
    assert len(jobs['jobs']) == 16
    assert all(j['run_id'] == ci['id'] and j['head_sha'] == old and j['status'] == 'completed' and j['run_attempt'] == 1 for j in jobs['jobs'])
    assert sorted(j['name'] for j in jobs['jobs'] if j['conclusion'] == 'failure') == ['test (windows-latest)', 'windows-tests / Windows tests (repo-s)']
    assert sum(j['conclusion'] == 'success' for j in jobs['jobs']) == 13 and sum(j['conclusion'] == 'skipped' for j in jobs['jobs']) == 1
    artifacts = json.loads(inputs['ci-43148655434-final-artifacts.json'])['artifacts']
    assert len(artifacts) == 1
    artifact = artifacts[0]
    assert artifact['id'] == 13913231491 and artifact['name'] == 'windows-test-binaries' and artifact['expired'] is False
    assert artifact['digest'] == 'sha256:8909635df5de52e0bea73aaae12780ddc856446f84ed7a0e3c89b2d850b53912'
    assert artifact['workflow_run']['id'] == ci['id'] and artifact['workflow_run']['head_sha'] == old
    binary = json.loads(inputs['windows-stack-repro-c3-binary.json'])
    assert binary['Hash'].lower() == '8c02f15b69b238b0e3d562fd134902f4b72db7457cf5ff074d5e54ca5918bd85'
    for prefix in ['owned-windows-job-v1-benign-success', 'owned-windows-job-v1-benign-timeout', 'windows-stack-repro-c3-a', 'windows-stack-repro-c3-b']:
        result, spec = json.loads(inputs[prefix + '.json']), json.loads(inputs[prefix + '-spec.json'])
        timeout = prefix.endswith('timeout')
        assert result['status'] == ('timeout' if timeout else 'completed')
        assert result['containment_verified'] is True and result['resumed'] is True and result['timed_out'] is timeout
        assert result['child_exit_code'] == (124 if timeout else 0) and result['cleanup_errors'] == []
        assert result['source_sha256'] == PINS['run-owned-windows-job-v1.py'] and result['spec_sha256'] == sha(inputs[prefix + '-spec.json'])
        assert result['argv'] == spec['argv'] and result['timeout_ms'] == spec['timeout_seconds'] * 1000
        if prefix.startswith('windows-stack'):
            assert spec['argv'][0].replace('\\', '/').casefold() == binary['Path'].replace('\\', '/').casefold()
            assert STACK in spec['argv'] and '--exact' in spec['argv']
            assert ('--test-threads=1' in spec['argv']) is prefix.endswith('-a')
            text = inputs[prefix + '.log'].decode('utf-8')
            assert re.search(r'^test ' + re.escape(STACK) + r' \.\.\. ok$', text, re.M)
            assert summaries(text) == [dict(passed=1, failed=0, ignored=0, measured=0, filtered=4985)]


def prepare_archive(sources, readme, manifest, destination):
    assert not destination.exists()
    names = [name for _, name, _ in sources]
    assert len(names) == len(set(names))
    assert all(name and name != '.' and str(PurePosixPath(name)) == name and not PurePosixPath(name).is_absolute()
        and '..' not in PurePosixPath(name).parts and not any(value in name for value in ['\\', ':', '\0']) for name in names)
    outputs = []
    for source, name, raw in sources:
        assert isinstance(raw, bytes)
        packed = gzip.compress(raw, mtime=0)
        outputs.append((name + '.gz', packed))
        manifest['artifacts'].append(dict(path=name + '.gz', source=str(source), sha256=sha(raw), bytes=len(raw), gzip_sha256=sha(packed), gzip_bytes=len(packed)))
    readme_raw = readme.encode('utf-8')
    manifest['readme'] = dict(sha256=sha(readme_raw), bytes=len(readme_raw))
    outputs += [('README.md', readme_raw), ('manifest.json', (json.dumps(manifest, indent=2) + '\n').encode('utf-8'))]
    assert len(outputs) == len({name for name, _ in outputs})
    assert all(not (destination / name).exists() for name, _ in outputs)
    return outputs


def publish_archive(outputs, destination):
    destination.mkdir(parents=True, exist_ok=False)
    for name, raw in outputs:
        target = destination / name
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open('xb') as stream:
            stream.write(raw)


def main():
    assert len(sys.argv) == 2
    run = Path(sys.argv[1]).resolve()
    assert run.parent == ROOT.resolve() and re.fullmatch(r'validation-8bca2a9a-[a-z0-9_]{8}', run.name)
    run_path = LINUX_ROOT + '/' + run.name
    env = {key: value for key, value in os.environ.items() if not key.upper().startswith('GIT_')}
    def git(*args):
        return subprocess.check_output(['git', '-c', 'core.autocrlf=true', '-C', str(REPO), *args], env=env)
    assert git('rev-parse', 'HEAD').decode().strip() == HEAD and git('rev-parse', 'HEAD^{tree}').decode().strip() == TREE
    assert git('rev-parse', 'HEAD^').decode().strip() == PARENT and git('branch', '--show-current').decode().strip() == 'maintainability/validated-v11'
    assert git('status', '--porcelain=v1', '--untracked-files=all').strip() == b''
    history = git('log', '--format=%an <%ae>|%cn <%ce>|%P', DEV + '..HEAD').decode().splitlines()
    assert len(history) == 30 and all(line.split('|')[:2] == [IDENTITY, IDENTITY] and len(line.split('|')[2].split()) == 1 for line in history)
    assert git('merge-base', '--is-ancestor', DEV, HEAD) == b''
    prior = PRIOR.read_bytes()
    assert sha(prior) == PRIOR_SHA
    shell_assets = {}
    for raw_path in filter(None, git('ls-files', '-z', '--', '*.sh').split(b'\0')):
        path = os.fsdecode(raw_path)
        raw = git('show', HEAD + ':' + path)
        assert b'\r' not in raw and (REPO / path).read_bytes() == raw
        shell_assets[path] = sha(raw)
    raw = (run / 'results.json').read_bytes()
    result = json.loads(raw)
    logs = {check['label']: (run / (check['label'] + '.log')).read_bytes() for check in result['checks']}
    binary_hashes = {}
    for artifact in [*result['artifacts'], result['application'], result['recovery_recording']]:
        with native(artifact['executable']).open('rb') as source:
            value = hashlib.sha256()
            for chunk in iter(lambda: source.read(1024 * 1024), b''):
                value.update(chunk)
        binary_hashes[artifact['executable']] = value.hexdigest()
    summary = validate_run(result, logs, run_path, binary_hashes, shell_assets)
    inputs = {name: (ROOT / name).read_bytes() for name in INPUT_NAMES}
    for name, expected in PINS.items():
        assert sha(inputs[name]) == expected
    validate_completion(inputs['watch-owned-8bca-worker-v5.log'], inputs['final-8bca-owned-completion.json'], run_path)
    validate_host(inputs)
    sources = [(run / 'results.json', 'results.json', raw)]
    sources += [(run / (label + '.log'), 'logs/' + label + '.log', logs[label]) for label in sorted(logs)]
    sources += [(ROOT / name, 'provenance/' + name, inputs[name]) for name in INPUT_NAMES]
    readme = f'''# Final v11 local validation

Candidate `{HEAD}`, tree `{TREE}`, completed all42 reviewed local gates in
`{run.name}` using runner `{RUNNER}`. The actual full-library result is5236
passed, zero failed,27 ignored and four filtered tests run separately. Both new
keymap tests and the dependent-ref stack test passed in exact early probes and
the full library suite. All six test executables, application and recovery
recording binary were bound to fresh hashes and their exact invocations.
All42 source snapshots remained unchanged and clean, including every tracked
LF shell asset. Python discovery ran61 tests; strict Linux and Windows GNU
cross Clippy each covered three packages. The30 single-parent units after
dev57d7395b use the required Jonas author and committer identity.

The owned launcher and observer handles completed successfully. The receipt and
read-only pidfd observer bind this exact run; no non-child Linux exit status is
inferred. Runtime uses direct host WSL with PID/proc/dev containment and E-drive
scripts/build targets, native Linux runtime scratch and no Docker. Windows cross
checks are not native Windows execution; supplementary-group ACL coverage remains
conditional, and live provider parity/real power-loss durability are not claimed.

Prior evidence remains unchanged at `../final-candidate-v10/`, manifest SHA256
`{PRIOR_SHA}`, binding application421. It is referenced rather than copied.
The new source review binds the keymap lock correction and stack diagnostic
ownership; their combined source required this new application run.

CI43148655434 attempt1 on c3d6fccf remains failed: the Windows repo-s shard
reached its20-minute timeout and the aggregate Windows job failed;13 other jobs
succeeded and the optional forge job was skipped. Raw metadata/logs are preserved.
Two contained host reproductions of that older downloaded Windows binary passed
the exact stack test in58.43s and38.97s (one explicit single-thread run and one
with the CI default-thread argv). They are execution of the old artifact, not
the new source, and did not reproduce the hang. The keymap fix is not claimed
to explain that earlier CI timeout. Owned Windows benign success/timeout probes,
runner source/proof/review, artifact digest and both repros are preserved.

All archive inputs and generated output bytes were preloaded before writing.
The archive uses fresh paths and exclusive creation; manifest entries include
raw/compressed hashes and lengths. This is evidence archival, not additional
application execution. Documentation changes must preserve application/gate
files before binding these results. Final CI is a separate delivery step.
'''
    manifest = dict(commit=HEAD, tree=TREE, parent=PARENT, history_units=30,
        run=run_path, runner_sha256=RUNNER, results_sha256=sha(raw), summary=summary,
        prior_archive=dict(path='../final-candidate-v10/manifest.json', sha256=PRIOR_SHA),
        binary_sha256=binary_hashes, artifacts=[])
    outputs = prepare_archive(sources, readme, manifest, DEST)
    publish_archive(outputs, DEST)
    print(json.dumps(dict(destination=str(DEST), artifacts=len(sources), commit=HEAD)))


if __name__ == '__main__':
    main()
