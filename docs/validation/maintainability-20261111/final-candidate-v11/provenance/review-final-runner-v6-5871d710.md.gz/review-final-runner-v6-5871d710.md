# Independent source review: final candidate runner v6

Verdict: PASS for frozen E-drive `run-final-candidate-v6.py`, SHA256 `5871d710ff9493a450b6e20f55e858a42079dfa31030419a0f6b52173ffad376`. This approves runner source before execution and does not establish any candidate pass.

Compared its complete source to reviewed v5 SHA256 d0f64d5404cf755e988bf634d203d7e9d97896490ad62b0c0f42f51db8a4508a. The complete diff is exactly one two-line loop inserted after the four early UI probes. Independently removed those two lines in memory and asserted all remaining lines equal v5. No command/source hash, clean-state, artifact inventory, runtime environment, process containment, cancellation, queue policy, test-skip or existing gate logic changes.

The loop adds three distinct early gates: keymap-context-source runs the actual-source AST/negative-control regression; keymap-context-viewports runs the ownership matrix; stack-update-refs runs the existing real dependent-ref rebase/undo fixture with its new diagnostics. Each uses the existing contained invocation, exact full test name, one test thread, fresh isolated runtime environment, the already built library binary and its before/after hash guard, exactly one required passing test and exact-name verification. All three tests also remain in the full library run. Existing 39 gates remain, so planned total is 42. The generic runner still binds the application commit/tree supplied at invocation and observes source cleanliness before/after every gate.

Digest implementation, six-binary/application compiler inventories, shell-asset checks, fresh binary/application hashing, PID/proc/dev namespace probe and all existing recording-before-owned-process safety measures remain identical to reviewed v5. The correction neither claims native Windows execution from WSL checks nor attributes the prior Windows CI timeout to keymap recursion. A complete new candidate run is still required.

Read source/diffs and verified hashes only. No runner, application, proof/test, CI or process action was executed. No repository or index/status mutation was performed. Only this standalone E-drive source review was written.
