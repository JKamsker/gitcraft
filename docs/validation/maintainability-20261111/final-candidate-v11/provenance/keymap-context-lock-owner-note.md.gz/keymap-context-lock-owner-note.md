# Keymap context lock correction: owner handoff

Published source unit **WIP, static checks passed; independent review and Rust compilation/runtime pending**:

- Commit `3af3288bc980468012967226a8ace9213cab18c7`.
- Tree `2bf334f914dd7123c3dcf368534dc33b00cb90e1`.
- Parent `c3d6fccf79429ec5d46419c0db3151516d549011`.
- Branch `maintainability/keymap-context-lock`, own worktree `E:/private/gitcraft-worktrees/keymap-context-lock`.
- Exact author and committer `Jonas Kamsker <11245306+JKamsker@users.noreply.github.com>` verified before push.
- Effective origin push URL verified as `https://github.com/JKamsker/gitcraft.git`; remote branch SHA equals the local commit. Receipt `keymap-context-lock-remote.txt`, SHA256 `4469727974dcad3443c905546a21278659980899ef0d7bdc121d36462089c3e6`.

The unit changes only `src/keymap/resolver.rs` (333 physical lines) and adds `src/keymap/resolver/context_tests.rs` (147 physical lines). `permitted` and `which_key` now calculate their viewport-derived key before entering `ctx.data`. The overlay reuses that exact key for its Area. Sibling resolver reads already calculate their keys before data access. Eligibility, scope sharing within a viewport, viewport isolation, dispatch and command contents are unchanged.

The original code indirectly reentered Context from `ctx.data` by calling `id(ctx, ...)`, which calls `ctx.viewport_id()`. Local egui0.36.2 source confirms both APIs read-lock the same Context. This is a recursive read acquisition, which can deadlock when a writer is queued; it is not asserted to deadlock unconditionally. The change removes that hazard without introducing a different locking mechanism.

The two new regressions are:

1. `keymap::resolver::context_tests::resolver_lock_closures_do_not_reenter_context_through_identifier_helpers`: a syn AST guard over the actual resolver source. It rejects Context capture in data/input/memory lock closures, includes both original indirect reentries as required negative controls, and accepts the precomputed-key pattern. This checks the original defect without deliberately deadlocking a GUI thread or starting process-control tests.
2. `keymap::resolver::context_tests::permission_and_chord_overlay_queries_preserve_scope_and_viewport_ownership`: actual GUI-only queries over all ten command scopes and three viewports. It checks shared scope IDs within each viewport, distinct viewport IDs, exact permission eligibility for every registered command, the allowed/active chord overlay candidate, safe Context access from the refusal callback and nonconsumption by the overlay. It performs no Git operation or global Settings/language mutation.

Completed local checks:

- `cargo fmt --all -- --check` passed, exit0. Empty log `keymap-context-fmt.log`, SHA256 `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`.
- Unchanged `ci/rust_file_size.py` passed using signed root-provided native Python at `E:/private/gitcraft-build/native-python31210/python.exe`, both working tree and complete staged index:2653 tracked Rust files,759 advisory warnings,0 cap errors. Logs `keymap-context-size-native-working.log` and `keymap-context-size-native-staged.log`, both SHA256 `8412475960cb7fc66cc2291f5125c24d888e89a36022d9c03f6ca679d87a0647`.
- Staged whitespace check passed; assigned worktree clean after commit/push.

No Rust application build or test was run by this implementer; root explicitly owns the final combined proof. Consequently neither added regression is represented as executed yet. The source unit was committed, pushed and remote-verified before handoff or any risky runtime test.

Earlier WSL attempts are not validation evidence: a Windows-worktree metadata lookup failed, and an explicit Linux GIT_DIR diagnostic reported `fatal: unterminated line in /mnt/e/private/gitcraft/.git/packed-refs: ...`. No shared metadata repair was attempted. An E-only native-Git/path adapter subsequently also completed both cap modes successfully, but the direct unchanged native-Python runs above are the cited evidence.

## CI hang attribution remains open

This hazard was discovered while scouting Windows run43148655434, but no direct confirmation-rendering call to `permitted` or `which_key` was found. The helper paints `confirm`, its preview, commands and standard buttons; its source does not itself call either keymap query. `Settings::get` and `Tokens::get` release their Context data read before constructing defaults. Therefore this unit must not be described as a proven repair for the isolated rebase hang. Parent additionally reports ProcessTrace was already enabled with no19-minute trace; that supports investigating GUI/other synchronous blocks, not a specific attribution. The separately owned contained-binary reproduction and lifecycle scout remain authoritative for locating that hang.

No final worktree modification, host-wide process search, signal, process-control feature, CI dispatch/poll, shared target build or application runtime occurred. E-only source-check helpers/logs and this implementer note are supplementary, not independent approval. Ownership of the preserved unit is handed to root for independent review, integration and combined validation.
