#!/bin/sh
set -eu
umask 077
cd /mnt/e/private/gitcraft-worktrees/final-maintainability
printf '%s\n' "$$" > /mnt/e/private/gitcraft-build/final-8bca-worker.pid
exec python3 /mnt/e/private/gitcraft-build/run-final-candidate-v6.py 8bca2a9a1e2e75bb94ca0f6be4044e92a93f119d > /mnt/e/private/gitcraft-build/final-8bca2a9a-progress.log 2>&1
