"""Archive final-run driver provenance after the reviewed 39-gate archive exists."""
import gzip
import hashlib
import json
from pathlib import Path

ROOT = Path('/mnt/e/private/gitcraft-build')
DEST = Path('/mnt/e/private/gitcraft-worktrees/final-maintainability/docs/validation/maintainability-20261111/final-candidate-v8')
PARTIAL = ROOT / 'validation-92656fb7-y7ydkc5v'
FRESH = ROOT / 'validation-92656fb7-85l0p9nv'
HEAD = '92656fb7d7c49a728824df9548cccf2c35325ad4'
TREE = '8f188f3aa5feab6597f1bdc0a9bf735c4604384c'

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

raw = (PARTIAL / 'results.json').read_bytes()
assert sha(raw) == 'b50dfde33be67a1a76ccf496a1cab11fe66077b1e8eb4d674fbfbe6984ee2130'
partial = json.loads(raw)
assert partial['commit'] == HEAD and partial['tree'] == TREE
assert len(partial['checks']) == 16
assert not any(partial.get(key) for key in ['status', 'fatal', 'finished'])
for entry in partial['checks']:
    assert type(entry['exit']) is int and entry['exit'] == 0
    assert all(entry[side]['head'] == HEAD and entry[side]['tree'] == TREE and entry[side]['status'] == '' for side in ['before', 'after'])
    assert sha(Path(entry['log']).read_bytes()) == entry['sha256']
final_raw = (FRESH / 'results.json').read_bytes()
final = json.loads(final_raw)
assert final['commit'] == HEAD and final['tree'] == TREE
assert final['status'] == 'passed' and final['finished'] and len(final['checks']) == 39
manifest_path = DEST / 'manifest.json'
manifest = json.loads(manifest_path.read_bytes())
assert manifest['commit'] == HEAD and manifest['tree'] == TREE
assert next(item for item in manifest['artifacts'] if item['path'] == 'results.json.gz')['sha256'] == sha(final_raw)
watch_events = [json.loads(line) for line in (ROOT / 'watch-owned-926-worker-v2.log').read_text().splitlines()]
assert watch_events[0]['event'] == 'owned-receipt-worker-bound'
assert watch_events[0]['results'] == str(FRESH / 'results.json')
assert watch_events[-1] == dict(event='pidfd-completed', child_exit_code_available=False, child_exit_code=None, final_manifest_passed=True)
names = [
    'launch-final-926-linux.sh', 'final-926-worker.pid',
    'final-92656fb7-wrapper-lost-progress.log', 'final-92656fb7-linux-progress.log',
    'describe-owned-926-identity.py', 'owned-926-identity.json',
    'watch-owned-926-worker.py', 'watch-owned-926-worker.log',
    'watch-owned-926-selftests.json', 'watch-owned-926-selftests.log',
    'watch-owned-926-owner-note.md', 'review-watch-owned-926-root.md',
    'watch-owned-926-worker-v2.py', 'watch-owned-926-worker-v2.log',
    'watch-owned-926-v2-selftests.json', 'watch-owned-926-v2-selftests.log',
    'watch-owned-926-v2-owner-note.md', 'review-watch-owned-926-v2-root.md',
    'validation-driver-recovery.md', 'supplement-final-926-driver-evidence.py',
]
sources = [(PARTIAL / 'results.json', 'driver-recovery/partial-run/results.json')]
sources += [(Path(item['log']), 'driver-recovery/partial-run/' + item['label'] + '.log') for item in partial['checks']]
sources += [(ROOT / name, 'driver-recovery/' + name) for name in names]
inputs = [(source, relative, source.read_bytes()) for source, relative in sources]
existing = {item['path'] for item in manifest['artifacts']}
assert len(inputs) == len({relative for _, relative, _ in inputs})
assert all(relative + '.gz' not in existing and not (DEST / (relative + '.gz')).exists() for _, relative, _ in inputs)
for source, relative, raw in inputs:
    compressed = gzip.compress(raw, mtime=0)
    target = DEST / (relative + '.gz')
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(compressed)
    manifest['artifacts'].append(dict(path=relative + '.gz', source=str(source), sha256=sha(raw), gzip_sha256=sha(compressed), bytes=len(raw)))
manifest_path.write_text(json.dumps(manifest, indent=2) + '\n')
readme = DEST / 'README.md'
readme.write_text(readme.read_text() + '''
The first run on this same application candidate, `validation-92656fb7-y7ydkc5v`,
was incomplete: its Windows wrapper ended with exit 1, and its final manifest
contains 16 completed checks with exit 0 but no overall status or finish time.
The Linux worker's exit status was not recovered. Two exact-argv read-only
observations found no matching worker before a fresh run was launched. The
partial manifest/logs and original progress output remain under `driver-recovery/`.
They are not evidence of a complete application pass. The final results above
come only from fresh run `validation-92656fb7-85l0p9nv`, using the unchanged
reviewed runner and application source. Its launcher redirects output inside
Linux and records the owned process receipt. A recording-tested, independently
authored observer validates that receipt and worker identity before read-only
pidfd polling; completion is recorded with a passing final 39-check manifest.
The observer cannot obtain the exit status of a non-child process and explicitly
records that limitation. Driver-recovery artifacts supplement the reviewed
archive helper without changing its source, application source, gates or tests.
''')
print(json.dumps(dict(destination=str(DEST), added_artifacts=len(inputs), total_artifacts=len(manifest['artifacts']))))
