"""Add source-review and recording-proof provenance to the final docs archive."""
import gzip
import hashlib
import json
from pathlib import Path
ROOT = Path('/mnt/e/private/gitcraft-build')
DEST = Path('/mnt/e/private/gitcraft-worktrees/final-maintainability/docs/validation/maintainability-20261111/final-candidate-v8')
manifest_path = DEST / 'manifest.json'
readme_path = DEST / 'README.md'
manifest = json.loads(manifest_path.read_bytes())
readme = readme_path.read_text()
assert manifest['commit'] == '92656fb7d7c49a728824df9548cccf2c35325ad4'
names = [
    'supplement-final-926-driver-evidence-before-readme-fix.py',
    'review-final-926-driver-supplement-adversarial.md',
    'review-final-926-driver-supplement-corrected-adversarial.md',
    'test_driver_supplement_input_order.py',
    'driver-supplement-input-order-results.json',
    'driver-supplement-input-order-tests.log',
    'append-reviewed-driver-notes.py',
]
inputs = [(ROOT / name, 'driver-recovery/review/' + name + '.gz', (ROOT / name).read_bytes()) for name in names]
existing = {entry['path'] for entry in manifest['artifacts']}
assert len(names) == len(set(names))
assert all(relative not in existing and not (DEST / relative).exists() for _, relative, _ in inputs)
proof = json.loads(next(raw for source, _, raw in inputs if source.name == 'driver-supplement-input-order-results.json'))
assert proof['tests'] == 7 and proof['failures'] == proof['errors'] == proof['skipped'] == 0
assert proof['helper_sha256'] == 'c572b1d78321edcdf4f2d59116288e8e8d3439f5e000a09505fdda6815010406'
assert proof['proof_sha256'] == 'd4fbdc8bfd85fc075eef64678952d16661d5c788c16ecd9b3fd66e7d05ce3f34'
assert hashlib.sha256(next(raw for source, _, raw in inputs if source.name == 'test_driver_supplement_input_order.py')).hexdigest() == proof['proof_sha256']
assert hashlib.sha256(next(raw for source, _, raw in inputs if source.name == 'driver-supplement-input-order-tests.log')).hexdigest() == proof['log_sha256']
for source, relative, raw in inputs:
    compressed = gzip.compress(raw, mtime=0)
    target = DEST / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(compressed)
    manifest['artifacts'].append(dict(path=relative, source=str(source), sha256=hashlib.sha256(raw).hexdigest(), gzip_sha256=hashlib.sha256(compressed).hexdigest(), bytes=len(raw)))
manifest_path.write_text(json.dumps(manifest, indent=2) + '\n')
readme_path.write_text(readme + '''
The driver supplement received a separate independent source review. Its initial
version read the README after archive writes and was blocked. The corrected
version preloads that input before any mutation. Both versions/reviews and seven
passing recording-only regression tests are retained in `driver-recovery/review/`.
The proof exercises the actual helper AST, missing inputs, collisions and the
original late-read version as a negative control. These are documentation-tooling
results, separate from application execution. All extra artifacts use the same
raw/compressed digest and raw-length manifest format as the primary archive.
''')
print(json.dumps(dict(added_artifacts=len(inputs), total_artifacts=len(manifest['artifacts']))))
