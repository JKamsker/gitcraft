# Owner record: receipt-only580 observer v3

Implemented `watch-owned-580-worker-v3.py`, SHA256 `f37918f86c73d591122e828e1da9000f02f19394d0044c46d43751af5e8d90ba`,284 physical lines including the seven existing recording tests. This is the implementer's handoff, not independent source approval. Root must review the script/diff/proof before any actual observation. No real observer was started by this author.

This is an exact constant/artifact-name rebind of v2 `watch-owned-926-worker-v2.py`, whose source hash was verified before and after copying as `ed8243da6ef61b6091cbe2b4169edd9715c7201503d26a139dd33f8b088a2ce7`. Static comparison confirmed the complete new source equals old source with only the approved substitutions: HEAD, tree, run-prefix, receipt filename and synthetic proof output prefixes. ARGV derives from the new HEAD, so it is rebound automatically. No process-control or observation behavior was added. The original v1/v2 scripts and their reviews, notes, proof logs/JSON and failed926 observation evidence were neither rewritten nor deleted.

New exact binding:

- HEAD `580542bfc9ff4d1586077beb57193768d0149fe4`; tree `091687f298049acfa30ef376e6a858b103ad97e2`.
- Runner `/mnt/e/private/gitcraft-build/run-final-candidate-v5.py`; unchanged SHA256 `d0f64d5404cf755e988bf634d203d7e9d97896490ad62b0c0f42f51db8a4508a`.
- Exact argv `python3 /mnt/e/private/gitcraft-build/run-final-candidate-v5.py 580542bfc9ff4d1586077beb57193768d0149fe4`.
- Expected cwd `/mnt/e/private/gitcraft-worktrees/final-maintainability`; all four Linux UID fields must equal the observer UID.
- Owned PID receipt `/mnt/e/private/gitcraft-build/final-580-worker.pid`; root's separately owned launcher writes this before exec.
- Caller-selected run directory must resolve to a direct child of `/mnt/e/private/gitcraft-build` with prefix `validation-580542bf-`.

Only the receipt PID is examined. There is no process discovery, signal, kill, subprocess/spawn, cleanup command, application execution, index/status inspection or CI action. The existing observation contract retains stable starttime/identity snapshots around pidfd binding, exact receipt bytes across binding/final success and runner-hash checks before/after binding/final success. Polling only reads completion readiness; it cannot obtain the nonchild's exit status. Completion explicitly reports `child_exit_code_available=false` and `child_exit_code=null`.

Manifest success still requires exact HEAD/tree/runner, statuspassed, nonempty finished string,39 unique checks, typed integer-zero exits and exact clean HEAD/tree before/after every check. An observer exit0 means that manifest verdict, not an inferred child exit code. Old926 evidence does not validate580.

Executed only:

    python3 /mnt/e/private/gitcraft-build/watch-owned-580-worker-v3.py --self-test

Result: seven tests, zero failures/errors/skips. They use synthetic receipt/snapshot/manifest dictionaries and recorded pidfd/poll boundaries; no actual receipt, `/proc`, pidfd or current-run results were read. The proof covers strict receipt parsing; exact argv/UID/cwd/starttime; receipt/snapshot mismatch and changes across binding; recorded descriptor close on mismatch; direct-child run-prefix validation; strict final manifest refusal; progress/completion; missing child exit status; source-recheck refusal; and poll errors. No application tests/builds ran.

Frozen artifacts:

- `watch-owned-580-worker-v3.py`: `f37918f86c73d591122e828e1da9000f02f19394d0044c46d43751af5e8d90ba`
- `watch-owned-580-v3-selftests.json`: `b7bb43ab14528db6a174603238d865220180e74241daa2929bc55bb5c09edf39`
- `watch-owned-580-v3-selftests.log`: `53fb78c9ea38d233f7c66a1e09bbc9a635b670c5c76c9fe09ecf23aab7b4b70e`
- `watch-owned-580-v3-rebind.diff`: `1354b0dae446812516e47178640d8a4d95f517f72e529d4fc5433516af005641`

After independent review, root owns the actual launch:

    python3 /mnt/e/private/gitcraft-build/watch-owned-580-worker-v3.py --watch RUN_DIRECTORY

Use the exact new worker run directory after its owned launcher has exec'd Python. Redirect stdout/stderr INSIDE Linux directly to an E-drive log so observation output persists independently of a Windows wrapper pipe. Retain root's launcher umask077; this observer rebind changes no umask or worker environment. The command above has not been executed by this author. All new files/proof writes are E-only. Ownership is handed back to root; v3 is frozen pending independent review and any later root-owned observation.
