#!/bin/sh
set -eu
umask 077
cd /mnt/e/private/gitcraft-worktrees/final-maintainability
printf '%s\n' "$$" > /mnt/e/private/gitcraft-build/final-580-worker.pid
exec python3 /mnt/e/private/gitcraft-build/run-final-candidate-v5.py 580542bfc9ff4d1586077beb57193768d0149fe4 > /mnt/e/private/gitcraft-build/final-580542bf-progress.log 2>&1
