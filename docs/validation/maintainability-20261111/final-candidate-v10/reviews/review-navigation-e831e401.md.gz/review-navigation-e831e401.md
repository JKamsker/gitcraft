# Independent corrected navigation fixture review

Reviewer: `/root/gate_scout`. Verdict: PASS for exact source `e831e401bff29ea90991469abe6185dcf31d5cfa`, parent `0622a2ac1237311e29f6dcc94788b30f5b094bb4`. No blocking source finding remains in this corrected unit. This is source-only approval; no application execution result is claimed.

Reviewed the complete unit against 0622 and its correction against c7, tracing both readiness branches through unchanged production `record`, `restore_commit_selection`, `NavHistory::replace_current` and `merge_around` behavior. My earlier c7/97 cached-forward approval remains explicitly withdrawn in `review-navigation-cached-forward-correction.md`; this is a fresh review of different source.

| Readiness | Recorded link history | After Back, Back, Forward and passive head refinement |
| --- | --- | --- |
| Cached head detail | Graph(head), Graph(base), Diff(head) | Graph(head), Diff(head), current Graph, Forward available |
| Pending head detail | Graph(head), Graph(base), Graph(head) | Graph(head), current Graph, no Forward |

The cached branch merges only equal Graph neighbours and preserves the distinct forward Diff. The pending branch merges both equal Graph neighbours. Subsequent detail delivery does not reopen the current Graph. The corrected shared assertion requires these exact entries, current view/history, absence of Back, correct `can_forward` and `peek`, then actual Forward-to-Diff and Back-to-Graph behavior when a forward entry exists. It finally asserts the diff is closed.

The recording test derives expected forward presence independently from its cached boolean and first requires the corresponding exact Diff or Graph. Thus it cannot hide a broken cached reveal by merely observing whatever view appeared. The real legacy link fixture classifies only the exact expected head/Unicode-file Diff, checking its key, or Graph; it then uses the same retained-forward assertions. Its synchronous action sequence does not poll unrelated detail messages between the captured branch and navigation trace.

The other three passive-fixture corrections and 40 manual, 24 user and 8 analogous source configurations remain present, totaling 72 across three new tests. Real `Select`/`SelectHash` auto-reveal, explicit same-file toggle, different-file opening and delayed-result suppression remain explicitly asserted. The selected-diff analogue still preserves exact selected commit and manual Diff places. Assertions were corrected to preserve reachable forward state rather than weakening production navigation or deleting the behavior check.

Only the same three test files change relative to 0622. The new module is 265 physical lines. Required Jonas author and committer identities and direct parent were verified from Git objects; published fix-v2 remote SHA matches this source. No production `NavHistory`, selection, auto-reveal, action or gate file changes.

Reviewed blobs: manual history `c72fc781aa77f79fb4b35909b2c8f47adffe6427`; test module wiring `0647eb9a4ce4088738809b4664982ddc6cc76134`; repository fixtures `c14765aaa70bdc1c6daccf59f7a61fff82b588e2`.

No candidate checkout/index/status refresh, source edit, app build/test, helper execution, signal or CI operation was performed. Only immutable Git-object/remote-ref reads from the reviewer's own worktree and this E-drive review write occurred. The integrated exact candidate must rebind these corrected blobs and complete the separately reviewed 39-gate runner before final validation/publication.
