# Fresh independent navigation-fixture source review

Result: PASS (source review only; no runtime or CI approval).

Reviewed source unit: e831e401bff29ea90991469abe6185dcf31d5cfa
Source tree: a396e43f27b2c5913af71c73225a1524e4eb0f39
Source parent: 0622a2ac1237311e29f6dcc94788b30f5b094bb4
Final candidate: c16814dbb820d0f0f3cf8d720a4bd1daa30f57a5
Final tree: 77a14d4fcf7aef3bab20f2b2939b8f880df80bd9
Final parent: b1963845825e2f5872a89adbeca45b562780fa42
Both reviewed commits use Jonas Kamsker <11245306+JKamsker@users.noreply.github.com>.

## Immutable scope binding

All inspection used explicit Git object IDs with GIT_OPTIONAL_LOCKS=0, from E:/private/gitcraft. The shared final worktree/index was neither inspected for status nor modified. No application compilation, application tests, process tests, CI dispatch, CI rerun, CI wait, or CI polling was performed.

The three source blobs are identical in the source unit and final candidate:

| Path | Git blob | Physical lines |
| --- | --- | ---: |
| src/repo/navigation/tests.rs | 0647eb9a4ce4088738809b4664982ddc6cc76134 | 332 |
| src/repo/navigation/tests_repository.rs | c14765aaa70bdc1c6daccf59f7a61fff82b588e2 | 413 |
| src/repo/navigation/manual_history.rs | c72fc781aa77f79fb4b35909b2c8f47adffe6427 | 265 |

Full explicit-commit name-status comparisons show that e831 changes exactly those three test sources relative to 0622. The final candidate adds those same blobs plus five documentation/evidence archive files under docs/validation/maintainability-20261111/ci-regressions/43109642223. There are no other application/gate changes relative to 0622; the explicit diff of src, ci, Cargo.toml, Cargo.lock, build.rs, and .github excluding the three test sources is empty. Existing application/gate source identity is preserved; this is not a claim that prior tests were rerun. Archive contents are outside this navigation-source review.

## Independent production-path trace

I read NavHistory::replace_current, merge_around, visit, go and peek directly from the immutable source, then traced navigation::record, restore_navigation, reselect and restore_commit_selection; apply and prepare_repo_action; select_history, reveal_selected_changes and finish_commit_changes; select/load_detail/fetch_detail/show_detail; detail_arrived and the detail cache; OpenDiff's same-key branch; file-view opening; and job-submission recording. I did not rely on earlier reviews or their conclusions.

1. Passive graph fixture setup is justified. restore_commit_selection stops commit-following state, preserves an existing explicit diff around ordinary select, and never requests first-file reveal. select_graph requires no diff before setup, records the resulting place, and asserts both the exact graph selection and stopped following state. Same-row select may return early; it still cannot initiate a reveal because the restoration path already stopped that intent.
2. Actual row and hash actions retain automatic reveal. Action::Select invokes select_history; Action::SelectHash enters goto with History intent and selects through select_history. With current/cached details, reveal_selected_changes completes synchronously and opens the first changed file. With pending details, the reveal waits. No production source changes are present in the patch.
3. Explicit same-key OpenDiff still toggles closed. prepare_repo_action stops following/pending intent before OpenDiff, and open_diff_of_lines removes a matching open diff. A different key opens instead. Later details cannot reopen a manually toggled or replaced diff because the pending reveal was stopped. The new user-action cases assert this distinct behavior for actual Select and SelectHash, both layouts, same/different first file, and current/cached/pending details.
4. Back/Forward restoration remains passive. restore_navigation stops following before restoring graph or diff places. A diff is opened only when its key differs from the one shown, and selection restoration does not replace that explicit destination. Late manual detail injection checks the current view and request identity rather than executing queued jobs.

## Corrected graph-refinement oracle

Let G(h) mean the graph selecting head, G(b) the graph selecting base, and D(h) the first-file head diff with head selected.

Cached head detail, empty cached base detail:

- Starting recorded G(h), SelectHash(base) appends G(b), and SelectHash(head) appends D(h): [G(h), G(b), D(h)].
- Back, Back, Forward returns to G(b) at index 1.
- Passive head selection records G(h) as a refinement. replace_current creates [G(h), G(h), D(h)]. merge_around removes the equal previous/current graph pair and adjusts the current index to 0.
- Correct result: [G(h), D(h)], current G(h), no Back, available Forward to D(h). The distinct diff must remain.

Pending head detail:

- The corresponding visits are [G(h), G(b), G(h)].
- Back, Back, Forward returns to G(b). Passive head refinement creates three equal adjacent graph places.
- merge_around removes the equal next entry, then the equal previous/current pair.
- Correct result: [G(h)], current G(h), no Back or Forward. A subsequently injected head detail has no reveal intent and leaves the graph shown.

The new shared assert_graph_refinement checks exact entries, current_view, nav.current, no Back, can_forward and peek(1), and when a distinct diff exists it actually exercises Forward to the diff and Back to the graph. This corrects the previously invalid unconditional one-graph expectation without discarding the distinct forward diff. The actual-repository following-links fixture still checks each prior Back/Forward selected-hash assertion and checks the observed optional forward diff against the exact expected commit/path before using the helper.

## Regression coverage and fixture containment

The three added test functions cover 72 configurations by source inspection:

- 40 manual graph/diff/file-history cases: saved layout x same/different initially selected row x same/different first changed file x five readiness/delivery points (ready, cached, after explicit open, after file view, after Back).
- 24 real user-action cases: saved layout x Select/SelectHash x same/different first changed file x current/cached/pending details. These preserve both automatic first-file reveal and explicit same-key toggle semantics.
- 8 graph-refinement/selected-diff analogue cases: two scenarios x saved layout x cached/pending head details. The base detail intentionally has no files so it does not add an unintended automatic diff place.

Manual late-detail injections assert stable diff destination and request ID, no graph reopening after Back, retained file-history Forward navigation, and stopped following state. The selected-diff analogue preserves selection refinement above an explicit saved-layout diff and asserts restoration of that exact diff with the refined base selection.

New synthetic tabs are deferred and marked shown before actions. All action/detail-delivery work occurs inside record_jobs. Its thread-local submission interception retains closures instead of executing them; no recorded closure is invoked by these tests. Construction/rebuild occurs before interception but uses deferred construction and synthetic history, not repository initialization. Existing real-repository fixtures retain their prior owned test behavior; I did not execute them.

All three changed Rust files remain below the mandatory 500-physical-line cap; the new cohesive module is below the 300-line target. This is an object-source line-count check, not execution of the repository's required size gate.

## Findings and limits

No actionable source finding in the three-blob navigation fixture correction or in its immutable final-candidate binding. The fixtures now express passive setup separately from actual user reveal/toggle actions, and the cached forward-diff assertion matches the production history algorithm.

No runtime result is claimed. Final-candidate local gates, platform execution, CI, and evidence archival require their separate owners and immutable evidence. This review does not approve the unrelated archive helper, nor attest to the contents of prior runtime evidence.