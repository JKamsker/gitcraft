# Independent adversarial source review: palette evidence helper v5

Verdict: **SOURCE PASS, conditional on successful completion of all 39 gates for the exact final candidate. No concrete blocking defect found.** The current final run was not polled, and this review makes no claim of final compile, runtime or CI success. The helper was not executed.

Reviewed `preserve-palette-candidate-evidence-v5.py`, SHA256 `f9e91f531c43fd7f4e6d57ca146d12dc47daf347e5be3ba268917c84d072c5b1`, against unchanged v4 `461e8f16d7a7926ac841e067769799d41316e054a13287ee31c06bfc55b501cc`. Read supplied proof source/result/log and root author-check/correction note SHA256 `a2217eb6a5e883a53076b483906e525d19f5c11b22e234fd22a8fcb3f99cdbee`. The proof source hash is `863095d98db41390a2042555648075ad65c1a214e4d461c694fc06ab7ed77913`. V4 helper, proof and reviews remain preserved, not rewritten or executed.

## Final binding and correction

Explicit immutable Git-object reads independently confirm final candidate `92656fb7d7c49a728824df9548cccf2c35325ad4`, complete tree `8f188f3aa5feab6597f1bdc0a9bf735c4604384c`, parent `f177144f0a16741ef5016cb3029ab6857e125ae3`, and whole-tree equality with accepted palette source `412d1118fb43af6ecc35a7755e5366949aeda511`. The 02a-to-926 source diff is confined to offline.rs and moves the unchanged documented palette_item function before cfg(test), with no lint suppression or behavioral edit. The new source-binding and explicit layout-correction notes were read.

V5 changes the final candidate/tree, branch, run-prefix, fresh destination (final-candidate-v8), palette-source and publication/review input names. It retains the prior checks for 25 exact authors, 19 changed Rust paths and preserved navigation fixture blobs. Candidate tree identity plus the accepted-source checks bind all source, test, documentation and gate blobs to corrected 412. Historical 5b/02a source approvals are retained alongside their explicit withdrawal/correction, not silently repurposed as approval of an uncorrected source. The README accurately records the compiler-only layout probe and that no application run started for the superseded layout candidate.

## Execution and write boundary

All original final gate requirements remain intact: a passed/finished manifest for 926, pinned runner, exactly 39 unique required labels, integer zero exits, unchanged clean before/after candidate/tree for every gate, raw log hashes, exact library summary 5232/0/27/0/4 and all six navigation plus four palette full test-name successes. Both all-package Clippy logs require three packages. No prior f177 pass or source-only helper review can satisfy these conditions for the new candidate.

The Git wrapper's case-insensitive removal of inherited GIT_ variables, explicit worktree selection, fresh destination check, deterministic gzip artifacts, raw/compressed hashes/lengths and complete source-byte preload before first destination mkdir/write are unchanged. The additional historical intermediate/correction artifacts are added before that preload. A required missing artifact fails before any destination write. No commit, push, branch switch, deletion, cleanup, process control or CI operation is performed by the helper.

The historical 97 stopped-result and c168 Clippy-failure guard/read code is unchanged in the v4-to-v5 diff. Both still run before the input preload and writes, bind the original source/runner/failure endpoint, reject runtime gate insertion and validate their raw/log/receipt hashes. Their failures remain failures in the README and archived evidence.

The new f177 intermediate results hash pin `42c30bc0deebeaea78a9e3ea0385331dca2a5f5cf7e069252b024d630eb779f0` was independently checked against the completed historical results file. That file records f177/tree383c0c92, pinned runner, status passed, finished 2026-11-12 01:08:33, 39 checks and library 5228 passed/0 failed/27 ignored/4 filtered. This supports the new bounded historical README sentence. Its raw results/logs remain separate from final candidate claims. I did not read or poll the active 926 run. The parent reports the earlier owned runner exited normally before the final worktree transition; that process-exit observation was not independently repeated here.

The README retains accurate boundaries for historical CI, source-only superseded units, isolated compiler probes, Windows GNU cross lint versus native execution, unproven live SSH/forge parity and power-loss durability. Documentation-only follow-up binding still requires unchanged application/gate files and does not claim a new application run.

## Recording evidence and review limits

The supplied rebound proof records 10 tests / 56 scenarios with zero failures/errors/skips and the same extracted historical guard AST digest `763f96d65b47f4e1fc0c99c5704b48ca0ee2288cae65d3e31a4cf7d4d71afaef`. Those are existing author-run results, not new execution by this reviewer. The proof covers synthetic historical-input rejection, removed-hash negative controls and source ordering before writes; it does not execute the archive module, actual Git, application or CI and does not establish final runtime success.

This review used local file reads and explicit immutable Git reads with GIT_OPTIONAL_LOCKS=0. No helper, proof, test, build, CI, mutable candidate status/index refresh, active-run poll or process-control action was executed. Only this standalone E-drive report and its SHA256 sidecar were written. Preserve the frozen helper and exact source binding; actual archive execution remains dependent on the exact 926 run passing all gates.
