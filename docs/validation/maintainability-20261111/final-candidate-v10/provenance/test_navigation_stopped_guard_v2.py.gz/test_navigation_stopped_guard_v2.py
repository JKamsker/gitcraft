"""Run only the actual stopped-evidence AST against in-memory recording paths."""
import ast
import copy
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import unittest

ROOT = Path('/mnt/e/private/gitcraft-build')
HELPER = ROOT / 'preserve-navigation-candidate-evidence-v2.py'
EXPECTED = '9b8684e9766f35e03a3b586aa6ba1131f36a3340e6dd996b178421f4736894d5'
raw = HELPER.read_bytes()
if hashlib.sha256(raw).hexdigest() != EXPECTED:
    raise SystemExit('Helper source differs from the pinned correction')
module = ast.parse(raw, filename=str(HELPER))
guard_index = next(i for i, node in enumerate(module.body)
                   if isinstance(node, ast.FunctionDef) and node.name == 'validate_stopped_results')
block = module.body[guard_index:guard_index + 6]
assert isinstance(block[-1], ast.Expr) and isinstance(block[-1].value, ast.Call)
assert isinstance(block[-1].value.func, ast.Name)
assert block[-1].value.func.id == 'validate_stopped_results'
assert [type(node).__name__ for node in block] == ['FunctionDef'] + ['Assign'] * 4 + ['Expr']
sha_node = next(node for node in module.body if isinstance(node, ast.FunctionDef) and node.name == 'sha')
selected = ast.Module(body=[sha_node, *block], type_ignores=[])
SOURCE = ast.unparse(selected) + '\n'
OLD_HEAD = '97a6aba4073ea465cb4241123c2d1379766ca234'
OLD_TREE = '0cea01cc09874f7043cf72990ce3fa5a935cad04'
OLD_RUNNER = 'fba211409fd0f961eb803af8d332eca08be039ea241fba7cd4ffec9be5e623b3'
CANDIDATE = 'c16814dbb820d0f0f3cf8d720a4bd1daa30f57a5'
TREE = '77a14d4fcf7aef3bab20f2b2939b8f880df80bd9'
INITIAL = '5e42014aa133bcf5130f644e33eb763eebd79b04198231814ec8cb833257c0be'
RESULT_PATH = '/recording/validation-97a6aba4-uaq5w87z/results.json'
RECEIPT_PATH = '/recording/stopped-97a6aba4-source-review.json'
LATE_PATH = '/recording/late-97a6aba4-source-review.json'
SCENARIOS = []


def encoded(value):
    return (json.dumps(value, indent=2) + '\n').encode()


def fixture():
    # Entirely synthetic data; no current/historical results or repository are opened.
    labels = ['rust_file_size-working', 'rust_file_size-index', 'rust_file_size-revision',
              'complexity_policy-working', 'complexity_policy-index', 'complexity_policy-revision',
              'tooling-regressions', 'fmt', 'check', 'clippy-packages',
              'windows-cross-clippy-packages', 'build-tests']
    before = dict(head=OLD_HEAD, tree=OLD_TREE, status='')
    checks = [dict(label=label, exit=0, before=copy.deepcopy(before), after=copy.deepcopy(before))
              for label in labels]
    checks[-1]['after'].update(head=CANDIDATE, tree=TREE)
    result = dict(commit=OLD_HEAD, tree=OLD_TREE, runner_sha256=OLD_RUNNER, checks=checks,
                  fatal='Candidate dirty or changed during build-tests')
    receipt = dict(commit=OLD_HEAD, tree=OLD_TREE, runner_sha256=OLD_RUNNER, results_sha256=INITIAL)
    late = dict(commit=OLD_HEAD, tree=OLD_TREE, fatal=result['fatal'],
                initial_observation_results_sha256=INITIAL, application_runtime_executed=False,
                after_head=CANDIDATE, before_head=OLD_HEAD, last_gate='build-tests', build_command_exit=0)
    return result, receipt, late


def blobs(result, receipt, late):
    late = copy.deepcopy(late)
    late.setdefault('results_sha256', hashlib.sha256(encoded(result)).hexdigest())
    late.setdefault('initial_observation_receipt_sha256', hashlib.sha256(encoded(receipt)).hexdigest())
    return {RESULT_PATH: encoded(result), RECEIPT_PATH: encoded(receipt), LATE_PATH: encoded(late)}


def execute(data, syntax=None):
    reads = []

    class RecordingPath:
        def __init__(self, path):
            self.path = str(PurePosixPath(path))

        def __truediv__(self, part):
            return RecordingPath(str(PurePosixPath(self.path) / part))

        def read_bytes(self):
            reads.append(self.path)
            return data[self.path]

    namespace = dict(ROOT=RecordingPath('/recording'), CANDIDATE=CANDIDATE, TREE=TREE,
                     json=json, hashlib=hashlib)
    exec(compile(ast.fix_missing_locations(copy.deepcopy(syntax or selected)), str(HELPER), 'exec'), namespace)
    return reads, namespace


class StoppedGuardTests(unittest.TestCase):
    def test_matching_late_manifest_uses_only_recorded_reads(self):
        SCENARIOS.append('matching-late-static-refusal')
        reads, namespace = execute(blobs(*fixture()))
        self.assertEqual(reads, [RESULT_PATH, RECEIPT_PATH, LATE_PATH])
        self.assertNotIn('git', namespace)
        self.assertNotIn('subprocess', namespace)
        self.assertNotIn('DEST', namespace)

    def test_rejects_mismatched_or_runtime_evidence(self):
        cases = {
            'stale-results-hash': lambda r, o, l: l.update(results_sha256=INITIAL),
            'wrong-source-commit': lambda r, o, l: r.update(commit='0' * 40),
            'wrong-source-tree': lambda r, o, l: r.update(tree='0' * 40),
            'wrong-source-runner': lambda r, o, l: r.update(runner_sha256='0' * 64),
            'wrong-fatal': lambda r, o, l: r.update(fatal='unrelated failure'),
            'wrong-after-head': lambda r, o, l: r['checks'][-1]['after'].update(head='0' * 40),
            'wrong-after-tree': lambda r, o, l: r['checks'][-1]['after'].update(tree='0' * 40),
            'unexpected-runtime': lambda r, o, l: r['checks'].append(dict(label='runtime-gitcraft-lib')),
            'unexpected-ui-probe': lambda r, o, l: r['checks'].append(dict(label='frame-font-readiness')),
            'unexpected-nav-probe': lambda r, o, l: r['checks'].append(dict(label='nav-history-walk')),
            'passed-status': lambda r, o, l: r.update(status='passed'),
            'boolean-build-exit': lambda r, o, l: r['checks'][-1].update(exit=False),
            'wrong-before-head': lambda r, o, l: r['checks'][-1]['before'].update(head='0' * 40),
            'wrong-before-tree': lambda r, o, l: r['checks'][-1]['before'].update(tree='0' * 40),
            'dirty-after-state': lambda r, o, l: r['checks'][-1]['after'].update(status=' M file'),
            'wrong-receipt-hash': lambda r, o, l: l.update(initial_observation_receipt_sha256='0' * 64),
            'wrong-initial-observation': lambda r, o, l: o.update(results_sha256='0' * 64),
            'wrong-late-after-head': lambda r, o, l: l.update(after_head='0' * 40),
            'late-runtime-claim': lambda r, o, l: l.update(application_runtime_executed=True),
            'late-boolean-build-exit': lambda r, o, l: l.update(build_command_exit=False),
            'missing-build-endpoint': lambda r, o, l: r['checks'].pop(),
        }
        for name, mutate in cases.items():
            with self.subTest(name=name):
                SCENARIOS.append(name)
                values = fixture()
                mutate(*values)
                with self.assertRaises(AssertionError):
                    execute(blobs(*values))

    def test_removed_hash_guard_negative_control_accepts_stale_receipt(self):
        SCENARIOS.append('removed-hash-guard-negative-control')
        broken = copy.deepcopy(selected)
        guard = next(node for node in broken.body if isinstance(node, ast.FunctionDef)
                     and node.name == 'validate_stopped_results')
        matches = [node for node in guard.body if isinstance(node, ast.Assert)
                   and ast.unparse(node.test) == "late['results_sha256'] == sha(stopped_raw)"]
        self.assertEqual(len(matches), 1)
        guard.body.remove(matches[0])
        values = fixture()
        values[2]['results_sha256'] = INITIAL
        # The intact AST rejects exactly this stale binding; deleting its actual
        # hash assertion must make the same otherwise valid recording pass.
        with self.assertRaises(AssertionError):
            execute(blobs(*values))
        reads, _ = execute(blobs(*values), broken)
        self.assertEqual(reads, [RESULT_PATH, RECEIPT_PATH, LATE_PATH])

    def test_missing_input_fails_without_a_write_boundary(self):
        SCENARIOS.append('missing-late-note')
        data = blobs(*fixture())
        del data[LATE_PATH]
        with self.assertRaises(KeyError):
            execute(data)

    def test_extraction_precedes_all_input_preloads_and_destination_writes(self):
        SCENARIOS.append('actual-block-before-all-inputs-and-writes')
        preload = next(node for node in module.body if isinstance(node, ast.Assign)
                       and any(isinstance(target, ast.Name) and target.id == 'inputs' for target in node.targets))
        writes = [node for node in ast.walk(module) if isinstance(node, ast.Call)
                  and isinstance(node.func, ast.Attribute)
                  and node.func.attr in ('write_bytes', 'write_text', 'mkdir')]
        self.assertLess(block[-1].lineno, preload.lineno)
        self.assertTrue(writes)
        self.assertTrue(all(preload.lineno < node.lineno for node in writes))
        self.assertEqual(hashlib.sha256(HELPER.read_bytes()).hexdigest(), EXPECTED)


if __name__ == '__main__':
    stream = io.StringIO()
    outcome = unittest.TextTestRunner(stream=stream, verbosity=2).run(
        unittest.defaultTestLoader.loadTestsFromTestCase(StoppedGuardTests))
    log = stream.getvalue()
    print(log, end='')
    log_path = ROOT / 'navigation-stopped-guard-v2-regressions.log'
    log_path.write_text(log)
    result = dict(helper=str(HELPER), helper_sha256=EXPECTED,
                  extracted_ast_sha256=hashlib.sha256(SOURCE.encode()).hexdigest(),
                  regression_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                  tests=outcome.testsRun, scenarios=len(SCENARIOS), scenario_names=SCENARIOS,
                  failures=len(outcome.failures), errors=len(outcome.errors), skipped=len(outcome.skipped),
                  log_sha256=hashlib.sha256(log.encode()).hexdigest(),
                  boundary='Actual sha/stopped-guard AST only; synthetic JSON and RecordingPath reads. No Git, CI, application, subprocess, signals, destination or helper module execution.')
    (ROOT / 'navigation-stopped-guard-v2-results.json').write_text(json.dumps(result, indent=2) + '\n')
    raise SystemExit(0 if outcome.wasSuccessful() else 1)
