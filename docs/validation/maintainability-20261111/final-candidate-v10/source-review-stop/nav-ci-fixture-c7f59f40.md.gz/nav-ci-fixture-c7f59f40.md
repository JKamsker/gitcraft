# Navigation CI fixture timing: c7f59f40

Source: c7f59f4009961a91c38300cd4212a4edac9a3626 on maintainability/nav-ci-fix, parent 0622a2ac1237311e29f6dcc94788b30f5b094bb4. Published branch remote SHA equals source. Author and committer: Jonas Kamsker <11245306+JKamsker@users.noreply.github.com>.

CI evidence: E:/private/gitcraft-build/ci-43109642223-linux.log records back_and_forward_through_a_repository failing tests_repository.rs:80, actual diff None, expected Unicode-path Commit diff. CI library summary: 5226 passed, 1 failed, 27 ignored, 2 filtered.

Diagnosis: opened() waits for history, not a particular Detail readiness. A ready or cached head Detail lets the redundant user Select(head) synchronously open its automatic first-file diff. The next explicit same-key OpenDiff intentionally toggles that diff closed. FileView is then reached from Graph, so Back correctly restores Graph. When Detail is still pending, the explicit open instead cancels automatic reveal and opens Diff. Production Back restoration and same-file toggle semantics are retained.

Changes are confined to three test files. select_graph establishes passive graph selection for the manual walk and two analogous graph-only setups: final graph refinement in following_links_to_commits_are_steps, and the post-CloseDiff head selection in back_to_a_diff_selects_its_commit_again. Every original navigation assertion remains. Intentional user Select/SelectHash elsewhere stays unchanged.

The new 267-line manual_history module exercises 72 deterministic recording-only cases: 40 manual Graph/Diff/File/back/forward cases across five Detail timings, saved split, same/different selected row, and same/different first file; 24 actual user row/hash selection and explicit-toggle cases across ready/cache/delayed Detail and both layout/file choices; eight analogous graph-refinement/selected-diff cases across cached/pending Detail and layout. Actual completion handlers and navigation dispatch are exercised; recorded submission prevents Git workers. Late Detail must preserve explicit requests, leave file/history ownership intact, and not reopen restored Graph. The actual-user matrix demonstrates why the old ready same-file sequence closes the diff.

Independent inventory by lifecycle_scout and gate_scout confirmed the failure mechanism. Gate's wider inventory found no additional confirmed manual same-key family case outside these navigation setups: keyboard UI already closes automatic reveal; remerge opens a different DiffKey; popout uses an unloaded target; palette asserts selected commit rather than a Graph-only place.

Static checks passed before commit: changed-file rustfmt, git diff --cached --check, working and complete-index Rust size (2641 files, zero errors). Size logs: nav-ci-size-working.log and nav-ci-size-staged.log, both SHA256 042878fd80128f4eba86d06d66b7877b0a6fcd732a28034dcebbd1808337cf75.

No application build, runtime tests, CI action, or candidate-worktree mutation was performed for this unit. Runtime validation and exact-source independent approval remain separate evidence. This note is the author's diagnosis and preservation record, not independent approval.