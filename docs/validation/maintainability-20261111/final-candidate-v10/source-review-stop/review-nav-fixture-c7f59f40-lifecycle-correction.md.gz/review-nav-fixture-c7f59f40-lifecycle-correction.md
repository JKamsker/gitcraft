# Correction to c7f59f40 source review

The earlier PASS in `review-nav-fixture-c7f59f40-lifecycle.md` (SHA256 `41456823437f77fb933fc7a325d650e9f80fd737d8c03d3679fc0e79f5fbfc6f`) is retracted for the cached graph-refinement assertion. Preserve that original artifact as historical review evidence, not current approval.

Exact source: `c7f59f4009961a91c38300cd4212a4edac9a3626`. Source tracing confirms that the ready/cached second link creates `[Graph(head), Graph(base), Diff(head)]`. Back, back, forward selects Graph(base). Passive refinement to head calls NavHistory::replace_current: it merges the adjacent equal graph entries while preserving the distinct forward Diff(head). The result is `[Graph(head), Diff(head)]`. The new graph_refinement_case and original real following_links fixture incorrectly require a single graph entry.

The fixture correction must preserve this forward diff. Deterministic cached cases should assert the explicit two-entry history, no back entry, forward availability and actual forward restoration of the expected diff. Pending cases should retain the single-entry graph-collapse assertion. The real repository test can classify its second link's actual graph/diff place and assert the corresponding retained forward entry; the deterministic readiness matrix must independently enforce the ready first-file reveal contract.

The earlier diagnosis of the CI same-key toggle and the passive setup fix remains valid. This correction identifies a distinct remaining expected-history error, not a reason to change production navigation or drop forward history. Root and the fix owner were notified. No edits to repository files, builds, tests or CI were performed for this re-review.
