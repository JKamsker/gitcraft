# Independent source-safety review: navigation evidence helper v2

Verdict: PASS for helper source SHA256 3f30af2001b48b2264f1dfad550678d05ceada45af987780a10e1589595860c6, conditional on the exact candidate completing all 39 gates and all provenance guards succeeding. No helper execution or current-run success is claimed. One stale historical input binding was found and reported to root; the helper correctly refuses it before writing.

Reviewed file: E:/private/gitcraft-build/preserve-navigation-candidate-evidence-v2.py.

## Safety and immutable bindings

I read the complete helper and the exact runner source. The helper binds final candidate c16814dbb820d0f0f3cf8d720a4bd1daa30f57a5, tree 77a14d4fcf7aef3bab20f2b2939b8f880df80bd9, parent b1963845825e2f5872a89adbeca45b562780fa42, branch maintainability/validated-v5, canonical final-worktree path, clean state and a fresh docs/validation/maintainability-20261111/final-candidate-v5 destination. It requires exactly the three navigation-test paths relative to the parent and binds each blob to reviewed source e831e401bff29ea90991469abe6185dcf31d5cfa. My preceding fresh source review independently verified these three final-candidate blobs and all other application/gate source identity with 0622a2ac1237311e29f6dcc94788b30f5b094bb4.

The helper requires 24 author entries since dev 57d7395bce9e187ff9f2a3ce9b96dc0d65715600, all using Jonas Kamsker <11245306+JKamsker@users.noreply.github.com>. Explicit immutable git-log inspection independently confirmed all 24 single-parent units and this identity.

The only subprocess operation in this helper is Git through a direct argument vector. There are no signals, PID selectors, application/test launches or CI calls. The Git wrapper removes every inherited environment key whose uppercase name starts GIT_. Its function text is exactly identical to helper 162b09ea9dfdb7fb922f9495ee16fca7b6a0dcc3b499d5c7e903081205dba73b, so its AST is unchanged. The earlier committed final-candidate/helper-regression directory remains present, including results.json.gz, review-regression.log.gz and test_git_environment.py.gz. This review reuses that source identity; it does not claim a new sanitation-proof execution.

RUN is resolved under the E-drive build root and must have the exact candidate-name prefix. The destination is fixed and required absent. Output relative paths derive from static names and the exact accepted prior/new labels. Every source is read into memory before the first mkdir/write of the destination, so missing evidence fails before archive publication begins. Writes create gzip artifacts, a JSON manifest and README only under the fresh documentation destination; existing source and earlier evidence archives are not rewritten. Gzip uses mtime=0, with raw/compressed hashes and original byte counts recorded.

## Completed-run prerequisites and text claims

The helper requires results commit/tree identities, status passed, a finished marker, and recorded/actual runner SHA256 d0f64d5404cf755e988bf634d203d7e9d97896490ad62b0c0f42f51db8a4508a. I verified the local runner bytes match that hash, but did not read the active run as a completed result.

Original results SHA256 098ebc67b6efd04411f6403ea9fd34f24b8bd677d16aa1fdb00f92eb56c545c3 was independently verified and its 33 unique labels inspected. The helper accepts exactly those 33 plus these six labels, with 39 total and 39 unique:

- nav-recording-manual-history
- nav-recording-user-selection
- nav-recording-forward-history
- nav-history-walk
- nav-history-selection
- nav-history-links

Each navigation probe requires one passing summary with zero failed/ignored tests. Every gate requires a typed integer zero exit, unchanged before/after candidate HEAD/tree/clean status and a matching raw log hash. Tooling must report exactly 61 Python tests; both Clippy logs must report 3 checked packages. The complete library summary must exactly equal 5228 passed, 0 failed, 27 ignored, 0 measured, 4 filtered. All three corrected legacy tests and all three new recording-test names must individually appear as passing in that library log. The reviewed pinned runner additionally enforces each early navigation probe's exact name, frozen application/binary hashes before/after runtime, shell-asset integrity, expected artifacts, containment probe and prior gates. The helper does not replace those runner checks.

The generated README's 72 source configurations (40 manual-history, 24 actual selection/toggle, 8 refinement/selected-diff analogues) agree with independent source tracing. Its library count, four separately executed filtered tests, ignored tests, six early navigation probes plus those same tests in the library, 61 tooling tests, 3 packages, four UI probes and zero-test doctest statements match the pinned runner's gates and the helper's completed-run requirements. Windows GNU cross-target checks are explicitly distinguished from native Windows runtime; live SSH/forge and actual power-loss durability remain separate claims. The runtime statements are generated only after all completed-pass prerequisites succeed. This source review does not assert those prerequisites have succeeded yet.

The exact runner's rebound recorded digest proof is included: test source SHA256 37695afa3685a5ab036df7ac63fc14b7bfaa756894c42389809fbd0278cb9028, results SHA256 c97d30769a701a094a93d87d9a0fd72ada29043c9bacd34977d7809455671943, log SHA256 839c98d2f234932cfc49cd9202608882cd0e60b25198da1be11c6f2f59e947e5. Existing JSON/log record 11 tests and 26 scenarios with 0 failures/errors/skips. I read these records and verified their hashes without executing their tests.

## Historical CI and superseded evidence

The lint metadata and log hashes independently match bc937cbd6c3663c857d85515ba4d4d449176b128b4b957b52c2b1437502d35c7 and 1fcb3c7d276592e142283f6c7ed78efdef78b290ae07eca42316ee2f4a796648. Stored metadata identifies completed successful lint job 130822169327 in run 43109642223 at exact head 0622a2ac1237311e29f6dcc94788b30f5b094bb4, with successful Formatting and Clippy steps. The log contains cargo fmt --check and three successful checked Clippy packages. The helper rechecks job/run/head/conclusions and archives both. README clearly assigns those earlier lint claims to this separate historical completed job, while retaining the Linux test-job failure and making no new-candidate CI claim.

The archive preserves the original c7/97 source reviews, correction notes, old helper 162b09ea, stopped partial results/logs, corrected e831 reviews, fresh independent review, pinned runner and its new proof. The README explicitly states that the 97 run stopped after the incorrect cached-forward source expectation was found, performed no application runtime, and has no full-pass claim. It explains why the corrected cached/ready case retains a forward diff while pending details coalesce the graph. The original helper review remains historical and is accompanied by its explicit withdrawal/corrections; this review does not revive its authorization.

## Historical input mismatch discovered during review

At inspection, E:/private/gitcraft-build/stopped-97a6aba4-source-review.json pins results_sha256 5e42014aa133bcf5130f644e33eb763eebd79b04198231814ec8cb833257c0be. The preserved validation-97a6aba4-uaq5w87z/results.json currently hashes b8fa957bb4400ce69a04e968a05dd2a5053f6bd383bc1a47f3e78c02d51faef7. The latter records additional static completion after the stop note, followed by fatal Candidate dirty or changed during build-tests, with build-tests after-state at c16814db. It contains no application-runtime entries or passed status. Helper line 116 correctly rejects this stale metadata binding before any destination write.

Root was notified. Preserve the original stop snapshot/statement and append or otherwise preserve an explicit correction binding the final historical result bytes and explaining late static completion/changed-candidate refusal; do not relabel the stopped run as passing. All 39 current gates and this corrected provenance binding must succeed before executing the helper. If evidence inputs are corrected without changing helper source, this source-safety verdict remains applicable to exact SHA 3f30af20; any helper-code change requires an updated review.

## Review boundary

I did not execute this helper, the runner, the digest proof or application builds/tests; did not read or poll the active 39-gate run; did not call/poll CI; did not modify candidate files, refresh candidate status/index or send signals. Only standalone source/evidence files, explicit Git objects and this E-drive report were read/written. Normal non-optimized Python execution is assumed, as the helper uses assert guards. No completed candidate runtime or documentation-follow-up application execution is claimed. A later documentation-only commit still needs exact application/gate equality verification before binding prior execution.