# Independent source review: navigation fixture readiness

Reviewer: `/root/gate_scout`. Verdict: PASS, no blocking source finding in `c7f59f4009961a91c38300cd4212a4edac9a3626`, parent `0622a2ac1237311e29f6dcc94788b30f5b094bb4`.

Reviewed the complete three-file diff and relevant unchanged selection, restoration, history-recording and action-precondition code. Only test files change. The patch corrects three legacy setups that intended a passive Graph place but invoked user selection: initial repository walk, final graph refinement after commit links, and final head selection after CloseDiff in the selected-diff test. I confirmed that third analogue after my initial family inventory missed it: ready head details can reopen a Diff place there too. `select_graph` explicitly calls the existing passive restoration method, checks there is no open diff, records the resulting place and asserts automatic history-follow is stopped. Every original behavior assertion remains. Actual user selections retained elsewhere still exercise their user semantics.

The new recording-only module independently covers the distinction instead of suppressing production behavior:

- Manual Graph→Diff→File→Back/Forward: 5 detail arrival timings × 2 saved layouts × 2 initial selected rows × 2 first-file identities = 40 configurations. It checks exact places, request preservation across late details, no late reopening, history boundaries and stopped automatic-follow ownership.
- Real row/hash user selection followed by explicit manual opening: 3 readiness modes × 2 action forms × 2 layouts × 2 first-file identities = 24 configurations. It requires automatic reveal when ready, same-file toggle closure, different-file opening, delayed-detail suppression after explicit intent and stopped follow ownership.
- Graph refinement and selected-diff restoration: 2 scenarios × 2 layouts × 2 cache states = 8 configurations. Cached user-link results are explicitly expected to be Diff places; uncached results remain Graph until details arrive. Passive refinement and selected-diff Back assertions remain exact.

Total: 72 configurations across three tests, not 112. The new module is 267 physical lines. All jobs are captured inside `messages::record_jobs`, and tabs use `new_deferred` with synthetic state; the source does not request real Git/process work from these new tests. These are source properties, not a test execution claim.

Immutable bindings:

- `src/repo/navigation/manual_history.rs`: `17ef5d7ded460d3c954a39e71635ac30da73c862`.
- `src/repo/navigation/tests.rs`: `0647eb9a4ce4088738809b4664982ddc6cc76134`.
- `src/repo/navigation/tests_repository.rs`: `760bdc761465215c7e39676300c599328ffbabbb`.

Verified the direct parent and required Jonas author/committer identities from Git objects in the reviewer's own worktree with optional locks disabled. I did not modify repository/candidate files or index/status, run builds/tests/CI, poll ongoing CI, or execute signals/process scenarios. Only this standalone E-drive review was written. The eventual integrated exact candidate needs mechanical rebinding and combined application/lint validation; this review does not infer those results.
