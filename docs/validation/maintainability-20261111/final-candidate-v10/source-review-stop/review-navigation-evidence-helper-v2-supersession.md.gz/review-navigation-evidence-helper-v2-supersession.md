# Supersession and owner correction: navigation archive historical inputs

This is the implementer's correction record, not independent source-safety approval. The actual archive helper has not been executed. Root must independently review the corrected helper before execution, and all 39 current candidate gates must complete successfully first.

Corrected helper: preserve-navigation-candidate-evidence-v2.py
SHA256: 9b8684e9766f35e03a3b586aa6ba1131f36a3340e6dd996b178421f4736894d5

The original helper and original review were copied before editing and verified byte-for-byte:

- preserve-navigation-candidate-evidence-v2-initial.py: 3f30af2001b48b2264f1dfad550678d05ceada45af987780a10e1589595860c6
- review-navigation-evidence-helper-v2-initial.md: fb2891d4f314b02c8204ae9611816a813feb5838c1d75f511585145aa567d1ba

The original review's conditional PASS applies only to original helper 3f30af20. It identified the stale historical input binding. That review is preserved as historical evidence; its verdict does not cover corrected helper 9b8684e9. This note supersedes its proposed historical-input handling without changing or deleting that original review. The root-owned current review path remains available for a fresh independent review; until replaced by one, its original source hash still limits its scope.

## Historical facts preserved

The original stopped-97a6aba4-source-review.json receipt is unchanged, SHA256 3d107fd6256ff2ebb5be9a7dd954cdc349000142724ccb771ebd60f35515841d. It records an initial observation at results hash 5e42014aa133bcf5130f644e33eb763eebd79b04198231814ec8cb833257c0be. That intermediate raw results snapshot was not separately retained, so neither the helper nor this note claims to archive its raw bytes.

Root's late-97a6aba4-source-review.json correction binds the final raw results b8fa957bb4400ce69a04e968a05dd2a5053f6bd383bc1a47f3e78c02d51faef7 and the original receipt's exact hash. The owned Windows session's exit after Ctrl-C did not establish that the Linux helper terminated. The Linux worker later completed cross-Clippy and its test-build command. The final manifest refused its changed source during build-tests: command exit 0, before HEAD 97a6aba4073ea465cb4241123c2d1379766ca234/tree 0cea01cc09874f7043cf72990ce3fa5a935cad04, after HEAD c16814dbb820d0f0f3cf8d720a4bd1daa30f57a5/tree 77a14d4fcf7aef3bab20f2b2939b8f880df80bd9, fatal Candidate dirty or changed during build-tests. It never reached frame, navigation or application-runtime checks and has no passed status. The changed-source build completion is not represented as a valid gate pass.

## Narrow correction

Only historical-evidence validation, associated archival inputs, and historical README explanation changed. The exact entire helper prefix before the historical block remains byte-for-byte identical to initial helper 3f30af20, preserving all current 39-gate candidate/source/runner/clean-state/log/count/library-name checks and existing input listings. Git sanitation is unchanged.

The new validate_stopped_results function binds raw historical commit/tree/runner to 97a6aba4/0cea01cc/fba21140, rejects passed status, requires the exact source-mismatch fatal message, binds the late correction to final raw bytes and the original receipt bytes, and verifies the initial observation hash linkage. It requires precisely the twelve static labels ending at build-tests, typed integer-zero exits, expected before/after identities, clean states, and the specific final build transition to c16814db/tree77a14d. UI/nav/runtime entries or an incorrect transition fail. The late correction must explicitly state no runtime and match the build endpoint.

The archival input set now includes both original receipt and late correction, original helper and original review, this supersession note, and the actual-AST regression source/results/log. Every input still preloads before any destination mkdir/write. README explicitly describes the observation-only initial receipt, missing intermediate raw snapshot, unproven Linux termination, late static completion and source-guard refusal before runtime.

## Recording-only verification executed

I ran only test_navigation_stopped_guard_v2.py directly under WSL Python. It pins the final helper SHA after all archive filenames were fixed, parses the actual helper AST, and compiles only the actual sha function plus validate_stopped_results and the four adjacent recorded Path reads/call. It never executes the helper module, Git wrapper, current-candidate guards, application, CI or real process-control logic. All evaluated stopped evidence is synthetic dictionary/JSON data and in-memory RecordingPath reads. Standalone proof output goes only to E-drive files.

Result: 5 tests, 25 scenarios, 0 failures, 0 errors, 0 skipped. Cases cover matching late refusal, missing correction, stale raw hash, wrong commit/tree/runner/fatal/after head/tree/before identities, unexpected runtime/UI/nav checks, passed status, boolean exits, dirty state, receipt/observation mismatches and late runtime claims. The negative control deletes the actual raw-hash assertion from a copied AST: the intact guard rejects a stale binding, while the mutated AST permits it. A structural check confirms the actual guard block precedes the full-input preload and all destination writes.

- Proof source SHA256: be98382fde4788c4d8c4e2912f9ad6ab924b21ea65b2920d02bec2a559c0f65f
- Proof results SHA256: aeb9b3a0eccaba9595bc7e91da70c88859f210a8c79faa966cb44bf645fd3b6e
- Proof log SHA256: 5457b999437dc969174a7182d377ffbf9967d41556115580bb9ed30684e821fd
- Extracted actual AST SHA256: 4a98f4ea5289db4a2d7d8e6f548372f94170731b794f65dccee7e510a269051f

I also read the preserved historical input objects and independently compared the current final-result and original-receipt hashes to the late correction; both match. I did not change those root-owned metadata files. No candidate/index/status mutation, app build/test, actual helper execution, active current-run result inspection, CI operation or signal occurred in this correction task.

## Later candidate status supplied by root

Root subsequently reported that the c16814db current run failed strict Clippy before runtime (cloned_ref_to_slice_refs at tests_repository.rs:65). Therefore helper 9b8684e9, which deliberately still binds c16814db, must not execute or archive a current-candidate pass. The historical-97 correction and its proof are complete; final candidate/fixture/tree binding and preservation of the failed c168 run must be updated for the next candidate and independently reviewed. A helper source rebind changes its hash and requires rebinding/rerunning this recording-only proof. No later candidate success is implied.
