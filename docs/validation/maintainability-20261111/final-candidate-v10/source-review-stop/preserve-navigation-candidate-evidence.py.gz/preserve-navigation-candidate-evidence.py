"""Archive a complete 33-gate pass for the navigation-fixture follow-up."""
import gzip
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys

ROOT = Path('/mnt/e/private/gitcraft-build')
REPO = Path('/mnt/e/private/gitcraft-worktrees/final-maintainability')
CANDIDATE = '97a6aba4073ea465cb4241123c2d1379766ca234'
TREE = '0cea01cc09874f7043cf72990ce3fa5a935cad04'
FIX = 'c7f59f4009961a91c38300cd4212a4edac9a3626'
PARENT = 'b1963845825e2f5872a89adbeca45b562780fa42'
RUNNER = 'fba211409fd0f961eb803af8d332eca08be039ea241fba7cd4ffec9be5e623b3'
DEST = REPO / 'docs/validation/maintainability-20261111/final-candidate-v4'
assert len(sys.argv) == 2
RUN = Path(sys.argv[1]).resolve()
assert RUN.is_relative_to(ROOT.resolve()) and RUN.name.startswith('validation-97a6aba4-')


def sha(data):
    return hashlib.sha256(data).hexdigest()


def git(*args):
    return subprocess.check_output(
        ['git', '-c', 'core.autocrlf=true', '-C', str(REPO), *args], text=True,
        env={key: value for key, value in os.environ.items() if not key.upper().startswith('GIT_')},
    ).strip()


assert git('rev-parse', 'HEAD') == CANDIDATE
assert Path(git('rev-parse', '--show-toplevel')).resolve() == REPO.resolve()
assert git('rev-parse', 'HEAD^{tree}') == TREE and git('rev-parse', 'HEAD^') == PARENT
assert git('branch', '--show-current') == 'maintainability/validated-v4'
assert git('status', '--porcelain') == '' and not DEST.exists()
authors = git('log', '--format=%an <%ae>', '57d7395bce9e187ff9f2a3ce9b96dc0d65715600..HEAD').splitlines()
assert len(authors) == 24 and set(authors) == {'Jonas Kamsker <11245306+JKamsker@users.noreply.github.com>'}
paths = ['src/repo/navigation/manual_history.rs', 'src/repo/navigation/tests.rs', 'src/repo/navigation/tests_repository.rs']
assert set(git('diff', '--name-only', PARENT, CANDIDATE).splitlines()) == set(paths)
blobs = {path: git('rev-parse', CANDIDATE + ':' + path) for path in paths}
assert all(blob == git('rev-parse', FIX + ':' + path) for path, blob in blobs.items())
results_raw = (RUN / 'results.json').read_bytes()
results = json.loads(results_raw)
assert results['commit'] == CANDIDATE and results['tree'] == TREE
assert results['status'] == 'passed' and results.get('finished')
assert results['runner_sha256'] == RUNNER == sha((ROOT / 'run-final-candidate-v4.py').read_bytes())
# The identical runner's label inventory comes from its prior immutable pass.
prior_raw = (ROOT / 'validation-0e6a8e52-2ypil253/results.json').read_bytes()
assert sha(prior_raw) == '098ebc67b6efd04411f6403ea9fd34f24b8bd677d16aa1fdb00f92eb56c545c3'
prior = json.loads(prior_raw)
checks = results['checks']
assert len(checks) == 33 and len({entry['label'] for entry in checks}) == 33
assert {entry['label'] for entry in checks} == {entry['label'] for entry in prior['checks']}
assert next(entry for entry in checks if entry['label'] == 'tooling-regressions')['python_test_count'] == 61
for label in ['clippy-packages', 'windows-cross-clippy-packages']:
    assert 'Clippy packages: 3 checked.' in (RUN / (label + '.log')).read_text()
for entry in checks:
    assert type(entry['exit']) is int and entry['exit'] == 0
    assert entry['before']['head'] == entry['after']['head'] == CANDIDATE
    assert entry['before']['tree'] == entry['after']['tree'] == TREE
    assert entry['before']['status'] == entry['after']['status'] == ''
    assert sha(Path(entry['log']).read_bytes()) == entry['sha256']
library = next(entry for entry in checks if entry['label'] == 'runtime-gitcraft-lib')
assert library['test_summaries'] == [dict(passed=5228, failed=0, ignored=27, measured=0, filtered=4)]
library_log = Path(library['log']).read_text()
required_tests = [
    'back_and_forward_through_a_repository',
    'back_to_a_diff_selects_its_commit_again',
    'following_links_to_commits_are_steps',
    'manual_history::manual_graph_diff_file_history_is_independent_of_detail_readiness',
    'manual_history::user_selection_and_explicit_same_file_toggle_keep_their_distinct_meanings',
    'manual_history::manual_graph_refinement_and_diff_selection_do_not_depend_on_cached_details',
]
for name in required_tests:
    assert re.search(r'^test ' + re.escape('repo::navigation::tests::' + name) + r' \.\.\. ok$', library_log, re.M), name
lint_raw = (ROOT / 'ci-43109642223-lint-job.json').read_bytes()
assert sha(lint_raw) == 'bc937cbd6c3663c857d85515ba4d4d449176b128b4b957b52c2b1437502d35c7'
lint = json.loads(lint_raw)
assert lint['id'] == 130822169327 and lint['run_id'] == 43109642223
assert lint['head_sha'] == '0622a2ac1237311e29f6dcc94788b30f5b094bb4'
assert lint['conclusion'] == 'success' and lint['status'] == 'completed'
for name in ['Formatting', 'Clippy']:
    assert next(step for step in lint['steps'] if step['name'] == name)['conclusion'] == 'success'
assert sha((ROOT / 'ci-43109642223-lint.log').read_bytes()) == '1fcb3c7d276592e142283f6c7ed78efdef78b290ae07eca42316ee2f4a796648'
sources = [(RUN / 'results.json', 'results.json')]
sources += [(Path(entry['log']), 'logs/' + entry['label'] + '.log') for entry in checks]
sources += [(ROOT / name, 'provenance/' + name) for name in [
    'run-final-candidate-v4.py', 'preserve-navigation-candidate-evidence.py',
    'final-97a6aba4-progress.log', 'nav-ci-fixture-c7f59f40.md',
    'nav-candidate-remote.txt', 'ci-followup-archive-remote.txt',
    'combined-nav-size-working.log', 'combined-nav-size-index.log',
    'ci-followup-size-working.log', 'ci-followup-size-index.log',
    'ci-43109642223-lint-job.json', 'ci-43109642223-lint.log',
]]
sources += [(ROOT / name, 'reviews/' + name) for name in [
    'review-navigation-c7f59f40.md', 'review-nav-fixture-c7f59f40-lifecycle.md',
    'review-nav-candidate-gate.md', 'review-navigation-evidence-helper.md',
    'review-final-documentation-0622a2ac.md',
]]
# Missing inputs must fail before the first destination write.
inputs = [(source, relative, source.read_bytes()) for source, relative in sources]
manifest = dict(commit=CANDIDATE, tree=TREE, fixture_source=FIX, fixture_blobs=blobs,
    parent=PARENT, history_units=24, previous_ci_head='0622a2ac1237311e29f6dcc94788b30f5b094bb4', artifacts=[])
for source, relative, raw in inputs:
    compressed = gzip.compress(raw, mtime=0)
    target = DEST / (relative + '.gz')
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(compressed)
    manifest['artifacts'].append(dict(path=relative + '.gz', source=str(source),
        sha256=sha(raw), gzip_sha256=sha(compressed), bytes=len(raw)))
(DEST / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
rows = []
for entry in checks:
    for count in entry.get('test_summaries', []):
        rows.append('| ' + entry['label'] + ' | ' + ' | '.join(str(count[key]) for key in ['passed', 'failed', 'ignored', 'filtered']) + ' |')
(DEST / 'README.md').write_text(f'''# Navigation follow-up candidate validation

Candidate `{CANDIDATE}`, complete tree `{TREE}`, passed all 33 local gates.
Its three changed test files exactly match reviewed fixture source `{FIX}`;
its parent `{PARENT}` preserves the failed Linux CI evidence. The 24 linear
history units begin at dev `57d7395bce9e187ff9f2a3ce9b96dc0d65715600`.
Application production source and quality gates are unchanged from `0622a2ac`.

The library passed 5,228 tests, with zero failures, 27 ignored and four filtered
tests executed separately. All three corrected legacy navigation tests and all
three new recording tests ran successfully in that full invocation. The new
tests cover 72 configurations: 40 manual-history, 24 real user-selection/toggle,
and eight link/refinement/selected-diff cases. Every old assertion remains.
Passive manual setup is explicit; actual row/hash automatic reveal and same-file
toggle behavior retain separate ready/cache/delayed-detail assertions.

Python discovery passed 61 tests. Working/index/revision caps and complexity
policy, formatting, all-target compilation, strict Linux and Windows GNU
cross-target Clippy across all three packages, all four early UI probes,
recording/recovery and OS/CLI/MCP/checkpoint suites passed. The doctest gate
executed zero tests. Windows GNU cross checks do not establish native Windows
execution; live SSH/forge parity and real power-loss durability are separate.

| Runtime gate | Passed | Failed | Ignored | Filtered |
| --- | ---: | ---: | ---: | ---: |
{chr(10).join(rows)}

Every gate binds unchanged candidate HEAD/tree/clean state and log hashes.
Runtime gates add fresh before/after binary/application hashes. Synthetic recordings precede owned-child
execution in a probed PID/proc/dev namespace; existing native owned ACL fixtures
run separately. Builds/tests run directly in WSL on the host with no Docker.
Scripts, targets and tooling scratch are on E:; private Linux runtime scratch
preserves native filesystem semantics.

The earlier local pass remains in `../final-candidate/`; its later failed Linux
CI result is preserved in `../ci-regressions/43109642223/`. Those historical
results are not relabeled as passes. That failed Linux test job establishes
compilation and its runtime failure. Formatting and Linux Clippy passed in the
separate completed lint job `130822169327` on the same `0622a2ac` head; its log
and API metadata are preserved here to bind the earlier archive's broader lint
statement. This is historical CI evidence, not a new CI run for this candidate.
Independent source reviews distinguish
authored areas and test execution. Original helper safety regression proofs
remain in the earlier archive; this run reuses the exact reviewed runner hash.
The archive Git wrapper retains its inherited-Git-variable sanitation.

This evidence is a documentation-only follow-up. Verify application and gate
files unchanged before binding the prior execution to that follow-up; no new
application execution is claimed for documentation changes. Final CI may run
only after exact candidate checks and independent review complete.
''')
print(json.dumps(dict(destination=str(DEST), artifacts=len(inputs))))
