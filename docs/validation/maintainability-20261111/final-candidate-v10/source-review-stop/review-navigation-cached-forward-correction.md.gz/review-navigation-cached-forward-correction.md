# Correction and supersession: cached forward navigation

Reviewer: `/root/gate_scout`.

My earlier source approval missed an incorrect cached-history expectation. Root's additional trace identified it; I independently confirmed it against immutable `c7f59f4009961a91c38300cd4212a4edac9a3626` and unchanged `NavHistory::replace_current`/`merge_around` source. This note preserves and explicitly supersedes the affected approval without overwriting the original reviews.

With cached head details, actual link navigation records `[Graph(head), Graph(base), Diff(head)]`. Back, Back, Forward selects the middle Graph(base). Passively refining that place to Graph(head) merges the adjacent equal Graph entries but preserves the distinct forward Diff(head). The correct history is `[Graph(head), Diff(head)]`, with Graph current and Forward available. The old c7 matrix instead required only `[Graph(head)]`. The legacy link-navigation fixture made the same Graph-only assertion. Pending details can produce the shorter graph-only history, so that expectation must depend on actual readiness rather than discarding a valid forward place.

Affected prior source-only approvals:

- `review-navigation-c7f59f40.md`, SHA256 `f46d5771d9355fd6ef7bdce0f4e57d87d649396389847d506418ba077394c45f`: withdraw its no-blocker verdict for the cached graph-refinement expectation and analogous legacy link assertion.
- `review-nav-candidate-gate.md`, SHA256 `2d22e13f09f968a12b449f4d25d7ef9c657ad5a582d9b890b23c9dfbea7f1d4c`: mechanical history/tree/blob comparisons remain factual, but its rebound approval of those expectations in candidate `97a6aba4073ea465cb4241123c2d1379766ca234` is withdrawn.
- `review-navigation-evidence-helper.md`, SHA256 `03da917790bb0f4e453d5738572784d7b117041bcfae6444a8b3bc515abd7b91`: do not execute helper SHA256 `162b09ea9dfdb7fb922f9495ee16fca7b6a0dcc3b499d5c7e903081205dba73b`. Its completed-pass prerequisite is unsatisfied, and the bound97 fixture cannot pass the identified matrix assertion unchanged. The helper review is historical, not approval to archive a success.

Production navigation behavior and earlier unchanged-source bindings are not implicated. No production `NavHistory` change is needed. The correction must preserve cached forward Diff while retaining the pending graph-only branch and explicitly test `peek`, `can_forward`, Forward-to-Diff and Back-to-Graph behavior. Generalized user row/hash reveal and same-key toggle coverage must remain separate from passive manual-history setup.

Root reports the owned97 local runner was interrupted after static gates through check, before application runtime. This note makes no claim of executing the failed matrix or any new application test. Published c7/97 branches, source helpers and original review files remain preserved. The corrected fixture, integrated exact candidate, expanded early navigation runner and archive bindings require fresh independent review and completed local validation before final delivery.

I performed only Git-object reads from my own worktree and wrote this standalone E-drive note. No repository/candidate edit, index/status refresh, build/test/CI execution, CI polling or process-control action was performed by me.
