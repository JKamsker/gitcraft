# Read-only observer source review

PASS for `watch-owned-926-worker.py`, SHA256 `48e84b4271492a6d050280e9d7248933ecdefae9963a11eac69a3e10fe9169de`, after reading the complete source and its recording-only test boundaries. This approves observation only, not application validation.

The observer never signals, spawns, terminates or cleans up any process. Discovery is used solely for a read-only wait: exact known runner argv/candidate, current real/effective/saved/filesystem UIDs, exact working directory and positive start-time identity must identify exactly one worker. The reviewed runner bytes are pinned. A stable pidfd is opened and the complete identity/start time rechecked; mismatch closes the descriptor and fails. No discovered PID is printed or used as a signal target.

Synthetic matching/uniqueness, recorded descriptor open/close/rechecks, recording-only polling, incomplete/mismatched manifests and poll errors are tested before any actual observation. The six-test proof records no actual /proc access or pidfd observation. Root must verify its pinned script digest and zero failures before launching --watch.

Polling is bounded to one second per call. Completion requires a ready stable descriptor plus the expected source/tree/runner, passed/finished manifest and 39 unique typed-zero clean-source checks. This structural observation is followed by the separately reviewed full evidence helper, which checks exact labels, logs, runtime counts and names. The observer explicitly cannot report the non-child worker's exit code and does not equate the Windows wrapper's exit with Linux termination. Its stdout must be redirected inside WSL to an E-drive file.

The candidate remains frozen. No application test or actual observation was executed by this source review, and no restart, cancellation or source change is approved or needed.
