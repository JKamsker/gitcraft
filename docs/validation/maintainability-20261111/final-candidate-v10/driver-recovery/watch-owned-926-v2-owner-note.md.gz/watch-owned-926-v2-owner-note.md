# Owner record: receipt-only926 observer v2

Implemented watch-owned-926-worker-v2.py, SHA256 ed8243da6ef61b6091cbe2b4169edd9715c7201503d26a139dd33f8b088a2ce7. This is the implementer's record, not independent signoff. Root must review before any actual --watch invocation. I did NOT launch the real observer or touch/restart/control a validation worker. Original v1 remains unchanged at SHA256 48e84b4271492a6d050280e9d7248933ecdefae9963a11eac69a3e10fe9169de.

V2 removes process discovery entirely. It reads only the decimal PID in /mnt/e/private/gitcraft-build/final-926-worker.pid, which root's owned launcher writes before exec. Receipt syntax must be one positive ASCII decimal PID within pid_t range. Only /proc/<that receipt PID> is read. Snapshot PID must equal receipt PID; all four UID values must equal the observer's UID, argv must exactly equal python3 /mnt/e/private/gitcraft-build/run-final-candidate-v5.py 92656fb7d7c49a728824df9548cccf2c35325ad4 and cwd must exactly equal /mnt/e/private/gitcraft-worktrees/final-maintainability. Linux stat starttime is read before/after snapshot fields and must remain stable.

The matching snapshot is bound to os.pidfd_open and rechecked for exact PID/starttime/argv/UID/cwd equality afterward. Receipt bytes must remain identical across binding and at successful final observation. The runner SHA is verified before binding, after binding and at successful final observation against d0f64d5404cf755e988bf634d203d7e9d97896490ad62b0c0f42f51db8a4508a. Identity mismatch refuses observation; only an owned descriptor is closed. There are no /proc directory scans, process selectors, signals, kill/spawn/cleanup commands, subprocess calls, application execution or CI operations.

CLI is explicit:

    python3 /mnt/e/private/gitcraft-build/watch-owned-926-worker-v2.py --watch RUN_DIRECTORY

Root must supply the actual newly launched run directory after the worker has exec'd Python. RUN_DIRECTORY resolves to a direct child of /mnt/e/private/gitcraft-build whose name begins validation-92656fb7-. It is deliberately not inferred from older partial manifests. Root must redirect stdout/stderr INSIDE Linux directly to an E-drive observation log; no Windows wrapper pipe should carry the durable observation stream. I have not executed that command.

Pidfd IN/HUP readiness reports completion; ERR/NVAL does not establish completion and raises refusal. Progress reports manifest count/latest label/status/fatal/finished changes. Completion explicitly reports child_exit_code_available=false and child_exit_code=null. The nonparent observer does not obtain a child exit status. Its own success requires the explicitly selected final manifest to show exact 926 HEAD/tree 8f188, reviewed runner SHA, passed status, nonempty string finished, 39 unique checks, typed integer-zero exits and exact clean HEAD/tree before/after every check. Observer exit 0 is that manifest verdict, not a recovered child exit code. The old y7ydkc5v partial run is not asserted to pass.

Executed only --self-test. Result: 7 tests, 0 failures, 0 errors, 0 skipped. Tests use synthetic snapshot/manifest/receipt data and recorded pidfd/poll boundaries. They cover receipt parsing, wrong receipt/snapshot PID, receipt changes across binding, exact argv/UID/cwd/starttime rechecks and descriptor close on mismatch, run-directory restriction, strict final manifest checks, progress/completion, unavailable child exit status and poll-error refusal. No real receipt, /proc, pidfd or current-run manifest was accessed in this proof. Source is 284 physical lines including inline tests.

- watch-owned-926-v2-selftests.json SHA256 cf07d03ee46b4cc6e9564060f1a00f4acdd4e299bb94b9269632b5d190e92d1b
- watch-owned-926-v2-selftests.log SHA256 53fb78c9ea38d233f7c66a1e09bbc9a635b670c5c76c9fe09ecf23aab7b4b70e

All edits and proof artifacts are E-drive-only. No product/source/index/status changes, app builds/tests, CI, actual helper/watch execution or process-control operations occurred. Ownership of this frozen script is handed back to root for independent review and later launch.