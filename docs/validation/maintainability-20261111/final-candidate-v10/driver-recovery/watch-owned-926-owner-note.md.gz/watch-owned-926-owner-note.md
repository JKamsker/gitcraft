# Owner record: read-only owned926 worker observation

Implemented E:/private/gitcraft-build/watch-owned-926-worker.py, SHA256 48e84b4271492a6d050280e9d7248933ecdefae9963a11eac69a3e10fe9169de. This is the author's implementation record, not independent signoff. The actual watcher has NOT been started. Root owns source review and any later --watch invocation. No validation worker was restarted, interrupted, signaled or otherwise controlled.

The 238-line script (including inline safety tests) has two explicit modes. --self-test runs synthetic/recording tests only. --watch performs read-only observation. No mode is selected implicitly. Actual observation is restricted to exactly one current-UID process whose NUL-separated argv is exactly python3 /mnt/e/private/gitcraft-build/run-final-candidate-v5.py 92656fb7d7c49a728824df9548cccf2c35325ad4, whose cwd is exactly /mnt/e/private/gitcraft-worktrees/final-maintainability, and whose four Linux Uid values match the observer's current UID. The reviewed runner file SHA must be d0f64d5404cf755e988bf634d203d7e9d97896490ad62b0c0f42f51db8a4508a.

/proc discovery is solely for read-only observation. Snapshot reads verify stable /proc stat starttime around argv/UID/cwd reads. The exact matched snapshot is bound by os.pidfd_open; identity/starttime are rechecked after opening and must match the prior snapshot exactly. A mismatch closes only the owned descriptor and refuses observation. No PID is emitted to users. There is no signal, kill, process-group selector, cleanup command, subprocess launch or application execution in the script.

The pidfd is registered for poll readiness. Poll ERR/NVAL fails without claiming worker completion. IN/HUP readiness reports pidfd completion and then requires the final manifest, rather than inferring validation success from process disappearance. The watcher explicitly reports child_exit_code_available=false and child_exit_code=null: a nonparent observer does not obtain the worker's exit status. Its own exit 0 means a verified final passed manifest, not a discovered child exit code; exit 2 means completion without a sufficient passed manifest.

The only observed results path is /mnt/e/private/gitcraft-build/validation-92656fb7-y7ydkc5v/results.json. Progress emits JSON summaries when count/last-check/status/fatal/finished change. Transient unreadable/partial JSON is tolerated while the worker runs. Final success requires exact candidate 92656fb7 and tree 8f188f3a, reviewed runner SHA, passed status, a nonempty string finished marker, 39 unique checks, typed integer-zero exits and every before/after HEAD/tree/clean state matching the expected candidate. Runner source is hashed before discovery, after binding and at successful final observation. The source bytes are never modified.

Executed only:

    python3 /mnt/e/private/gitcraft-build/watch-owned-926-worker.py --self-test

Result: 6 tests, 0 failures, 0 errors, 0 skipped. Tests cover exact/multiple/missing/UID/cwd/argv/starttime matching, recorded pidfd opening and rechecks with descriptor close on mismatch, wrong/partial/falsely typed final manifests, recorded polling/progress/completion, unknown child exit status, final source mismatch and poll-error refusal. Every pidfd/poll boundary in tests is recording-only; all snapshots/manifests are synthetic. --self-test does not read /proc or the current result manifest, bind a real pidfd, observe the worker or execute an application/tooling gate.

- Self-test JSON: watch-owned-926-selftests.json, SHA256 e309059e813255bb4f32c332faa50c8f5610ce12bbff7420d217e0e1bc791532
- Self-test log: watch-owned-926-selftests.log, SHA256 e9a7107a2f5ff726d7cde2e3ccf298c7d7e6c3017656679d2ec101aaedd25178

After root's independent review, any real launcher must redirect stdout/stderr inside WSL directly to an E-drive file, for example the following command TEXT (not executed here):

    sh -c 'python3 /mnt/e/private/gitcraft-build/watch-owned-926-worker.py --watch > /mnt/e/private/gitcraft-build/watch-owned-926-observation.log 2>&1'

That avoids relying on a Windows wrapper stdout pipe for observation records. Root must retain the fixed source hash and the observation log as supplemental driver evidence, without treating the watcher as new application execution or a CI result. Frozen application/helper/source/index state is unchanged.