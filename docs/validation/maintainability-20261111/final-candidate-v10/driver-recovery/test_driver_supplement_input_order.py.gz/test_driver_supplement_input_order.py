"""Record extracted archive-boundary AST using synthetic paths and bytes only."""
import ast
import copy
import gzip
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import unittest

ROOT = Path('/mnt/e/private/gitcraft-build')
HELPER = ROOT / 'supplement-final-926-driver-evidence.py'
OLD = ROOT / 'supplement-final-926-driver-evidence-before-readme-fix.py'
PINS = {HELPER: 'c572b1d78321edcdf4f2d59116288e8e8d3439f5e000a09505fdda6815010406',
        OLD: '33ede6b79e44c0c1e38d9ef589c303fa6361a683583163b81a581d5effbac9a8'}
MODULES = {}
BLOCKS = {}
for source, expected in PINS.items():
    raw = source.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == expected
    module = ast.parse(raw, filename=str(source))
    at = next(i for i, node in enumerate(module.body)
              if isinstance(node, ast.Assign) and isinstance(node.targets[0], ast.Name)
              and node.targets[0].id == 'names')
    MODULES[source] = module
    BLOCKS[source] = ast.Module(body=module.body[at:], type_ignores=[])


class ReadAfterMutation(AssertionError):
    pass


def record(source=HELPER, missing=None, collision=False, duplicate=False):
    events = []
    files = {'/recording/archive/README.md': b'original archive\n'}
    names = ast.literal_eval(BLOCKS[source].body[0].value)
    files['/recording/partial/results.json'] = b'synthetic partial manifest\n'
    for name in names:
        files['/recording/' + name] = ('synthetic ' + name + '\n').encode()
    files['/recording/logs/one.log'] = b'one\n'
    files['/recording/logs/two.log'] = b'two\n'
    if missing:
        del files[missing]

    class RecordingPath:
        def __init__(self, value):
            self.value = str(PurePosixPath(value))

        def __truediv__(self, part):
            return RecordingPath(str(PurePosixPath(self.value) / part))

        def __str__(self):
            return self.value

        @property
        def parent(self):
            return RecordingPath(str(PurePosixPath(self.value).parent))

        def exists(self):
            events.append(('exists', self.value))
            return collision and self.value.endswith('driver-recovery/partial-run/results.json.gz')

        def read_bytes(self):
            if any(kind in {'mkdir', 'write_bytes', 'write_text'} for kind, _ in events):
                raise ReadAfterMutation(self.value)
            events.append(('read', self.value))
            return files[self.value]

        def read_text(self):
            return self.read_bytes().decode()

        def mkdir(self, **kwargs):
            events.append(('mkdir', self.value))

        def write_bytes(self, raw):
            events.append(('write_bytes', self.value))

        def write_text(self, text):
            events.append(('write_text', self.value))

    manifest = {'artifacts': [{'path': 'results.json.gz'}]}
    checks = [{'label': 'one', 'log': '/recording/logs/one.log'},
              {'label': 'one' if duplicate else 'two', 'log': '/recording/logs/two.log'}]
    namespace = dict(ROOT=RecordingPath('/recording'), DEST=RecordingPath('/recording/archive'),
                     PARTIAL=RecordingPath('/recording/partial'), partial={'checks': checks},
                     manifest=manifest, manifest_path=RecordingPath('/recording/archive/manifest.json'),
                     Path=RecordingPath, gzip=gzip, json=json,
                     sha=lambda raw: hashlib.sha256(raw).hexdigest(), print=lambda *args: None)
    try:
        exec(compile(copy.deepcopy(BLOCKS[source]), str(source), 'exec'), namespace)
    except BaseException as error:
        return events, error
    return events, None


class BoundaryTests(unittest.TestCase):
    def assert_no_mutation(self, events):
        self.assertFalse([event for event in events if event[0] in {'mkdir', 'write_bytes', 'write_text'}])

    def test_corrected_actual_ast_reads_all_inputs_before_first_mutation(self):
        events, error = record()
        self.assertIsNone(error)
        first = next(i for i, event in enumerate(events) if event[0] == 'mkdir')
        self.assertTrue(any(kind == 'read' and path.endswith('/README.md') for kind, path in events[:first]))
        self.assertFalse(any(kind == 'read' for kind, _ in events[first:]))
        self.assertEqual(sum(kind == 'write_bytes' for kind, _ in events), 23)
        self.assertEqual([path for kind, path in events if kind == 'write_text'],
                         ['/recording/archive/manifest.json', '/recording/archive/README.md'])

    def test_missing_readme_fails_before_any_mutation(self):
        events, error = record(missing='/recording/archive/README.md')
        self.assertIsInstance(error, KeyError)
        self.assert_no_mutation(events)

    def test_every_missing_artifact_fails_before_any_mutation(self):
        names = ast.literal_eval(BLOCKS[HELPER].body[0].value)
        paths = ['/recording/partial/results.json', '/recording/logs/one.log', '/recording/logs/two.log']
        paths += ['/recording/' + name for name in names]
        for path in paths:
            with self.subTest(path=path):
                events, error = record(missing=path)
                self.assertIsInstance(error, KeyError)
                self.assert_no_mutation(events)

    def test_existing_artifact_fails_before_any_mutation(self):
        events, error = record(collision=True)
        self.assertIsInstance(error, AssertionError)
        self.assert_no_mutation(events)

    def test_duplicate_artifact_fails_before_any_mutation(self):
        events, error = record(duplicate=True)
        self.assertIsInstance(error, AssertionError)
        self.assert_no_mutation(events)

    def test_original_helper_negative_control_detects_read_after_mutation(self):
        events, error = record(OLD)
        self.assertIsInstance(error, ReadAfterMutation)
        self.assertTrue(any(kind == 'write_text' and path.endswith('/manifest.json') for kind, path in events))
        missing_events, missing_error = record(OLD, missing='/recording/archive/README.md')
        self.assertIsInstance(missing_error, ReadAfterMutation)
        self.assertTrue(any(kind == 'write_bytes' for kind, _ in missing_events))

    def test_extracted_ast_contains_every_production_mutation(self):
        for source, module in MODULES.items():
            start = BLOCKS[source].body[0].lineno
            writes = [node for node in ast.walk(module) if isinstance(node, ast.Call)
                      and isinstance(node.func, ast.Attribute)
                      and node.func.attr in {'mkdir', 'write_bytes', 'write_text'}]
            self.assertEqual(len(writes), 4)
            self.assertTrue(all(node.lineno > start for node in writes))
            self.assertFalse(any(isinstance(node, (ast.Import, ast.ImportFrom)) for node in ast.walk(BLOCKS[source])))


if __name__ == '__main__':
    output = io.StringIO()
    result = unittest.TextTestRunner(stream=output, verbosity=2).run(
        unittest.defaultTestLoader.loadTestsFromTestCase(BoundaryTests))
    text = output.getvalue()
    print(text, end='')
    (ROOT / 'driver-supplement-input-order-tests.log').write_text(text)
    meta = dict(helper_sha256=PINS[HELPER], old_helper_sha256=PINS[OLD],
                proof_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                extracted_ast_sha256=hashlib.sha256(ast.dump(BLOCKS[HELPER]).encode()).hexdigest(),
                tests=result.testsRun, failures=len(result.failures), errors=len(result.errors),
                skipped=len(result.skipped), log_sha256=hashlib.sha256(text.encode()).hexdigest(),
                boundary='Actual source AST from artifact-name declaration through end; synthetic in-memory paths/bytes and recording-only mutations. No real archive/module, Git, application, CI, process inspection or control.')
    (ROOT / 'driver-supplement-input-order-results.json').write_text(json.dumps(meta, indent=2) + '\n')
    raise SystemExit(0 if result.wasSuccessful() else 1)
