from pathlib import Path
import json
import os

expected = ['/mnt/e/private/gitcraft-build/run-final-candidate-v5.py',
            '92656fb7d7c49a728824df9548cccf2c35325ad4']
found = []
for proc in Path('/proc').iterdir():
    if not proc.name.isdecimal():
        continue
    try:
        argv = [os.fsdecode(value) for value in (proc / 'cmdline').read_bytes().rstrip(b'\0').split(b'\0')]
        if argv[1:] != expected:
            continue
        uids = next(line.split()[1:] for line in (proc / 'status').read_text().splitlines() if line.startswith('Uid:'))
        found.append(dict(argv=argv, cwd=os.readlink(proc / 'cwd'), uids=uids,
                          observer_uid=os.getuid()))
    except (OSError, ValueError, StopIteration):
        continue
print(json.dumps(found, indent=2))
