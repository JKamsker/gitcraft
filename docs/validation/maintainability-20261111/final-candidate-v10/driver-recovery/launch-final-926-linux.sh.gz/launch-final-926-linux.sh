#!/bin/sh
set -eu
umask 077
cd /mnt/e/private/gitcraft-worktrees/final-maintainability
printf '%s\n' "$$" > /mnt/e/private/gitcraft-build/final-926-worker.pid
exec python3 /mnt/e/private/gitcraft-build/run-final-candidate-v5.py 92656fb7d7c49a728824df9548cccf2c35325ad4 > /mnt/e/private/gitcraft-build/final-92656fb7-linux-progress.log 2>&1
