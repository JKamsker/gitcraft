"""Read-only pidfd observation of one exact validation worker; no child exit code."""
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import select
import sys
import unittest

ROOT = Path('/mnt/e/private/gitcraft-build')
RUNNER = ROOT / 'run-final-candidate-v5.py'
RUNNER_SHA = 'd0f64d5404cf755e988bf634d203d7e9d97896490ad62b0c0f42f51db8a4508a'
HEAD = '4212389c6ce69ee6dba14a31a9972a54d5a2266d'
TREE = '5ae3781e43d4d97c4ed3190020da15bd07d0ffaf'
CWD = '/mnt/e/private/gitcraft-worktrees/final-maintainability'
ARGV = ['python3', str(RUNNER), HEAD]
RECEIPT = ROOT / 'final-421-worker.pid'


def matches(snapshot, uid):
    return (isinstance(snapshot, dict) and snapshot.get('argv') == ARGV
            and snapshot.get('cwd') == CWD and snapshot.get('uids') == [uid] * 4
            and type(snapshot.get('pid')) is int and snapshot['pid'] > 0
            and type(snapshot.get('start')) is int and snapshot['start'] > 0)


def same_owner(before, after, uid):
    return matches(before, uid) and matches(after, uid) and before == after


def snapshot(pid):
    try:
        proc = Path('/proc') / str(pid)
        first = proc.joinpath('stat').read_text().rsplit(')', 1)[1].split()[19]
        argv = proc.joinpath('cmdline').read_bytes().rstrip(b'\0').split(b'\0')
        uids = next(line.split()[1:] for line in proc.joinpath('status').read_text().splitlines()
                    if line.startswith('Uid:'))
        value = dict(pid=pid, start=int(first), argv=[os.fsdecode(arg) for arg in argv],
                     cwd=os.readlink(proc / 'cwd'), uids=list(map(int, uids)))
        last = proc.joinpath('stat').read_text().rsplit(')', 1)[1].split()[19]
        return value if first == last else None
    except (OSError, ValueError, IndexError, StopIteration):
        return None


def receipt_pid(raw):
    text = raw.decode('ascii').strip()
    if not text.isdecimal() or not 0 < int(text) < 2 ** 31:
        raise RuntimeError('Expected one positive decimal PID in the owned receipt')
    return int(text)


def checked_result_path(root, run):
    if run.parent != root or not run.name.startswith('validation-4212389c-'):
        raise RuntimeError('Pass the exact new candidate run directory under the E build root')
    return run / 'results.json'


def bind(before, uid, reader=snapshot, opener=os.pidfd_open, closer=os.close):
    if not matches(before, uid):
        raise RuntimeError('Initial worker identity differs')
    fd = opener(before['pid'], 0)
    try:
        if not same_owner(before, reader(before['pid']), uid):
            raise RuntimeError('Worker identity changed across pidfd binding')
    except BaseException:
        closer(fd)
        raise
    return fd


def bind_receipt(raw, uid, reader=snapshot, reread=RECEIPT.read_bytes,
                 opener=os.pidfd_open, closer=os.close):
    pid = receipt_pid(raw)
    before = reader(pid)
    if not matches(before, uid) or before['pid'] != pid:
        raise RuntimeError('Receipt and worker snapshot identities differ')
    fd = bind(before, uid, reader, opener, closer)
    try:
        if reread() != raw:
            raise RuntimeError('Owned PID receipt changed across binding')
    except BaseException:
        closer(fd)
        raise
    return fd


def passed(value):
    try:
        checks = value['checks']
        return (value['commit'] == HEAD and value['tree'] == TREE
                and value['runner_sha256'] == RUNNER_SHA and value['status'] == 'passed'
                and type(value['finished']) is str and bool(value['finished'])
                and len(checks) == 39 and len({entry['label'] for entry in checks}) == 39
                and all(type(entry['exit']) is int and entry['exit'] == 0
                        and all(entry[side]['head'] == HEAD and entry[side]['tree'] == TREE
                                and entry[side]['status'] == '' for side in ['before', 'after'])
                        for entry in checks))
    except (KeyError, TypeError):
        return False


def load_result(path):
    try:
        return json.loads(path.read_bytes())
    except (OSError, ValueError):
        return None


def observe(poller, load, emit, final_source=lambda: True):
    previous = None
    while True:
        value = load()
        if isinstance(value, dict):
            checks = value.get('checks') if isinstance(value.get('checks'), list) else []
            last = checks[-1].get('label') if checks and isinstance(checks[-1], dict) else None
            summary = dict(checks=len(checks), last=last,
                           status=value.get('status'), fatal=value.get('fatal'), finished=value.get('finished'))
            if summary != previous:
                emit(dict(event='manifest', **summary))
                previous = summary
        ready = poller.poll(1000)
        if any(mask & (select.POLLERR | select.POLLNVAL) for _, mask in ready):
            raise RuntimeError('pidfd polling failed; completion is not established')
        if any(mask & (select.POLLIN | select.POLLHUP) for _, mask in ready):
            final = load()
            ok = passed(final) and final_source() if isinstance(final, dict) else False
            emit(dict(event='pidfd-completed', child_exit_code_available=False,
                      child_exit_code=None, final_manifest_passed=ok))
            return 0 if ok else 2


def watch(run_directory):
    result_path = checked_result_path(ROOT.resolve(), Path(run_directory).resolve())
    if hashlib.sha256(RUNNER.read_bytes()).hexdigest() != RUNNER_SHA:
        raise RuntimeError('Runner bytes differ from reviewed source')
    uid = os.getuid()
    receipt = RECEIPT.read_bytes()
    fd = bind_receipt(receipt, uid)
    try:
        if hashlib.sha256(RUNNER.read_bytes()).hexdigest() != RUNNER_SHA:
            raise RuntimeError('Runner changed during ownership binding')
        poller = select.poll()
        poller.register(fd, select.POLLIN | select.POLLHUP | select.POLLERR)
        def emit(value):
            print(json.dumps(value), flush=True)
        emit(dict(event='owned-receipt-worker-bound', results=str(result_path), child_exit_code_available=False))
        return observe(poller, lambda: load_result(result_path), emit,
                       lambda: RECEIPT.read_bytes() == receipt
                       and hashlib.sha256(RUNNER.read_bytes()).hexdigest() == RUNNER_SHA)
    finally:
        os.close(fd)


class RecordingTests(unittest.TestCase):
    def fixture(self):
        return dict(pid=41, start=900, argv=ARGV.copy(), cwd=CWD, uids=[1000] * 4)

    def manifest(self):
        state = dict(head=HEAD, tree=TREE, status='')
        return dict(commit=HEAD, tree=TREE, runner_sha256=RUNNER_SHA, status='passed', finished='recorded',
                    checks=[dict(label=str(i), exit=0, before=state.copy(), after=state.copy()) for i in range(39)])

    def test_exact_identity_and_owned_receipt(self):
        value = self.fixture()
        self.assertTrue(matches(value, 1000))
        self.assertEqual(receipt_pid(b'41\n'), 41)
        for raw in [b'', b'0', b'-1', b'41\n42', b'python3 41', b'2147483648', b'\xff']:
            with self.assertRaises((RuntimeError, UnicodeDecodeError)):
                receipt_pid(raw)
        for field, wrong in [('argv', ARGV + ['extra']), ('argv', ['python3', str(RUNNER), 'other']),
                             ('cwd', '/other'), ('uids', [1001] * 4), ('uids', [1000, 1001, 1000, 1000]),
                             ('pid', True), ('start', 0)]:
            self.assertFalse(matches(dict(value, **{field: wrong}), 1000))

    def test_receipt_binding_rechecks_and_run_directory(self):
        value, calls = self.fixture(), []
        opened = lambda pid, flags: calls.append(('open', pid, flags)) or 88
        closed = lambda fd: calls.append(('close', fd))
        self.assertEqual(bind_receipt(b'41\n', 1000, lambda pid: value.copy(),
                                     lambda: b'41\n', opened, closed), 88)
        self.assertEqual(calls, [('open', 41, 0)])
        calls.clear()
        with self.assertRaises(RuntimeError):
            bind_receipt(b'41\n', 1000, lambda pid: value.copy(), lambda: b'42\n', opened, closed)
        self.assertEqual(calls, [('open', 41, 0), ('close', 88)])
        calls.clear()
        with self.assertRaises(RuntimeError):
            bind_receipt(b'41\n', 1000, lambda pid: dict(value, pid=42), lambda: b'41\n', opened, closed)
        self.assertEqual(calls, [])
        root = PurePosixPath('/recording')
        self.assertEqual(checked_result_path(root, root / 'validation-4212389c-new').name, 'results.json')
        for run in [root / 'other', root / 'nested/validation-4212389c-new',
                    PurePosixPath('/other/validation-4212389c-new')]:
            with self.assertRaises(RuntimeError):
                checked_result_path(root, run)

    def test_recorded_pidfd_and_before_after_recheck(self):
        value, calls = self.fixture(), []
        opened = lambda pid, flags: calls.append(('open', pid, flags)) or 88
        closed = lambda fd: calls.append(('close', fd))
        self.assertEqual(bind(value, 1000, lambda pid: value.copy(), opened, closed), 88)
        self.assertEqual(calls, [('open', 41, 0)])
        for after in [None, dict(value, start=901), dict(value, argv=ARGV + ['extra']),
                      dict(value, cwd='/other'), dict(value, uids=[1001] * 4)]:
            calls.clear()
            with self.assertRaises(RuntimeError):
                bind(value, 1000, lambda pid: after, opened, closed)
            self.assertEqual(calls, [('open', 41, 0), ('close', 88)])

    def test_final_manifest_refuses_partial_wrong_or_boolean_exits(self):
        good = self.manifest()
        self.assertTrue(passed(good))
        for field, wrong in [('commit', 'wrong'), ('tree', 'wrong'), ('runner_sha256', 'wrong'),
                             ('status', 'running'), ('finished', ''), ('finished', True)]:
            self.assertFalse(passed(dict(good, **{field: wrong})))
        for exit_value in [False, 1, None]:
            bad = self.manifest()
            bad['checks'][0]['exit'] = exit_value
            self.assertFalse(passed(bad))
        for side, field, wrong in [('before', 'head', 'wrong'), ('after', 'tree', 'wrong'), ('after', 'status', ' M x')]:
            bad = self.manifest()
            bad['checks'][0][side][field] = wrong
            self.assertFalse(passed(bad))
        self.assertFalse(passed(dict(good, checks=good['checks'][:-1])))

    def test_recorded_poll_completion_and_progress(self):
        events, polls = [], []
        answers = iter([[], [(88, select.POLLIN)]])
        class Poll:
            def poll(self, timeout):
                polls.append(timeout)
                return next(answers)
        good = self.manifest()
        values = iter([dict(good, status='running'), good, good])
        self.assertEqual(observe(Poll(), lambda: next(values), events.append), 0)
        self.assertEqual(polls, [1000, 1000])
        self.assertEqual(events[-1], dict(event='pidfd-completed', child_exit_code_available=False,
                                          child_exit_code=None, final_manifest_passed=True))
        self.assertEqual([event['event'] for event in events], ['manifest', 'manifest', 'pidfd-completed'])

    def test_completion_does_not_invent_success_or_child_exit_code(self):
        class Poll:
            def poll(self, timeout):
                return [(88, select.POLLIN)]
        events = []
        self.assertEqual(observe(Poll(), lambda: None, events.append), 2)
        self.assertIsNone(events[-1]['child_exit_code'])
        self.assertFalse(events[-1]['final_manifest_passed'])
        self.assertEqual(observe(Poll(), self.manifest, events.append, lambda: False), 2)
        self.assertFalse(events[-1]['final_manifest_passed'])

    def test_recorded_poll_error_is_not_completion(self):
        class Poll:
            def poll(self, timeout):
                return [(88, select.POLLERR)]
        events = []
        with self.assertRaises(RuntimeError):
            observe(Poll(), lambda: None, events.append)
        self.assertEqual(events, [])


def self_test():
    output = io.StringIO()
    result = unittest.TextTestRunner(stream=output, verbosity=2).run(
        unittest.defaultTestLoader.loadTestsFromTestCase(RecordingTests))
    log = output.getvalue()
    print(log, end='')
    (ROOT / 'watch-owned-421-v4-selftests.log').write_text(log)
    meta = dict(script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), tests=result.testsRun,
                failures=len(result.failures), errors=len(result.errors), skipped=len(result.skipped),
                log_sha256=hashlib.sha256(log.encode()).hexdigest(),
                boundary='Synthetic snapshots/manifests and recorded pidfd/poll only; no /proc reads, real pidfd, worker observation or application execution.')
    (ROOT / 'watch-owned-421-v4-selftests.json').write_text(json.dumps(meta, indent=2) + '\n')
    return 0 if result.wasSuccessful() else 1


if __name__ == '__main__':
    if sys.argv[1:] == ['--self-test']:
        raise SystemExit(self_test())
    if len(sys.argv) != 3 or sys.argv[1] != '--watch':
        raise SystemExit('Specify --self-test or explicitly reviewed --watch RUN_DIRECTORY')
    raise SystemExit(watch(sys.argv[2]))
