#!/bin/sh
set -eu
umask 077
cd /mnt/e/private/gitcraft-worktrees/final-maintainability
printf '%s\n' "$$" > /mnt/e/private/gitcraft-build/final-421-worker.pid
exec python3 /mnt/e/private/gitcraft-build/run-final-candidate-v5.py 4212389c6ce69ee6dba14a31a9972a54d5a2266d > /mnt/e/private/gitcraft-build/final-4212389c-progress.log 2>&1
