# Owner record: receipt-only421 observer v4

Implementer handoff only; independent root review and actual observation remain pending. New source `watch-owned-421-worker-v4.py` SHA256 `97aa421e7291fd94695222a7b33c00bfda5e2fe9c9e56d518b96bd46e636819d`,284 physical lines including the seven recording tests.

V4 is an exact identity/artifact-name rebind of frozen v3 `watch-owned-580-worker-v3.py`, verified before copying and afterward at SHA256 `f37918f86c73d591122e828e1da9000f02f19394d0044c46d43751af5e8d90ba`. Static full-source equality with the five approved substitutions was asserted. The preserved diff records only HEAD, tree, receipt, run-prefix and selftest output prefixes. ARGV derives from HEAD. No control features, ownership checks, polling, manifest rules, CLI flags or runner behavior changed. All earlier scripts/proof/reviews/logs remain untouched; failed580 observation does not validate421.

Exact binding:

- HEAD `4212389c6ce69ee6dba14a31a9972a54d5a2266d`; tree `5ae3781e43d4d97c4ed3190020da15bd07d0ffaf`.
- Runner `/mnt/e/private/gitcraft-build/run-final-candidate-v5.py`; unchanged SHA256 `d0f64d5404cf755e988bf634d203d7e9d97896490ad62b0c0f42f51db8a4508a`.
- Exact argv `python3 /mnt/e/private/gitcraft-build/run-final-candidate-v5.py 4212389c6ce69ee6dba14a31a9972a54d5a2266d`.
- Expected cwd `/mnt/e/private/gitcraft-worktrees/final-maintainability`; all four Linux UID fields equal the observer UID.
- Owned receipt `/mnt/e/private/gitcraft-build/final-421-worker.pid`.
- Caller-selected run directory resolves to a direct E-build-root child with prefix `validation-4212389c-`.

Only the receipt PID is examined, with stable starttime/identity snapshots around pidfd binding, receipt bytes checked across binding/final success and runner hashes before/after binding/final success. No discovery, signal, spawn, cleanup command, application execution, Git/index/status inspection or CI action was added or performed. Pidfd polling observes readiness only; completion explicitly reports unavailable nonchild exit status (`child_exit_code_available=false`, `child_exit_code=null`). Observer success requires the selected manifest's exact source/tree/runner, passed status, nonempty finished string,39 unique checks, typed integer-zero exits and exact clean source/tree before/after every check. It does not recover a child exit code.

Executed only the new script's `--self-test`: seven passed, zero failures/errors/skips. Fixtures use synthetic receipt/snapshot/manifests and recording pidfd/poll boundaries. No actual receipt, `/proc`, pidfd, active results or worker was read. The tests retain coverage of exact identity, receipt syntax/mismatch/change, binding rechecks and recorded descriptor closure, run-prefix/direct-child restriction, final manifest refusal, progress/completion, unavailable child status and poll errors.

Frozen proof artifacts:

- `watch-owned-421-v4-selftests.json`: `c2010e53e5816b40c91439dd826e916d6043f533ecb8ded0b38e0a94c95ee063`
- `watch-owned-421-v4-selftests.log`: `53fb78c9ea38d233f7c66a1e09bbc9a635b670c5c76c9fe09ecf23aab7b4b70e`
- `watch-owned-421-v4-rebind.diff`: `bd980eed38a02775099e798d3bce89de8a52d876193fbba8b4820999fd01be8b`

Root owns independent review (corresponding suggested filename `review-watch-owned-421-v4-root.md`) and any later actual launch:

    python3 /mnt/e/private/gitcraft-build/watch-owned-421-worker-v4.py --watch RUN_DIRECTORY

That command has NOT been executed by this author. Supply the exact new run directory after the owned launcher has exec'd Python. Redirect observation stdout/stderr INSIDE Linux to a new E-drive log, independently of Windows wrapper pipes. Root's launcher `launch-final-421-linux.sh` and progress `final-4212389c-progress.log` remain root-owned; the observer changes no umask or worker environment. No app tests/builds, CI, actual observer start or product/Git mutation occurred. All new source/proof/note writes are E-only. V4 is now frozen and handed back to root.
