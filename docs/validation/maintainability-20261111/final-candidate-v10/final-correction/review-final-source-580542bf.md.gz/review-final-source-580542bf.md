# Independent exact source binding: 580542bf

Verdict: **SOURCE PASS** for immutable consolidated candidate `580542bfc9ff4d1586077beb57193768d0149fe4`, complete tree `091687f298049acfa30ef376e6a858b103ad97e2`, parent `205d7528a82e464a6ebbfe0cc022bb6047fdff2f`, grandparent `92656fb7d7c49a728824df9548cccf2c35325ad4`. No concrete blocking defect was found in the complete two-unit correction delta. Full combined validation of this new candidate remains separate; no compile, runtime or CI pass is claimed.

## Whole-tree scope and provenance

Explicit immutable Git-object inspection establishes exactly five changed paths from the previously reviewed926 source:

- src/git/file_comparison/index_transaction/tests.rs (186 physical lines)
- src/git/file_comparison/index_transaction/tests/policy.rs (215)
- src/repo/core_seams/palette_actions.rs (280)
- src/repo/core_seams/palette_contexts.rs (198)
- src/repo/core_seams/palette_shortcuts.rs (104)

The complete tree delta contains no other source, test, documentation, gate, dependency or configuration changes. The palette_actions.rs change consists solely of a cfg(test)-gated module declaration. All remaining edits are test code or test organization. Application production behavior, runner and quality gates are unchanged from926. Both new commits have one parent; the full history after dev57d7395bce9e187ff9f2a3ce9b96dc0d65715600 has27 single-parent units, each using exactly Jonas Kamsker <11245306+JKamsker@users.noreply.github.com> as author and committer.

The independently reviewed926 production/palette source remains retained, including complete-tree412 equivalence within that earlier scope. Preserved review-final-source-92656fb7.md SHA256 `3765448cc72a4a23f324cbdf31eac89c5969cb213a915209d59f55850e59d568` and review-palette-412d1118-nav.md SHA256 `52506241f932ea58ee4116ec6f373d8222d362dcb89c5d5fb376a5774db968b8` remain source evidence, not successful application execution. The new permission unit's independent review review-permission-fixtures-205d7528-nav.md SHA256 `2c670c14920a8af9b90927466c7eca3baf481ce8f78d0002ec4834b585b17844` binds its exact first correction commit.

## Permission fixture correction

The existing configured-private/group test and macOS ACL test move into a cohesive policy child module; parent test helpers/imports remain accessible through Rust descendant privacy. Parent Unix test gating and macOS-specific gating remain intact. The existing owner/group test stays in its prior module, preserving its exact runner filter. Native Git mode comparisons, unrelated staged-entry assertions and absent-index0600 behavior are retained.

The original drift fixture now establishes core.sharedRepository=false before recapturing the lens. Its configuration change to0600 is therefore intentional, and is read back. The mode branch reads its baseline, derives a guaranteed different mode by XOR0040 and verifies readback. Hook success is required; an unrelated early failure cannot satisfy refusal. Original index bytes, working bytes and unrelated staged content remain checked.

The new six-case matrix crosses initial0600/0644/0660 with same-mode versus genuine mode change. It explicitly installs matching numeric Git sharing policy and exact owned index mode before lens capture. The hook verifies the baseline and target; genuine drift must refuse without changing original staged bytes/content, whereas same-mode chmod must succeed. Every case checks final mode, unchanged worktree bytes and unrelated staged entry. Owner read/write remains available and no executable/privileged bit or global umask is changed. This is generalized actual publication coverage rather than weakening production's state-based policy guard.

## Palette shortcut fixture correction

The new test-only palette_shortcuts module separates Default, valid Custom, Unbound and deliberately Conflicting inputs. The Custom sequences all use an unbound F6 prefix followed by distinct suffix keys; this avoids plain F7's real NextChange conflict. Conflicting deliberately uses the original plain-key map and independently expects safe default fallback for the entire invalid map. I inspected the unchanged BINDINGS, config::validate/usable and Settings::put_for_test implementations against those assumptions.

Expected labels derive from explicit context semantics and the default binding registry rather than the production effective/usable resolution helper. Installation verifies all seven relevant command labels. The composed transport matrix still checks typed actions, ordered labels/hints and review/offline behavior across16 contexts (2review x2pause x4shortcut), and now compares against the independent expected context labels. The existing16 composed repository contexts remain. A new same-egui-Context transition test repeatedly installs custom/conflicting/unbound/default settings and verifies all seven labels after each change, guarding stale settings/fallback behavior.

No keymap or palette production change is made to accommodate an invalid fixture. The newly added tests exercise genuine policy drift/no-op distinctions and valid/invalid shortcut boundaries while preserving the accepted feature behavior.

## Evidence limits

The parent reports the926 run completed its available33 checks with library5230 passed,2 failed,27 ignored and4 filtered. That failed run must remain failed evidence; this source review does not relabel it. Two added tests make5234 the expected new library-pass count if the replacement candidate succeeds; this is an inventory expectation, not observed execution. Parent-reported physical cap/fmt/push checks are not claimed as newly executed here.

I used explicit immutable Git reads with GIT_OPTIONAL_LOCKS=0 and read preserved review notes. No mutable status/index refresh, application/source edit, build/test, CI action, active-run poll or process control was performed. Only this standalone E-drive source-binding note and its SHA256 sidecar were written. The exact580 combined runtime/archive/documentation-head gates remain required before delivery.
