# Immutable index-policy failure scout

Source reviewed: `92656fb7d7c49a728824df9548cccf2c35325ad4`, tree `8f188f3aa5feab6597f1bdc0a9bf735c4604384c`. This is a source-only diagnosis and proposed generalized fixture correction. The active full-suite failure body and owned completion have not been observed by this reviewer; no runtime result is inferred here.

## Findings

1. **Confirmed test precondition defect:** `src/git/file_comparison/index_transaction/tests.rs:172-195` unconditionally changes the original index to mode0600 in the metadata-drift hook, then unconditionally expects refusal. With an inherited restrictive umask077 the initial index can already be0600. The hook then changes no policy. Production correctly compares the captured/current inode, contents, access metadata, complete mode, UID and GID; matching state is allowed. Thus this test can falsely fail without a production regression. Parent reports that the new launcher sets umask077; this explains why an unchanged source test can fail after an earlier run passed under another launcher environment. The actual failure assertion still needs the completed log to confirm this attribution.

2. **Additional environment-dependent test precondition:** the configuration-drift branch changes effective `core.sharedRepository` to0600 without establishing a different initial effective value. `tests::Repo::command` disables system configuration, but does not disable global configuration. An inherited effective0600 would make this a second no-op. The current runner reportedly isolates global configuration, so this is a generalized fixture issue rather than evidence of the present failure.

3. **Regression precision gap:** checking only `result.is_err()` and unchanged index bytes does not establish that the hook was reached, the intended policy actually changed, or refusal came from that drift. An unrelated earlier refusal could satisfy the negative assertion. Pairing each refusal case with a successful no-drift case and recording the injection/readback would strengthen the regression materially.

## Proposed correction after the active run completes

- Configure the owned fixture's initial sharing policy explicitly, e.g. local `core.sharedRepository=false`, instead of inheriting that policy.
- For metadata drift, use an explicit baseline matrix0600/0644 (optionally0660 for group permissions). Set the mode on that owned fixture, read it back, and acquire the staging lens afterward. Avoid changing process-global umask in a multithreaded test binary.
- Derive a genuinely different mode from the observed baseline, e.g. toggle group-read with `mode ^ 0o040`, retaining owner read/write. Record that `Prepared` ran and that readback equals the requested changed mode and differs from the captured mode. Check refusal leaves original index bytes, unrelated index entries, working bytes and the externally injected mode intact.
- Include same-mode chmod positive controls for restrictive and permissive baselines. They should publish the patch successfully using native Git's resulting permission policy. This prevents a purported fix that rejects all metadata calls or demands an error for a no-op. Do not require the published mode to equal the old mode when native Git's configured policy/umask chooses a different mode.
- Keep configuration drift separate: capture explicit initial effective policy, mutate to a verified different0600 at `Prepared`, require refusal and unchanged index contents. If adding a same-policy control, require success rather than refusal.
- A pure snapshot equality matrix can cover equal versus distinct mode/UID/GID independently of filesystem capabilities; the actual apply-hook matrix must remain to exercise publication refusal. The existing real alternate-group ownership case remains conditional on supplementary-group availability, and is not proof that every environment executed a real group change.

No production change is supported by this failure hypothesis. In particular, treating a same-mode chmod as stale policy would weaken the intended state-based contract. The implementation snapshots effective sharing configuration separately from filesystem mode, uses native Git for candidate mode, and checks original policy again before publication. This review does not claim exhaustive proof against arbitrary adversarial races.

## Immutable binding and limits

The following blobs are byte-identical to `f177144f0a16741ef5016cb3029ab6857e125ae3` (explicit object diff returned0):

- `src/git/file_comparison/index_transaction.rs`: `d4e33e2013c44e43309f8bc55bdc25faabeaaa16`
- `src/git/file_comparison/index_transaction/tests.rs`: `a28a2a8ae96a51a8efd18c9de5d199bd85143604`
- `src/git/file_comparison/tests.rs`: `bb9db25b50a3109fecd754e0b61fa6c557e0302b`
- `src/standalone/access.rs`: `889cf822c56f8f91c109e5770c17c6c3642bd92a`

Only explicit immutable Git object reads were used for app source. No app source/index/status mutation, build, test, CI operation, global environment mutation in the running worker, or process signal was performed. This report is an actionable source diagnosis, not a runtime pass or approval of a future fix.
