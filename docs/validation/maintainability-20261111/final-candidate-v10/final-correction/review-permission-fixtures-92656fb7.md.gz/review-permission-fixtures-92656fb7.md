# Read-only permission-fixture scout

Candidate: 92656fb7d7c49a728824df9548cccf2c35325ad4, tree 8f188f3aa5feab6597f1bdc0a9bf735c4604384c.

Scope: source-only search for other policy-drift fixtures whose fixed chmod can be a no-op, or whose assertions rely on permissive ambient umask. The failing file_comparison::index_transaction fixture is owned by the navigation scout; no duplicate implementation or detailed re-review of that failure is claimed here. All source inspection used explicit immutable Git objects with GIT_OPTIONAL_LOCKS=0. No source edits, builds/tests, CI, mutable index/status refresh, active-run polling or process actions were performed. The active final run must finish normally before future changes.

Verdict: no additional concrete fixed-chmod/no-op drift assertion found within this scoped search. This is not a claim that every filesystem test is environment-independent.

Searches covered Rust mode literals 0600/0640/0660/0644/0664/0755 and chmod/set_permissions/readonly/policy-drift patterns throughout tracked src/ and crates/, followed by source inspection of relevant permission preservation, native policy and standalone-save fixtures. Most chmod calls establish executable helper setup rather than simulate policy drift.

Specific adjacent fixtures:

- drafts/native_files/saved_policy_tests.rs explicitly constructs policy mode decimal416 (0640), then changes it to0600 and asserts inequality. It is pure value serialization coverage; the mode change is genuine and independent of filesystem umask.
- drafts/tests.rs sets0600 before preview/restore and asserts preservation. A no-op chmod there is valid setup, not a promised policy-drift mutation followed by refusal.
- drafts/lists/tests.rs, drafts/tests/turns.rs and drafts/virtuals/tests.rs explicitly establish0640 and check recovery preservation. They do not depend on initial creation permissions for their checked mode.
- file_comparison/transaction/owned_remote_correction_tests.rs deliberately forces actual native index rewrites after changing core.sharedRepository, records the resulting native mode and compares publication against that measured reference. Its absent-index0600 expectation is tied to explicitly configured0600 policy. This is already robust against a no-op git add retaining an earlier inode/mode.
- standalone/save/tests/transaction.rs makes a new writable owned output readonly before asserting capture refusal, then restores its captured permissions. An ambient077 creation mask still leaves owner read/write before the readonly transition.
- standalone/permissions.rs explicitly sets04755 before testing metadata preservation and removal of privileged bits. Script/executable fixture paths elsewhere explicitly set executable modes; these are setup operations, not drift witnesses.
- Native macOS/Windows policy-drift families use explicit ACL/attribute changes rather than the Unix creation umask. Their platform execution is outside this scout.

Recommended generalized regression pattern for the already identified drift fixture:

1. Keep native Git sharing-policy comparisons based on the actual native rewrite reference; do not replace their intended semantics with hardcoded final modes.
2. For the specific drift subcases, establish deterministic safe per-file initial modes on owned files before snapshot capture, or read the actual captured mode and derive a guaranteed distinct mutation. Exercise initial0600/0640/0660 where practical so restrictive and shared-mode starts are covered explicitly.
3. Toggle only one safe non-owner permission bit, for example `(before & 0777) ^ 0040`, and assert the observed before/after modes differ before expecting refusal. This retains owner read/write and changes no executable/setuid/setgid bit. Owned fixture parents should remain private, so adding group-read on a fixture does not expose unrelated paths.
4. Cover no-change controls separately from genuine drift: unchanged policy should be accepted when the rest of the operation permits it; a successful chmod to the same mode is not drift. For every deliberate drift phase, retain the safety assertions for refusal and original bytes/index/foreign entries.
5. Do not call process-global umask in the parallel Rust harness. If ambient-umask variation is later desired, select it only at an explicitly owned isolated child boundary. Deterministic initial per-file modes and observed-mutation assertions are sufficient to regress the reported no-op bug without launcher/environment changes.

Only this E-drive scout note and its SHA256 sidecar were written. The parent/navigation owner should resolve the already confirmed fixture issue after the current full run completes, retain failed-run evidence, and bind any replacement candidate validation independently.
