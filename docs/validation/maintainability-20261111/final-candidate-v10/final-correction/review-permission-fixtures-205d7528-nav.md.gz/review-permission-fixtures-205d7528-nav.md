# Independent source review: permission fixture correction

Verdict: **PASS, source only; compilation and runtime pending.** No blocking defect found in the exact published unit `205d7528a82e464a6ebbfe0cc022bb6047fdff2f`, tree `6c3414ba499c254d6c363c1331b759b9e5d8b10d`, parent `92656fb7d7c49a728824df9548cccf2c35325ad4`. Author and committer both match `Jonas Kamsker <11245306+JKamsker@users.noreply.github.com>`.

The completed926 assertion at the original tests.rs195, reported by the parent, confirms the earlier source diagnosis: chmod0600 need not change a restrictive initial index. This unit corrects the fixture while retaining production's state-based policy comparison.

## Scope and extraction

The entire immutable parent-to-unit diff changes only:

- `src/git/file_comparison/index_transaction/tests.rs`: blob `1e16a133f39c596b58f75762c3d65e04c29cc555`,186 physical lines.
- `src/git/file_comparison/index_transaction/tests/policy.rs`: blob `1e87dffe4ae13bc472784c2fc3aea5f9d93962cc`,215 physical lines.

No production, runner, gate, dependency or unrelated fixture source changes. The child module groups index metadata/configuration and native ACL policy tests around their existing parent fixture/helpers; Rust descendant privacy permits the inherited imports/helpers. The parent remains gated by `cfg(all(test, unix))`, and the macOS-specific test retains its narrower platform gate. The new child module path matches the Rust filesystem hierarchy. Both changed Rust files remain below300 physical lines.

The original native0600/group comparison, selected/unrelated index assertions and empty-index0600 publication case remain. The macOS ACL preservation/drift function and retained owner/group function compare exactly after normalizing Git-show line separators. Original foreign-lock, parent-swap, late-creator and split-index behavior/assertions remain unchanged. The isolated owner/group test's full module path remains unchanged for the runner's exact filter. The extracted configuration/native-ACL test names acquire the child `policy` segment; neither immutable tracked source nor the reviewed E runner has an exact filter for their former full names.

## Corrected preconditions and generalized regression

The original metadata/configuration drift loop now explicitly establishes fixture-local sharing policyfalse before reacquiring the staging lens. Changing configuration to0600 is consequently a real policy change rather than an assumption about inherited effective configuration. The hook reads back0600. The metadata branch derives its target from the observed initial permissions with XOR0040, proves inequality, performs the chmod and reads back the target. Both branches require the successful injection hook to have run, propagate setup/operation errors, require refusal, and retain original index bytes, working bytes and the unrelated index entry.

The additional matrix executes0600/0644/0660 baselines crossed with no-op/drift, six actual apply cases. Each case explicitly configures matching numeric Git sharing policy, sets/read-verifies the owned index mode, and acquires its lens afterward. At `Prepared`, the hook verifies the captured baseline is still current, performs the requested chmod and checks exact readback. Recording success is required, so an earlier unrelated error cannot satisfy the negative case.

Drift cases require an error, byte-identical original index and original staged `a` content. No-op cases require success and staged `a=after`. Every case checks the final target mode, unchanged working `a`, and unchanged unrelated staged entry. Numeric sharing policy makes native Git's published candidate mode agree with these explicit baselines; the success assertions do not assume an arbitrary preexisting mode survives an unrelated Git policy. This covers restrictive, ordinary readable and group-writable baselines without process-global umask/environment changes. Same-mode positive controls prevent a false fix that rejects harmless chmod calls.

Production's inode/content/access-metadata/mode/ownership/configuration comparisons remain unchanged. There is no new I/O outside fixture-owned repositories, process-control logic, global permission mutation, or weakening of refusal semantics in this unit.

## Evidence limits

This reviewer used explicit immutable Git object reads with optional locks disabled. The only writes were this E-only report. No mutable index/status inspection, application build/test, CI action, process signal or app source edit was performed. Parent-reported formatting, complete-index cap checks and verified remote receipt are not claimed as newly executed by this review. The verdict is source approval of this exact unit, not compilation/runtime validation or approval of later commits.
