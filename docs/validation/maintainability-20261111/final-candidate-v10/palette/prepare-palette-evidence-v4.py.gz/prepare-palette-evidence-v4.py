from pathlib import Path
import ast
import hashlib

root = Path('/mnt/e/private/gitcraft-build')
old = root / 'preserve-navigation-candidate-evidence-v3.py'
assert hashlib.sha256(old.read_bytes()).hexdigest() == '1d3d9722455ac6f2f4fb6f7fed4cca775e63c4879c25cc0c8251d0008f10762f'
text = old.read_text(encoding='utf-8')

def replace(before, after, count=1):
    global text
    assert text.count(before) == count, (before, text.count(before))
    text = text.replace(before, after)

replace("CANDIDATE = 'f177144f0a16741ef5016cb3029ab6857e125ae3'", "CANDIDATE = '02a5c7ce7de437abd6e740e4bb267c7c083afaf9'")
replace("TREE = '383c0c92b59d2ea05d17217234852dc8a4d6e158'", "TREE = '0c768d70e35233a71f88bdb6b74c036c37fcafc7'")
replace("PARENT = 'b1963845825e2f5872a89adbeca45b562780fa42'", "PARENT = 'f177144f0a16741ef5016cb3029ab6857e125ae3'")
replace('final-candidate-v6', 'final-candidate-v7')
replace('validation-f177144f-', 'validation-02a5c7ce-')
replace('maintainability/validated-v6', 'maintainability/validated-v7')
replace('len(authors) == 24', 'len(authors) == 25')
replace("assert set(git('diff', '--name-only', PARENT, CANDIDATE).splitlines()) == set(paths)", """palette_source = '5b57110664e824c93b2c89d4ecfc518eeb05daa3'
assert git('rev-parse', palette_source + '^{tree}') == TREE
palette_paths = git('diff', '--name-only', PARENT, palette_source).splitlines()
assert len(palette_paths) == 19 and all(path.startswith('src/repo/') and path.endswith('.rs') for path in palette_paths)
assert set(git('diff', '--name-only', PARENT, CANDIDATE).splitlines()) == set(palette_paths)""")
replace('passed=5228', 'passed=5232')
replace("for name in required_tests:", """palette_tests = [
    'repo::actions::palette_actions::palette_contracts::feature_contributions_preserve_order_search_hints_and_exact_targets',
    'repo::actions::palette_actions::palette_contexts::transport_intents_and_shortcuts_follow_review_pause_and_keymap_contexts',
    'repo::actions::palette_actions::palette_contexts::owned_groups_keep_their_global_slots_across_repository_contexts',
    'repo::dialogs::stash::palette_tests::palette_stash_intents_keep_their_exact_confirmation_choices',
]
for name in palette_tests:
    assert re.search(r'^test ' + re.escape(name) + r' \\.\\.\\. ok$', library_log, re.M), name
for name in required_tests:""")
replace("'preserve-navigation-candidate-evidence-v3.py',", "'preserve-palette-candidate-evidence-v4.py',")
replace("'final-f177144f-progress.log',", "'final-02a5c7ce-progress.log',")
replace("'review-navigation-evidence-helper-v3.md',", "'review-palette-evidence-helper-v4-root.md',")
replace("'review-navigation-evidence-helper-v3-adversarial.md',", "'review-palette-evidence-helper-v4-adversarial.md',")
replace("# Missing inputs must fail before the first destination write.", """sources += [(ROOT / name, 'palette/' + name) for name in [
    'review-maintainability-scope-c16814db.md', 'review-remaining-hotspots-f177144f.md',
    'review-palette-423758ee-nav.md', 'review-palette-5b571106-nav.md',
    'review-palette-5b571106-root.md', 'review-final-source-02a5c7ce.md',
    'palette-owners-source-parity-5b571106.json',
    'palette-owners-size-working.log', 'palette-owners-size-staged.log',
    'combined-palette-size-working.log', 'combined-palette-size-index.log',
    'palette-final-candidate-remote.txt',
    'preserve-navigation-candidate-evidence-v3.py',
    'test_palette_archive_guards_v4.py', 'palette-archive-guards-v4-results.json',
    'palette-archive-guards-v4-regressions.log', 'prepare-palette-evidence-v4.py',
]]
# Missing inputs must fail before the first destination write.""")
replace('parent=PARENT, history_units=24', 'parent=PARENT, history_units=25, palette_source=palette_source')
replace('# Navigation follow-up candidate validation', '# Consolidated maintainability candidate validation')
replace("""Its parent `{PARENT}` preserves the failed Linux CI evidence. The 24 linear
history units begin at dev `57d7395bce9e187ff9f2a3ce9b96dc0d65715600`.
Application production source and quality gates are unchanged from `0622a2ac`.""", """The complete candidate tree equals reviewed combined source `{palette_source}`.
Its parent `{PARENT}` retains the corrected navigation unit and failed Linux CI
evidence. The 25 linear history units begin at dev
`57d7395bce9e187ff9f2a3ce9b96dc0d65715600`. The final feature unit changes 19
palette ownership/test paths; all other application and gate files match its parent.
Feature contributors preserve ordered labels, hints, typed actions and operands.
Four new palette tests check 12 review/offline/keymap contexts, 16 composed
review/selection/busy/LFS contexts, fixed intent contracts and stash choices.
The original source-only palette unit had corrupted expected Unicode ellipses;
its blocked review is preserved. The corrected expectations use explicit Unicode
escapes and compare the unchanged actual user-visible labels. No runtime failure
or success is claimed for that superseded, unexecuted source unit.""")
replace('The library passed 5,228 tests', 'The library passed 5,232 tests')
replace('All six navigation tests also ran in the full library suite.', 'All six navigation tests and all four new palette tests also ran in the full library suite.')
ast.parse(text)
target = root / 'preserve-palette-candidate-evidence-v4.py'
assert not target.exists()
target.write_text(text, encoding='utf-8', newline='\n')
print(hashlib.sha256(target.read_bytes()).hexdigest())
