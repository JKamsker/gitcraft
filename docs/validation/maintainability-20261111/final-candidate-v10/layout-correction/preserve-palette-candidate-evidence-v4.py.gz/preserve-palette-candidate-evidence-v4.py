"""Archive a complete 39-gate pass for the navigation-fixture follow-up."""
import gzip
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys

ROOT = Path('/mnt/e/private/gitcraft-build')
REPO = Path('/mnt/e/private/gitcraft-worktrees/final-maintainability')
CANDIDATE = '02a5c7ce7de437abd6e740e4bb267c7c083afaf9'
TREE = '0c768d70e35233a71f88bdb6b74c036c37fcafc7'
FIX = 'e831e401bff29ea90991469abe6185dcf31d5cfa'
PARENT = 'f177144f0a16741ef5016cb3029ab6857e125ae3'
RUNNER = 'd0f64d5404cf755e988bf634d203d7e9d97896490ad62b0c0f42f51db8a4508a'
DEST = REPO / 'docs/validation/maintainability-20261111/final-candidate-v7'
FAILED_C168_RESULTS_SHA = '45204a6d9d5ae0f4efff791d29a1d023311a5502606693de8e00a94e54df3c10'
FAILED_C168_LOG_SHA = '5847541645c5f2900f8b11caf7c301456c2fdda8456e8975066bcf2ae8ca0c0b'
FAILED_C168_LABELS = [
    'rust_file_size-working', 'rust_file_size-index', 'rust_file_size-revision',
    'complexity_policy-working', 'complexity_policy-index', 'complexity_policy-revision',
    'tooling-regressions', 'fmt', 'check', 'clippy-packages',
]
assert len(sys.argv) == 2
RUN = Path(sys.argv[1]).resolve()
assert RUN.is_relative_to(ROOT.resolve()) and RUN.name.startswith('validation-02a5c7ce-')


def sha(data):
    return hashlib.sha256(data).hexdigest()


def git(*args):
    return subprocess.check_output(
        ['git', '-c', 'core.autocrlf=true', '-C', str(REPO), *args], text=True,
        env={key: value for key, value in os.environ.items() if not key.upper().startswith('GIT_')},
    ).strip()


assert git('rev-parse', 'HEAD') == CANDIDATE
assert Path(git('rev-parse', '--show-toplevel')).resolve() == REPO.resolve()
assert git('rev-parse', 'HEAD^{tree}') == TREE and git('rev-parse', 'HEAD^') == PARENT
assert git('branch', '--show-current') == 'maintainability/validated-v7'
assert git('status', '--porcelain') == '' and not DEST.exists()
authors = git('log', '--format=%an <%ae>', '57d7395bce9e187ff9f2a3ce9b96dc0d65715600..HEAD').splitlines()
assert len(authors) == 25 and set(authors) == {'Jonas Kamsker <11245306+JKamsker@users.noreply.github.com>'}
paths = ['src/repo/navigation/manual_history.rs', 'src/repo/navigation/tests.rs', 'src/repo/navigation/tests_repository.rs']
palette_source = '5b57110664e824c93b2c89d4ecfc518eeb05daa3'
assert git('rev-parse', palette_source + '^{tree}') == TREE
palette_paths = git('diff', '--name-only', PARENT, palette_source).splitlines()
assert len(palette_paths) == 19 and all(path.startswith('src/repo/') and path.endswith('.rs') for path in palette_paths)
assert set(git('diff', '--name-only', PARENT, CANDIDATE).splitlines()) == set(palette_paths)
blobs = {path: git('rev-parse', CANDIDATE + ':' + path) for path in paths}
assert blobs == {
    'src/repo/navigation/manual_history.rs': 'c72fc781aa77f79fb4b35909b2c8f47adffe6427',
    'src/repo/navigation/tests.rs': '0647eb9a4ce4088738809b4664982ddc6cc76134',
    'src/repo/navigation/tests_repository.rs': 'ca42f1c2209c77d05ca0d3aa1f5748925409bd02',
}
assert all(blobs[path] == git('rev-parse', FIX + ':' + path) for path in paths[:2])
repository_tests = 'src/repo/navigation/tests_repository.rs'
original_tests = git('show', FIX + ':' + repository_tests)
current_tests = git('show', CANDIDATE + ':' + repository_tests)
old_expected_slice = 'assert_eq!(tab.nav.entries(), &[current.clone()]);'
new_expected_slice = 'assert_eq!(tab.nav.entries(), std::slice::from_ref(&current));'
assert original_tests.count(old_expected_slice) == 1
assert current_tests == original_tests.replace(old_expected_slice, new_expected_slice, 1)
results_raw = (RUN / 'results.json').read_bytes()
results = json.loads(results_raw)
assert results['commit'] == CANDIDATE and results['tree'] == TREE
assert results['status'] == 'passed' and results.get('finished')
assert results['runner_sha256'] == RUNNER == sha((ROOT / 'run-final-candidate-v5.py').read_bytes())
# All original labels remain; the reviewed runner adds six exact navigation probes.
prior_raw = (ROOT / 'validation-0e6a8e52-2ypil253/results.json').read_bytes()
assert sha(prior_raw) == '098ebc67b6efd04411f6403ea9fd34f24b8bd677d16aa1fdb00f92eb56c545c3'
prior = json.loads(prior_raw)
checks = results['checks']
navigation_labels = {'nav-recording-manual-history', 'nav-recording-user-selection', 'nav-recording-forward-history', 'nav-history-walk', 'nav-history-selection', 'nav-history-links'}
assert len(checks) == 39 and len({entry['label'] for entry in checks}) == 39
assert {entry['label'] for entry in checks} == {entry['label'] for entry in prior['checks']} | navigation_labels
for entry in checks:
    if entry['label'] in navigation_labels:
        assert len(entry['test_summaries']) == 1
        count = entry['test_summaries'][0]
        assert count['passed'] == 1 and count['failed'] == count['ignored'] == 0
assert next(entry for entry in checks if entry['label'] == 'tooling-regressions')['python_test_count'] == 61
for label in ['clippy-packages', 'windows-cross-clippy-packages']:
    assert 'Clippy packages: 3 checked.' in (RUN / (label + '.log')).read_text()
for entry in checks:
    assert type(entry['exit']) is int and entry['exit'] == 0
    assert entry['before']['head'] == entry['after']['head'] == CANDIDATE
    assert entry['before']['tree'] == entry['after']['tree'] == TREE
    assert entry['before']['status'] == entry['after']['status'] == ''
    assert sha(Path(entry['log']).read_bytes()) == entry['sha256']
library = next(entry for entry in checks if entry['label'] == 'runtime-gitcraft-lib')
assert library['test_summaries'] == [dict(passed=5232, failed=0, ignored=27, measured=0, filtered=4)]
library_log = Path(library['log']).read_text()
required_tests = [
    'back_and_forward_through_a_repository',
    'back_to_a_diff_selects_its_commit_again',
    'following_links_to_commits_are_steps',
    'manual_history::manual_graph_diff_file_history_is_independent_of_detail_readiness',
    'manual_history::user_selection_and_explicit_same_file_toggle_keep_their_distinct_meanings',
    'manual_history::manual_graph_refinement_and_diff_selection_do_not_depend_on_cached_details',
]
palette_tests = [
    'repo::actions::palette_actions::palette_contracts::feature_contributions_preserve_order_search_hints_and_exact_targets',
    'repo::actions::palette_actions::palette_contexts::transport_intents_and_shortcuts_follow_review_pause_and_keymap_contexts',
    'repo::actions::palette_actions::palette_contexts::owned_groups_keep_their_global_slots_across_repository_contexts',
    'repo::dialogs::stash::palette_tests::palette_stash_intents_keep_their_exact_confirmation_choices',
]
for name in palette_tests:
    assert re.search(r'^test ' + re.escape(name) + r' \.\.\. ok$', library_log, re.M), name
for name in required_tests:
    assert re.search(r'^test ' + re.escape('repo::navigation::tests::' + name) + r' \.\.\. ok$', library_log, re.M), name
lint_raw = (ROOT / 'ci-43109642223-lint-job.json').read_bytes()
assert sha(lint_raw) == 'bc937cbd6c3663c857d85515ba4d4d449176b128b4b957b52c2b1437502d35c7'
lint = json.loads(lint_raw)
assert lint['id'] == 130822169327 and lint['run_id'] == 43109642223
assert lint['head_sha'] == '0622a2ac1237311e29f6dcc94788b30f5b094bb4'
assert lint['conclusion'] == 'success' and lint['status'] == 'completed'
for name in ['Formatting', 'Clippy']:
    assert next(step for step in lint['steps'] if step['name'] == name)['conclusion'] == 'success'
assert sha((ROOT / 'ci-43109642223-lint.log').read_bytes()) == '1fcb3c7d276592e142283f6c7ed78efdef78b290ae07eca42316ee2f4a796648'
sources = [(RUN / 'results.json', 'results.json')]
sources += [(Path(entry['log']), 'logs/' + entry['label'] + '.log') for entry in checks]
sources += [(ROOT / name, 'provenance/' + name) for name in [
    'run-final-candidate-v5.py', 'preserve-palette-candidate-evidence-v4.py',
    'final-02a5c7ce-progress.log', 'nav-ci-fixture-e831e401.md',
    'nav-v3-candidate-remote.txt', 'ci-followup-archive-remote.txt',
    'combined-nav-v3-size-working.log', 'combined-nav-v3-size-index.log',
    'ci-followup-size-working.log', 'ci-followup-size-index.log',
    'ci-43109642223-lint-job.json', 'ci-43109642223-lint.log',
    'test_final_digest_v5_d0f64d54.py', 'digest-v5-d0f64d54-results.json',
    'digest-v5-d0f64d54-regressions.log',
]]
sources += [(ROOT / name, 'reviews/' + name) for name in [
    'review-navigation-e831e401.md', 'review-nav-fixture-e831e401-lifecycle.md',
    'review-palette-evidence-helper-v4-root.md',
    'review-palette-evidence-helper-v4-adversarial.md',
    'review-final-documentation-0622a2ac.md',
    'review-final-runner-v5-d0f64d54.md', 'review-nav-fixture-e831e401-fresh.md',
    'review-nav-fixture-f177144f-fresh.md',
]]
def validate_stopped_results(stopped_raw, receipt_raw, late_raw):
    """Bind the final refused run and the preserved initial observation receipt."""
    result, receipt, late = map(json.loads, (stopped_raw, receipt_raw, late_raw))
    old_head = '97a6aba4073ea465cb4241123c2d1379766ca234'
    old_tree = '0cea01cc09874f7043cf72990ce3fa5a935cad04'
    old_runner = 'fba211409fd0f961eb803af8d332eca08be039ea241fba7cd4ffec9be5e623b3'
    assert result['commit'] == receipt['commit'] == late['commit'] == old_head
    assert result['tree'] == receipt['tree'] == late['tree'] == old_tree
    assert result['runner_sha256'] == receipt['runner_sha256'] == old_runner
    assert result.get('status') != 'passed'
    assert result['fatal'] == late['fatal'] == 'Candidate dirty or changed during build-tests'
    assert late['results_sha256'] == sha(stopped_raw)
    assert late['initial_observation_receipt_sha256'] == sha(receipt_raw)
    assert late['initial_observation_results_sha256'] == receipt['results_sha256'] == '5e42014aa133bcf5130f644e33eb763eebd79b04198231814ec8cb833257c0be'
    assert late['application_runtime_executed'] is False
    static_labels = [
        'rust_file_size-working', 'rust_file_size-index', 'rust_file_size-revision',
        'complexity_policy-working', 'complexity_policy-index', 'complexity_policy-revision',
        'tooling-regressions', 'fmt', 'check', 'clippy-packages',
        'windows-cross-clippy-packages', 'build-tests',
    ]
    checks = result['checks']
    assert [entry['label'] for entry in checks] == static_labels
    for entry in checks:
        assert type(entry['exit']) is int and entry['exit'] == 0
        assert entry['before']['head'] == old_head and entry['before']['tree'] == old_tree
        assert entry['before']['status'] == entry['after']['status'] == ''
    for entry in checks[:-1]:
        assert entry['after']['head'] == old_head and entry['after']['tree'] == old_tree
    build = checks[-1]
    assert build['after']['head'] == late['after_head'] == 'c16814dbb820d0f0f3cf8d720a4bd1daa30f57a5'
    assert build['after']['tree'] == '77a14d4fcf7aef3bab20f2b2939b8f880df80bd9'
    assert late['before_head'] == old_head and late['last_gate'] == 'build-tests'
    assert type(late['build_command_exit']) is int and late['build_command_exit'] == 0


stopped = ROOT / 'validation-97a6aba4-uaq5w87z'
stopped_raw = (stopped / 'results.json').read_bytes()
receipt_raw = (ROOT / 'stopped-97a6aba4-source-review.json').read_bytes()
late_raw = (ROOT / 'late-97a6aba4-source-review.json').read_bytes()
validate_stopped_results(stopped_raw, receipt_raw, late_raw)
sources += [(stopped / 'results.json', 'source-review-stop/results.json')]
sources += [(path, 'source-review-stop/' + path.name) for path in sorted(stopped.glob('*.log'))]
sources += [(ROOT / name, 'source-review-stop/' + name) for name in [
    'stopped-97a6aba4-source-review.json', 'late-97a6aba4-source-review.json',
    'final-97a6aba4-progress.log',
    'preserve-navigation-candidate-evidence-v2-initial.py',
    'review-navigation-evidence-helper-v2-initial.md',
    'review-navigation-evidence-helper-v2-supersession.md',
    'preserve-navigation-candidate-evidence.py', 'review-navigation-evidence-helper.md',
    'review-navigation-c7f59f40.md', 'review-nav-fixture-c7f59f40-lifecycle.md',
    'review-nav-fixture-c7f59f40-lifecycle-correction.md',
    'review-navigation-cached-forward-correction.md', 'nav-ci-fixture-c7f59f40.md',
    'review-nav-candidate-gate.md',
]]
sources += [(ROOT / name, 'provenance/' + name) for name in [
    'preserve-navigation-candidate-evidence-v2.py',
    'review-navigation-evidence-helper-v2.md',
    'test_navigation_stopped_guard_v2.py', 'navigation-stopped-guard-v2-results.json',
    'navigation-stopped-guard-v2-regressions.log',
    'test_navigation_archive_guards_v3.py', 'navigation-archive-guards-v3-results.json',
    'navigation-archive-guards-v3-regressions.log',
    'review-navigation-evidence-helper-v3-owner-correction.md',
]]


def validate_failed_c168_results(failed_raw, failed_logs):
    """Preserve the prior strict-Clippy failure without implying runtime ran."""
    result = json.loads(failed_raw)
    head = 'c16814dbb820d0f0f3cf8d720a4bd1daa30f57a5'
    tree = '77a14d4fcf7aef3bab20f2b2939b8f880df80bd9'
    assert sha(failed_raw) == FAILED_C168_RESULTS_SHA
    assert result['commit'] == head and result['tree'] == tree
    assert result['runner_sha256'] == 'd0f64d5404cf755e988bf634d203d7e9d97896490ad62b0c0f42f51db8a4508a'
    assert result.get('status') != 'passed' and not result.get('finished')
    assert result['fatal'] == 'Gate failed: clippy-packages'
    checks = result['checks']
    assert [entry['label'] for entry in checks] == FAILED_C168_LABELS
    assert set(failed_logs) == set(FAILED_C168_LABELS)
    for entry in checks:
        assert type(entry['exit']) is int
        assert entry['exit'] == (1 if entry['label'] == 'clippy-packages' else 0)
        assert entry['before']['head'] == entry['after']['head'] == head
        assert entry['before']['tree'] == entry['after']['tree'] == tree
        assert entry['before']['status'] == entry['after']['status'] == ''
        assert entry['sha256'] == sha(failed_logs[entry['label']])
    log = failed_logs['clippy-packages']
    assert sha(log) == FAILED_C168_LOG_SHA
    text = log.decode()
    assert 'src/repo/navigation/tests_repository.rs:65:39' in text
    assert 'cloned_ref_to_slice_refs' in text
    assert 'std::slice::from_ref(&current)' in text


failed_c168 = ROOT / 'validation-c16814db-n904yq7m'
failed_c168_raw = (failed_c168 / 'results.json').read_bytes()
failed_c168_logs = {label: (failed_c168 / (label + '.log')).read_bytes() for label in FAILED_C168_LABELS}
validate_failed_c168_results(failed_c168_raw, failed_c168_logs)
sources += [(failed_c168 / 'results.json', 'clippy-source-failure-c168/results.json')]
sources += [(failed_c168 / (label + '.log'), 'clippy-source-failure-c168/' + label + '.log') for label in FAILED_C168_LABELS]
sources += [(ROOT / name, 'clippy-source-failure-c168/' + name) for name in [
    'final-c16814db-progress.log', 'nav-v2-candidate-remote.txt',
    'combined-nav-v2-size-working.log', 'combined-nav-v2-size-index.log',
]]
sources += [(ROOT / name, 'palette/' + name) for name in [
    'review-maintainability-scope-c16814db.md', 'review-remaining-hotspots-f177144f.md',
    'review-palette-423758ee-nav.md', 'review-palette-5b571106-nav.md',
    'review-palette-5b571106-root.md', 'review-final-source-02a5c7ce.md',
    'palette-owners-source-parity-5b571106.json',
    'palette-owners-size-working.log', 'palette-owners-size-staged.log',
    'combined-palette-size-working.log', 'combined-palette-size-index.log',
    'palette-final-candidate-remote.txt',
    'preserve-navigation-candidate-evidence-v3.py',
    'test_palette_archive_guards_v4.py', 'palette-archive-guards-v4-results.json',
    'palette-archive-guards-v4-regressions.log', 'prepare-palette-evidence-v4.py',
]]
intermediate = ROOT / 'validation-f177144f-91pjrzai'
sources += [(intermediate / 'results.json', 'intermediate-navigation/results.json')]
sources += [(path, 'intermediate-navigation/' + path.name) for path in sorted(intermediate.glob('*.log'))]
sources += [(ROOT / 'final-f177144f-progress.log', 'intermediate-navigation/progress.log')]
# Missing inputs must fail before the first destination write.
inputs = [(source, relative, source.read_bytes()) for source, relative in sources]
manifest = dict(commit=CANDIDATE, tree=TREE, fixture_source=FIX, fixture_blobs=blobs,
    parent=PARENT, history_units=25, palette_source=palette_source, previous_ci_head='0622a2ac1237311e29f6dcc94788b30f5b094bb4', artifacts=[])
for source, relative, raw in inputs:
    compressed = gzip.compress(raw, mtime=0)
    target = DEST / (relative + '.gz')
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(compressed)
    manifest['artifacts'].append(dict(path=relative + '.gz', source=str(source),
        sha256=sha(raw), gzip_sha256=sha(compressed), bytes=len(raw)))
(DEST / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
rows = []
for entry in checks:
    for count in entry.get('test_summaries', []):
        rows.append('| ' + entry['label'] + ' | ' + ' | '.join(str(count[key]) for key in ['passed', 'failed', 'ignored', 'filtered']) + ' |')
(DEST / 'README.md').write_text(f'''# Consolidated maintainability candidate validation

Candidate `{CANDIDATE}`, complete tree `{TREE}`, passed all 39 local gates.
Two changed test files exactly match reviewed fixture source `{FIX}`; the
repository-test file differs only by the independently reviewed equivalent
`std::slice::from_ref(&current)` expected-slice expression replacing a clone.
The complete candidate tree equals reviewed combined source `{palette_source}`.
Its parent `{PARENT}` retains the corrected navigation unit and failed Linux CI
evidence. The 25 linear history units begin at dev
`57d7395bce9e187ff9f2a3ce9b96dc0d65715600`. The final feature unit changes 19
palette ownership/test paths; all other application and gate files match its parent.
Feature contributors preserve ordered labels, hints, typed actions and operands.
Four new palette tests check 12 review/offline/keymap contexts, 16 composed
review/selection/busy/LFS contexts, fixed intent contracts and stash choices.
The original source-only palette unit had corrupted expected Unicode ellipses;
its blocked review is preserved. The corrected expectations use explicit Unicode
escapes and compare the unchanged actual user-visible labels. No runtime failure
or success is claimed for that superseded, unexecuted source unit.

The library passed 5,232 tests, with zero failures, 27 ignored and four filtered
tests executed separately. All three corrected legacy navigation tests and all
three new recording tests ran successfully in that full invocation. The new
tests cover 72 configurations: 40 manual-history, 24 real user-selection/toggle,
and eight link/refinement/selected-diff cases. Existing Back/Forward and selection
assertions remain; graph coalescing now verifies the exact readiness-dependent
forward history, including a real Forward-diff/Back-graph round trip.
Passive manual setup is explicit; actual row/hash automatic reveal and same-file
toggle behavior retain separate ready/cache/delayed-detail assertions.

Python discovery passed 61 tests. Working/index/revision caps and complexity
policy, formatting, all-target compilation, strict Linux and Windows GNU
cross-target Clippy across all three packages, all four early UI probes,
six early exact navigation probes, recording/recovery and OS/CLI/MCP/checkpoint
suites passed. All six navigation tests and all four new palette tests also ran in the full library suite. The doctest gate
executed zero tests. Windows GNU cross checks do not establish native Windows
execution; live SSH/forge parity and real power-loss durability are separate.

| Runtime gate | Passed | Failed | Ignored | Filtered |
| --- | ---: | ---: | ---: | ---: |
{chr(10).join(rows)}

Every gate binds unchanged candidate HEAD/tree/clean state and log hashes.
Runtime gates add fresh before/after binary/application hashes. Synthetic recordings precede owned-child
execution in a probed PID/proc/dev namespace; existing native owned ACL fixtures
run separately. Builds/tests run directly in WSL on the host with no Docker.
Scripts, targets and tooling scratch are on E:; private Linux runtime scratch
preserves native filesystem semantics.

The earlier local pass remains in `../final-candidate/`; its later failed Linux
CI result is preserved in `../ci-regressions/43109642223/`. Those historical
results are not relabeled as passes. That failed Linux test job establishes
compilation and its runtime failure. Formatting and Linux Clippy passed in the
separate completed lint job `130822169327` on the same `0622a2ac` head; its log
and API metadata are preserved here to bind the earlier archive's broader lint
statement. This is historical CI evidence, not a new CI run for this candidate.
The intermediate `97a6aba4` run received an interruption request after source review found an incorrect
cached-forward expectation in the first fixture matrix. Its partial results,
original reviews, explicit corrections and unexecuted archive helper are preserved
under `source-review-stop/`. The original stop receipt remains an initial
observation; its intermediate raw results snapshot was not separately retained.
The owned Windows session exiting after Ctrl-C did not establish termination of
the Linux helper. It later completed static cross-Clippy and test compilation;
the unchanged-source guard then refused the changed candidate before any
application runtime. The late correction binds that final failed manifest and
the original receipt. No full-pass claim is made for it. The corrected unit independently expects a
retained forward diff when ready/cached and a coalesced graph when pending.
Independent source reviews distinguish authored areas and test execution. Original helper safety regression proofs
remain in the earlier archive; the revised runner retains those hash/integrity guards and adds six exact probes.
Its rebound eleven-test/26-scenario digest regression is also preserved here.
The archive Git wrapper retains its inherited-Git-variable sanitation.
The historical-input guard's actual AST has a separate recording-only regression,
including stale/mismatched evidence and a removed-hash-guard negative control.
The subsequent `c16814db` attempt failed strict Clippy at the unnecessary clone
before any application runtime. Its exact results and ten logs are preserved in
`clippy-source-failure-c168/`; no full-pass claim is made for that candidate.
The replacement expected slice retains the same one-element equality assertion.
The earlier f177 navigation run and its raw logs are retained under
`intermediate-navigation/`; final runtime claims above refer to the consolidated
candidate, including its four new palette regressions.
The new recording proof also exercises the actual historical failure guards,
including raw/log digests, source identity, failure endpoint and absence of runtime.

This evidence is a documentation-only follow-up. Verify application and gate
files unchanged before binding the prior execution to that follow-up; no new
application execution is claimed for documentation changes. Final CI may run
only after exact candidate checks and independent review complete.
''')
print(json.dumps(dict(destination=str(DEST), artifacts=len(inputs))))
