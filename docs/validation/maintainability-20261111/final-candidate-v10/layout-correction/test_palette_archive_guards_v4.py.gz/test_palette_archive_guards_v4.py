"""Record the actual two historical archive guards; never execute their module."""
import ast
import copy
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import unittest

ROOT = Path('/mnt/e/private/gitcraft-build')
HELPER = ROOT / 'preserve-palette-candidate-evidence-v4.py'
EXPECTED = '461e8f16d7a7926ac841e067769799d41316e054a13287ee31c06bfc55b501cc'
raw = HELPER.read_bytes()
if hashlib.sha256(raw).hexdigest() != EXPECTED:
    raise SystemExit('Helper source differs from the pinned correction')
module = ast.parse(raw, filename=str(HELPER))
guard_index = next(i for i, node in enumerate(module.body)
                   if isinstance(node, ast.FunctionDef) and node.name == 'validate_stopped_results')
block = module.body[guard_index:guard_index + 6]
assert isinstance(block[-1], ast.Expr) and isinstance(block[-1].value, ast.Call)
assert isinstance(block[-1].value.func, ast.Name)
assert block[-1].value.func.id == 'validate_stopped_results'
assert [type(node).__name__ for node in block] == ['FunctionDef'] + ['Assign'] * 4 + ['Expr']
sha_node = next(node for node in module.body if isinstance(node, ast.FunctionDef) and node.name == 'sha')
selected = ast.Module(body=[sha_node, *block], type_ignores=[])
SOURCE = ast.unparse(selected) + '\n'
clippy_index = next(i for i, node in enumerate(module.body)
                    if isinstance(node, ast.FunctionDef) and node.name == 'validate_failed_c168_results')
clippy_block = module.body[clippy_index:clippy_index + 5]
assert [type(node).__name__ for node in clippy_block] == ['FunctionDef'] + ['Assign'] * 3 + ['Expr']
assert ast.unparse(clippy_block[-1].value.func) == 'validate_failed_c168_results'
clippy_selected = ast.Module(body=[sha_node, *clippy_block], type_ignores=[])
ALL_SOURCE = ast.unparse(ast.Module(body=[sha_node, *block, *clippy_block], type_ignores=[])) + '\n'
OLD_HEAD = '97a6aba4073ea465cb4241123c2d1379766ca234'
OLD_TREE = '0cea01cc09874f7043cf72990ce3fa5a935cad04'
OLD_RUNNER = 'fba211409fd0f961eb803af8d332eca08be039ea241fba7cd4ffec9be5e623b3'
CANDIDATE = '02a5c7ce7de437abd6e740e4bb267c7c083afaf9'
TREE = '0c768d70e35233a71f88bdb6b74c036c37fcafc7'
HISTORICAL_HEAD = 'c16814dbb820d0f0f3cf8d720a4bd1daa30f57a5'
HISTORICAL_TREE = '77a14d4fcf7aef3bab20f2b2939b8f880df80bd9'
INITIAL = '5e42014aa133bcf5130f644e33eb763eebd79b04198231814ec8cb833257c0be'
RESULT_PATH = '/recording/validation-97a6aba4-uaq5w87z/results.json'
RECEIPT_PATH = '/recording/stopped-97a6aba4-source-review.json'
LATE_PATH = '/recording/late-97a6aba4-source-review.json'
CLIPPY_ROOT = '/recording/validation-c16814db-n904yq7m/'
FAILED_LABELS = ['rust_file_size-working', 'rust_file_size-index', 'rust_file_size-revision',
                 'complexity_policy-working', 'complexity_policy-index', 'complexity_policy-revision',
                 'tooling-regressions', 'fmt', 'check', 'clippy-packages']
SCENARIOS = []


def encoded(value):
    return (json.dumps(value, indent=2) + '\n').encode()


def fixture():
    # Entirely synthetic data; no current/historical results or repository are opened.
    labels = ['rust_file_size-working', 'rust_file_size-index', 'rust_file_size-revision',
              'complexity_policy-working', 'complexity_policy-index', 'complexity_policy-revision',
              'tooling-regressions', 'fmt', 'check', 'clippy-packages',
              'windows-cross-clippy-packages', 'build-tests']
    before = dict(head=OLD_HEAD, tree=OLD_TREE, status='')
    checks = [dict(label=label, exit=0, before=copy.deepcopy(before), after=copy.deepcopy(before))
              for label in labels]
    checks[-1]['after'].update(head=HISTORICAL_HEAD, tree=HISTORICAL_TREE)
    result = dict(commit=OLD_HEAD, tree=OLD_TREE, runner_sha256=OLD_RUNNER, checks=checks,
                  fatal='Candidate dirty or changed during build-tests')
    receipt = dict(commit=OLD_HEAD, tree=OLD_TREE, runner_sha256=OLD_RUNNER, results_sha256=INITIAL)
    late = dict(commit=OLD_HEAD, tree=OLD_TREE, fatal=result['fatal'],
                initial_observation_results_sha256=INITIAL, application_runtime_executed=False,
                after_head=HISTORICAL_HEAD, before_head=OLD_HEAD, last_gate='build-tests', build_command_exit=0)
    return result, receipt, late


def blobs(result, receipt, late):
    late = copy.deepcopy(late)
    late.setdefault('results_sha256', hashlib.sha256(encoded(result)).hexdigest())
    late.setdefault('initial_observation_receipt_sha256', hashlib.sha256(encoded(receipt)).hexdigest())
    return {RESULT_PATH: encoded(result), RECEIPT_PATH: encoded(receipt), LATE_PATH: encoded(late)}


def execute(data, syntax=None, config=None):
    reads = []

    class RecordingPath:
        def __init__(self, path):
            self.path = str(PurePosixPath(path))

        def __truediv__(self, part):
            return RecordingPath(str(PurePosixPath(self.path) / part))

        def read_bytes(self):
            reads.append(self.path)
            return data[self.path]

    namespace = dict(ROOT=RecordingPath('/recording'), CANDIDATE=CANDIDATE, TREE=TREE,
                     json=json, hashlib=hashlib)
    namespace.update(config or {})
    exec(compile(ast.fix_missing_locations(copy.deepcopy(syntax or selected)), str(HELPER), 'exec'), namespace)
    return reads, namespace


class StoppedGuardTests(unittest.TestCase):
    def test_matching_late_manifest_uses_only_recorded_reads(self):
        SCENARIOS.append('matching-late-static-refusal')
        reads, namespace = execute(blobs(*fixture()))
        self.assertEqual(reads, [RESULT_PATH, RECEIPT_PATH, LATE_PATH])
        self.assertNotIn('git', namespace)
        self.assertNotIn('subprocess', namespace)
        self.assertNotIn('DEST', namespace)

    def test_rejects_mismatched_or_runtime_evidence(self):
        cases = {
            'stale-results-hash': lambda r, o, l: l.update(results_sha256=INITIAL),
            'wrong-source-commit': lambda r, o, l: r.update(commit='0' * 40),
            'wrong-source-tree': lambda r, o, l: r.update(tree='0' * 40),
            'wrong-source-runner': lambda r, o, l: r.update(runner_sha256='0' * 64),
            'wrong-fatal': lambda r, o, l: r.update(fatal='unrelated failure'),
            'wrong-after-head': lambda r, o, l: r['checks'][-1]['after'].update(head='0' * 40),
            'wrong-after-tree': lambda r, o, l: r['checks'][-1]['after'].update(tree='0' * 40),
            'unexpected-runtime': lambda r, o, l: r['checks'].append(dict(label='runtime-gitcraft-lib')),
            'unexpected-ui-probe': lambda r, o, l: r['checks'].append(dict(label='frame-font-readiness')),
            'unexpected-nav-probe': lambda r, o, l: r['checks'].append(dict(label='nav-history-walk')),
            'passed-status': lambda r, o, l: r.update(status='passed'),
            'boolean-build-exit': lambda r, o, l: r['checks'][-1].update(exit=False),
            'wrong-before-head': lambda r, o, l: r['checks'][-1]['before'].update(head='0' * 40),
            'wrong-before-tree': lambda r, o, l: r['checks'][-1]['before'].update(tree='0' * 40),
            'dirty-after-state': lambda r, o, l: r['checks'][-1]['after'].update(status=' M file'),
            'wrong-receipt-hash': lambda r, o, l: l.update(initial_observation_receipt_sha256='0' * 64),
            'wrong-initial-observation': lambda r, o, l: o.update(results_sha256='0' * 64),
            'wrong-late-after-head': lambda r, o, l: l.update(after_head='0' * 40),
            'late-runtime-claim': lambda r, o, l: l.update(application_runtime_executed=True),
            'late-boolean-build-exit': lambda r, o, l: l.update(build_command_exit=False),
            'missing-build-endpoint': lambda r, o, l: r['checks'].pop(),
        }
        for name, mutate in cases.items():
            with self.subTest(name=name):
                SCENARIOS.append(name)
                values = fixture()
                mutate(*values)
                with self.assertRaises(AssertionError):
                    execute(blobs(*values))

    def test_removed_hash_guard_negative_control_accepts_stale_receipt(self):
        SCENARIOS.append('removed-hash-guard-negative-control')
        broken = copy.deepcopy(selected)
        guard = next(node for node in broken.body if isinstance(node, ast.FunctionDef)
                     and node.name == 'validate_stopped_results')
        matches = [node for node in guard.body if isinstance(node, ast.Assert)
                   and ast.unparse(node.test) == "late['results_sha256'] == sha(stopped_raw)"]
        self.assertEqual(len(matches), 1)
        guard.body.remove(matches[0])
        values = fixture()
        values[2]['results_sha256'] = INITIAL
        # The intact AST rejects exactly this stale binding; deleting its actual
        # hash assertion must make the same otherwise valid recording pass.
        with self.assertRaises(AssertionError):
            execute(blobs(*values))
        reads, _ = execute(blobs(*values), broken)
        self.assertEqual(reads, [RESULT_PATH, RECEIPT_PATH, LATE_PATH])

    def test_missing_input_fails_without_a_write_boundary(self):
        SCENARIOS.append('missing-late-note')
        data = blobs(*fixture())
        del data[LATE_PATH]
        with self.assertRaises(KeyError):
            execute(data)

    def test_extraction_precedes_all_input_preloads_and_destination_writes(self):
        SCENARIOS.append('actual-block-before-all-inputs-and-writes')
        preload = next(node for node in module.body if isinstance(node, ast.Assign)
                       and any(isinstance(target, ast.Name) and target.id == 'inputs' for target in node.targets))
        writes = [node for node in ast.walk(module) if isinstance(node, ast.Call)
                  and isinstance(node.func, ast.Attribute)
                  and node.func.attr in ('write_bytes', 'write_text', 'mkdir')]
        self.assertLess(block[-1].lineno, preload.lineno)
        self.assertTrue(writes)
        self.assertTrue(all(preload.lineno < node.lineno for node in writes))
        self.assertEqual(hashlib.sha256(HELPER.read_bytes()).hexdigest(), EXPECTED)


def clippy_fixture():
    logs = {label: ('synthetic ' + label + '\n').encode() for label in FAILED_LABELS}
    logs['clippy-packages'] = (
        'error: cloned_ref_to_slice_refs\n'
        'src/repo/navigation/tests_repository.rs:65:39\n'
        'help: try std::slice::from_ref(&current)\n').encode()
    state = dict(head=HISTORICAL_HEAD, tree=HISTORICAL_TREE, status='')
    checks = [dict(label=label, exit=1 if label == 'clippy-packages' else 0,
                   before=copy.deepcopy(state), after=copy.deepcopy(state),
                   sha256=hashlib.sha256(logs[label]).hexdigest()) for label in FAILED_LABELS]
    result = dict(commit=HISTORICAL_HEAD, tree=HISTORICAL_TREE,
                  runner_sha256='d0f64d5404cf755e988bf634d203d7e9d97896490ad62b0c0f42f51db8a4508a',
                  fatal='Gate failed: clippy-packages', checks=checks)
    return result, logs


def clippy_blobs(result, logs):
    data = {CLIPPY_ROOT + 'results.json': encoded(result)}
    data.update({CLIPPY_ROOT + label + '.log': raw_log for label, raw_log in logs.items()})
    # Only expected fixture digests are injected. The extracted actual sha AST
    # still hashes every recorded byte. Source-pin literals are checked below.
    config = dict(FAILED_C168_LABELS=FAILED_LABELS,
                  FAILED_C168_RESULTS_SHA=hashlib.sha256(encoded(result)).hexdigest(),
                  FAILED_C168_LOG_SHA=hashlib.sha256(logs['clippy-packages']).hexdigest())
    return data, config


class ClippyFailureGuardTests(unittest.TestCase):
    def test_matching_static_failure_and_production_pins(self):
        SCENARIOS.append('c168-matching-static-failure-and-production-pins')
        data, config = clippy_blobs(*clippy_fixture())
        reads, namespace = execute(data, clippy_selected, config)
        self.assertEqual(reads, [CLIPPY_ROOT + 'results.json'] +
                         [CLIPPY_ROOT + label + '.log' for label in FAILED_LABELS])
        self.assertNotIn('git', namespace)
        self.assertNotIn('subprocess', namespace)
        self.assertNotIn('DEST', namespace)
        pins = {node.targets[0].id: ast.literal_eval(node.value) for node in module.body
                if isinstance(node, ast.Assign) and len(node.targets) == 1
                and isinstance(node.targets[0], ast.Name)
                and node.targets[0].id in {'FAILED_C168_RESULTS_SHA', 'FAILED_C168_LOG_SHA', 'FAILED_C168_LABELS'}}
        self.assertEqual(pins, dict(
            FAILED_C168_RESULTS_SHA='45204a6d9d5ae0f4efff791d29a1d023311a5502606693de8e00a94e54df3c10',
            FAILED_C168_LOG_SHA='5847541645c5f2900f8b11caf7c301456c2fdda8456e8975066bcf2ae8ca0c0b',
            FAILED_C168_LABELS=FAILED_LABELS))

    def test_rejects_wrong_source_endpoint_and_runtime_claims(self):
        cases = {
            'c168-wrong-source': lambda r, l: r.update(commit='0' * 40),
            'c168-wrong-tree': lambda r, l: r.update(tree='0' * 40),
            'c168-wrong-runner': lambda r, l: r.update(runner_sha256='0' * 64),
            'c168-wrong-fatal': lambda r, l: r.update(fatal='other failure'),
            'c168-passed-status': lambda r, l: r.update(status='passed'),
            'c168-finished-marker': lambda r, l: r.update(finished='unexpected'),
            'c168-zero-final-exit': lambda r, l: r['checks'][-1].update(exit=0),
            'c168-boolean-final-exit': lambda r, l: r['checks'][-1].update(exit=True),
            'c168-nonzero-earlier-exit': lambda r, l: r['checks'][0].update(exit=1),
            'c168-boolean-earlier-exit': lambda r, l: r['checks'][0].update(exit=False),
            'c168-wrong-before-head': lambda r, l: r['checks'][-1]['before'].update(head=CANDIDATE),
            'c168-wrong-after-head': lambda r, l: r['checks'][-1]['after'].update(head=CANDIDATE),
            'c168-wrong-before-tree': lambda r, l: r['checks'][-1]['before'].update(tree=TREE),
            'c168-wrong-after-tree': lambda r, l: r['checks'][-1]['after'].update(tree=TREE),
            'c168-dirty-after': lambda r, l: r['checks'][-1]['after'].update(status=' M file'),
            'c168-unexpected-runtime': lambda r, l: r['checks'].append(dict(label='runtime-gitcraft-lib')),
            'c168-unexpected-ui': lambda r, l: r['checks'].append(dict(label='frame-font-readiness')),
            'c168-unexpected-nav': lambda r, l: r['checks'].append(dict(label='nav-history-walk')),
            'c168-missing-static-entry': lambda r, l: r['checks'].pop(0),
            'c168-wrong-log-digest': lambda r, l: r['checks'][0].update(sha256='0' * 64),
        }
        for name, mutate in cases.items():
            with self.subTest(name=name):
                SCENARIOS.append(name)
                values = clippy_fixture()
                mutate(*values)
                data, config = clippy_blobs(*values)
                with self.assertRaises(AssertionError):
                    execute(data, clippy_selected, config)

    def test_rejects_raw_and_log_tampering_and_missing_inputs(self):
        for name in ['raw-pin', 'clippy-pin', 'other-log-tamper', 'clippy-log-tamper', 'missing-log']:
            with self.subTest(name=name):
                SCENARIOS.append('c168-' + name)
                data, config = clippy_blobs(*clippy_fixture())
                if name == 'raw-pin':
                    config['FAILED_C168_RESULTS_SHA'] = '0' * 64
                elif name == 'clippy-pin':
                    config['FAILED_C168_LOG_SHA'] = '0' * 64
                elif name == 'other-log-tamper':
                    data[CLIPPY_ROOT + 'fmt.log'] += b'tampered\n'
                elif name == 'clippy-log-tamper':
                    data[CLIPPY_ROOT + 'clippy-packages.log'] += b'tampered\n'
                else:
                    del data[CLIPPY_ROOT + 'fmt.log']
                with self.assertRaises(KeyError if name == 'missing-log' else AssertionError):
                    execute(data, clippy_selected, config)

    def test_removed_actual_raw_hash_guard_negative_control(self):
        SCENARIOS.append('c168-removed-raw-hash-guard-negative-control')
        broken = copy.deepcopy(clippy_selected)
        guard = next(node for node in broken.body if isinstance(node, ast.FunctionDef)
                     and node.name == 'validate_failed_c168_results')
        matches = [node for node in guard.body if isinstance(node, ast.Assert)
                   and ast.unparse(node.test) == 'sha(failed_raw) == FAILED_C168_RESULTS_SHA']
        self.assertEqual(len(matches), 1)
        guard.body.remove(matches[0])
        data, config = clippy_blobs(*clippy_fixture())
        config['FAILED_C168_RESULTS_SHA'] = '0' * 64
        with self.assertRaises(AssertionError):
            execute(data, clippy_selected, config)
        reads, _ = execute(data, broken, config)
        self.assertEqual(len(reads), 11)

    def test_diagnostic_text_and_before_all_writes(self):
        for marker in ['src/repo/navigation/tests_repository.rs:65:39',
                       'cloned_ref_to_slice_refs', 'std::slice::from_ref(&current)']:
            with self.subTest(marker=marker):
                SCENARIOS.append('c168-diagnostic:' + marker)
                result, logs = clippy_fixture()
                logs['clippy-packages'] = logs['clippy-packages'].replace(marker.encode(), b'missing')
                result['checks'][-1]['sha256'] = hashlib.sha256(logs['clippy-packages']).hexdigest()
                data, config = clippy_blobs(result, logs)
                with self.assertRaises(AssertionError):
                    execute(data, clippy_selected, config)
        SCENARIOS.append('c168-actual-block-before-all-inputs-and-writes')
        preload = next(node for node in module.body if isinstance(node, ast.Assign)
                       and any(isinstance(target, ast.Name) and target.id == 'inputs' for target in node.targets))
        writes = [node for node in ast.walk(module) if isinstance(node, ast.Call)
                  and isinstance(node.func, ast.Attribute)
                  and node.func.attr in ('write_bytes', 'write_text', 'mkdir')]
        self.assertLess(clippy_block[-1].lineno, preload.lineno)
        self.assertTrue(all(preload.lineno < node.lineno for node in writes))


if __name__ == '__main__':
    stream = io.StringIO()
    outcome = unittest.TextTestRunner(stream=stream, verbosity=2).run(
        unittest.TestSuite([unittest.defaultTestLoader.loadTestsFromTestCase(StoppedGuardTests),
                            unittest.defaultTestLoader.loadTestsFromTestCase(ClippyFailureGuardTests)]))
    log = stream.getvalue()
    print(log, end='')
    log_path = ROOT / 'palette-archive-guards-v4-regressions.log'
    log_path.write_text(log)
    result = dict(helper=str(HELPER), helper_sha256=EXPECTED,
                  extracted_ast_sha256=hashlib.sha256(ALL_SOURCE.encode()).hexdigest(),
                  regression_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                  tests=outcome.testsRun, scenarios=len(SCENARIOS), scenario_names=SCENARIOS,
                  failures=len(outcome.failures), errors=len(outcome.errors), skipped=len(outcome.skipped),
                  log_sha256=hashlib.sha256(log.encode()).hexdigest(),
                  production_pin_check='Actual source literal SHA pins verified; only synthetic expected-digest globals are injected for recorded fixture bytes.',
                  boundary='Actual sha plus both historical guard/read AST blocks only; synthetic JSON and RecordingPath reads. No Git, CI, application, subprocess, signals, destination or helper module execution.')
    (ROOT / 'palette-archive-guards-v4-results.json').write_text(json.dumps(result, indent=2) + '\n')
    raise SystemExit(0 if outcome.wasSuccessful() else 1)
