# Correction: palette offline contributor after test module

I missed a strict-Clippy source blocker in the palette review: offline::palette_item was appended after offline.rs's cfg(test) module. The preceding no-blocker source verdicts for accepted palette source 5b57110664e824c93b2c89d4ecfc518eeb05daa3 and consolidated candidate 02a5c7ce7de437abd6e740e4bb267c7c083afaf9 are withdrawn for that layout defect. They must not authorize delivery of those unchanged sources.

Preserved original reviews remain unchanged:

- review-palette-5b571106-nav.md, SHA256 f3b4f6545267c0766b1732c2887ec504483deec6181cd00449f6fb6e53725665
- review-final-source-02a5c7ce.md, SHA256 9ec8fc6b344d693f5dabc352636eaa552cec53d0ae81960f4114819765c3ee57

Explicit immutable inspection of 02a5 confirms cfg(test) at offline.rs:183, mod tests at line 184, and the new production palette_item function at line 424. The unit originated this placement in 423; the later Unicode correction changed only the two test files, so the layout remains in 5b and identical-tree 02a. Under the repository's strict all-target Clippy gate, the production item after a test module can trigger items_after_test_module with -D warnings.

Root independently confirmed this using E-drive-only standalone clippy-driver fixtures. I read the preserved probe sources and logs without executing them. clippy-item-layout-probe.rs reproduces a production function after a cfg(test) module; its log explicitly reports items_after_test_module and aborts. The same function moved before the test module in clippy-item-layout-fixed-probe.rs has an empty fixed-probe log; root reports metadata-only compile exits 1/0 respectively. These are root's isolated tooling probes, not an application build/test or final-candidate result by this reviewer.

The required correction is an exact body-preserving move of offline::palette_item and its documentation before the cfg(test) module. No lint allowance is needed. The new immutable source and assembled candidate require fresh source review, followed by actual combined candidate format/Clippy/compile/runtime gates. Earlier source-only approval did not establish those gates; they remain pending.

The following mechanical facts remain valid: 02a5's entire tree equals 5b's tree 0c768d70e35233a71f88bdb6b74c036c37fcafc7; the original palette unit touches exactly 19 paths relative to f177; all other blobs are unchanged; and the 25 final history author/committer identities are the required Jonas identity. The unchanged production contributor bodies, labels/hints/typed intents and corrected Unicode facts are not invalidated by this placement defect. Their prior no-blocker conclusion is explicitly superseded rather than rewriting the original reports.

I made no source/index/status changes, executed no application or tooling probe, and called no CI or signal operation. Only immutable source/review/probe evidence reads and this standalone E-drive correction note were performed. No compile/runtime success is claimed for 5b or 02a.