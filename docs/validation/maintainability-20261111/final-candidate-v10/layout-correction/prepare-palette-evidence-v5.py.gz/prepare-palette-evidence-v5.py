from pathlib import Path
import ast
import hashlib

root = Path('/mnt/e/private/gitcraft-build')
source = root / 'preserve-palette-candidate-evidence-v4.py'
assert hashlib.sha256(source.read_bytes()).hexdigest() == '461e8f16d7a7926ac841e067769799d41316e054a13287ee31c06bfc55b501cc'
text = source.read_text(encoding='utf-8')
changes = {
    "CANDIDATE = '02a5c7ce7de437abd6e740e4bb267c7c083afaf9'": "CANDIDATE = '92656fb7d7c49a728824df9548cccf2c35325ad4'",
    "TREE = '0c768d70e35233a71f88bdb6b74c036c37fcafc7'": "TREE = '8f188f3aa5feab6597f1bdc0a9bf735c4604384c'",
    "palette_source = '5b57110664e824c93b2c89d4ecfc518eeb05daa3'": "palette_source = '412d1118fb43af6ecc35a7755e5366949aeda511'",
    'final-candidate-v7': 'final-candidate-v8',
    'validation-02a5c7ce-': 'validation-92656fb7-',
    'maintainability/validated-v7': 'maintainability/validated-v8',
    "'preserve-palette-candidate-evidence-v4.py',": "'preserve-palette-candidate-evidence-v5.py',",
    'final-02a5c7ce-progress.log': 'final-92656fb7-progress.log',
    'review-palette-evidence-helper-v4-root.md': 'review-palette-evidence-helper-v5-root.md',
    'review-palette-evidence-helper-v4-adversarial.md': 'review-palette-evidence-helper-v5-adversarial.md',
    'review-final-source-02a5c7ce.md': 'review-final-source-92656fb7.md',
    'combined-palette-size-working.log': 'combined-palette-v8-size-working.log',
    'combined-palette-size-index.log': 'combined-palette-v8-size-index.log',
    'palette-final-candidate-remote.txt': 'palette-v8-final-candidate-remote.txt',
    'test_palette_archive_guards_v4.py': 'test_palette_archive_guards_v5.py',
    'palette-archive-guards-v4-results.json': 'palette-archive-guards-v5-results.json',
    'palette-archive-guards-v4-regressions.log': 'palette-archive-guards-v5-regressions.log',
}
for before, after in changes.items():
    assert text.count(before) == 1, (before, text.count(before))
    text = text.replace(before, after)
marker = '# Missing inputs must fail before the first destination write.'
assert text.count(marker) == 1
text = text.replace(marker, """assert sha((intermediate / 'results.json').read_bytes()) == '42c30bc0deebeaea78a9e3ea0385331dca2a5f5cf7e069252b024d630eb779f0'
sources += [(ROOT / name, 'layout-correction/' + name) for name in [
    'review-palette-item-layout-correction.md', 'review-palette-412d1118-nav.md',
    'review-final-source-02a5c7ce.md', 'palette-final-candidate-remote.txt',
    'palette-owners-layout-size-working.log', 'palette-owners-layout-size-staged.log',
    'clippy-item-layout-probe.rs', 'clippy-item-layout-probe.log',
    'clippy-item-layout-fixed-probe.rs', 'clippy-item-layout-fixed-probe.log',
    'clippy-item-layout-fixed-probe-result.txt',
    'preserve-palette-candidate-evidence-v4.py',
    'test_palette_archive_guards_v4.py', 'palette-archive-guards-v4-results.json',
    'palette-archive-guards-v4-regressions.log',
    'review-palette-evidence-helper-v4-root.md',
    'review-palette-evidence-helper-v4-adversarial.md', 'prepare-palette-evidence-v5.py',
]]
""" + marker)
before = 'escapes and compare the unchanged actual user-visible labels. No runtime failure'
after = '''escapes and compare the unchanged actual user-visible labels. A later source
check found an item-after-test-module Clippy layout blocker in the intermediate
palette source. Its original source approvals and explicit correction are
preserved. An isolated compiler-only fixture rejects that layout; moving the
same helper before the test module passes. The accepted source moves only that
unchanged block. Strict all-package Clippy also protects this class in future.
No application run was started for that intermediate layout candidate. No runtime failure'''
assert text.count(before) == 1
text = text.replace(before, after)
before = 'The earlier f177 navigation run and its raw logs are retained under'
after = 'The earlier f177 navigation run completed 39 gates, including 5,228 library passes, and its raw logs are retained under'
assert text.count(before) == 1
text = text.replace(before, after)
ast.parse(text)
target = root / 'preserve-palette-candidate-evidence-v5.py'
assert not target.exists()
target.write_text(text, encoding='utf-8', newline='\n')
print(hashlib.sha256(target.read_bytes()).hexdigest())
