pub fn before() -> usize {
    1
}

pub fn after() -> usize {
    1
}

#[cfg(test)]
mod tests {
    #[test]
    fn uses_both() {
        assert_eq!(super::before() + super::after(), 2);
    }
}
