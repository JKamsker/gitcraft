"""Exercise selected actual helper AST with synthetic data and recording paths only."""
import ast
import copy
import gzip
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import re
import unittest

ROOT = Path(__file__).resolve().parent
HELPER = ROOT / 'preserve-final-candidate-evidence-v6.py'
PIN = 'bfc6958f3cce9c20356b18f641952e2a95741d7e2347edcca9735e3feff1db90'
raw = HELPER.read_bytes()
assert hashlib.sha256(raw).hexdigest() == PIN
module = ast.parse(raw, filename=str(HELPER))
selected_names = {'sha', 'validate_926_results', 'validate_failed_580_results', 'validate_final_observer',
                  'prepare_outputs', 'publish_outputs'}
selected = ast.Module(body=[node for node in module.body
    if isinstance(node, ast.FunctionDef) and node.name in selected_names], type_ignores=[])
constants = {}
for node in module.body:
    if isinstance(node, ast.Assign) and isinstance(node.targets[0], ast.Name):
        try:
            constants[node.targets[0].id] = ast.literal_eval(node.value)
        except (ValueError, TypeError):
            pass
constants['FAILED_926_LABELS'] = constants['FAILED_C168_LABELS'] + [
    'windows-cross-clippy-packages', 'build-tests', 'frame-font-readiness',
    'frame-accessibility', 'frame-layout-profile', 'frame-settings-profile',
    'recording-pipes', 'recording-outcomes', 'recording-resolver',
    'nav-recording-manual-history', 'nav-recording-user-selection',
    'nav-recording-forward-history', 'nav-history-walk', 'nav-history-selection',
    'nav-history-links', 'build-recovery-recording', 'list-recovery-recording',
    'recovery-recording', 'runtime-gitcraft_os-lib', 'runtime-gitcraft-main',
    'runtime-standalone_cli-standalone_cli', 'runtime-mcp_stdio-mcp_stdio',
    'runtime-gitcraft-lib']
SCENARIOS = []


def digest(value):
    return hashlib.sha256(value).hexdigest()


def encode(value):
    return (json.dumps(value, indent=2) + '\n').encode()


def namespace():
    space = dict(constants, json=json, re=re, hashlib=hashlib, gzip=gzip, Path=Path)
    exec(compile(copy.deepcopy(selected), str(HELPER), 'exec'), space)
    return space


def fixture(kind):
    space = namespace()
    failed = kind != 'partial'
    early = kind == '580'
    labels = space['FAILED_C168_LABELS'] if early else space['FAILED_926_LABELS'][:33 if failed else 16]
    head = '580542bfc9ff4d1586077beb57193768d0149fe4' if early else space['FAILED_926_HEAD']
    tree = '091687f298049acfa30ef376e6a858b103ad97e2' if early else space['FAILED_926_TREE']
    state = dict(head=head, tree=tree, status='')
    logs = {label: ('synthetic log for ' + label).encode() for label in labels}
    if early:
        logs['clippy-packages'] = b'error: used `unwrap()` on an `Option` value\nsrc/repo/core_seams/palette_shortcuts.rs:34:23\nclippy::unwrap-used\n'
    elif failed:
        logs['runtime-gitcraft-lib'] = ('\n'.join('test ' + name + ' ... FAILED\n---- ' + name + ' stdout ----'
            for name in space['FAILED_926_NAMES']) + '\nassertion failed: result.is_err()\n'
            + 'assertion `left == right` failed\n  left: "Ctrl+Shift+F"\n right: "F6"\n'
            + 'test result: FAILED. 5230 passed; 2 failed; 27 ignored; 0 measured; 4 filtered out; finished in 1s\n').encode()
    checks = [dict(label=label, exit=0, before=copy.deepcopy(state), after=copy.deepcopy(state), sha256=digest(logs[label])) for label in labels]
    if failed:
        checks[-1]['exit'] = 1 if early else 101
    if failed and not early:
        checks[-1]['test_summaries'] = [dict(passed=5230, failed=2, ignored=27, measured=0, filtered=4)]
    result = dict(commit=head, tree=tree, runner_sha256=space['RUNNER'], checks=checks)
    if failed:
        result['fatal'] = 'Gate failed: ' + ('clippy-packages' if early else 'runtime-gitcraft-lib')
    return space, result, logs


def execute(kind, result, logs, *, repin=True, space=None):
    space = namespace() if space is None else space
    raw = encode(result)
    if repin:
        space[{'926': 'FAILED_926_RESULTS_SHA', 'partial': 'PARTIAL_926_RESULTS_SHA', '580': 'FAILED_580_RESULTS_SHA'}[kind]] = digest(raw)
        if kind == '926':
            space['FAILED_926_LOG_SHA'] = digest(logs['runtime-gitcraft-lib'])
        if kind == '580':
            space['FAILED_580_LOG_SHA'] = digest(logs['clippy-packages'])
    if kind == '580':
        return space['validate_failed_580_results'](raw, logs)
    return space['validate_926_results'](raw, logs, failed=kind == '926')


class HistoricalGuards(unittest.TestCase):
    def test_exact_published_digest_pins_and_legacy_functions_are_preserved(self):
        self.assertEqual(constants['FAILED_926_RESULTS_SHA'], '25971817dd914e348848b627d7b31408716ff9e34e704a6ba6819804d7d56786')
        self.assertEqual(constants['PARTIAL_926_RESULTS_SHA'], 'b50dfde33be67a1a76ccf496a1cab11fe66077b1e8eb4d674fbfbe6984ee2130')
        self.assertEqual(constants['FAILED_580_RESULTS_SHA'], '08e0fdc0fd69da6a18bfc2eed44a540fb5afbfa6d0addd80e2343d95ac101bd8')
        old_raw = (ROOT / 'preserve-palette-candidate-evidence-v5.py').read_bytes()
        self.assertEqual(digest(old_raw), 'f9e91f531c43fd7f4e6d57ca146d12dc47daf347e5be3ba268917c84d072c5b1')
        old = ast.parse(old_raw)
        for name in ['validate_stopped_results', 'validate_failed_c168_results']:
            nodes = [next(node for node in item.body if isinstance(node, ast.FunctionDef) and node.name == name) for item in [old, module]]
            self.assertEqual(ast.dump(nodes[0]), ast.dump(nodes[1]))

    def test_actual_guards_accept_only_their_synthetic_valid_shapes(self):
        for kind in ['926', 'partial', '580']:
            with self.subTest(kind=kind):
                space, result, logs = fixture(kind)
                self.assertEqual(execute(kind, result, logs, space=space), result)
                SCENARIOS.append(kind + ':valid')

    def test_metadata_endpoint_source_and_log_mutations_are_rejected(self):
        for kind in ['926', 'partial', '580']:
            changes = {
                'commit': lambda r, l: r.update(commit='wrong'),
                'tree': lambda r, l: r.update(tree='wrong'),
                'runner': lambda r, l: r.update(runner_sha256='wrong'),
                'passed_status': lambda r, l: r.update(status='passed'),
                'empty_status': lambda r, l: r.update(status=''),
                'finished': lambda r, l: r.update(finished=True),
                'false_finished': lambda r, l: r.update(finished=False),
                'wrong_fatal': lambda r, l: r.update(fatal='wrong'),
                'missing_gate': lambda r, l: r['checks'].pop(),
                'duplicate_gate': lambda r, l: r['checks'].append(r['checks'][0]),
                'swapped_gate': lambda r, l: r['checks'].reverse(),
                'bool_exit': lambda r, l: r['checks'][0].update(exit=False),
                'unexpected_exit': lambda r, l: r['checks'][0].update(exit=1),
                'dirty_before': lambda r, l: r['checks'][0]['before'].update(status='M changed'),
                'changed_after_head': lambda r, l: r['checks'][-1]['after'].update(head='wrong'),
                'changed_after_tree': lambda r, l: r['checks'][-1]['after'].update(tree='wrong'),
                'missing_log': lambda r, l: l.pop(r['checks'][0]['label']),
                'extra_log': lambda r, l: l.update(extra=b'extra'),
                'changed_log': lambda r, l: l.update({r['checks'][0]['label']: b'corrupt'}),
                'wrong_log_digest': lambda r, l: r['checks'][0].update(sha256='wrong'),
            }
            if kind != 'partial':
                changes['missing_fatal'] = lambda r, l: r.pop('fatal')
                changes['wrong_endpoint_exit'] = lambda r, l: r['checks'][-1].update(exit=0)
            for label, mutate in changes.items():
                with self.subTest(kind=kind, mutation=label):
                    space, result, logs = fixture(kind)
                    mutate(result, logs)
                    with self.assertRaises((AssertionError, KeyError)):
                        execute(kind, result, logs, space=space)
                    SCENARIOS.append(kind + ':' + label)

    def test_original_raw_and_library_digest_checks_reject_even_valid_shape(self):
        for kind in ['926', 'partial', '580']:
            space, result, logs = fixture(kind)
            with self.assertRaises(AssertionError):
                execute(kind, result, logs, repin=False, space=space)
            SCENARIOS.append(kind + ':raw_digest')
        for kind, key in [('926', 'FAILED_926_LOG_SHA'), ('580', 'FAILED_580_LOG_SHA')]:
            space, result, logs = fixture(kind)
            space[{'926': 'FAILED_926_RESULTS_SHA', '580': 'FAILED_580_RESULTS_SHA'}[kind]] = digest(encode(result))
            space[key] = 'wrong'
            with self.assertRaises(AssertionError):
                execute(kind, result, logs, repin=False, space=space)
            SCENARIOS.append(kind + ':specific_log_digest')

    def test_failure_summary_assertion_text_and_exact_names_are_required(self):
        for marker in ['assertion failed: result.is_err()', 'Ctrl+Shift+F', 'right: "F6"', 'test result: FAILED.', *constants['FAILED_926_NAMES']]:
            space, result, logs = fixture('926')
            logs['runtime-gitcraft-lib'] = logs['runtime-gitcraft-lib'].replace(marker.encode(), b'changed')
            result['checks'][-1]['sha256'] = digest(logs['runtime-gitcraft-lib'])
            with self.assertRaises(AssertionError):
                execute('926', result, logs, space=space)
            SCENARIOS.append('926:missing_assertion_or_name:' + marker)
        for field in ['passed', 'failed', 'ignored', 'measured', 'filtered']:
            space, result, logs = fixture('926')
            result['checks'][-1]['test_summaries'][0][field] += 1
            with self.assertRaises(AssertionError):
                execute('926', result, logs, space=space)
            SCENARIOS.append('926:summary:' + field)
        for marker in ['src/repo/core_seams/palette_shortcuts.rs:34:23', 'error: used `unwrap()` on an `Option` value', 'clippy::unwrap-used']:
            space, result, logs = fixture('580')
            logs['clippy-packages'] = logs['clippy-packages'].replace(marker.encode(), b'changed')
            result['checks'][-1]['sha256'] = digest(logs['clippy-packages'])
            with self.assertRaises(AssertionError):
                execute('580', result, logs, space=space)
            SCENARIOS.append('580:lint_diagnostic:' + marker)


def record_boundary(*, missing=False, duplicate=False, collision=False, traversal=False):
    events, files = [], {'/source/one': b'one', '/source/two': b'two'}
    if missing:
        del files['/source/two']

    class RecordingPath:
        def __init__(self, value):
            self.value = str(PurePosixPath(value))

        def __str__(self):
            return self.value

        def __truediv__(self, part):
            return RecordingPath(str(PurePosixPath(self.value) / part))

        @property
        def parent(self):
            return RecordingPath(str(PurePosixPath(self.value).parent))

        @property
        def parts(self):
            return PurePosixPath(self.value).parts

        def is_absolute(self):
            return PurePosixPath(self.value).is_absolute()

        def exists(self):
            events.append(('exists', self.value))
            return collision and self.value == '/archive'

        def read_bytes(self):
            assert not any(event[0] in {'mkdir', 'open', 'write'} for event in events)
            events.append(('read', self.value))
            return files[self.value]

        def mkdir(self, **kwargs):
            events.append(('mkdir', self.value, kwargs))

        def open(self, mode):
            assert mode == 'xb'
            events.append(('open', self.value))
            assert self.value not in files
            path = self.value

            class Output:
                def __enter__(self):
                    return self

                def __exit__(self, *args):
                    return False

                def write(self, raw):
                    events.append(('write', path))
                    files[path] = raw

            return Output()

    space = namespace()
    space.update(Path=RecordingPath, DEST=RecordingPath('/archive'))
    names = ['logs/one', 'logs/one' if duplicate else '../escape' if traversal else 'logs/two']
    sources = [(RecordingPath('/source/' + original), name) for original, name in zip(['one', 'two'], names)]
    manifest = {'artifacts': []}
    try:
        output = space['prepare_outputs'](sources, 'README prepared', 'correction prepared', manifest)
        space['publish_outputs'](output)
    except BaseException as error:
        return events, files, manifest, error
    return events, files, manifest, None


class ArchiveBoundary(unittest.TestCase):
    def test_owned_final_observer_requires_exact_binding_completion_and_pass(self):
        space = namespace()
        expected = '/recording/final/results.json'
        events = [dict(event='owned-receipt-worker-bound', results=expected, child_exit_code_available=False),
                  dict(event='pidfd-completed', child_exit_code_available=False, child_exit_code=None, final_manifest_passed=True)]
        def encode_events(value):
            return ('\n'.join(json.dumps(item) for item in value) + '\n').encode()
        space['validate_final_observer'](encode_events(events), expected)
        for index, key, value in [(0, 'results', '/wrong/results.json'), (0, 'child_exit_code_available', True),
                                  (1, 'event', 'still-running'), (1, 'final_manifest_passed', False),
                                  (1, 'child_exit_code', 0), (1, 'child_exit_code_available', True)]:
            changed = copy.deepcopy(events)
            changed[index][key] = value
            with self.assertRaises(AssertionError):
                space['validate_final_observer'](encode_events(changed), expected)
            SCENARIOS.append('observer:' + str(index) + ':' + key)

    def test_actual_ast_preloads_all_bytes_then_exclusively_creates_complete_archive(self):
        events, files, manifest, error = record_boundary()
        self.assertIsNone(error)
        first_write = next(i for i, event in enumerate(events) if event[0] == 'mkdir')
        self.assertEqual([event[1] for event in events[:first_write] if event[0] == 'read'], ['/source/one', '/source/two'])
        self.assertFalse([event for event in events[first_write:] if event[0] == 'read'])
        self.assertEqual(events[first_write][2], dict(parents=True, exist_ok=False))
        for entry in manifest['artifacts']:
            packed = files['/archive/' + entry['path']]
            unpacked = gzip.decompress(packed)
            self.assertEqual((entry['sha256'], entry['bytes']), (digest(unpacked), len(unpacked)))
            self.assertEqual((entry['gzip_sha256'], entry['gzip_bytes']), (digest(packed), len(packed)))
        for entry in manifest['generated']:
            raw = files['/archive/' + entry['path']]
            self.assertEqual((entry['sha256'], entry['bytes']), (digest(raw), len(raw)))
        self.assertEqual(json.loads(files['/archive/manifest.json']), manifest)
        SCENARIOS.append('archive:preload_and_exclusive_write')

    def test_missing_duplicate_traversal_and_existing_destinations_fail_before_write(self):
        for field in ['missing', 'duplicate', 'collision', 'traversal']:
            events, _, _, error = record_boundary(**{field: True})
            self.assertIsNotNone(error)
            self.assertFalse([event for event in events if event[0] in {'mkdir', 'open', 'write'}])
            SCENARIOS.append('archive:' + field)


if __name__ == '__main__':
    output = io.StringIO()
    result = unittest.TextTestRunner(stream=output, verbosity=2).run(unittest.defaultTestLoader.loadTestsFromModule(__import__(__name__)))
    log = output.getvalue().encode()
    (ROOT / 'final-archive-guards-v6-regressions.log').write_bytes(log)
    summary = dict(helper_sha256=PIN, proof_sha256=digest(Path(__file__).read_bytes()),
        tests=result.testsRun, failures=len(result.failures), errors=len(result.errors),
        scenarios=len(SCENARIOS), scenario_names=SCENARIOS, log_sha256=digest(log),
        execution='selected actual AST only; synthetic manifests/logs and recording paths; no helper module execution, Git, application, historical/current candidate reads or subprocesses')
    (ROOT / 'final-archive-guards-v6-results.json').write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8')
    print(output.getvalue())
    print(json.dumps(summary, indent=2))
    raise SystemExit(not result.wasSuccessful())
