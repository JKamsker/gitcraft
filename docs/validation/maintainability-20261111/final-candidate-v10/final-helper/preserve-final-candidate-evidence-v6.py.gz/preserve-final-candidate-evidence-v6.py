"""Conditionally archive an exact final580 pass; never execute superseded helpers."""
import gzip
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys

ROOT = Path('/mnt/e/private/gitcraft-build')
REPO = Path('/mnt/e/private/gitcraft-worktrees/final-maintainability')
CANDIDATE = '4212389c6ce69ee6dba14a31a9972a54d5a2266d'
TREE = '5ae3781e43d4d97c4ed3190020da15bd07d0ffaf'
FIX = 'e831e401bff29ea90991469abe6185dcf31d5cfa'
PARENT = '205d7528a82e464a6ebbfe0cc022bb6047fdff2f'
RUNNER = 'd0f64d5404cf755e988bf634d203d7e9d97896490ad62b0c0f42f51db8a4508a'
DEST = REPO / 'docs/validation/maintainability-20261111/final-candidate-v10'
FAILED_C168_RESULTS_SHA = '45204a6d9d5ae0f4efff791d29a1d023311a5502606693de8e00a94e54df3c10'
FAILED_C168_LOG_SHA = '5847541645c5f2900f8b11caf7c301456c2fdda8456e8975066bcf2ae8ca0c0b'
FAILED_C168_LABELS = [
    'rust_file_size-working', 'rust_file_size-index', 'rust_file_size-revision',
    'complexity_policy-working', 'complexity_policy-index', 'complexity_policy-revision',
    'tooling-regressions', 'fmt', 'check', 'clippy-packages',
]
assert len(sys.argv) == 2
RUN = Path(sys.argv[1]).resolve()
assert RUN.is_relative_to(ROOT.resolve()) and RUN.name.startswith('validation-4212389c-')


def sha(data):
    return hashlib.sha256(data).hexdigest()


def git(*args):
    return subprocess.check_output(
        ['git', '-c', 'core.autocrlf=true', '-C', str(REPO), *args], text=True,
        env={key: value for key, value in os.environ.items() if not key.upper().startswith('GIT_')},
    ).strip()


assert git('rev-parse', 'HEAD') == CANDIDATE
assert Path(git('rev-parse', '--show-toplevel')).resolve() == REPO.resolve()
assert git('rev-parse', 'HEAD^{tree}') == TREE and git('rev-parse', 'HEAD^') == PARENT
assert git('branch', '--show-current') == 'maintainability/validated-v10'
assert git('status', '--porcelain') == '' and not DEST.exists()
authors = git('log', '--format=%an <%ae>', '57d7395bce9e187ff9f2a3ce9b96dc0d65715600..HEAD').splitlines()
assert len(authors) == 27 and set(authors) == {'Jonas Kamsker <11245306+JKamsker@users.noreply.github.com>'}
committers = git('log', '--format=%cn <%ce>', '57d7395bce9e187ff9f2a3ce9b96dc0d65715600..HEAD').splitlines()
assert committers == authors
parents = git('rev-list', '--parents', '57d7395bce9e187ff9f2a3ce9b96dc0d65715600..HEAD').splitlines()
assert len(parents) == 27 and all(len(line.split()) == 2 for line in parents)
paths = ['src/repo/navigation/manual_history.rs', 'src/repo/navigation/tests.rs', 'src/repo/navigation/tests_repository.rs']
palette_source = '412d1118fb43af6ecc35a7755e5366949aeda511'
baseline = 'f177144f0a16741ef5016cb3029ab6857e125ae3'
previous = '92656fb7d7c49a728824df9548cccf2c35325ad4'
previous_tree = '8f188f3aa5feab6597f1bdc0a9bf735c4604384c'
assert git('rev-parse', palette_source + '^{tree}') == previous_tree
assert git('rev-parse', previous + '^{tree}') == previous_tree
palette_paths = git('diff', '--name-only', baseline, previous).splitlines()
assert len(palette_paths) == 19 and all(path.startswith('src/repo/') and path.endswith('.rs') for path in palette_paths)
assert set(git('diff', '--name-only', baseline, palette_source).splitlines()) == set(palette_paths)
correction_paths = {
    'src/git/file_comparison/index_transaction/tests.rs',
    'src/git/file_comparison/index_transaction/tests/policy.rs',
    'src/repo/core_seams/palette_actions.rs',
    'src/repo/core_seams/palette_contexts.rs',
    'src/repo/core_seams/palette_shortcuts.rs',
}
assert set(git('diff', '--name-only', previous, CANDIDATE).splitlines()) == correction_paths
assert sha((ROOT / 'review-final-source-580542bf.md').read_bytes()) == '23877b12e49857a4e8bc945efee00d8ebb7fc9644e8d333ef8f9c5734d2d6468'
assert sha((ROOT / 'review-final-source-4212389c.md').read_bytes()) == '53f87ad90dcbff238d41b14e6d361d8b3552f1f9a380eaa0fae162ef81225bb7'
assert git('diff', '--name-only', '580542bfc9ff4d1586077beb57193768d0149fe4', CANDIDATE).splitlines() == ['src/repo/core_seams/palette_shortcuts.rs']
blobs = {path: git('rev-parse', CANDIDATE + ':' + path) for path in paths}
assert blobs == {
    'src/repo/navigation/manual_history.rs': 'c72fc781aa77f79fb4b35909b2c8f47adffe6427',
    'src/repo/navigation/tests.rs': '0647eb9a4ce4088738809b4664982ddc6cc76134',
    'src/repo/navigation/tests_repository.rs': 'ca42f1c2209c77d05ca0d3aa1f5748925409bd02',
}
assert all(blobs[path] == git('rev-parse', FIX + ':' + path) for path in paths[:2])
repository_tests = 'src/repo/navigation/tests_repository.rs'
original_tests = git('show', FIX + ':' + repository_tests)
current_tests = git('show', CANDIDATE + ':' + repository_tests)
old_expected_slice = 'assert_eq!(tab.nav.entries(), &[current.clone()]);'
new_expected_slice = 'assert_eq!(tab.nav.entries(), std::slice::from_ref(&current));'
assert original_tests.count(old_expected_slice) == 1
assert current_tests == original_tests.replace(old_expected_slice, new_expected_slice, 1)
results_raw = (RUN / 'results.json').read_bytes()
results = json.loads(results_raw)
assert results['commit'] == CANDIDATE and results['tree'] == TREE
assert results['status'] == 'passed' and results.get('finished')
assert results['runner_sha256'] == RUNNER == sha((ROOT / 'run-final-candidate-v5.py').read_bytes())
# All original labels remain; the reviewed runner adds six exact navigation probes.
prior_raw = (ROOT / 'validation-0e6a8e52-2ypil253/results.json').read_bytes()
assert sha(prior_raw) == '098ebc67b6efd04411f6403ea9fd34f24b8bd677d16aa1fdb00f92eb56c545c3'
prior = json.loads(prior_raw)
checks = results['checks']
navigation_labels = {'nav-recording-manual-history', 'nav-recording-user-selection', 'nav-recording-forward-history', 'nav-history-walk', 'nav-history-selection', 'nav-history-links'}
assert len(checks) == 39 and len({entry['label'] for entry in checks}) == 39
assert {entry['label'] for entry in checks} == {entry['label'] for entry in prior['checks']} | navigation_labels
for entry in checks:
    if entry['label'] in navigation_labels:
        assert len(entry['test_summaries']) == 1
        count = entry['test_summaries'][0]
        assert count['passed'] == 1 and count['failed'] == count['ignored'] == 0
assert next(entry for entry in checks if entry['label'] == 'tooling-regressions')['python_test_count'] == 61
for label in ['clippy-packages', 'windows-cross-clippy-packages']:
    assert 'Clippy packages: 3 checked.' in (RUN / (label + '.log')).read_text()
for entry in checks:
    assert type(entry['exit']) is int and entry['exit'] == 0
    assert entry['before']['head'] == entry['after']['head'] == CANDIDATE
    assert entry['before']['tree'] == entry['after']['tree'] == TREE
    assert entry['before']['status'] == entry['after']['status'] == ''
    assert sha(Path(entry['log']).read_bytes()) == entry['sha256']
library = next(entry for entry in checks if entry['label'] == 'runtime-gitcraft-lib')
assert library['test_summaries'] == [dict(passed=5234, failed=0, ignored=27, measured=0, filtered=4)]
library_log = Path(library['log']).read_text()
required_tests = [
    'back_and_forward_through_a_repository',
    'back_to_a_diff_selects_its_commit_again',
    'following_links_to_commits_are_steps',
    'manual_history::manual_graph_diff_file_history_is_independent_of_detail_readiness',
    'manual_history::user_selection_and_explicit_same_file_toggle_keep_their_distinct_meanings',
    'manual_history::manual_graph_refinement_and_diff_selection_do_not_depend_on_cached_details',
]
palette_tests = [
    'repo::actions::palette_actions::palette_contracts::feature_contributions_preserve_order_search_hints_and_exact_targets',
    'repo::actions::palette_actions::palette_contexts::transport_intents_and_shortcuts_follow_review_pause_and_keymap_contexts',
    'repo::actions::palette_actions::palette_contexts::owned_groups_keep_their_global_slots_across_repository_contexts',
    'repo::dialogs::stash::palette_tests::palette_stash_intents_keep_their_exact_confirmation_choices',
]
palette_tests += [
    'repo::actions::palette_actions::palette_shortcuts::context_changes_preserve_valid_disabled_and_fallback_shortcuts',
    'git::file_comparison::index_transaction::tests::policy::configured_private_and_group_modes_match_native_git_and_policy_drift_is_refused',
    'git::file_comparison::index_transaction::tests::policy::actual_mode_drift_and_same_mode_controls_cover_private_and_shared_indices',
]
for name in palette_tests:
    assert re.search(r'^test ' + re.escape(name) + r' \.\.\. ok$', library_log, re.M), name
for name in required_tests:
    assert re.search(r'^test ' + re.escape('repo::navigation::tests::' + name) + r' \.\.\. ok$', library_log, re.M), name
lint_raw = (ROOT / 'ci-43109642223-lint-job.json').read_bytes()
assert sha(lint_raw) == 'bc937cbd6c3663c857d85515ba4d4d449176b128b4b957b52c2b1437502d35c7'
lint = json.loads(lint_raw)
assert lint['id'] == 130822169327 and lint['run_id'] == 43109642223
assert lint['head_sha'] == '0622a2ac1237311e29f6dcc94788b30f5b094bb4'
assert lint['conclusion'] == 'success' and lint['status'] == 'completed'
for name in ['Formatting', 'Clippy']:
    assert next(step for step in lint['steps'] if step['name'] == name)['conclusion'] == 'success'
assert sha((ROOT / 'ci-43109642223-lint.log').read_bytes()) == '1fcb3c7d276592e142283f6c7ed78efdef78b290ae07eca42316ee2f4a796648'
sources = [(RUN / 'results.json', 'results.json')]
sources += [(Path(entry['log']), 'logs/' + entry['label'] + '.log') for entry in checks]
sources += [(ROOT / name, 'provenance/' + name) for name in [
    'run-final-candidate-v5.py', 'preserve-palette-candidate-evidence-v5.py',
    'final-92656fb7-progress.log', 'nav-ci-fixture-e831e401.md',
    'nav-v3-candidate-remote.txt', 'ci-followup-archive-remote.txt',
    'combined-nav-v3-size-working.log', 'combined-nav-v3-size-index.log',
    'ci-followup-size-working.log', 'ci-followup-size-index.log',
    'ci-43109642223-lint-job.json', 'ci-43109642223-lint.log',
    'test_final_digest_v5_d0f64d54.py', 'digest-v5-d0f64d54-results.json',
    'digest-v5-d0f64d54-regressions.log',
]]
sources += [(ROOT / name, 'reviews/' + name) for name in [
    'review-navigation-e831e401.md', 'review-nav-fixture-e831e401-lifecycle.md',
    'review-palette-evidence-helper-v5-root.md',
    'review-palette-evidence-helper-v5-adversarial.md',
    'review-final-documentation-0622a2ac.md',
    'review-final-runner-v5-d0f64d54.md', 'review-nav-fixture-e831e401-fresh.md',
    'review-nav-fixture-f177144f-fresh.md',
]]
def validate_stopped_results(stopped_raw, receipt_raw, late_raw):
    """Bind the final refused run and the preserved initial observation receipt."""
    result, receipt, late = map(json.loads, (stopped_raw, receipt_raw, late_raw))
    old_head = '97a6aba4073ea465cb4241123c2d1379766ca234'
    old_tree = '0cea01cc09874f7043cf72990ce3fa5a935cad04'
    old_runner = 'fba211409fd0f961eb803af8d332eca08be039ea241fba7cd4ffec9be5e623b3'
    assert result['commit'] == receipt['commit'] == late['commit'] == old_head
    assert result['tree'] == receipt['tree'] == late['tree'] == old_tree
    assert result['runner_sha256'] == receipt['runner_sha256'] == old_runner
    assert result.get('status') != 'passed'
    assert result['fatal'] == late['fatal'] == 'Candidate dirty or changed during build-tests'
    assert late['results_sha256'] == sha(stopped_raw)
    assert late['initial_observation_receipt_sha256'] == sha(receipt_raw)
    assert late['initial_observation_results_sha256'] == receipt['results_sha256'] == '5e42014aa133bcf5130f644e33eb763eebd79b04198231814ec8cb833257c0be'
    assert late['application_runtime_executed'] is False
    static_labels = [
        'rust_file_size-working', 'rust_file_size-index', 'rust_file_size-revision',
        'complexity_policy-working', 'complexity_policy-index', 'complexity_policy-revision',
        'tooling-regressions', 'fmt', 'check', 'clippy-packages',
        'windows-cross-clippy-packages', 'build-tests',
    ]
    checks = result['checks']
    assert [entry['label'] for entry in checks] == static_labels
    for entry in checks:
        assert type(entry['exit']) is int and entry['exit'] == 0
        assert entry['before']['head'] == old_head and entry['before']['tree'] == old_tree
        assert entry['before']['status'] == entry['after']['status'] == ''
    for entry in checks[:-1]:
        assert entry['after']['head'] == old_head and entry['after']['tree'] == old_tree
    build = checks[-1]
    assert build['after']['head'] == late['after_head'] == 'c16814dbb820d0f0f3cf8d720a4bd1daa30f57a5'
    assert build['after']['tree'] == '77a14d4fcf7aef3bab20f2b2939b8f880df80bd9'
    assert late['before_head'] == old_head and late['last_gate'] == 'build-tests'
    assert type(late['build_command_exit']) is int and late['build_command_exit'] == 0


stopped = ROOT / 'validation-97a6aba4-uaq5w87z'
stopped_raw = (stopped / 'results.json').read_bytes()
receipt_raw = (ROOT / 'stopped-97a6aba4-source-review.json').read_bytes()
late_raw = (ROOT / 'late-97a6aba4-source-review.json').read_bytes()
validate_stopped_results(stopped_raw, receipt_raw, late_raw)
sources += [(stopped / 'results.json', 'source-review-stop/results.json')]
sources += [(path, 'source-review-stop/' + path.name) for path in sorted(stopped.glob('*.log'))]
sources += [(ROOT / name, 'source-review-stop/' + name) for name in [
    'stopped-97a6aba4-source-review.json', 'late-97a6aba4-source-review.json',
    'final-97a6aba4-progress.log',
    'preserve-navigation-candidate-evidence-v2-initial.py',
    'review-navigation-evidence-helper-v2-initial.md',
    'review-navigation-evidence-helper-v2-supersession.md',
    'preserve-navigation-candidate-evidence.py', 'review-navigation-evidence-helper.md',
    'review-navigation-c7f59f40.md', 'review-nav-fixture-c7f59f40-lifecycle.md',
    'review-nav-fixture-c7f59f40-lifecycle-correction.md',
    'review-navigation-cached-forward-correction.md', 'nav-ci-fixture-c7f59f40.md',
    'review-nav-candidate-gate.md',
]]
sources += [(ROOT / name, 'provenance/' + name) for name in [
    'preserve-navigation-candidate-evidence-v2.py',
    'review-navigation-evidence-helper-v2.md',
    'test_navigation_stopped_guard_v2.py', 'navigation-stopped-guard-v2-results.json',
    'navigation-stopped-guard-v2-regressions.log',
    'test_navigation_archive_guards_v3.py', 'navigation-archive-guards-v3-results.json',
    'navigation-archive-guards-v3-regressions.log',
    'review-navigation-evidence-helper-v3-owner-correction.md',
]]


def validate_failed_c168_results(failed_raw, failed_logs):
    """Preserve the prior strict-Clippy failure without implying runtime ran."""
    result = json.loads(failed_raw)
    head = 'c16814dbb820d0f0f3cf8d720a4bd1daa30f57a5'
    tree = '77a14d4fcf7aef3bab20f2b2939b8f880df80bd9'
    assert sha(failed_raw) == FAILED_C168_RESULTS_SHA
    assert result['commit'] == head and result['tree'] == tree
    assert result['runner_sha256'] == 'd0f64d5404cf755e988bf634d203d7e9d97896490ad62b0c0f42f51db8a4508a'
    assert result.get('status') != 'passed' and not result.get('finished')
    assert result['fatal'] == 'Gate failed: clippy-packages'
    checks = result['checks']
    assert [entry['label'] for entry in checks] == FAILED_C168_LABELS
    assert set(failed_logs) == set(FAILED_C168_LABELS)
    for entry in checks:
        assert type(entry['exit']) is int
        assert entry['exit'] == (1 if entry['label'] == 'clippy-packages' else 0)
        assert entry['before']['head'] == entry['after']['head'] == head
        assert entry['before']['tree'] == entry['after']['tree'] == tree
        assert entry['before']['status'] == entry['after']['status'] == ''
        assert entry['sha256'] == sha(failed_logs[entry['label']])
    log = failed_logs['clippy-packages']
    assert sha(log) == FAILED_C168_LOG_SHA
    text = log.decode()
    assert 'src/repo/navigation/tests_repository.rs:65:39' in text
    assert 'cloned_ref_to_slice_refs' in text
    assert 'std::slice::from_ref(&current)' in text


failed_c168 = ROOT / 'validation-c16814db-n904yq7m'
failed_c168_raw = (failed_c168 / 'results.json').read_bytes()
failed_c168_logs = {label: (failed_c168 / (label + '.log')).read_bytes() for label in FAILED_C168_LABELS}
validate_failed_c168_results(failed_c168_raw, failed_c168_logs)
sources += [(failed_c168 / 'results.json', 'clippy-source-failure-c168/results.json')]
sources += [(failed_c168 / (label + '.log'), 'clippy-source-failure-c168/' + label + '.log') for label in FAILED_C168_LABELS]
sources += [(ROOT / name, 'clippy-source-failure-c168/' + name) for name in [
    'final-c16814db-progress.log', 'nav-v2-candidate-remote.txt',
    'combined-nav-v2-size-working.log', 'combined-nav-v2-size-index.log',
]]
sources += [(ROOT / name, 'palette/' + name) for name in [
    'review-maintainability-scope-c16814db.md', 'review-remaining-hotspots-f177144f.md',
    'review-palette-423758ee-nav.md', 'review-palette-5b571106-nav.md',
    'review-palette-5b571106-root.md', 'review-final-source-92656fb7.md',
    'palette-owners-source-parity-5b571106.json',
    'palette-owners-size-working.log', 'palette-owners-size-staged.log',
    'combined-palette-v8-size-working.log', 'combined-palette-v8-size-index.log',
    'palette-v8-final-candidate-remote.txt',
    'preserve-navigation-candidate-evidence-v3.py',
    'test_palette_archive_guards_v5.py', 'palette-archive-guards-v5-results.json',
    'palette-archive-guards-v5-regressions.log', 'prepare-palette-evidence-v4.py',
]]
intermediate = ROOT / 'validation-f177144f-91pjrzai'
sources += [(intermediate / 'results.json', 'intermediate-navigation/results.json')]
sources += [(path, 'intermediate-navigation/' + path.name) for path in sorted(intermediate.glob('*.log'))]
sources += [(ROOT / 'final-f177144f-progress.log', 'intermediate-navigation/progress.log')]
assert sha((intermediate / 'results.json').read_bytes()) == '42c30bc0deebeaea78a9e3ea0385331dca2a5f5cf7e069252b024d630eb779f0'
sources += [(ROOT / name, 'layout-correction/' + name) for name in [
    'review-palette-item-layout-correction.md', 'review-palette-412d1118-nav.md',
    'review-final-source-02a5c7ce.md', 'palette-final-candidate-remote.txt',
    'palette-owners-layout-size-working.log', 'palette-owners-layout-size-staged.log',
    'clippy-item-layout-probe.rs', 'clippy-item-layout-probe.log',
    'clippy-item-layout-fixed-probe.rs', 'clippy-item-layout-fixed-probe.log',
    'clippy-item-layout-fixed-probe-result.txt',
    'preserve-palette-candidate-evidence-v4.py',
    'test_palette_archive_guards_v4.py', 'palette-archive-guards-v4-results.json',
    'palette-archive-guards-v4-regressions.log',
    'review-palette-evidence-helper-v4-root.md',
    'review-palette-evidence-helper-v4-adversarial.md', 'prepare-palette-evidence-v5.py',
]]
# Historical926 is FAILED or INCOMPLETE, never a successful final archive.
FAILED_926_RESULTS_SHA = '25971817dd914e348848b627d7b31408716ff9e34e704a6ba6819804d7d56786'
FAILED_926_LOG_SHA = '8de107f989a8e93a5998991e907588d55869974948daa4dcdbc55909e98c8e51'
PARTIAL_926_RESULTS_SHA = 'b50dfde33be67a1a76ccf496a1cab11fe66077b1e8eb4d674fbfbe6984ee2130'
FAILED_926_HEAD = '92656fb7d7c49a728824df9548cccf2c35325ad4'
FAILED_926_TREE = '8f188f3aa5feab6597f1bdc0a9bf735c4604384c'
FAILED_926_LABELS = FAILED_C168_LABELS + [
    'windows-cross-clippy-packages', 'build-tests', 'frame-font-readiness',
    'frame-accessibility', 'frame-layout-profile', 'frame-settings-profile',
    'recording-pipes', 'recording-outcomes', 'recording-resolver',
    'nav-recording-manual-history', 'nav-recording-user-selection',
    'nav-recording-forward-history', 'nav-history-walk', 'nav-history-selection',
    'nav-history-links', 'build-recovery-recording', 'list-recovery-recording',
    'recovery-recording', 'runtime-gitcraft_os-lib', 'runtime-gitcraft-main',
    'runtime-standalone_cli-standalone_cli', 'runtime-mcp_stdio-mcp_stdio',
    'runtime-gitcraft-lib',
]
FAILED_926_NAMES = [
    'git::file_comparison::index_transaction::tests::configured_private_and_group_modes_match_native_git_and_policy_drift_is_refused',
    'repo::actions::palette_actions::palette_contexts::transport_intents_and_shortcuts_follow_review_pause_and_keymap_contexts',
]

FAILED_580_RESULTS_SHA = '08e0fdc0fd69da6a18bfc2eed44a540fb5afbfa6d0addd80e2343d95ac101bd8'
FAILED_580_LOG_SHA = 'ffd53319b474858317452d8d32eaeca982ebf516ad8a1867e6f730c25c222606'


def validate_failed_580_results(raw, logs):
    """Exact early-Clippy failure; no later gate or application execution."""
    result = json.loads(raw)
    assert sha(raw) == FAILED_580_RESULTS_SHA
    assert result['commit'] == '580542bfc9ff4d1586077beb57193768d0149fe4'
    assert result['tree'] == '091687f298049acfa30ef376e6a858b103ad97e2'
    assert result['runner_sha256'] == RUNNER
    assert 'status' not in result and 'finished' not in result
    assert result['fatal'] == 'Gate failed: clippy-packages'
    assert [entry['label'] for entry in result['checks']] == FAILED_C168_LABELS
    assert set(logs) == set(FAILED_C168_LABELS)
    for entry in result['checks']:
        assert type(entry['exit']) is int
        assert entry['exit'] == (1 if entry['label'] == 'clippy-packages' else 0)
        for side in ['before', 'after']:
            assert entry[side]['head'] == result['commit']
            assert entry[side]['tree'] == result['tree'] and entry[side]['status'] == ''
        assert sha(logs[entry['label']]) == entry['sha256']
    log = logs['clippy-packages']
    assert sha(log) == FAILED_580_LOG_SHA
    text = log.decode('utf-8')
    assert 'src/repo/core_seams/palette_shortcuts.rs:34:23' in text
    assert 'error: used `unwrap()` on an `Option` value' in text
    assert 'clippy::unwrap-used' in text
    return result


def validate_926_results(raw, logs, *, failed):
    """Pure guard for the two exact superseded manifests and all raw logs."""
    result = json.loads(raw)
    assert sha(raw) == (FAILED_926_RESULTS_SHA if failed else PARTIAL_926_RESULTS_SHA)
    assert result['commit'] == FAILED_926_HEAD and result['tree'] == FAILED_926_TREE
    assert result['runner_sha256'] == RUNNER
    assert 'status' not in result and 'finished' not in result
    if failed:
        assert result['fatal'] == 'Gate failed: runtime-gitcraft-lib'
    else:
        assert 'fatal' not in result
    labels = FAILED_926_LABELS if failed else FAILED_926_LABELS[:16]
    checks = result['checks']
    assert [entry['label'] for entry in checks] == labels
    assert set(logs) == set(labels)
    for entry in checks:
        expected_exit = 101 if failed and entry['label'] == 'runtime-gitcraft-lib' else 0
        assert type(entry['exit']) is int and entry['exit'] == expected_exit
        for side in ['before', 'after']:
            assert entry[side]['head'] == FAILED_926_HEAD
            assert entry[side]['tree'] == FAILED_926_TREE and entry[side]['status'] == ''
        assert sha(logs[entry['label']]) == entry['sha256']
    if failed:
        library = checks[-1]
        assert library['test_summaries'] == [dict(passed=5230, failed=2, ignored=27, measured=0, filtered=4)]
        log = logs['runtime-gitcraft-lib']
        assert sha(log) == FAILED_926_LOG_SHA
        text = log.decode('utf-8')
        failed_names = re.findall(r'^test (\S+) \.\.\. FAILED$', text, re.M)
        assert sorted(failed_names) == sorted(FAILED_926_NAMES)
        for name in FAILED_926_NAMES:
            assert '---- ' + name + ' stdout ----' in text
        assert 'assertion failed: result.is_err()' in text
        assert 'assertion `left == right` failed\n  left: "Ctrl+Shift+F"\n right: "F6"' in text
        assert re.search(r'^test result: FAILED\. 5230 passed; 2 failed; 27 ignored; 0 measured; 4 filtered out;', text, re.M)
    return result


failed_926 = ROOT / 'validation-92656fb7-85l0p9nv'
partial_926 = ROOT / 'validation-92656fb7-y7ydkc5v'
for directory, failed, category in [
    (failed_926, True, 'failed-926/FAILED'),
    (partial_926, False, 'driver-recovery/INCOMPLETE'),
]:
    raw = (directory / 'results.json').read_bytes()
    labels = FAILED_926_LABELS if failed else FAILED_926_LABELS[:16]
    logs = {label: (directory / (label + '.log')).read_bytes() for label in labels}
    validate_926_results(raw, logs, failed=failed)
    sources += [(directory / 'results.json', category + '/results.json')]
    sources += [(directory / (label + '.log'), category + '/' + label + '.log') for label in labels]

failed_580 = ROOT / 'validation-580542bf-eqpc2kb4'
raw_580 = (failed_580 / 'results.json').read_bytes()
logs_580 = {label: (failed_580 / (label + '.log')).read_bytes() for label in FAILED_C168_LABELS}
validate_failed_580_results(raw_580, logs_580)
sources += [(failed_580 / 'results.json', 'failed-580/FAILED/results.json')]
sources += [(failed_580 / (label + '.log'), 'failed-580/FAILED/' + label + '.log') for label in FAILED_C168_LABELS]
sources += [(ROOT / name, 'failed-580/' + name) for name in [
    'final-580542bf-progress.log', 'watch-owned-580-worker-v3.log',
]]

sources += [(ROOT / name, 'driver-recovery/' + name) for name in [
    'launch-final-926-linux.sh', 'final-926-worker.pid',
    'final-92656fb7-wrapper-lost-progress.log', 'final-92656fb7-linux-progress.log',
    'describe-owned-926-identity.py', 'owned-926-identity.json',
    'watch-owned-926-worker.py', 'watch-owned-926-worker.log',
    'watch-owned-926-selftests.json', 'watch-owned-926-selftests.log',
    'watch-owned-926-owner-note.md', 'review-watch-owned-926-root.md',
    'watch-owned-926-worker-v2.py', 'watch-owned-926-worker-v2.log',
    'watch-owned-926-v2-selftests.json', 'watch-owned-926-v2-selftests.log',
    'watch-owned-926-v2-owner-note.md', 'review-watch-owned-926-v2-root.md',
    'validation-driver-recovery.md', 'failed-92656fb7-runtime-receipt.json',
    'test_driver_supplement_input_order.py', 'driver-supplement-input-order-results.json',
    'driver-supplement-input-order-tests.log',
]]
sources += [(ROOT / name, 'superseded-UNEXECUTED/' + name) for name in [
    'supplement-final-926-driver-evidence.py',
    'supplement-final-926-driver-evidence-before-readme-fix.py',
    'append-reviewed-driver-notes.py',
    'review-final-926-driver-supplement-adversarial.md',
    'review-final-926-driver-supplement-corrected-adversarial.md',
]]
sources += [(ROOT / name, 'final-correction/' + name) for name in [
    'review-final-source-580542bf.md', 'review-permission-fixtures-205d7528-nav.md',
    'review-permission-fixtures-92656fb7.md', 'review-index-policy-92656fb7.md',
    'permission-fixtures-size-working.log', 'permission-fixtures-size-index.log',
    'permission-fixtures-remote.txt', 'palette-shortcuts-size-working.log',
    'palette-shortcuts-size-index.log', 'palette-shortcuts-final-remote.txt',
    'palette-shortcuts-v2-size-working.log', 'palette-shortcuts-v2-size-index.log',
    'palette-shortcuts-v2-final-remote.txt', 'review-final-source-4212389c.md',
]]
sources += [(ROOT / name, 'failed-580/driver/' + name) for name in [
    'launch-final-580-linux.sh', 'watch-owned-580-worker-v3.py',
    'watch-owned-580-v3-selftests.json', 'watch-owned-580-v3-selftests.log',
    'watch-owned-580-v3-owner-note.md', 'watch-owned-580-v3-rebind.diff',
    'review-watch-owned-580-v3-root.md',
]]
sources += [(ROOT / name, 'final-driver/' + name) for name in [
    'launch-final-421-linux.sh', 'final-421-worker.pid', 'final-4212389c-progress.log',
    'watch-owned-421-worker-v4.py', 'watch-owned-421-worker-v4.log',
    'watch-owned-421-v4-selftests.json', 'watch-owned-421-v4-selftests.log',
    'watch-owned-421-v4-owner-note.md', 'watch-owned-421-v4-rebind.diff',
    'review-watch-owned-421-v4-root.md',
]]
sources += [(ROOT / name, 'final-helper/' + name) for name in [
    'preserve-final-candidate-evidence-v6.py', 'test_final_archive_guards_v6.py',
    'final-archive-guards-v6-results.json', 'final-archive-guards-v6-regressions.log',
    'review-final-evidence-helper-v6-adversarial.md',
]]

for name, expected in {
    'preserve-palette-candidate-evidence-v5.py': 'f9e91f531c43fd7f4e6d57ca146d12dc47daf347e5be3ba268917c84d072c5b1',
    'supplement-final-926-driver-evidence.py': 'c572b1d78321edcdf4f2d59116288e8e8d3439f5e000a09505fdda6815010406',
    'supplement-final-926-driver-evidence-before-readme-fix.py': '33ede6b79e44c0c1e38d9ef589c303fa6361a683583163b81a581d5effbac9a8',
    'append-reviewed-driver-notes.py': 'c650ed6271dde74673db4dbfd716f0ff5286bd5887d28373682c1c5db98ed7ee',
}.items():
    assert sha((ROOT / name).read_bytes()) == expected


def validate_final_observer(raw, results_path):
    """Completion is evidence about the owned observer, never a non-child exit."""
    events = [json.loads(line) for line in raw.decode('utf-8').splitlines()]
    assert events[0] == dict(event='owned-receipt-worker-bound', results=str(results_path), child_exit_code_available=False)
    assert events[-1] == dict(event='pidfd-completed', child_exit_code_available=False, child_exit_code=None, final_manifest_passed=True)


validate_final_observer((ROOT / 'watch-owned-421-worker-v4.log').read_bytes(), RUN / 'results.json')

correction_note = '''# Correction of the historical driver recovery note

The preserved validation-driver-recovery.md was written before the replacement
926 run completed. Its passing-observer language described a future condition.
Actual validation-92656fb7-85l0p9nv failed its library gate: 5230 passed, two
failed, 27 ignored, four filtered; exit101 after 32 successful gates. The owned
pidfd established completion; it did not establish a passing manifest or recover
the non-child Linux exit code. The failure receipt binds the exact raw results
and library log hashes. The earlier y7ydkc5v run remains incomplete at16 checks.
Neither is a complete pass. Original notes, helpers and supplements are preserved
verbatim, including superseded conditional pass assertions; none was executed
to archive these failed/incomplete runs. Final421 pass claims are permitted only
after this helper validates that separate candidate's39 gates and exact logs.
'''

rows = []
for entry in checks:
    for count in entry.get('test_summaries', []):
        rows.append('| ' + entry['label'] + ' | ' + ' | '.join(str(count[key]) for key in ['passed', 'failed', 'ignored', 'filtered']) + ' |')
readme_text = f'''# Consolidated maintainability candidate validation

Candidate `{CANDIDATE}`, complete tree `{TREE}`, passed all39 local gates.
This statement is emitted only after validating its actual final passing manifest,
all39 clean before/after source bindings and all39 exact raw log digests.
The parent is `{PARENT}`. The27 linear single-parent units after dev
`57d7395bce9e187ff9f2a3ce9b96dc0d65715600` use exactly Jonas Kamsker
<11245306+JKamsker@users.noreply.github.com> as author and committer.

Previous926 has the complete accepted412 tree `{previous_tree}`. Its19 palette
ownership/test paths are measured from f177. Final421 differs from926 in exactly
five reviewed test paths, including a test-only module declaration; it is not
claimed to equal the older412 whole tree. All three navigation blobs remain
unchanged. The original clone-to-from_ref test correction remains equivalent.
Feature-owned contributors preserve ordered labels, hints, typed actions and
operands. The transport matrix covers16 review/pause/shortcut contexts, with
Default, valid Custom chord, Unbound and deliberately Conflicting fallback.
A separate same-context reset test verifies all seven shortcuts across setting
changes. Existing16 composed review/selection/busy/LFS contexts, fixed intent
contracts and exact stash choices remain. The original Unicode and item layout
blockers and their explicit corrections/reviews remain preserved.

The actual final library summary is5234 passed, zero failed,27 ignored, zero
measured and four filtered. All original six navigation tests, original four
palette tests, the new shortcut-reset test and both permission-policy tests have
exact successful full-library log entries. Permission coverage includes six
private/shared mode cases crossing0600/0644/0660 with real drift and same-mode
controls, without changing the process umask. The original navigation recording
matrices cover72 configurations:40 manual-history,24 user-selection/toggle and
eight links/refinement/selected-diff cases, preserving readiness-sensitive history.

Python discovery passed61 tests. Working/index/revision physical caps and
complexity policy, formatting, compilation, strict Linux and Windows GNU cross
Clippy across three packages, four early UI probes, six exact navigation probes,
recording/recovery and OS/CLI/MCP/checkpoint suites passed. Doctests executed zero
tests. Windows cross checks do not establish native Windows execution. Live
SSH/forge parity and real power-loss durability are not claimed.

| Runtime gate | Passed | Failed | Ignored | Filtered |
| --- | ---: | ---: | ---: | ---: |
{chr(10).join(rows)}

Runtime gates bind fresh binary/application hashes. Synthetic recordings precede
owned-child execution in a probed PID/proc/dev namespace; native owned ACL
fixtures run separately. Builds/tests run directly in WSL on the host, with no
Docker. Scripts, targets and tooling scratch live on E:; private Linux runtime
scratch preserves native filesystem semantics. Observer v1/v2/v3 sources,
recording proofs, ownership notes and root reviews remain available. Read-only
pidfd completion cannot recover a non-child exit status.

Historical CI and earlier local evidence retain their original status. The
0622 Linux test failure and separate successful lint job130822169327 on run
43109642223 are not new CI evidence for421. The97 source-change refusal,
c168 strict-Clippy failure, and intermediate f17739-gate pass/5228 library passes
remain unchanged. Original source and helper reviews are preserved as source
evidence. The failed926 run is archived under `failed-926/FAILED/` with all33
raw logs/results; its summary is5230 passed/two failed/27 ignored/four filtered.
The partial926 run is archived under `driver-recovery/INCOMPLETE/` with all16
logs/results and no overall status, finish or fatal field. The original recovery
note predates the failed run and is preserved verbatim, with an explicit
`driver-recovery/CORRECTION.md` describing its superseded future-pass assumption.
The later580 attempt failed Clippy after ten gates because its new test fixture
used an Option unwrap forbidden by the existing gate; it did not reach builds
of test executables or application runtime. All ten raw logs/results remain
under `failed-580/FAILED/`. Its v3 driver artifacts remain historical failure
evidence. Final421 replaces that one test lookup with an explicit typed loop
checking exactly two strokes. Only its separately bound v4 observer/launcher
and39-gate run support the final pass above.
Old f9 helper and c572 supplements remain unexecuted conditional drafts; no
failure has been relabeled. Historical97/c168 guards and all legacy inputs stay
unchanged. New actual-AST recording proofs cover failed/incomplete guards and
preload-before-write behavior; they are synthetic proof, not application tests.

This is a documentation-only evidence follow-up. Verify application and gate
files unchanged before binding prior execution to documentation changes; no new
application execution is claimed for them. Final CI may begin only after exact
candidate local checks and independent review complete.
'''


def prepare_outputs(sources, readme_text, correction_note, manifest):
    """Preload all source bytes and output bytes before any destination mutation."""
    assert not DEST.exists()
    names = [relative for _, relative in sources]
    assert len(names) == len(set(names))
    for relative in names:
        path = Path(relative)
        assert not path.is_absolute() and '..' not in path.parts
        assert relative not in {'README.md', 'manifest.json'}
    inputs = [(source, relative, source.read_bytes()) for source, relative in sources]
    output = []
    for source, relative, raw in inputs:
        compressed = gzip.compress(raw, mtime=0)
        output.append((relative + '.gz', compressed))
        manifest['artifacts'].append(dict(path=relative + '.gz', source=str(source),
            sha256=sha(raw), gzip_sha256=sha(compressed), bytes=len(raw), gzip_bytes=len(compressed)))
    output += [('README.md', readme_text.encode('utf-8')),
               ('driver-recovery/CORRECTION.md', correction_note.encode('utf-8'))]
    manifest['generated'] = [dict(path=name, sha256=sha(raw), bytes=len(raw)) for name, raw in output[-2:]]
    output.append(('manifest.json', (json.dumps(manifest, indent=2) + '\n').encode('utf-8')))
    assert len(output) == len({name for name, _ in output})
    assert all(not (DEST / name).exists() for name, _ in output)
    return output


def publish_outputs(output):
    """Fresh root and exclusive files prevent replacement of existing evidence."""
    DEST.mkdir(parents=True, exist_ok=False)
    for name, raw in output:
        target = DEST / name
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open('xb') as stream:
            stream.write(raw)


manifest = dict(commit=CANDIDATE, tree=TREE, fixture_source=FIX, fixture_blobs=blobs,
    parent=PARENT, history_units=27, palette_source=palette_source,
    palette_baseline=baseline, palette_candidate=previous, palette_tree=previous_tree,
    correction_paths=sorted(correction_paths), previous_ci_head='0622a2ac1237311e29f6dcc94788b30f5b094bb4',
    historical_926_failed_results_sha256=FAILED_926_RESULTS_SHA,
    historical_926_incomplete_results_sha256=PARTIAL_926_RESULTS_SHA,
    historical_580_failed_results_sha256=FAILED_580_RESULTS_SHA, artifacts=[])
outputs = prepare_outputs(sources, readme_text, correction_note, manifest)
publish_outputs(outputs)
print(json.dumps(dict(destination=str(DEST), artifacts=len(sources))))
