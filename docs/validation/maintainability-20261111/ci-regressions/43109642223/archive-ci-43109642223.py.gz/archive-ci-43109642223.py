"""Preserve the completed Linux CI failure without rerunning CI or application tests."""
from pathlib import Path
import gzip
import hashlib
import json
import os
import subprocess

ROOT = Path('/mnt/e/private/gitcraft-build')
REPO = Path('/mnt/e/private/gitcraft-worktrees/final-maintainability')
PARENT = '0622a2ac1237311e29f6dcc94788b30f5b094bb4'
DEST = REPO / 'docs/validation/maintainability-20261111/ci-regressions/43109642223'
env = {k: v for k, v in os.environ.items() if not k.upper().startswith('GIT_')}


def git(*args):
    return subprocess.check_output(['git', '-c', 'core.autocrlf=true', '-C', str(REPO), *args], env=env, text=True).strip()


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


assert git('rev-parse', 'HEAD') == PARENT
assert git('branch', '--show-current') == 'maintainability/validated-v4'
assert git('status', '--porcelain') == '' and not DEST.exists()
log = (ROOT / 'ci-43109642223-linux.log').read_bytes()
job_raw = (ROOT / 'ci-43109642223-linux-job.json').read_bytes()
job = json.loads(job_raw)
assert job['id'] == 130822169435 and job['run_id'] == 43109642223
assert job['head_sha'] == PARENT and job['conclusion'] == 'failure'
assert sha(log) == '0ec271de8b53870ac4b2f026d492597b576327eaac4d23c4936bbb0001c10017'
assert sha(job_raw) == '60f1222b393226859e97543f341f6e683e826ab35578708922bbf6cfac48bceb'
assert b'test result: FAILED. 5226 passed; 1 failed; 27 ignored; 0 measured; 2 filtered out;' in log
assert b'test repo::navigation::tests::back_and_forward_through_a_repository ... FAILED' in log
inputs = [('linux.log', log), ('linux-job.json', job_raw), ('archive-ci-43109642223.py', Path(__file__).read_bytes())]
manifest = dict(ci_head=PARENT, run_id=job['run_id'], job_id=job['id'], artifacts=[])
DEST.mkdir(parents=True)
for name, raw in inputs:
    compressed = gzip.compress(raw, mtime=0)
    (DEST / (name + '.gz')).write_bytes(compressed)
    manifest['artifacts'].append(dict(path=name + '.gz', sha256=sha(raw), gzip_sha256=sha(compressed), bytes=len(raw)))
(DEST / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
(DEST / 'README.md').write_text('''# Preserved Linux CI regression

CI run [43109642223](https://github.com/JKamsker/gitcraft/actions/runs/43109642223),
completed Linux job `130822169435`, tested head `0622a2ac1237311e29f6dcc94788b30f5b094bb4`.
Compilation, formatting and Linux lint passed. The combined library invocation
reported 5,226 passed, one failed, 27 ignored and two filtered; subsequent isolated
palette/bisect and real SSH steps did not run after that failure. Native Windows
execution is not established by this Linux job record.

`repo::navigation::tests::back_and_forward_through_a_repository` failed at
`tests_repository.rs:80`: Back yielded no diff where the fixture expected its
manually opened commit diff. The source trace identifies readiness-sensitive
setup: redundant user selection auto-reveals the diff when detail is ready/cached,
then explicit same-key open intentionally toggles it closed. Pending detail takes
the fixture's passing path. The link-navigation fixture has an analogous graph-only
assumption. Follow-up coverage must distinguish passive manual-history setup from
real Select/SelectHash reveal and same-file toggle behavior for ready, cached and
delayed detail, retaining the navigation invariants.

The prior local 33-gate pass remains genuine for application candidate `0e6a8e52`
and its documentation-only follow-up `0622a2ac`; it does not supersede this failed
CI result. Its immutable evidence remains under `../../final-candidate/`.
This archive preserves the downloaded job log and completed-job API metadata with
raw/compressed hashes. It does not claim a rerun, a fixed candidate, new application
test execution, or completion of other CI jobs. All scripts and tooling are on E:.
''')
print(json.dumps(dict(destination=str(DEST), artifacts=len(inputs))))
