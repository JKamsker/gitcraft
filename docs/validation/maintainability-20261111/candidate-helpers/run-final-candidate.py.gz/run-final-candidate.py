"""Final immutable-candidate gates. Run only after the candidate is committed and pushed."""
from pathlib import Path
import os, subprocess, json, tempfile, hashlib, re, sys, datetime
repo = Path('/mnt/e/private/gitcraft-worktrees/final-maintainability')
os.chdir(repo)
if len(sys.argv) != 2 or not re.fullmatch(r'[0-9a-f]{40}', sys.argv[1]):
    raise SystemExit('Pass the intended full candidate SHA explicitly')
sha = sys.argv[1]
base = Path(tempfile.mkdtemp(prefix='validation-' + sha[:8] + '-', dir='/mnt/e/private/gitcraft-build'))
compiler_overrides=sorted(key for key in os.environ if
    (key.startswith('RUST') and key!='RUSTUP_HOME') or key.startswith('CLIPPY') or
    re.match(r'^CARGO_(?:BUILD_|TARGET_|ENCODED_|PROFILE_|CONFIG|ALIAS_|UNSTABLE_)',key))
env = {key:value for key,value in os.environ.items() if not key.startswith('GIT_') and key not in compiler_overrides}
build_tmp = base/'build-tmp'
build_tmp.mkdir()
env.update(CARGO_TARGET_DIR='/mnt/e/private/gitcraft-build/linux', CARGO_BUILD_JOBS='4', PATH='/home/jonas/.cargo/bin:/usr/local/bin:/usr/bin:/bin', GIT_CONFIG_GLOBAL='/dev/null', GIT_CONFIG_NOSYSTEM='1', TMPDIR=str(build_tmp))
def git(*args):
    return subprocess.check_output(['git', '-c', 'core.autocrlf=true', *args], env=env, text=True).strip()
def digest(path):
    return hashlib.file_digest(Path(path).open('rb'), 'sha256').hexdigest()
manifest = dict(commit=sha, tree=git('rev-parse', sha+'^{tree}'), started=datetime.datetime.now(datetime.timezone.utc).isoformat(), runner_sha256=digest(__file__), checks=[], artifacts=[], environment={k:env[k] for k in ['CARGO_TARGET_DIR','CARGO_BUILD_JOBS','PATH','GIT_CONFIG_GLOBAL','GIT_CONFIG_NOSYSTEM']}, uid=os.getuid(), gid=os.getgid(), supplementary_groups=os.getgroups(), acl_group_drift_coverage='Conditional within test; a passing summary alone does not establish the real supplementary-group branch ran.')
manifest['removed_compiler_override_names']=compiler_overrides
manifest['toolchain_homes']={key:str(Path(env.get(key,default)).expanduser().resolve()) for key,default in [('HOME',str(Path.home())),('CARGO_HOME',str(Path.home()/'.cargo')),('RUSTUP_HOME',str(Path.home()/'.rustup'))]}
manifest['cargo_home_configs']=[dict(path=str(path),sha256=digest(path)) for name in ['config','config.toml'] if (path:=Path(manifest['toolchain_homes']['CARGO_HOME'])/name).is_file()]
for cmd in [['python3','--version'],['rustc','--version'],['cargo','--version'],['git','--version'],['bwrap','--version']]:
    manifest.setdefault('versions', []).append(dict(command=cmd, output=subprocess.check_output(cmd, env=env, text=True).strip()))
def save():
    (base/'results.json').write_text(json.dumps(manifest, indent=2)+'\n')
def state():
    observed=dict(head=git('rev-parse','HEAD'), tree=git('rev-parse','HEAD^{tree}'), status=git('status','--porcelain=v1','--untracked-files=all'))
    if manifest.get('shell_assets'):
        observed['shell_assets']={item['path']:digest(repo/item['path']) if (repo/item['path']).is_file() else None for item in manifest['shell_assets']}
    return observed
def require(condition, message):
    if not condition:
        manifest['fatal']=message
        save()
        raise SystemExit(message)
def clean(observed):
    expected=dict(head=sha, tree=manifest['tree'], status='')
    if manifest.get('shell_assets'):
        expected['shell_assets']={item['path']:item['sha256'] for item in manifest['shell_assets']}
    return observed == expected
def contained(args):
    return ['bwrap','--unshare-pid','--die-with-parent','--bind','/','/','--dev','/dev','--proc','/proc','--', *args]
def runtime_env():
    scratch=tempfile.mkdtemp(prefix='gitcraft-maintainability-runtime-', dir='/tmp')
    return dict(env, TMPDIR=scratch, XDG_CONFIG_HOME=scratch+'/config', XDG_DATA_HOME=scratch+'/data', XDG_CACHE_HOME=scratch+'/cache')
def run(label, args, custom_env=None, binary=None, expected_passed=None, minimum_passed=None, exact_test=None, python_tests=False):
    entry=dict(label=label, command=args, before=state(), environment={key:(custom_env or env).get(key) for key in ['TMPDIR','XDG_CONFIG_HOME','XDG_DATA_HOME','XDG_CACHE_HOME','CARGO_TARGET_DIR','CARGO_BUILD_TARGET','CARGO_BUILD_JOBS','RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER','CLIPPY_CONF_DIR','CLIPPY_ARGS','RUSTUP_TOOLCHAIN']})
    manifest['checks'].append(entry)
    save()
    require(clean(entry['before']), 'Candidate dirty or changed before '+label)
    if binary and manifest.get('application'):
        entry['application_sha256_before']=digest(manifest['application']['executable'])
        require(entry['application_sha256_before']==manifest['application']['sha256'], 'Application binary changed before '+label)
    if binary:
        entry['binary_sha256_before']=digest(binary)
        require(entry['binary_sha256_before']==binary_hashes[binary], 'Binary changed before '+label)
    log=base/(label+'.log')
    try:
        with log.open('w') as out:
            entry['exit']=subprocess.run(args, env=custom_env or env, stdout=out, stderr=subprocess.STDOUT).returncode
    except Exception as error:
        entry['exception']=str(error)
        save()
        raise
    entry.update(log=str(log), sha256=digest(log), after=state())
    text=log.read_text()
    counts=[dict(zip(['passed','failed','ignored','measured','filtered'], map(int, match))) for match in re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;', text)]
    entry['test_summaries']=counts
    if binary and manifest.get('application'):
        entry['application_sha256_after']=digest(manifest['application']['executable'])
    if binary:
        entry['binary_sha256_after']=digest(binary)
    save()
    require(clean(entry['after']), 'Candidate dirty or changed during '+label)
    if binary:
        require(entry['binary_sha256_after']==binary_hashes[binary], 'Binary changed during '+label)
    if binary and manifest.get('application'):
        require(entry['application_sha256_after']==manifest['application']['sha256'], 'Application binary changed during '+label)
    require(entry['exit']==0, 'Gate failed: '+label)
    if python_tests:
        summary=re.findall(r'^Ran (\d+) tests? in [\d.]+s$', text, re.M)
        require(len(summary)==1 and int(summary[0])>=61 and re.search(r'^OK$', text, re.M) is not None, 'Missing full tooling test summary: '+label)
        require('skipped=' not in text and 'expected failures=' not in text and 'unexpected successes=' not in text, 'Tooling tests were skipped or softened: '+label)
        entry['python_test_count']=int(summary[0])
        save()
    if expected_passed is not None:
        require(len(counts)==1 and counts[0]['passed']==expected_passed and counts[0]['failed']==0 and counts[0]['ignored']==0, 'Unexpected test count: '+label)
    if minimum_passed is not None:
        require(len(counts)==1 and counts[0]['passed']>=minimum_passed and counts[0]['failed']==0, 'Missing test summary or insufficient count: '+label)
    if exact_test:
        require(re.search(r'^test '+re.escape(exact_test)+r' \.\.\. ok$', text, re.M) is not None, 'Exact test did not run: '+label)
    print(label, entry['exit'], counts, flush=True)
print(str(base), flush=True)
require(clean(state()), 'Expected candidate must be checked out clean')
require(Path(git('rev-parse','--show-toplevel')).resolve()==repo.resolve(), 'Git observes a different checkout')
shell_paths=subprocess.check_output(['git','ls-files','-z','--','*.sh'],env=env).split(b'\0')
manifest['shell_assets']=[]
for raw_path in filter(None,shell_paths):
    path=os.fsdecode(raw_path)
    committed=subprocess.check_output(['git','show',sha+':'+path],env=env)
    materialized=(repo/path).read_bytes()
    require(materialized==committed and b'\r' not in committed, 'Shell asset checkout differs from committed LF bytes: '+path)
    manifest['shell_assets'].append(dict(path=path,sha256=hashlib.sha256(materialized).hexdigest()))
require(bool(manifest['shell_assets']), 'No tracked shell assets checked')
save()
probe = subprocess.check_output(contained(['python3','-c',"import os; print(os.readlink('/proc/self/ns/pid'))"]),env=env,text=True).strip()
manifest['namespace_probe'] = dict(host=os.readlink('/proc/self/ns/pid'),child=probe)
require(probe != manifest['namespace_probe']['host'], 'PID namespace containment probe failed')
for script in ['rust_file_size.py','complexity_policy.py']:
    for mode,args in [('working',[]),('index',['--staged']),('revision',['--revision','HEAD'])]:
        run(script.removesuffix('.py')+'-'+mode,['python3','ci/'+script,*args])
tooling_tmp=base/'tooling-tmp'
tooling_tmp.mkdir()
tooling_env=dict(env,TMPDIR=str(tooling_tmp),XDG_CONFIG_HOME=str(base/'tooling-config'),XDG_DATA_HOME=str(base/'tooling-data'),XDG_CACHE_HOME=str(base/'tooling-cache'),CARGO_TARGET_DIR=str(base/'tooling-target'))
run('tooling-regressions',['python3','-m','unittest','discover','-s','ci','-p','test_*.py','-v'],tooling_env,python_tests=True)
for label,args in [('fmt',['cargo','fmt','--all','--','--check']),('check',['cargo','check','--locked','--all-targets']),('clippy-packages',['python3','ci/clippy_packages.py'])]:
    run(label,args)
cross_env=dict(env,CARGO_TARGET_DIR='/mnt/e/private/gitcraft-build/windows-cross',CARGO_BUILD_TARGET='x86_64-pc-windows-gnu',CARGO_BUILD_JOBS='2')
run('windows-cross-clippy-packages',['python3','ci/clippy_packages.py'],cross_env)
run('build-tests',['cargo','test','--locked','--no-run','--message-format=json'])
expected={('gitcraft_os',('lib',),'crates/gitcraft-os/src/lib.rs'),('gitcraft',('lib',),'src/lib.rs'),('gitcraft',('bin',),'src/main.rs'),('checkpoint_cli',('test',),'tests/checkpoint_cli.rs'),('mcp_stdio',('test',),'tests/mcp_stdio.rs'),('standalone_cli',('test',),'tests/standalone_cli.rs')}
applications=[]
for line in (base/'build-tests.log').read_text().splitlines():
    try: item=json.loads(line)
    except ValueError: continue
    if item.get('reason')=='compiler-artifact' and item.get('executable') and not item.get('profile',{}).get('test') and item['target']['name']=='gitcraft' and item['target']['kind']==['bin'] and Path(item['target']['src_path'])==repo/'src/main.rs':
        applications.append(dict(executable=item['executable'],sha256=digest(item['executable'])))
    if item.get('reason')=='compiler-artifact' and item.get('executable') and item.get('profile',{}).get('test'):
        target=item['target']; src=str(Path(target['src_path']).relative_to(repo)); executable=item['executable']
        manifest['artifacts'].append(dict(name=target['name'], kind=target['kind'], source=src, executable=executable, sha256=digest(executable)))
require(len(applications)==1, 'Expected exactly one non-test application binary')
manifest['application']=applications[0]
actual=[(x['name'],tuple(x['kind']),x['source']) for x in manifest['artifacts']]
save()
require(len(actual)==6 and set(actual)==expected, 'Unexpected test artifact inventory: '+repr(actual))
binary_hashes={x['executable']:x['sha256'] for x in manifest['artifacts']}
require(len(binary_hashes)==6, 'Duplicate test executables')
library=next(x['executable'] for x in manifest['artifacts'] if x['source']=='src/lib.rs')
for label,pattern,count in [('recording-pipes','processes::execution::pipe_io::tests',6),('recording-outcomes','processes::recording_outcomes',3),('recording-resolver','resolver::process::tests::recording_failure_mapping_and_join_proof_fail_closed',1)]:
    run(label,contained([library,pattern,'--test-threads=1']), runtime_env(), binary=library, expected_passed=count)
recovery_env=dict(env,CARGO_TARGET_DIR=str(base/'recovery-target'),RUSTFLAGS='--cfg recovery_recording')
recovery_env.pop('CARGO_ENCODED_RUSTFLAGS',None)
run('build-recovery-recording',['cargo','test','--locked','--manifest-path','src/resolver/park/checks/Cargo.toml','--no-run','--message-format=json'],recovery_env)
recovery_artifacts=[]
for line in (base/'build-recovery-recording.log').read_text().splitlines():
    try: item=json.loads(line)
    except ValueError: continue
    if item.get('reason')=='compiler-artifact' and item.get('executable') and item.get('profile',{}).get('test'):
        recovery_artifacts.append(item)
require(len(recovery_artifacts)==1, 'Expected exactly one recovery recording test artifact')
recovery=recovery_artifacts[0]
require(recovery['target']['name']=='gitcraft_recovery_recording' and recovery['target']['kind']==['lib'] and Path(recovery['target']['src_path'])==repo/'src/resolver/park/checks/lib.rs', 'Unexpected recovery recording target')
recovery_binary=recovery['executable']
binary_hashes[recovery_binary]=digest(recovery_binary)
manifest['recovery_recording']=dict(executable=recovery_binary,sha256=binary_hashes[recovery_binary],source='src/resolver/park/checks/lib.rs')
save()
recovery_runtime=dict(runtime_env(),CARGO_TARGET_DIR=recovery_env['CARGO_TARGET_DIR'])
run('list-recovery-recording',contained([recovery_binary,'--list']),recovery_runtime,binary=recovery_binary)
recovery_tests=re.findall(r'^(.+): test$',(base/'list-recovery-recording.log').read_text(),re.M)
require(len(recovery_tests)>=19 and len(set(recovery_tests))==len(recovery_tests), 'Recovery recording test inventory is incomplete')
manifest['recovery_recording']['tests']=recovery_tests
save()
run('recovery-recording',contained([recovery_binary,'--test-threads=1','--nocapture']),recovery_runtime,binary=recovery_binary,expected_passed=len(recovery_tests))
special=[('bisect-isolated','parallel_bisect::tests::a_test_past_its_limit_is_stopped_and_skipped'),('acl-save','standalone::save::tests::acl_only_tightening_during_each_save_boundary_refuses_stale_policy_and_retains_recovery'),('acl-index','git::file_comparison::index_transaction::tests::index_owner_comparison_and_real_group_drift_refuse_stale_publication'),('palette-isolated','app::palette::tests::thousands_of_branches_open_and_filter_quickly')]
for item in manifest['artifacts']:
    binary=item['executable']; label='runtime-'+item['name']+('-lib' if item['source'].endswith('/lib.rs') else '-'+Path(item['source']).stem)
    args=[binary,'--test-threads=4']
    if binary==library:
        for _, test in special: args+=['--skip',test]
    run(label,contained(args),runtime_env(),binary=binary,minimum_passed=0 if item['source']=='src/main.rs' else 1)
for label,test in special:
    args=[library,test,'--exact','--test-threads=1']
    run(label,args if label in ['acl-save','acl-index'] else contained(args),runtime_env(),binary=library,expected_passed=1,exact_test=test)
    manifest['checks'][-1]['containment']='native-owned-ACL-metadata-fixture' if label in ['acl-save','acl-index'] else 'PID/proc/dev namespace'
    save()
run('doc-tests',['cargo','test','--locked','--doc'])
manifest['finished']=datetime.datetime.now(datetime.timezone.utc).isoformat()
manifest['final_state']=state()
require(clean(manifest['final_state']), 'Candidate dirty or changed at final observation')
manifest['status']='passed'
save()
