"""Assemble preserved, reviewable features from dev; never rewrite published branches."""
from pathlib import Path
import json
import os
import re
import subprocess
import sys

if sys.flags.optimize or os.environ.get('PYTHONOPTIMIZE'):
    raise SystemExit('Run without Python optimization: assembly safeguards must remain enabled')

repo = Path('/mnt/e/private/gitcraft-worktrees/final-maintainability')
records_path = Path('/mnt/e/private/gitcraft-build/assembly.json')
old = json.loads(records_path.read_text())
assert len(sys.argv) >= 4 and all(re.fullmatch('[0-9a-f]{40}', value) for value in sys.argv[1:])
accepted = sys.argv[1]
lint_source = sys.argv[2]
ui_source = sys.argv[3]
ci_units = sys.argv[4:]
branch = 'maintainability/validated'
base = old['base']
env = {k: v for k, v in os.environ.items() if k not in ('GIT_DIR', 'GIT_WORK_TREE', 'GIT_INDEX_FILE')}
env.update(GIT_AUTHOR_NAME='Jonas Kamsker', GIT_COMMITTER_NAME='Jonas Kamsker',
           GIT_AUTHOR_EMAIL='11245306+JKamsker@users.noreply.github.com',
           GIT_COMMITTER_EMAIL='11245306+JKamsker@users.noreply.github.com')


def git(*args):
    return subprocess.check_output(['git', '-c', 'core.autocrlf=true', *args], cwd=repo, env=env, text=True).strip()


def run(*args):
    subprocess.run(args, cwd=repo, env=env, check=True, stdout=subprocess.DEVNULL)


assert git('status', '--porcelain') == ''
assert git('branch', '--show-current') == 'maintainability/final'
assert git('rev-parse', 'HEAD') == old['candidate']
assert git('remote', 'get-url', 'origin') == 'https://github.com/JKamsker/gitcraft.git'
assert git('ls-remote', 'origin', 'refs/heads/dev').split()[0] == base
assert not git('branch', '--list', branch)
archive = records_path.with_name('assembly-baf6cc14.json')
if archive.exists():
    assert json.loads(archive.read_text()) == old
else:
    archive.write_text(json.dumps(old, indent=2) + '\n')
run('git', '-c', 'core.autocrlf=true', 'switch', '-c', branch, base)
manifest = dict(base=base, accepted_source=accepted, features=[])
output = records_path.with_name('assembly-validated.json')


def unit(title, paths, source=accepted):
    paths = sorted(set(paths))
    if not paths:
        return
    run('git', '-c', 'core.autocrlf=true', 'restore', '--source', source, '--staged', '--worktree', '--', *paths)
    if '.gitattributes' in paths:
        # Attributes do not rematerialize unchanged files in an existing worktree.
        # Force Git to apply the LF checkout rule before include_str! builds.
        assets = git('ls-files', '*.sh').splitlines()
        assert assets
        run('git', '-c', 'core.autocrlf=true', 'checkout-index', '--force', '--', *assets)
    if not git('diff', '--cached', '--name-only'):
        return
    for mode in ([], ['--staged']):
        run('python3', 'ci/rust_file_size.py', *mode)
    run('git', 'diff', '--cached', '--check')
    run('git', 'commit', '-m', title)
    commit = git('rev-parse', 'HEAD')
    assert git('show', '-s', '--format=%an <%ae>') == 'Jonas Kamsker <11245306+JKamsker@users.noreply.github.com>'
    run('/mnt/c/Program Files/Git/cmd/git.exe', '-C', 'E:/private/gitcraft-worktrees/final-maintainability',
        'push', 'origin', 'HEAD:refs/heads/' + branch)
    assert git('ls-remote', 'origin', 'refs/heads/' + branch).split()[0] == commit
    manifest['features'].append(dict(title=title, commit=commit, source=source, paths=paths,
                                     status='WIP: final combined checks pending'))
    output.write_text(json.dumps(manifest, indent=2) + '\n')
    print(commit, title, flush=True)


def changed():
    return set(git('diff', '--name-only', 'HEAD', accepted).splitlines())


def from_units(commits):
    paths = set()
    for commit in commits:
        paths.update(git('show', '--format=', '--name-only', commit).splitlines())
    return (paths - {''}) & changed()


for feature in old['features']:
    if feature['title'].startswith(('Enforce the compiler', 'Preserve immutable')):
        continue
    unit(feature['title'], feature['paths'], feature['source'])

unit('Keep platform imports and Windows file identities explicit', from_units(['54efd373']))
unit('Keep the recovery recording profile within strict lint rules', from_units(['70a4f9c0']))
unit('Retire Insights reads across repository and forge lifetimes',
     from_units(['be63c471', 'e7f7f38b', 'cb8e29d2', 'd655c9cc']),
     source='d655c9cc5a32726b222481922b2467b8aa771a00')
unit('Keep lifecycle regression fixtures within the existing lint rules',
     [p for p in from_units([lint_source]) if p.startswith('src/repo/insights/')], source=lint_source)
ui_paths = from_units(['d8bb9be6']) | set(git('diff', '--name-only', '651a673f9a1334fac5d3a648493e4897501556a7', ui_source).splitlines())
assert not any(p.startswith(('src/ci/timing', 'src/insights/ci_path/', 'src/repo/insights/ci_path/')) for p in ui_paths)
# Preserve both merged initializer lint corrections and UI frame fixes. These
# paths are explicitly disjoint from the later CI comparison feature.
unit('Keep explicit diff layout choices local and preserve navigation behavior', ui_paths & changed())
unit('Compare pinned CI attempts and observed same-SHA outcomes', from_units(ci_units))
unit('Preserve LF shell assets across Windows and Unix checkouts', {'.gitattributes', 'ci/test_checkout_assets.py'} & changed())
remaining_app = sorted(p for p in changed() if p.endswith('.rs'))
assert not remaining_app, ('Unassigned application changes require a feature decision', remaining_app)
unit('Enforce compiler complexity and complete mandatory quality checks',
     [p for p in changed() if not p.startswith('docs/validation/')])
unit('Preserve immutable scouting and regression evidence', changed())
assert git('status', '--porcelain') == ''
assert git('rev-parse', 'HEAD^{tree}') == git('rev-parse', accepted + '^{tree}')
manifest.update(candidate=git('rev-parse', 'HEAD'), tree=git('rev-parse', 'HEAD^{tree}'), accepted_tree_verified=True)
output.write_text(json.dumps(manifest, indent=2) + '\n')
print('EXACT_TREE_MATCH', manifest['candidate'], manifest['tree'], flush=True)
