"""Pre-final regression checks of preserved 651a; not final delivery evidence."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import tempfile

repo = Path('/mnt/e/private/gitcraft')
sha = '651a673f9a1334fac5d3a648493e4897501556a7'
output = Path('/mnt/e/private/gitcraft-build/targeted-651a')
output.mkdir(exist_ok=True)
env = {k: v for k, v in os.environ.items() if k not in ('GIT_DIR', 'GIT_WORK_TREE', 'GIT_INDEX_FILE')}
env.update(PATH='/home/jonas/.cargo/bin:/usr/local/bin:/usr/bin:/bin', GIT_CONFIG_GLOBAL='/dev/null', GIT_CONFIG_NOSYSTEM='1')


def state():
    def git(*args):
        return subprocess.check_output(['git', '-c', 'core.autocrlf=true', *args], cwd=repo, env=env, text=True).strip()
    return dict(head=git('rev-parse', 'HEAD'), tree=git('rev-parse', 'HEAD^{tree}'), status=git('status', '--porcelain'))


def digest(path):
    with Path(path).open('rb') as source:
        return hashlib.file_digest(source, 'sha256').hexdigest()


def contained(args):
    return ['bwrap', '--unshare-pid', '--die-with-parent', '--bind', '/', '/', '--dev', '/dev', '--proc', '/proc', '--', *args]


initial = state()
assert initial['head'] == sha and initial['status'] == ''
build = Path('/mnt/e/private/gitcraft-build/combined-651a-test-build.log')
items = []
for line in build.read_text().splitlines():
    try:
        items.append(json.loads(line))
    except ValueError:
        pass
assert any(item.get('reason') == 'build-finished' and item.get('success') is True for item in items)
libraries = [item['executable'] for item in items if item.get('reason') == 'compiler-artifact'
             and item.get('profile', {}).get('test') and item.get('executable')
             and item.get('target', {}).get('src_path') == str(repo / 'src/lib.rs')]
assert len(libraries) == 1
binary = libraries[0]
binary_hash = digest(binary)
probe = subprocess.check_output(contained(['python3', '-c', "import os; print(os.readlink('/proc/self/ns/pid'))"]), env=env, text=True).strip()
assert probe != os.readlink('/proc/self/ns/pid')
manifest = dict(candidate=initial, binary=binary, binary_sha256=binary_hash, build_log_sha256=digest(build),
                runner_sha256=digest(__file__), namespace=probe, checks=[])
checks = [
    ('recording-pipes', ['processes::execution::pipe_io::tests'], 6),
    ('recording-outcomes', ['processes::recording_outcomes'], 3),
    ('recording-resolver', ['resolver::process::tests::recording_failure_mapping_and_join_proof_fail_closed'], 1),
    ('insights', ['repo::insights::'], None),
    ('diff-layout', ['repo::diff_split::tests'], 4),
    ('navigation', ['repo::navigation::tests::the_keys_step_through_the_drawn_tab', '--exact'], 1),
    ('checkpoint-shell', ['agent::checkpoint_tests'], None),
    ('repair-shell', ['push_preflight::fix::remote_repair::tests::owned_host_script_repairs_pinned_tree_and_receipts_a_stale_retry', '--exact'], 1),
]
for label, arguments, expected in checks:
    assert state() == initial and digest(binary) == binary_hash
    scratch = tempfile.mkdtemp(prefix='gitcraft-targeted-651a-', dir='/tmp')
    runtime = dict(env, TMPDIR=scratch, XDG_CONFIG_HOME=scratch+'/config', XDG_DATA_HOME=scratch+'/data', XDG_CACHE_HOME=scratch+'/cache')
    log = output / (label + '.log')
    command = contained([binary, *arguments, '--test-threads=1'])
    with log.open('w') as stream:
        code = subprocess.run(command, env=runtime, cwd=repo, stdout=stream, stderr=subprocess.STDOUT).returncode
    text = log.read_text()
    entry = dict(label=label, command=command, exit=code, log_sha256=digest(log), expected_passed=expected)
    manifest['checks'].append(entry)
    (output/'results.json').write_text(json.dumps(manifest, indent=2)+'\n')
    assert state() == initial and digest(binary) == binary_hash
    print(label, code, flush=True)
    assert code == 0, label
    if expected is not None:
        assert f'test result: ok. {expected} passed; 0 failed; 0 ignored;' in text, label
    else:
        assert 'test result: ok. 0 passed;' not in text and 'test result: ok.' in text, label
manifest['status'] = 'passed'
(output/'results.json').write_text(json.dumps(manifest, indent=2)+'\n')
