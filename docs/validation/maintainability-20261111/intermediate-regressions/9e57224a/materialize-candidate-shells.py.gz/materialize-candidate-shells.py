"""Materialize committed LF bytes after verifying only CRLF checkout differences exist."""
from pathlib import Path
import hashlib
import json
import subprocess

repo = Path('/mnt/e/private/gitcraft-worktrees/final-maintainability').resolve()
candidate = '9e57224a584fcebfeeb6f8d9b80a6d5160dd82e6'


def git(*args):
    return subprocess.check_output(['git', '-c', 'core.autocrlf=true', *args], cwd=repo)


assert git('rev-parse', 'HEAD').decode().strip() == candidate
assert not git('diff', '--cached', '--name-only').strip()
changes = []
for raw in filter(None, git('ls-files', '-z', '--', '*.sh').split(b'\0')):
    relative = raw.decode()
    path = repo/relative
    assert path.resolve().is_relative_to(repo) and not path.is_symlink()
    committed = git('show', candidate+':'+relative)
    materialized = path.read_bytes()
    assert b'\r' not in committed
    assert materialized.replace(b'\r\n', b'\n') == committed, relative
    changes.append((path, committed, dict(path=relative,
        before_sha256=hashlib.sha256(materialized).hexdigest(),
        after_sha256=hashlib.sha256(committed).hexdigest(), changed=materialized != committed)))
assert len(changes) == 5
for path, committed, _ in changes:
    path.write_bytes(committed)
assert not git('status', '--porcelain', '--untracked-files=all').strip()
report = dict(commit=candidate, tree=git('rev-parse', 'HEAD^{tree}').decode().strip(),
              runner_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              assets=[record for _, _, record in changes])
Path('/mnt/e/private/gitcraft-build/physical-shell-repair-9e57224a.json').write_text(json.dumps(report, indent=2)+'\n')
print(json.dumps(report, indent=2))
