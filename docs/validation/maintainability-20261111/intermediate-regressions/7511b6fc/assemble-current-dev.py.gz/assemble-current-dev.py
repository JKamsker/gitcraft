"""Replay reviewed feature units on current dev while preserving prior candidates."""
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys

if sys.flags.optimize or os.environ.get('PYTHONOPTIMIZE'):
    raise SystemExit('Assembly safeguards require assertions')
assert len(sys.argv) == 2 and re.fullmatch('[0-9a-f]{40}', sys.argv[1])
accepted = sys.argv[1]
repo = Path('/mnt/e/private/gitcraft-worktrees/final-maintainability')
root = Path('/mnt/e/private/gitcraft-build')
old = json.loads((root / 'assembly-validated.json').read_text())
base = '57d7395bce9e187ff9f2a3ce9b96dc0d65715600'
branch = 'maintainability/validated-v2'
env = {key: value for key, value in os.environ.items() if not key.upper().startswith('GIT_')}
env.update(GIT_AUTHOR_NAME='Jonas Kamsker', GIT_COMMITTER_NAME='Jonas Kamsker',
           GIT_AUTHOR_EMAIL='11245306+JKamsker@users.noreply.github.com',
           GIT_COMMITTER_EMAIL='11245306+JKamsker@users.noreply.github.com')


def git(*args):
    return subprocess.check_output(['git', '-c', 'core.autocrlf=true', *args],
                                   cwd=repo, env=env, text=True).strip()


def run(*args):
    subprocess.run(args, cwd=repo, env=env, check=True, stdout=subprocess.DEVNULL)


assert len(old['features']) == 20
assert old['candidate'] == '9e57224a584fcebfeeb6f8d9b80a6d5160dd82e6'
assert git('rev-parse', 'HEAD') == old['candidate']
assert git('status', '--porcelain') == ''
assert Path(git('rev-parse', '--show-toplevel')).resolve() == repo.resolve()
assert git('branch', '--show-current') == 'maintainability/validated'
assert git('remote', 'get-url', 'origin') == 'https://github.com/JKamsker/gitcraft.git'
assert git('ls-remote', 'origin', 'refs/heads/dev').split()[0] == base
assert git('ls-remote', 'origin', 'refs/heads/maintainability/validated').split()[0] == old['candidate']
assert git('ls-remote', 'origin', 'refs/heads/' + branch) == ''
run('git', 'merge-base', '--is-ancestor', base, accepted)
previous = old['base']
for feature in old['features']:
    assert git('rev-parse', feature['commit'] + '^') == previous
    previous = feature['commit']
run('git', '-c', 'core.autocrlf=true', 'switch', '-c', branch, base)
manifest = dict(base=base, accepted_source=accepted, preserved_candidate=old['candidate'],
                runner_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), features=[])
output = root / 'assembly-current-dev.json'
output.write_text(json.dumps(manifest, indent=2) + '\n')
for index, feature in enumerate(old['features'], 1):
    parent = git('rev-parse', 'HEAD')
    applied = subprocess.run(['git', '-c', 'core.autocrlf=true', 'cherry-pick', '--no-commit', feature['commit']], cwd=repo, env=env)
    overlays = []
    if applied.returncode:
        conflicts = set(git('diff', '--name-only', '--diff-filter=U').splitlines())
        resolution = 'src/repo/review_workflow/echo_push/resolution.rs'
        assert index == 7 and conflicts == {resolution}, (index, conflicts)
        overlays = [resolution, 'src/repo/review_workflow/echo_push/resolution/arguments.rs']
        run('git', '-c', 'core.autocrlf=true', 'restore', '--source', accepted, '--staged', '--worktree', '--', *overlays)
        assert git('diff', '--name-only', '--diff-filter=U') == ''
        run('git', 'cherry-pick', '--quit')
    if index == 16:
        overlays = ['src/repo/diff_split/tests.rs', 'src/settings/view_preferences.rs']
        run('git', '-c', 'core.autocrlf=true', 'restore', '--source', accepted, '--staged', '--worktree', '--', *overlays)
    if index == 20:
        run('git', '-c', 'core.autocrlf=true', 'restore', '--source', accepted, '--staged', '--worktree', '--', 'docs/validation')
    if index == 18:
        assets = git('ls-files', '--', '*.sh').splitlines()
        assert assets
        receipts = []
        for asset in assets:
            path = repo / asset
            assert path.is_file() and not path.is_symlink()
            assert path.resolve().is_relative_to(repo.resolve())
            committed = subprocess.check_output(['git', 'show', ':' + asset], cwd=repo, env=env)
            materialized = path.read_bytes()
            assert b'\r' not in committed and materialized.replace(b'\r\n', b'\n') == committed
            path.write_bytes(committed)
            receipts.append(dict(path=asset, before=hashlib.sha256(materialized).hexdigest(),
                                 after=hashlib.sha256(committed).hexdigest(), blob=git('rev-parse', ':' + asset)))
        run('git', '-c', 'core.autocrlf=true', 'add', '--', *assets)
        assert all(git('rev-parse', ':' + item['path']) == item['blob'] for item in receipts)
        manifest['shell_materializations'] = receipts
    paths = git('diff', '--cached', '--name-only').splitlines()
    assert paths
    if index == 20:
        assert all(path.startswith('docs/validation/') for path in paths)
    else:
        assert set(paths) <= set(feature['paths']) | set(overlays)
    for path in overlays:
        assert git('rev-parse', ':' + path) == git('rev-parse', accepted + ':' + path)
    for args in [[], ['--staged']]:
        run('python3', 'ci/rust_file_size.py', *args)
    run('git', '-c', 'core.autocrlf=true', 'diff', '--cached', '--check')
    run('git', '-c', 'core.autocrlf=true', 'commit', '-m', feature['title'])
    commit = git('rev-parse', 'HEAD')
    assert git('rev-parse', 'HEAD^') == parent
    assert git('show', '-s', '--format=%an <%ae>') == 'Jonas Kamsker <11245306+JKamsker@users.noreply.github.com>'
    run('/mnt/c/Program Files/Git/cmd/git.exe', '-C', 'E:/private/gitcraft-worktrees/final-maintainability', 'push', 'origin', 'HEAD:refs/heads/' + branch)
    assert git('ls-remote', 'origin', 'refs/heads/' + branch).split()[0] == commit
    manifest['features'].append(dict(title=feature['title'], commit=commit, replayed=feature['commit'],
                                     overlays=overlays, paths=paths, status='WIP: final combined checks pending'))
    output.write_text(json.dumps(manifest, indent=2) + '\n')
    print(commit, feature['title'], flush=True)
assert git('status', '--porcelain') == ''
assert git('rev-parse', 'HEAD^{tree}') == git('rev-parse', accepted + '^{tree}')
manifest.update(candidate=git('rev-parse', 'HEAD'), tree=git('rev-parse', 'HEAD^{tree}'), accepted_tree_verified=True)
output.write_text(json.dumps(manifest, indent=2) + '\n')
print('EXACT_TREE_MATCH', manifest['candidate'], manifest['tree'], flush=True)
