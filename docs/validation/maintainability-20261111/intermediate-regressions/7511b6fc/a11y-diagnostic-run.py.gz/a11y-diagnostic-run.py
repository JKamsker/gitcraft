"""One authorized frozen-binary accessibility diagnostic; no build or checkout refresh."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import re
import subprocess
import tempfile

SHA = "7511b6fc12f5b6184c3a061d9810c0ad7983bd5a"
TREE = "2b497fcd6969a917dbb2df10267742e4f5b28737"
TEST = "a11y::tests::repo_view::the_graph_is_reached_with_tab_and_read_aloud"
BASE = Path("/mnt/e/private/gitcraft-build/a11y-7511-diagnostic")
SOURCE = Path("/mnt/e/private/gitcraft-build/validation-7511b6fc-dfc5e7bq/results.json")
OWN = Path("/mnt/e/private/gitcraft-worktrees/ui-fixture-frames")


def require(value, message):
    if not value:
        raise RuntimeError(message)


def digest(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


require(not (BASE / "results.json").exists(), "Diagnostic already recorded; no retries")
source_bytes = SOURCE.read_bytes()
source = json.loads(source_bytes)
require(source["commit"] == SHA and source["tree"] == TREE, "Wrong source candidate")
library, = [item for item in source["artifacts"] if item["source"] == "src/lib.rs"]
require(library["name"] == "gitcraft" and library["kind"] == ["lib"], "Wrong artifact")
application = source["application"]
preflight = []
for label, count in [("recording-pipes", 6), ("recording-outcomes", 3),
                     ("recording-resolver", 1), ("recovery-recording", 27)]:
    check, = [item for item in source["checks"] if item["label"] == label]
    summary, = check["test_summaries"]
    require(check["exit"] == 0 and summary["passed"] == count
            and summary["failed"] == 0 and summary["ignored"] == 0,
            "Recording preflight failed: " + label)
    require(digest(check["log"]) == check["sha256"], "Preflight log changed: " + label)
    require(check["before"]["head"] == SHA and check["after"]["head"] == SHA,
            "Unbound preflight: " + label)
    preflight.append({key: check[key] for key in ["label", "log", "sha256", "test_summaries"]})

env = {key: value for key, value in os.environ.items() if not key.startswith("GIT_")}
scratch = tempfile.mkdtemp(prefix="gitcraft-a11y-7511-", dir="/tmp")
env.update(PATH="/home/jonas/.cargo/bin:/usr/local/bin:/usr/bin:/bin",
           TMPDIR=scratch, XDG_CONFIG_HOME=scratch + "/config",
           XDG_DATA_HOME=scratch + "/data", XDG_CACHE_HOME=scratch + "/cache",
           GIT_CONFIG_GLOBAL="/dev/null", GIT_CONFIG_NOSYSTEM="1", RUST_BACKTRACE="1")


def objects():
    return {kind: subprocess.check_output(["git", "-C", str(OWN), "rev-parse", spec],
                                         env=env, text=True).strip()
            for kind, spec in [("commit", SHA), ("tree", SHA + "^{tree}")]}


def hashes():
    actual = dict(library=digest(library["executable"]),
                  application=digest(application["executable"]))
    require(actual == dict(library=library["sha256"], application=application["sha256"]),
            "Frozen binary/application hash mismatch")
    return actual


def contained(args):
    return ["bwrap", "--unshare-pid", "--die-with-parent", "--bind", "/", "/",
            "--dev", "/dev", "--proc", "/proc", "--", *args]


evidence = dict(commit=SHA, tree=TREE, started=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                source_manifest=str(SOURCE), source_manifest_snapshot_sha256=hashlib.sha256(source_bytes).hexdigest(),
                script_sha256=digest(__file__), artifact=library, application=application,
                preflight=preflight, objects_before=objects(), hashes_before=hashes(),
                environment={key: env[key] for key in ["PATH", "TMPDIR", "XDG_CONFIG_HOME",
                             "XDG_DATA_HOME", "XDG_CACHE_HOME", "GIT_CONFIG_GLOBAL",
                             "GIT_CONFIG_NOSYSTEM", "RUST_BACKTRACE"]})
require(evidence["objects_before"] == dict(commit=SHA, tree=TREE), "Wrong Git objects")
host = os.readlink("/proc/self/ns/pid")
probe = subprocess.check_output(contained(["python3", "-c",
    "import os,json;print(json.dumps(dict(pid=os.getpid(),namespace=os.readlink('/proc/self/ns/pid'))))"]),
    env=env, text=True)
evidence["namespace_probe"] = dict(host=host, inside=json.loads(probe))
require(evidence["namespace_probe"]["inside"]["namespace"] != host, "PID namespace unchanged")
command = contained([library["executable"], TEST, "--exact", "--nocapture", "--test-threads=1"])
evidence["command"] = command
(BASE / "source-results-snapshot.json").write_bytes(source_bytes)
(BASE / "results.json").write_text(json.dumps(evidence, indent=2) + "\n")
with (BASE / "test.log").open("w") as stream:
    result = subprocess.run(command, cwd=OWN, env=env, stdout=stream, stderr=subprocess.STDOUT)
evidence.update(exit=result.returncode, log_sha256=digest(BASE / "test.log"),
                objects_after=objects(), hashes_after=hashes())
text = (BASE / "test.log").read_text()
evidence["test_summaries"] = re.findall(r"test result: (?:ok|FAILED)\..*", text)
require(evidence["objects_after"] == dict(commit=SHA, tree=TREE), "Git object binding changed")
(BASE / "results.json").write_text(json.dumps(evidence, indent=2) + "\n")
print(json.dumps({key: evidence[key] for key in ["exit", "log_sha256", "test_summaries"]}))
raise SystemExit(result.returncode)
