"""Recording-only regression for the immutable evidence helper's Git boundary."""

import ast
import copy
import hashlib
import io
import json
from pathlib import Path
from types import SimpleNamespace
import unittest
from unittest.mock import Mock


ROOT = Path(__file__).resolve().parent
HELPER = ROOT.parent / "preserve-final-evidence.py"
EXPECTED_HELPER_SHA256 = "a955aab130b364b00e92d4a208af9b25c4ccb46c5f39b0334026b5e13e075997"
DESTINATION = "/recording-only/destination-repository"
GIT_VARIABLES = [
    "GIT_DIR", "GIT_WORK_TREE", "GIT_INDEX_FILE", "GIT_COMMON_DIR",
    "GIT_CONFIG", "GIT_CONFIG_GLOBAL", "GIT_CONFIG_SYSTEM",
    "GIT_CONFIG_NOSYSTEM", "GIT_CONFIG_COUNT", "GIT_CONFIG_KEY_0",
    "GIT_CONFIG_VALUE_0", "GIT_CONFIG_PARAMETERS", "GIT_CONFIG_ENVIRONMENT",
    "GIT_OBJECT_DIRECTORY", "GIT_ALTERNATE_OBJECT_DIRECTORIES",
    "GIT_CEILING_DIRECTORIES", "GIT_NAMESPACE", "GIT_PREFIX",
    "GIT_EXEC_PATH", "GIT_CONFIG_FUTURE_OVERRIDE",
]
ORDINARY = {
    "PATH": "/recording-only/bin", "HOME": "/recording-only/home",
    "TMPDIR": "/recording-only/tmp", "CARGO_HOME": "/recording-only/cargo",
    "GITHUB_TOKEN": "recording-only-placeholder", "MY_GIT_SETTING": "keep",
}


def digest(data):
    return hashlib.sha256(data).hexdigest()


def git_ast(source):
    functions = [node for node in ast.parse(source).body
                 if isinstance(node, ast.FunctionDef) and node.name == "git"]
    if len(functions) != 1:
        raise ValueError("Expected exactly one actual git() helper")
    return ast.Module(body=[functions[0]], type_ignores=[])


class DropEnvironment(ast.NodeTransformer):
    def __init__(self):
        self.removed = 0

    def visit_Call(self, node):
        self.generic_visit(node)
        if isinstance(node.func, ast.Attribute) and node.func.attr == "check_output":
            self.removed += sum(keyword.arg == "env" for keyword in node.keywords)
            node.keywords = [keyword for keyword in node.keywords if keyword.arg != "env"]
        return node


def suite(module):
    class GitEnvironment(unittest.TestCase):
        def test_actual_helper_records_destination_and_strips_all_git_overrides(self):
            variants = [str.upper, str.lower, lambda value: value.title()]
            cases = [
                {variant(name): "untrusted-override"}
                for name in GIT_VARIABLES for variant in variants
            ]
            cases.append({variant(name): "untrusted-override"
                          for name in GIT_VARIABLES for variant in variants})
            for overrides in cases:
                with self.subTest(override_names=sorted(overrides)):
                    environment = dict(ORDINARY, **overrides)
                    original = environment.copy()
                    execute = Mock(return_value="recorded-output\n")
                    namespace = {
                        "os": SimpleNamespace(environ=environment),
                        "subprocess": SimpleNamespace(check_output=execute),
                        "REPO": DESTINATION,
                    }
                    exec(compile(copy.deepcopy(module), str(HELPER), "exec"), namespace)
                    self.assertEqual(namespace["git"]("rev-parse", "--show-toplevel"),
                                     "recorded-output")
                    execute.assert_called_once()
                    args, options = execute.call_args
                    self.assertEqual(args, (["git", "-c", "core.autocrlf=true", "-C",
                                             DESTINATION, "rev-parse", "--show-toplevel"],))
                    self.assertIs(options["text"], True)
                    self.assertIn("env", options, "Git must not inherit the host environment")
                    self.assertEqual(options["env"], ORDINARY)
                    self.assertFalse(any(key.upper().startswith("GIT_")
                                         for key in options["env"]))
                    self.assertEqual(environment, original, "Do not mutate the caller environment")
    return unittest.defaultTestLoader.loadTestsFromTestCase(GitEnvironment)


def main():
    source = HELPER.read_bytes()
    if digest(source) != EXPECTED_HELPER_SHA256:
        raise ValueError("Helper differs from the independently reviewed immutable source")
    module = git_ast(source)
    broken = copy.deepcopy(module)
    mutation = DropEnvironment()
    broken = ast.fix_missing_locations(mutation.visit(broken))
    if mutation.removed != 1:
        raise ValueError("Negative control must remove exactly one env sanitation boundary")
    records = []
    logs = []
    for label, implementation, should_pass in [
        ("fixed", module, True),
        ("negative-control-no-env-sanitation", broken, False),
        ("fixed-again", module, True),
    ]:
        output = io.StringIO()
        result = unittest.TextTestRunner(stream=output, verbosity=2).run(suite(implementation))
        passed = result.wasSuccessful()
        records.append({"label": label, "tests_run": result.testsRun,
                        "failures": len(result.failures), "errors": len(result.errors),
                        "successful": passed, "expected_successful": should_pass})
        logs.append(label + "\n" + output.getvalue())
        if passed != should_pass or result.errors or result.testsRun != 1:
            raise AssertionError(f"Unexpected regression outcome: {records[-1]}")
        if not should_pass and not result.failures:
            raise AssertionError("Negative control must fail an assertion")
    if HELPER.read_bytes() != source:
        raise AssertionError("The actual helper must remain unchanged")
    log = "\n".join(logs).encode()
    (ROOT / "review-regression.log").write_bytes(log)
    results = {
        "helper": str(HELPER), "helper_sha256": digest(source),
        "test_sha256": digest(Path(__file__).read_bytes()),
        "log_sha256": digest(log), "schedules": records,
        "variable_names": GIT_VARIABLES, "case_variants": ["upper", "lower", "title"],
        "cases_per_schedule": len(GIT_VARIABLES) * 3 + 1,
        "boundary": "Only the actual git() AST is executed; subprocess.check_output is a Mock.",
        "limitations": "No Git/process/repository operation, application build/test, CI, or final-run gate execution.",
    }
    (ROOT / "results.json").write_text(json.dumps(results, indent=2) + "\n")
    print(json.dumps({"schedules": records, "cases_per_schedule": results["cases_per_schedule"],
                      "helper_sha256": digest(source)}))


if __name__ == "__main__":
    main()
