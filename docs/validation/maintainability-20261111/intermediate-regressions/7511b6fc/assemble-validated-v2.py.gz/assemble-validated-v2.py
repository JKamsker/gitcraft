"""Preserve the old candidate and replace only its reviewed fixture feature."""
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys

if sys.flags.optimize or os.environ.get('PYTHONOPTIMIZE'):
    raise SystemExit('Assembly safeguards require assertions')
assert len(sys.argv) == 2 and re.fullmatch('[0-9a-f]{40}', sys.argv[1])
accepted = sys.argv[1]
repo = Path('/mnt/e/private/gitcraft-worktrees/final-maintainability')
root = Path('/mnt/e/private/gitcraft-build')
old = json.loads((root / 'assembly-validated.json').read_text())
branch = 'maintainability/validated-v2'
env = {key: value for key, value in os.environ.items() if not key.upper().startswith('GIT_')}
env.update(GIT_AUTHOR_NAME='Jonas Kamsker', GIT_COMMITTER_NAME='Jonas Kamsker',
           GIT_AUTHOR_EMAIL='11245306+JKamsker@users.noreply.github.com',
           GIT_COMMITTER_EMAIL='11245306+JKamsker@users.noreply.github.com')


def git(*args):
    return subprocess.check_output(['git', '-c', 'core.autocrlf=true', *args],
                                   cwd=repo, env=env, text=True).strip()


def run(*args):
    subprocess.run(args, cwd=repo, env=env, check=True, stdout=subprocess.DEVNULL)


assert len(old['features']) == 20
assert old['candidate'] == '9e57224a584fcebfeeb6f8d9b80a6d5160dd82e6'
assert git('rev-parse', 'HEAD') == old['candidate']
assert git('status', '--porcelain') == ''
assert Path(git('rev-parse', '--show-toplevel')).resolve() == repo.resolve()
assert git('branch', '--show-current') == 'maintainability/validated'
assert git('remote', 'get-url', 'origin') == 'https://github.com/JKamsker/gitcraft.git'
assert git('ls-remote', 'origin', 'refs/heads/dev').split()[0] == old['base']
assert git('ls-remote', 'origin', 'refs/heads/maintainability/validated').split()[0] == old['candidate']
assert git('ls-remote', 'origin', 'refs/heads/' + branch) == ''
application_changes = [path for path in git('diff', '--name-only', old['candidate'], accepted).splitlines() if not path.startswith('docs/')]
assert set(application_changes) == {'src/repo/diff_split/tests.rs', 'src/settings/view_preferences.rs'}
previous = old['base']
for feature in old['features']:
    assert git('rev-parse', feature['commit'] + '^') == previous
    previous = feature['commit']
assert git('rev-parse', old['features'][14]['commit']) == 'ce041c0a17ae934626859b5c3e7768cff0c2dda4'
run('git', '-c', 'core.autocrlf=true', 'switch', '-c', branch, old['features'][14]['commit'])
manifest = dict(base=old['base'], accepted_source=accepted, preserved_candidate=old['candidate'],
                runner_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                features=old['features'][:15])
output = root / 'assembly-validated-v2.json'
output.write_text(json.dumps(manifest, indent=2) + '\n')
for index, feature in enumerate(old['features'][15:], 16):
    paths = feature['paths']
    if index == 20:
        paths = git('diff', '--name-only', 'HEAD', accepted).splitlines()
        assert paths and all(path.startswith('docs/validation/') for path in paths)
    run('git', '-c', 'core.autocrlf=true', 'restore', '--source', accepted, '--staged', '--worktree', '--', *paths)
    staged = set(git('diff', '--cached', '--name-only').splitlines())
    assert staged and staged <= set(paths)
    for path in paths:
        assert git('rev-parse', ':' + path) == git('rev-parse', accepted + ':' + path)
    for args in [[], ['--staged']]:
        run('python3', 'ci/rust_file_size.py', *args)
    run('git', '-c', 'core.autocrlf=true', 'diff', '--cached', '--check')
    run('git', '-c', 'core.autocrlf=true', 'commit', '-m', feature['title'])
    commit = git('rev-parse', 'HEAD')
    assert git('show', '-s', '--format=%an <%ae>') == 'Jonas Kamsker <11245306+JKamsker@users.noreply.github.com>'
    run('/mnt/c/Program Files/Git/cmd/git.exe', '-C', 'E:/private/gitcraft-worktrees/final-maintainability', 'push', 'origin', 'HEAD:refs/heads/' + branch)
    assert git('ls-remote', 'origin', 'refs/heads/' + branch).split()[0] == commit
    manifest['features'].append(dict(title=feature['title'], commit=commit, source=accepted,
                                     paths=paths, status='WIP: final combined checks pending'))
    output.write_text(json.dumps(manifest, indent=2) + '\n')
    print(commit, feature['title'], flush=True)
assert git('status', '--porcelain') == ''
assert git('rev-parse', 'HEAD^{tree}') == git('rev-parse', accepted + '^{tree}')
manifest.update(candidate=git('rev-parse', 'HEAD'), tree=git('rev-parse', 'HEAD^{tree}'), accepted_tree_verified=True)
output.write_text(json.dumps(manifest, indent=2) + '\n')
print('EXACT_TREE_MATCH', manifest['candidate'], manifest['tree'], flush=True)
