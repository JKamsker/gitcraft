# Exact-candidate source and assembly review

Reviewer: `/root/gate_scout`.

Candidate: `7511b6fc12f5b6184c3a061d9810c0ad7983bd5a`.
Tree: `2b497fcd6969a917dbb2df10267742e4f5b28737`.
Base: `57d7395bce9e187ff9f2a3ce9b96dc0d65715600`.
The complete candidate tree equals independently reviewed accepted merge
`741ca7fdefcfaf8ef8496ed6b4526fcd169d6f4a`.

Verdict: PASS for the reviewed source scopes and mechanical assembly. No blocking
source finding remains. This is not a runtime or final combined-gate approval.

## Assembly audit

Read immutable Git objects from the scout's own worktree. Independently verified
exactly twenty commits after the current dev base, their complete single-parent
chain, required Jonas author and committer identities, titles, original replay
commit correspondence, and every declared changed-path set. Each unit's paths
remain within its original feature plus declared overlays; the last unit contains
only `docs/validation/` paths. Accepted overlays match both blob and mode at their
feature commits. Final tree equality leaves no unexplained source differences.

Manifest: `E:/private/gitcraft-build/assembly-current-dev.json`.
SHA-256: `e18a22588a0c59a534c4180eeb28364e0dfb0f875bda082bdcbac2394b46fc95`.
Reviewed assembly helper SHA-256:
`19fdfe38be047318e75744740df153f5877a07721d5166f736c5c7934b7f1685`.

Local and remote `maintainability/validated` still point at preserved
`9e57224a584fcebfeeb6f8d9b80a6d5160dd82e6`; remote
`maintainability/validated-v2` points at this candidate. Remote dev was the stated
base when read. The helper's LF materialization preserves committed shell blobs
and records physical hashes; this review does not claim to rerun that operation.

## Source review and bindings

- Rebound the independent review of `9e57224a` to unchanged source. Selected diff,
  passive graph restoration, exact diff-request preservation, pending target
  intent, and new primary-destination retirement retain the reviewed `7ab8e7a`
  fixes and generalized fixtures. Navigation trees remain
  `8f949fc4e9b49028ae1c181db84f3f8709cfbee8` (`navigate/`) and
  `e45eaa360d533f7a12be2fc95dd7ea180a62f75f` (`navigation/`).
- Search ownership and scope setters retain allocation identity, owned-child
  cancellation, current/persisted scope witnesses, and A→B→A retirement.
  Search blob: `23efd3ddf3a1b17d80b3825b51b40b8bc7711adf`.
- Owned process capture/settlement is unchanged from the prior reviewed candidate:
  process tree `b85912c60d2ac4886482d9205cab36ff94025235`. Typed executor phases
  retain their prior guards, completion indices, inverse ownership, and no-op
  stash behavior. Operation-plan tree is now
  `39690d73f17bb99e68f01ad438738939ffc46630` because upstream changed `start.rs`.
- The four reviewed headless fixture corrections from `a4e6b39d` explicitly
  consume frame outputs with `drop_without_applying_deltas`. All frame execution,
  loop axes, zoom/layout/profile assertions, and the existing struct-literal lint
  correction remain. Final fixture blobs are
  `9d93b0364c522f29cac628bbbeb6590c5edc1498` (diff split) and
  `24a86a9aab6e74286dd3a0e0d64d7e4ea8081ebd` (view preferences).
- Rebound the reviewed PR #207 integration at `741ca7fd`. Nineteen other upstream
  files match dev byte-for-byte. The merged action preconditions retain both dev's
  pending-echo waiter condition and the reviewed layout/navigation ownership
  behavior; blob `6196319c4b4d1d31af62c8c2a3b03e3578172983`.
- The sole parser conflict retains extraction and accepts dev's
  `--recurse-submodules=check` alongside `no`. Regression cases cover both modes
  before and after `--`, exact positional targets, and unchanged flags; unsupported
  `on-demand` remains rejected. Upstream ordinary-push source-evidence regression
  remains intact. Resolution blob: `d4f1ec7bf08b68823eacabcb3bd9a45c15ed113f`;
  argument-parser blob: `36579951648ae3d6dbc206569354f43c8b11ce73`.

## Authorship exclusions and limits

Semantic approval excludes this scout's CI comparison and quality-policy code.
Own-authored native-query/backend, recovery scan/provenance, and transcript
parser/budget units retain their separate external-review requirement; mechanical
tree/path equality does not turn an author's inspection into independent approval.

No candidate index/status refresh, repository edits, builds, tests, runtime
scenarios, signals, or GitHub CI were performed. Only this standalone review file
was written outside the repository. The full local runner was active separately;
its results are not claimed or inferred here. Final combined validation must be
reported from its own immutable execution evidence.
