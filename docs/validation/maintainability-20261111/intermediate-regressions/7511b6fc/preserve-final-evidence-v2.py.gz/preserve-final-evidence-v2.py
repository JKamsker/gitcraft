"""Archive completed candidate checks without altering application source."""
import gzip
import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path

ROOT = Path('/mnt/e/private/gitcraft-build')
REPO = Path('/mnt/e/private/gitcraft-worktrees/final-maintainability')
CANDIDATE = '7511b6fc12f5b6184c3a061d9810c0ad7983bd5a'
TREE = '2b497fcd6969a917dbb2df10267742e4f5b28737'
assert len(sys.argv) == 2
RUN = Path(sys.argv[1]).resolve()
assert RUN.is_relative_to(ROOT.resolve()) and RUN.name.startswith('validation-7511b6fc-')
DEST = REPO / 'docs/validation/maintainability-20261111/final-candidate'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def git(*args):
    return subprocess.check_output(
        ['git', '-c', 'core.autocrlf=true', '-C', str(REPO), *args], text=True,
        env={key: value for key, value in os.environ.items() if not key.upper().startswith('GIT_')},
    ).strip()


results = json.loads((RUN / 'results.json').read_bytes())
assert results['commit'] == CANDIDATE and results['tree'] == TREE
assert results['status'] == 'passed' and results.get('finished')
assert git('rev-parse', 'HEAD') == CANDIDATE
assert Path(git('rev-parse', '--show-toplevel')).resolve() == REPO.resolve()
assert git('rev-parse', 'HEAD^{tree}') == TREE
assert git('rev-list', '--count', '57d7395bce9e187ff9f2a3ce9b96dc0d65715600..HEAD') == '20'
assert git('status', '--porcelain') == ''
assert not DEST.exists()
checks = results['checks']
assert len(checks) == 31, len(checks)
assert len({entry['label'] for entry in checks}) == 31
expected_labels = {
    *(name + '-' + mode for name in ['rust_file_size', 'complexity_policy']
      for mode in ['working', 'index', 'revision']),
    'tooling-regressions', 'fmt', 'check', 'clippy-packages',
    'windows-cross-clippy-packages', 'build-tests', 'recording-pipes',
    'frame-layout-profile', 'frame-settings-profile',
    'recording-outcomes', 'recording-resolver', 'build-recovery-recording',
    'list-recovery-recording', 'recovery-recording', 'runtime-gitcraft_os-lib',
    'runtime-gitcraft-lib', 'runtime-gitcraft-main',
    'runtime-checkpoint_cli-checkpoint_cli', 'runtime-mcp_stdio-mcp_stdio',
    'runtime-standalone_cli-standalone_cli', 'bisect-isolated', 'acl-save',
    'acl-index', 'palette-isolated', 'doc-tests',
}
assert {entry['label'] for entry in checks} == expected_labels
assert next(entry for entry in checks if entry['label'] == 'tooling-regressions')['python_test_count'] == 61
for label in ['clippy-packages', 'windows-cross-clippy-packages']:
    assert 'Clippy packages: 3 checked.' in (RUN / (label + '.log')).read_text()
for entry in checks:
    assert entry['exit'] == 0
    assert entry['before']['head'] == entry['after']['head'] == CANDIDATE
    assert entry['before']['tree'] == entry['after']['tree'] == TREE
    assert entry['before']['status'] == entry['after']['status'] == ''
    assert sha(Path(entry['log']).read_bytes()) == entry['sha256']
assert results['runner_sha256'] == sha((ROOT / 'run-final-candidate-v2.py').read_bytes())
manifest = {'commit': CANDIDATE, 'tree': TREE, 'artifacts': []}
sources = [(RUN / 'results.json', 'results.json')]
sources += [(Path(entry['log']), 'logs/' + entry['label'] + '.log') for entry in checks]
sources += [(ROOT / name, 'provenance/' + name) for name in [
    'assembly-current-dev.json', 'assembly-current-dev-progress.log',
    'assemble-current-dev.py', 'assemble-validated-v2.py',
    'assembly-validated-v2-progress.log', 'run-final-candidate-v2.py',
    'preserve-final-evidence-v2.py', 'preserve-final-evidence.py',
    'final-7511b6fc-progress.log',
]]
sources += [(ROOT / name, 'reviews/' + name) for name in [
    'review-gate-7511b6fc.md', 'review-hotspot-7511b6fc.md',
    'review-lifecycle-7511b6fc.md', 'review-evidence-helper.md',
    'review-evidence-helper-v2.md',
]]
sources += [(source, 'helper-regression/' + source.name) for source in
            sorted((ROOT / 'evidence-helper-regression').iterdir()) if source.is_file()]
archive_inputs = [(source, relative, source.read_bytes()) for source, relative in sources]
for source, relative, data in archive_inputs:
    compressed = gzip.compress(data, mtime=0)
    target = DEST / (relative + '.gz')
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(compressed)
    manifest['artifacts'].append({
        'path': relative + '.gz', 'source': str(source),
        'sha256': sha(data), 'gzip_sha256': sha(compressed),
        'bytes': len(data),
    })
(DEST / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
summary = []
for entry in checks:
    if entry.get('test_summaries'):
        for counts in entry['test_summaries']:
            summary.append('| ' + entry['label'] + ' | ' + ' | '.join(
                str(counts[name]) for name in ['passed', 'failed', 'ignored', 'filtered']
            ) + ' |')
readme = f'''# Final candidate local validation

Application candidate: `{CANDIDATE}`. Complete source tree: `{TREE}`.
This tree equals accepted combined source `741ca7fdefcfaf8ef8496ed6b4526fcd169d6f4a`.
The assembled history contains 20 feature units from dev
`57d7395bce9e187ff9f2a3ce9b96dc0d65715600`, with preserved source provenance.

All 31 local gates passed. Full Python discovery ran 61 tests successfully.
Working-tree, complete-index and committed-revision size and complexity checks,
formatting, all-target compilation, and strict Clippy for all three tracked Cargo
packages passed. Linux execution and Windows GNU cross-target Clippy are distinct:
the cross check did not execute native Windows tests.

| Runtime gate | Passed | Failed | Ignored | Filtered |
| --- | ---: | ---: | ---: | ---: |
{chr(10).join(summary)}

The four specially isolated library tests are excluded from the combined library
invocation and each executed separately. Ignored tests remain visible in raw logs;
this local run does not establish live SSH/WSL/forge parity or real power-loss
durability. Synthetic recording checks precede owned-child execution. Real
process suites run in a probed PID/proc/dev namespace without host PID selectors
or host signals. Existing owned ACL fixtures run in private native Linux folders.
No Docker was used. Build scripts, compiler targets and tooling scratch are on E:;
private Linux runtime scratch preserves native filesystem semantics.

Prior candidate `9e57224a` failed two newly added headless zoom/profile fixtures:
egui frame outputs contained unapplied texture deltas. The four corrected output
disposals preserve all frame executions, assertions and loop axes. Both exact
tests now run early and again in the complete library suite. Prior failed logs,
source reviews and shell-checkout repairs remain in `../intermediate-regressions`.
Dev advanced during validation with PR #207; the final history replays onto its
merge commit and preserves its direct-push behavior. The only parser conflict
retains extracted ownership plus submodule-check support and a generalized
supported-mode/option-boundary regression. Unit 18 explicitly materializes exact
LF shell bytes and records before/after hashes without changing index blobs.
An earlier replay helper correctly refused the stale dev base before mutation;
that stopped helper and log are preserved separately from the successful replay.

Three independent source reviews bind to the exact application candidate and
state their authorship exclusions. Source review is separate from test execution.
Raw results bind every gate to unchanged HEAD/tree, binary and log hashes, cleared
compiler overrides, tool versions, commands, environment and shell checkout bytes.
Gzip archives preserve original bytes; manifest hashes verify both representations.
The original runner and assembly helper are preserved in `../candidate-helpers`.
The archive helper's inherited Git-environment correction has recording-only
coverage: 61 varied override cases pass, fail with sanitation removed in memory,
and pass after restoration. This is separate from application test execution.

This evidence is added in a documentation-only follow-up. Application and gate
files must be verified unchanged before binding these prior executions to that
follow-up. No new application test execution is claimed for documentation changes.
Final GitHub CI is intentionally deferred until local checks and independent
review pass; its exact commit and results belong in the consolidated PR.
'''
(DEST / 'README.md').write_text(readme)
print(json.dumps({'destination': str(DEST), 'artifacts': len(sources)}))
