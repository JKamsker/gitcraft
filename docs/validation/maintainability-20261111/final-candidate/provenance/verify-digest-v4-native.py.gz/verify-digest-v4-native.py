"""Hash owned E: fixtures with only the reviewed digest AST; no runner execution."""
import ast, hashlib, json, re, subprocess, tempfile
from pathlib import Path
ROOT = Path('/mnt/e/private/gitcraft-build')
RUNNER = ROOT / 'run-final-candidate-v4.py'
EXPECTED = 'fba211409fd0f961eb803af8d332eca08be039ea241fba7cd4ffec9be5e623b3'
raw = RUNNER.read_bytes()
assert hashlib.sha256(raw).hexdigest() == EXPECTED
nodes = [n for n in ast.parse(raw).body if isinstance(n, ast.FunctionDef) and n.name == 'digest']
assert len(nodes) == 1
ns = dict(Path=Path, hashlib=hashlib, re=re, subprocess=subprocess)
exec(compile(ast.fix_missing_locations(ast.Module(body=nodes, type_ignores=[])), str(RUNNER), 'exec'), ns)
folder = Path(tempfile.mkdtemp(prefix='digest-v4-native-', dir=ROOT))
fixture = folder / 'spaced fixture.bin'
checks = []
for label, payload in [('empty', b''), ('one-byte', b'x'), ('binary', bytes(range(256))*256), ('empty-again', b'')]:
    fixture.write_bytes(payload)
    actual = ns['digest'](fixture)
    expected = hashlib.sha256(payload).hexdigest()
    assert actual == expected
    checks.append(dict(label=label, bytes=len(payload), sha256=actual))
# Confirm the original failing zero-byte log also takes the corrected path.
log = ROOT / 'validation-0e6a8e52-ks5048sc/fmt.log'
assert log.stat().st_size == 0
assert ns['digest'](log) == hashlib.sha256(b'').hexdigest()
checks.append(dict(label='original-empty-format-log', bytes=0, sha256=ns['digest'](log)))
report = dict(runner_sha256=EXPECTED, script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), checks=checks, fixture_directory=str(folder), boundary='Actual digest function only; owned hash fixtures and prior empty log; no application build/tests or CI')
(ROOT / 'digest-v4-native-results.json').write_text(json.dumps(report, indent=2)+'\n')
print(json.dumps(report, indent=2))
