"""Read-only native Windows hashing comparison against frozen runner evidence."""
import hashlib
import json
from pathlib import Path
import re
import subprocess
import time

ROOT = Path('/mnt/e/private/gitcraft-build')
EVIDENCE = ROOT / 'validation-7511b6fc-dfc5e7bq/results.json'
CERTUTIL = '/mnt/c/Windows/System32/certutil.exe'
OUT = ROOT / 'native-sha256-7511-results.json'
source = EVIDENCE.read_bytes()
results = json.loads(source)
assert results['commit'] == '7511b6fc12f5b6184c3a061d9810c0ad7983bd5a'
application = results['application']
libraries = [item for item in results['artifacts'] if item['source'] == 'src/lib.rs']
assert len(libraries) == 1
records = []
for label, artifact in [('application', application), ('library-tests', libraries[0])]:
    path = Path(artifact['executable']).resolve()
    assert path.is_relative_to(ROOT.resolve())
    windows_path = 'E:\\' + str(path.relative_to('/mnt/e')).replace('/', '\\')
    command = [CERTUTIL, '-hashfile', windows_path, 'SHA256']
    started = time.perf_counter()
    process = subprocess.run(command, capture_output=True)
    elapsed = time.perf_counter() - started
    output = (process.stdout + process.stderr).decode('utf-8', errors='replace')
    found = re.findall(r'(?im)^\s*([0-9a-f]{64})\s*$', output)
    record = {'label': label, 'path': str(path), 'bytes': path.stat().st_size,
              'command': command, 'seconds': elapsed, 'exit_code': process.returncode,
              'output': output, 'recorded_sha256': artifact['sha256'],
              'native_sha256': found[0].lower() if len(found) == 1 else None}
    records.append(record)
    assert process.returncode == 0 and len(found) == 1, record
    assert record['native_sha256'] == artifact['sha256'], record
report = {'candidate': results['commit'], 'tree': results['tree'],
          'evidence': str(EVIDENCE), 'evidence_sha256': hashlib.sha256(source).hexdigest(),
          'benchmark_script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
          'checks': records,
          'limitations': 'One read-only certutil measurement per frozen binary; no runner modification or build/test execution.'}
OUT.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))
