"""Archive completed candidate checks without altering application source."""
import gzip
import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path

ROOT = Path('/mnt/e/private/gitcraft-build')
REPO = Path('/mnt/e/private/gitcraft-worktrees/final-maintainability')
CANDIDATE = '0e6a8e52d1f16e19122a674b314eef70abeb58b9'
TREE = '1ae8537f6c9d734e1d9194472d897c09b0dd5654'
assert len(sys.argv) == 2
RUN = Path(sys.argv[1]).resolve()
assert RUN.is_relative_to(ROOT.resolve()) and RUN.name.startswith('validation-0e6a8e52-')
DEST = REPO / 'docs/validation/maintainability-20261111/final-candidate'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def git(*args):
    return subprocess.check_output(
        ['git', '-c', 'core.autocrlf=true', '-C', str(REPO), *args], text=True,
        env={key: value for key, value in os.environ.items() if not key.upper().startswith('GIT_')},
    ).strip()


results = json.loads((RUN / 'results.json').read_bytes())
assert results['commit'] == CANDIDATE and results['tree'] == TREE
assert results['status'] == 'passed' and results.get('finished')
assert git('rev-parse', 'HEAD') == CANDIDATE
assert Path(git('rev-parse', '--show-toplevel')).resolve() == REPO.resolve()
assert git('rev-parse', 'HEAD^{tree}') == TREE
assert git('rev-list', '--count', '57d7395bce9e187ff9f2a3ce9b96dc0d65715600..HEAD') == '21'
assert git('status', '--porcelain') == ''
assert not DEST.exists()
checks = results['checks']
assert len(checks) == 33, len(checks)
assert len({entry['label'] for entry in checks}) == 33
expected_labels = {
    *(name + '-' + mode for name in ['rust_file_size', 'complexity_policy']
      for mode in ['working', 'index', 'revision']),
    'tooling-regressions', 'fmt', 'check', 'clippy-packages',
    'windows-cross-clippy-packages', 'build-tests', 'recording-pipes',
    'frame-font-readiness', 'frame-accessibility',
    'frame-layout-profile', 'frame-settings-profile',
    'recording-outcomes', 'recording-resolver', 'build-recovery-recording',
    'list-recovery-recording', 'recovery-recording', 'runtime-gitcraft_os-lib',
    'runtime-gitcraft-lib', 'runtime-gitcraft-main',
    'runtime-checkpoint_cli-checkpoint_cli', 'runtime-mcp_stdio-mcp_stdio',
    'runtime-standalone_cli-standalone_cli', 'bisect-isolated', 'acl-save',
    'acl-index', 'palette-isolated', 'doc-tests',
}
assert {entry['label'] for entry in checks} == expected_labels
assert next(entry for entry in checks if entry['label'] == 'tooling-regressions')['python_test_count'] == 61
for label in ['clippy-packages', 'windows-cross-clippy-packages']:
    assert 'Clippy packages: 3 checked.' in (RUN / (label + '.log')).read_text()
for entry in checks:
    assert entry['exit'] == 0
    assert entry['before']['head'] == entry['after']['head'] == CANDIDATE
    assert entry['before']['tree'] == entry['after']['tree'] == TREE
    assert entry['before']['status'] == entry['after']['status'] == ''
    assert sha(Path(entry['log']).read_bytes()) == entry['sha256']
assert results['runner_sha256'] == sha((ROOT / 'run-final-candidate-v4.py').read_bytes())
assembly = json.loads((ROOT / 'assembly-font-candidate.json').read_bytes())
assert assembly['candidate'] == CANDIDATE and assembly['tree'] == TREE
assert assembly['accepted_tree_verified'] is True
assert results['runner_sha256'] == 'fba211409fd0f961eb803af8d332eca08be039ea241fba7cd4ffec9be5e623b3'
assert sha((ROOT / 'assemble-font-candidate.py').read_bytes()) == '535a6c1b2f85ebc24bd321717edaf4830034a74da3b70eaef40bff15dd6bd7f0'
authors = git('log', '--format=%an <%ae>', '57d7395bce9e187ff9f2a3ce9b96dc0d65715600..HEAD').splitlines()
assert len(authors) == 21 and set(authors) == {'Jonas Kamsker <11245306+JKamsker@users.noreply.github.com>'}
manifest = {'commit': CANDIDATE, 'tree': TREE, 'artifacts': []}
sources = [(RUN / 'results.json', 'results.json')]
sources += [(Path(entry['log']), 'logs/' + entry['label'] + '.log') for entry in checks]
sources += [(ROOT / name, 'provenance/' + name) for name in [
    'assembly-font-candidate.json', 'assembly-font-candidate-progress.log',
    'assemble-font-candidate.py', 'run-final-candidate-v4.py',
    'preserve-final-evidence-v4.py', 'preserve-final-evidence.py',
    'final-0e6a8e52-v4-progress.log', 'font-fixture-inventory-a227a598.md',
    'native-sha256-7511-results.json', 'benchmark-native-sha256-7511.py',
    'test_font_assembly_guard.py', 'font-assembly-guard-results.json',
    'font-assembly-guard.log', 'test_final_digest_v3_28d38c4b.py',
    'digest-v3-28d38c4b-results.json', 'digest-v3-28d38c4b-regressions.log',
    'test_final_digest_v4_fba21140.py', 'digest-v4-fba21140-results.json',
    'digest-v4-fba21140-regressions.log', 'verify-digest-v4-native.py',
    'digest-v4-native-results.json',
]]
sources += [(ROOT / name, 'reviews/' + name) for name in [
    'review-gate-0e6a8e52.md', 'review-hotspot-0e6a8e52.md',
    'review-lifecycle-0e6a8e52.md', 'review-evidence-helper.md',
    'review-evidence-helper-v4.md', 'review-final-helpers-535a-28d3.md',
    'review-headless-font-a227a598.md', 'review-final-runner-v4-fba21140.md',
    'review-evidence-helper-v3.md',
]]
sources += [(source, 'helper-regression/' + source.name) for source in
            sorted((ROOT / 'evidence-helper-regression').iterdir()) if source.is_file()]
stopped = ROOT / 'validation-0e6a8e52-ks5048sc'
sources += [(stopped / 'results.json', 'infrastructure-stop/results.json')]
sources += [(path, 'infrastructure-stop/' + path.name) for path in sorted(stopped.glob('*.log'))]
sources += [(ROOT / name, 'infrastructure-stop/' + name) for name in [
    'run-final-candidate-v3.py', 'final-0e6a8e52-progress.log',
    'preserve-final-evidence-v3.py',
]]
archive_inputs = [(source, relative, source.read_bytes()) for source, relative in sources]
for source, relative, data in archive_inputs:
    compressed = gzip.compress(data, mtime=0)
    target = DEST / (relative + '.gz')
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(compressed)
    manifest['artifacts'].append({
        'path': relative + '.gz', 'source': str(source),
        'sha256': sha(data), 'gzip_sha256': sha(compressed),
        'bytes': len(data),
    })
(DEST / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
summary = []
for entry in checks:
    if entry.get('test_summaries'):
        for counts in entry['test_summaries']:
            summary.append('| ' + entry['label'] + ' | ' + ' | '.join(
                str(counts[name]) for name in ['passed', 'failed', 'ignored', 'filtered']
            ) + ' |')
readme = f'''# Final candidate local validation

Application candidate: `{CANDIDATE}`. Complete source tree: `{TREE}`.
This tree equals accepted combined source `83f25dc09327b0e0db9436ccdb2c815dc17cea68`.
The assembled history contains 21 feature units from dev
`57d7395bce9e187ff9f2a3ce9b96dc0d65715600`, with preserved source provenance.

All 33 local gates passed. Full Python discovery ran 61 tests successfully.
Working-tree, complete-index and committed-revision size and complexity checks,
formatting, all-target compilation, and strict Clippy for all three tracked Cargo
packages passed. Linux execution and Windows GNU cross-target Clippy are distinct:
the cross check did not execute native Windows tests.

| Runtime gate | Passed | Failed | Ignored | Filtered |
| --- | ---: | ---: | ---: | ---: |
{chr(10).join(summary)}

The four specially isolated library tests are excluded from the combined library
invocation and each executed separately. Ignored tests remain visible in raw logs;
this local run does not establish live SSH/WSL/forge parity or real power-loss
durability. Synthetic recording checks precede owned-child execution. Real
process suites run in a probed PID/proc/dev namespace without host PID selectors
or host signals. Existing owned ACL fixtures run in private native Linux folders.
No Docker was used. Build scripts, compiler targets and tooling scratch are on E:;
private Linux runtime scratch preserves native filesystem semantics.

Prior candidate `9e57224a` failed two newly added headless zoom/profile fixtures:
egui frame outputs contained unapplied texture deltas. The four corrected output
disposals preserve all frame executions, assertions and loop axes. Both exact
tests now run early and again in the complete library suite. Prior failed logs,
source reviews and shell-checkout repairs remain in `../intermediate-regressions`.
Dev advanced during validation with PR #207; the final history replays onto its
merge commit and preserves its direct-push behavior. The only parser conflict
retains extracted ownership plus submodule-check support and a generalized
supported-mode/option-boundary regression. Unit 18 explicitly materializes exact
LF shell bytes and records before/after hashes without changing index blobs.
An earlier replay helper correctly refused the stale dev base before mutation;
that stopped helper and log are preserved separately from the successful replay.

Prior candidate `7511b6fc` passed those texture-disposal probes but its full suite
exposed first-frame font readiness in the accessibility fixture. The corrected
eframe creation callback installs fonts before its first pass. Both analogous
resolver fixtures defer actual paints until a subsequent font-ready pass. A
ready/pending regression exercises both strategies; this and the original
accessibility test run early and again in the complete suite. The failed suite
and one contained timing diagnostic remain preserved, without treating the
isolated pass as a replacement for that failure.

The first run of this unchanged application candidate stopped in the validation
helper after 61 tooling regressions and a successful formatting command: native
certutil rejected the zero-byte formatting log. No application runtime ran in
that stopped attempt. The corrected runner streams empty files through hashlib,
retains fresh native hashes for nonempty E: files, and fails on native hash errors.
Eleven recording tests cover 26 scenarios including an empty-to-nonempty transition,
stat failures and a removed-guard negative control. Five actual digest checks cover
owned empty/nonempty fixtures and the original zero-byte log. Both attempts and
helper versions remain archived; only the completed attempt supplies the 33-gate
pass claim above.

Three independent source reviews bind to the exact application candidate and
state their authorship exclusions. Source review is separate from test execution.
Raw results bind every gate to unchanged HEAD/tree, binary and log hashes, cleared
compiler overrides, tool versions, commands, environment and shell checkout bytes.
Gzip archives preserve original bytes; manifest hashes verify both representations.
The original runner and assembly helper are preserved in `../candidate-helpers`.
The archive helper's inherited Git-environment correction has recording-only
coverage: 61 varied override cases pass, fail with sanitation removed in memory,
and pass after restoration. This is separate from application test execution.

This evidence is added in a documentation-only follow-up. Application and gate
files must be verified unchanged before binding these prior executions to that
follow-up. No new application test execution is claimed for documentation changes.
Final GitHub CI is intentionally deferred until local checks and independent
review pass; its exact commit and results belong in the consolidated PR.
'''
(DEST / 'README.md').write_text(readme)
print(json.dumps({'destination': str(DEST), 'artifacts': len(sources)}))
