"""Archive completed candidate checks without altering application source."""
import gzip
import hashlib
import json
import os
import subprocess
from pathlib import Path

ROOT = Path('/mnt/e/private/gitcraft-build')
REPO = Path('/mnt/e/private/gitcraft-worktrees/final-maintainability')
CANDIDATE = '9e57224a584fcebfeeb6f8d9b80a6d5160dd82e6'
TREE = 'f530380ad78105f1bec2ac917156fa797746f734'
RUN = ROOT / 'validation-9e57224a-tfn6v4mv'
DEST = REPO / 'docs/validation/maintainability-20261111/final-candidate'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def git(*args):
    return subprocess.check_output(
        ['git', '-c', 'core.autocrlf=true', '-C', str(REPO), *args], text=True,
        env={key: value for key, value in os.environ.items() if not key.upper().startswith('GIT_')},
    ).strip()


results = json.loads((RUN / 'results.json').read_bytes())
assert results['commit'] == CANDIDATE and results['tree'] == TREE
assert results['status'] == 'passed' and results.get('finished')
assert git('rev-parse', 'HEAD') == CANDIDATE
assert Path(git('rev-parse', '--show-toplevel')).resolve() == REPO.resolve()
assert git('rev-parse', 'HEAD^{tree}') == TREE
assert git('rev-list', '--count', '2b370d4eb7c000748bb81c3dafaa8bd23bc596b5..HEAD') == '20'
assert git('status', '--porcelain') == ''
assert not DEST.exists()
checks = results['checks']
assert len(checks) == 29, len(checks)
assert len({entry['label'] for entry in checks}) == 29
expected_labels = {
    *(name + '-' + mode for name in ['rust_file_size', 'complexity_policy']
      for mode in ['working', 'index', 'revision']),
    'tooling-regressions', 'fmt', 'check', 'clippy-packages',
    'windows-cross-clippy-packages', 'build-tests', 'recording-pipes',
    'recording-outcomes', 'recording-resolver', 'build-recovery-recording',
    'list-recovery-recording', 'recovery-recording', 'runtime-gitcraft_os-lib',
    'runtime-gitcraft-lib', 'runtime-gitcraft-main',
    'runtime-checkpoint_cli-checkpoint_cli', 'runtime-mcp_stdio-mcp_stdio',
    'runtime-standalone_cli-standalone_cli', 'bisect-isolated', 'acl-save',
    'acl-index', 'palette-isolated', 'doc-tests',
}
assert {entry['label'] for entry in checks} == expected_labels
assert next(entry for entry in checks if entry['label'] == 'tooling-regressions')['python_test_count'] == 61
for label in ['clippy-packages', 'windows-cross-clippy-packages']:
    assert 'Clippy packages: 3 checked.' in (RUN / (label + '.log')).read_text()
for entry in checks:
    assert entry['exit'] == 0
    assert entry['before']['head'] == entry['after']['head'] == CANDIDATE
    assert entry['before']['tree'] == entry['after']['tree'] == TREE
    assert entry['before']['status'] == entry['after']['status'] == ''
    assert sha(Path(entry['log']).read_bytes()) == entry['sha256']
assert results['runner_sha256'] == sha((ROOT / 'run-final-candidate.py').read_bytes())
manifest = {'commit': CANDIDATE, 'tree': TREE, 'artifacts': []}
sources = [(RUN / 'results.json', 'results.json')]
sources += [(Path(entry['log']), 'logs/' + entry['label'] + '.log') for entry in checks]
sources += [(ROOT / name, 'provenance/' + name) for name in [
    'assembly-validated.json', 'assembly-validated-progress.log',
    'assembly-validated-continuation-progress.log',
    'continue-assembly-validated.py', 'materialize-candidate-shells.py',
    'preserve-final-evidence.py',
    'physical-shell-repair-9e57224a.json',
    'final-9e57224a-progress.log', 'final-9e57224a-r2-progress.log',
]]
sources += [(ROOT / 'validation-9e57224a-od4fh_tc/results.json', 'provenance/initial-shell-preflight-results.json')]
sources += [(ROOT / name, 'reviews/' + name) for name in [
    'review-gate-9e57224a.md', 'review-hotspot-9e57224a.md',
    'review-lifecycle-9e57224a.md', 'review-evidence-helper.md',
]]
archive_inputs = [(source, relative, source.read_bytes()) for source, relative in sources]
for source, relative, data in archive_inputs:
    compressed = gzip.compress(data, mtime=0)
    target = DEST / (relative + '.gz')
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(compressed)
    manifest['artifacts'].append({
        'path': relative + '.gz', 'source': str(source),
        'sha256': sha(data), 'gzip_sha256': sha(compressed),
        'bytes': len(data),
    })
(DEST / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
summary = []
for entry in checks:
    if entry.get('test_summaries'):
        for counts in entry['test_summaries']:
            summary.append('| ' + entry['label'] + ' | ' + ' | '.join(
                str(counts[name]) for name in ['passed', 'failed', 'ignored', 'filtered']
            ) + ' |')
readme = f'''# Final candidate local validation

Application candidate: `{CANDIDATE}`. Complete source tree: `{TREE}`.
This tree equals accepted combined source `0cbe9832a7ddb8813753df1b8fa93d59103ec81f`.
The assembled history contains 20 feature units from dev
`2b370d4eb7c000748bb81c3dafaa8bd23bc596b5`, with preserved source provenance.

All 29 local gates passed. Full Python discovery ran 61 tests successfully.
Working-tree, complete-index and committed-revision size and complexity checks,
formatting, all-target compilation, and strict Clippy for all three tracked Cargo
packages passed. Linux execution and Windows GNU cross-target Clippy are distinct:
the cross check did not execute native Windows tests.

| Runtime gate | Passed | Failed | Ignored | Filtered |
| --- | ---: | ---: | ---: | ---: |
{chr(10).join(summary)}

The four specially isolated library tests are excluded from the combined library
invocation and each executed separately. Ignored tests remain visible in raw logs;
this local run does not establish live SSH/WSL/forge parity or real power-loss
durability. Synthetic recording checks precede owned-child execution. Real
process suites run in a probed PID/proc/dev namespace without host PID selectors
or host signals. Existing owned ACL fixtures run in private native Linux folders.
No Docker was used. Build scripts, compiler targets and tooling scratch are on E:;
private Linux runtime scratch preserves native filesystem semantics.

The first final invocation stopped at shell-byte preflight: stale CRLF working
copies differed from committed LF blobs. Materialization restored exact committed
bytes without changing the commit, index blobs or source tree. The saved repair
report is the successful second verification and therefore records already
canonical bytes, not the original CRLF hashes. The restarted complete run above
passed. Earlier assembly also stopped on inconsistent Git autocrlf whitespace
interpretation; the preserved, independently reviewed continuation uses one
consistent Git configuration and finishes the exact accepted tree.

Three independent source reviews bind to the exact application candidate and
state their authorship exclusions. Source review is separate from test execution.
Raw results bind every gate to unchanged HEAD/tree, binary and log hashes, cleared
compiler overrides, tool versions, commands, environment and shell checkout bytes.
Gzip archives preserve original bytes; manifest hashes verify both representations.
The original runner and assembly helper are preserved in `../candidate-helpers`.

This evidence is added in a documentation-only follow-up. Application and gate
files must be verified unchanged before binding these prior executions to that
follow-up. No new application test execution is claimed for documentation changes.
Final GitHub CI is intentionally deferred until local checks and independent
review pass; its exact commit and results belong in the consolidated PR.
'''
(DEST / 'README.md').write_text(readme)
print(json.dumps({'destination': str(DEST), 'artifacts': len(sources)}))
