"""Preserve prior candidates; retain nineteen features and add reviewed fixtures."""
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys

if sys.flags.optimize or os.environ.get('PYTHONOPTIMIZE'):
    raise SystemExit('Assembly safeguards require assertions')
assert len(sys.argv) == 2 and re.fullmatch('[0-9a-f]{40}', sys.argv[1])
accepted = sys.argv[1]
repo = Path('/mnt/e/private/gitcraft-worktrees/final-maintainability')
root = Path('/mnt/e/private/gitcraft-build')
old = json.loads((root / 'assembly-current-dev.json').read_text())
branch = 'maintainability/validated-v3'
env = {key: value for key, value in os.environ.items() if not key.upper().startswith('GIT_')}
env.update(GIT_AUTHOR_NAME='Jonas Kamsker', GIT_COMMITTER_NAME='Jonas Kamsker',
           GIT_AUTHOR_EMAIL='11245306+JKamsker@users.noreply.github.com',
           GIT_COMMITTER_EMAIL='11245306+JKamsker@users.noreply.github.com')


def git(*args):
    return subprocess.check_output(['git', '-c', 'core.autocrlf=true', *args], cwd=repo, env=env, text=True).strip()


def run(*args):
    subprocess.run(args, cwd=repo, env=env, check=True, stdout=subprocess.DEVNULL)


assert old['candidate'] == '7511b6fc12f5b6184c3a061d9810c0ad7983bd5a'
assert old['base'] == '57d7395bce9e187ff9f2a3ce9b96dc0d65715600'
assert len(old['features']) == 20
assert git('rev-parse', 'HEAD') == old['candidate']
assert git('status', '--porcelain') == ''
assert Path(git('rev-parse', '--show-toplevel')).resolve() == repo.resolve()
assert git('branch', '--show-current') == 'maintainability/validated-v2'
assert git('remote', 'get-url', 'origin') == 'https://github.com/JKamsker/gitcraft.git'
assert git('ls-remote', 'origin', 'refs/heads/maintainability/validated-v2').split()[0] == old['candidate']
assert git('ls-remote', 'origin', 'refs/heads/' + branch) == ''
assert git('ls-remote', 'origin', 'refs/heads/dev').split()[0] == old['base']
run('git', 'merge-base', '--is-ancestor', old['base'], accepted)
changed = git('diff', '--name-only', old['candidate'], accepted).splitlines()
application = sorted(path for path in changed if not path.startswith('docs/validation/'))
assert set(application) == {'src/a11y/tests/repo_view.rs', 'src/repo/resolver/flow_tests.rs', 'src/repo/resolver/look_tests.rs', 'src/theme/test_paint.rs'}
previous = old['base']
for feature in old['features']:
    assert git('rev-parse', feature['commit'] + '^') == previous
    assert git('show', '-s', '--format=%an <%ae>', feature['commit']) == 'Jonas Kamsker <11245306+JKamsker@users.noreply.github.com>'
    previous = feature['commit']
run('git', '-c', 'core.autocrlf=true', 'switch', '-c', branch, old['features'][18]['commit'])
manifest = dict(base=old['base'], accepted_source=accepted, preserved_candidate=old['candidate'],
                observed_remote_dev=git('ls-remote', 'origin', 'refs/heads/dev').split()[0],
                runner_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), features=old['features'][:19])
output = root / 'assembly-font-candidate.json'
output.write_text(json.dumps(manifest, indent=2) + '\n')
for title, paths in [(old['features'][19]['title'], ['docs/validation']),
                     ('Prepare headless fixture fonts before initial repository paints', application)]:
    parent = git('rev-parse', 'HEAD')
    run('git', '-c', 'core.autocrlf=true', 'restore', '--source', accepted, '--staged', '--worktree', '--', *paths)
    actual = git('diff', '--cached', '--name-only').splitlines()
    assert actual
    if paths == ['docs/validation']:
        assert all(path.startswith('docs/validation/') for path in actual)
    else:
        assert set(actual) == set(application)
    for path in actual:
        assert git('rev-parse', ':' + path) == git('rev-parse', accepted + ':' + path)
    for args in [[], ['--staged']]:
        run('python3', 'ci/rust_file_size.py', *args)
    run('git', '-c', 'core.autocrlf=true', 'diff', '--cached', '--check')
    run('git', '-c', 'core.autocrlf=true', 'commit', '-m', title)
    commit = git('rev-parse', 'HEAD')
    assert git('rev-parse', 'HEAD^') == parent
    assert git('show', '-s', '--format=%an <%ae>') == 'Jonas Kamsker <11245306+JKamsker@users.noreply.github.com>'
    run('/mnt/c/Program Files/Git/cmd/git.exe', '-C', 'E:/private/gitcraft-worktrees/final-maintainability', 'push', 'origin', 'HEAD:refs/heads/' + branch)
    assert git('ls-remote', 'origin', 'refs/heads/' + branch).split()[0] == commit
    manifest['features'].append(dict(title=title, commit=commit, source=accepted, paths=actual, status='WIP: final combined checks pending'))
    output.write_text(json.dumps(manifest, indent=2) + '\n')
    print(commit, title, flush=True)
assert git('status', '--porcelain') == ''
assert git('rev-parse', 'HEAD^{tree}') == git('rev-parse', accepted + '^{tree}')
assets = git('ls-files', '--', '*.sh').splitlines()
assert assets
for asset in assets:
    committed = subprocess.check_output(['git', 'show', 'HEAD:' + asset], cwd=repo, env=env)
    assert b'\r' not in committed and (repo / asset).read_bytes() == committed
manifest.update(candidate=git('rev-parse', 'HEAD'), tree=git('rev-parse', 'HEAD^{tree}'), accepted_tree_verified=True)
output.write_text(json.dumps(manifest, indent=2) + '\n')
print('EXACT_TREE_MATCH', manifest['candidate'], manifest['tree'], flush=True)
