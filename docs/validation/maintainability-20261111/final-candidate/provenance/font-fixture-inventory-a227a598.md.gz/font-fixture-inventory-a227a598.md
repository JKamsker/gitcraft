# Headless font lifecycle inventory

Base candidate: `7511b6fc12f5b6184c3a061d9810c0ad7983bd5a`, tree `2b497fcd6969a917dbb2df10267742e4f5b28737`.
Accepted fixture source: `a227a59846ecbcf29f147bc55210b0340fb85ff5`, including earlier published `7deac349aff6a919372e813e48208937974ebbb4` on `maintainability/a11y-fixture-lifecycle`.

The full base-candidate library suite failed inside epaint with `FontFamily::Name("semibold") is not bound to any fonts`. The one authorized isolated exact-test diagnostic passed; its manifest and complete output remain under `a11y-7511-diagnostic`. This supports a timing-dependent initialization failure, not a failed graph keyboard assertion.

egui 0.36.2 `Context::set_fonts` documents and implements activation at the start of the next pass. The old accessibility harness installed fonts inside the first UI callback and immediately called `RepoTab::ui`. A fast repository read could therefore paint a named font before installation became active.

The immutable call-site inventory is `font-fixture-7511-call-sites.txt` (126 `install_fonts(ui.ctx())` occurrences). Callback context scouting additionally examined `font-fixture-all-contexts.txt` and `font-fixture-unguarded-contexts.txt`; these context extracts were collected after the initial accessibility fix, before the resolver follow-up, and are not claimed as an immutable base snapshot.

Confirmed analogous cases were `src/repo/resolver/flow_tests.rs` and `src/repo/resolver/look_tests.rs`: both installed fonts during `Option<RepoTab>::get_or_insert_with` and immediately painted the real repository UI. Both now preserve their state APIs and existing assertions while using the shared test-only `theme::test_paint::fonts_before_paint` guard. It records the installation pass, defers painting, and asserts that actual painting happens in a later pass.

Most other callbacks return or use an else branch after installation. `settings/preview/mod.rs` uses a separate setup pass before painting. `repo/file_comparison/tests_widgets.rs` and `repo/history_activity/tests.rs` also install and continue in one callback, but their direct view subtrees do not use the named medium/semibold families, so this investigation did not confirm the same missing-family failure there. They were retained.

The accessibility harness now uses supported `HarnessBuilder::build_eframe` initialization: settings, fonts and theme are prepared in its creation callback before the first pass. Its actual repository painting and all original keyboard/accessibility assertions remain. The deterministic regression exercises ready/pending content through both preparation strategies, paints both named families, verifies actual first-paint pass ordering, and checks pending-to-ready transition.

Verification before preservation: per-file rustfmt and diff whitespace checks passed; complete working and staged physical-size checks covered 2,640 tracked Rust files with zero errors. Both source commits use the required Jonas Kamsker author and were pushed with matching remote SHAs. This report makes no runtime/build/CI claim for the new source. Production application source is unchanged.
