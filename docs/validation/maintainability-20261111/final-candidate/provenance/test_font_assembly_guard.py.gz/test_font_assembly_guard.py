"""Execute actual preflight AST against recording-only Git boundaries."""
import ast
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import types
import unittest

ROOT = Path('/mnt/e/private/gitcraft-build')
SOURCE = ROOT / 'assemble-font-candidate.py'
EXPECTED = '535a6c1b2f85ebc24bd321717edaf4830034a74da3b70eaef40bff15dd6bd7f0'
raw = SOURCE.read_bytes()
if hashlib.sha256(raw).hexdigest() != EXPECTED:
    raise SystemExit('Assembly source binding changed')
tree = ast.parse(raw)
old = json.loads((ROOT / 'assembly-current-dev.json').read_text())
switches = [i for i, node in enumerate(tree.body) if isinstance(node, ast.Expr)
            and isinstance(node.value, ast.Call) and isinstance(node.value.func, ast.Name)
            and node.value.func.id == 'run' and any(isinstance(arg, ast.Constant) and arg.value == 'switch' for arg in node.value.args)]
if len(switches) != 1:
    raise SystemExit('Expected one explicit switch boundary')
prefix = tree.body[:switches[0] + 1]
prefix = [node for node in prefix if not (isinstance(node, ast.Import)
          and any(alias.name in ('sys', 'subprocess') for alias in node.names))]
guards = [node for node in prefix if isinstance(node, ast.Assert) and 'refs/heads/dev' in ast.unparse(node)]
if len(guards) != 1:
    raise SystemExit('Expected exactly one explicit dev assertion')
EVENTS = []


class SwitchBoundary(Exception):
    pass


def exercise(remote, remove_guard=False):
    reads, commands = [], []
    parents = {feature['commit'] + '^': previous for feature, previous in
               zip(old['features'], [old['base']] + [f['commit'] for f in old['features'][:-1]])}

    def output(argv, **kwargs):
        assert argv[:3] == ['git', '-c', 'core.autocrlf=true']
        args = argv[3:]
        reads.append(args)
        if args == ['rev-parse', 'HEAD']:
            return old['candidate'] + '\n'
        if args == ['status', '--porcelain']:
            return ''
        if args == ['rev-parse', '--show-toplevel']:
            return '/mnt/e/private/gitcraft-worktrees/final-maintainability\n'
        if args == ['branch', '--show-current']:
            return 'maintainability/validated-v2\n'
        if args == ['remote', 'get-url', 'origin']:
            return 'https://github.com/JKamsker/gitcraft.git\n'
        if args == ['ls-remote', 'origin', 'refs/heads/maintainability/validated-v2']:
            return old['candidate'] + '\trefs/heads/maintainability/validated-v2\n'
        if args == ['ls-remote', 'origin', 'refs/heads/maintainability/validated-v3']:
            return ''
        if args == ['ls-remote', 'origin', 'refs/heads/dev']:
            if isinstance(remote, Exception):
                raise remote
            return remote
        if args == ['diff', '--name-only', old['candidate'], 'a' * 40]:
            return '\n'.join(['docs/validation/fixture.md', 'src/a11y/tests/repo_view.rs',
                              'src/repo/resolver/flow_tests.rs', 'src/repo/resolver/look_tests.rs',
                              'src/theme/test_paint.rs'])
        if len(args) == 2 and args[0] == 'rev-parse' and args[1] in parents:
            return parents[args[1]] + '\n'
        if args[:3] == ['show', '-s', '--format=%an <%ae>'] and len(args) == 4:
            assert args[3] in [f['commit'] for f in old['features']]
            return 'Jonas Kamsker <11245306+JKamsker@users.noreply.github.com>\n'
        raise AssertionError('Unexpected read boundary: ' + repr(args))

    def run(argv, **kwargs):
        commands.append(argv)
        if argv[:3] == ('git', 'merge-base', '--is-ancestor'):
            return types.SimpleNamespace(returncode=0)
        if 'switch' in argv:
            raise SwitchBoundary('Recorded only; no command executed')
        raise AssertionError('Unexpected command boundary: ' + repr(argv))

    nodes = [node for node in prefix if not (remove_guard and node is guards[0])]
    namespace = {'subprocess': types.SimpleNamespace(check_output=output, run=run, DEVNULL=subprocess.DEVNULL),
                 'sys': types.SimpleNamespace(flags=types.SimpleNamespace(optimize=0), argv=[str(SOURCE), 'a' * 40])}
    try:
        exec(compile(ast.fix_missing_locations(ast.Module(body=nodes, type_ignores=[])), str(SOURCE), 'exec'), namespace)
    except (AssertionError, IndexError, subprocess.CalledProcessError, SwitchBoundary) as error:
        return error, reads, commands
    raise AssertionError('Expected preflight rejection or recorded switch boundary')


class GuardTests(unittest.TestCase):
    def test_matching_dev_reaches_only_recorded_switch(self):
        error, reads, commands = exercise(old['base'] + '\trefs/heads/dev\n')
        self.assertIsInstance(error, SwitchBoundary)
        self.assertEqual(len(commands), 2)
        self.assertIn('switch', commands[-1])
        EVENTS.append('matching dev: preflight reaches recorded switch, no command executed')

    def test_advanced_missing_malformed_or_failed_remote_aborts_before_any_command(self):
        cases = [('advanced', 'b' * 40 + '\trefs/heads/dev\n'), ('missing', ''),
                 ('malformed', 'not-a-sha refs/heads/dev\n'),
                 ('failed', subprocess.CalledProcessError(128, ['recorded', 'ls-remote']))]
        for label, remote in cases:
            with self.subTest(label=label):
                error, reads, commands = exercise(remote)
                self.assertNotIsInstance(error, SwitchBoundary)
                self.assertEqual(commands, [])
                self.assertEqual(reads[-1], ['ls-remote', 'origin', 'refs/heads/dev'])
                EVENTS.append(label + ' dev: aborted before all command/mutation boundaries')

    def test_negative_control_removing_actual_guard_reaches_switch_on_advanced_dev(self):
        error, reads, commands = exercise('b' * 40 + '\trefs/heads/dev\n', remove_guard=True)
        self.assertIsInstance(error, SwitchBoundary)
        self.assertEqual(len(commands), 2)
        EVENTS.append('negative control: deleting only actual dev assertion permits advanced dev to recorded switch')


if __name__ == '__main__':
    with (ROOT / 'font-assembly-guard.log').open('w') as log:
        result = unittest.TextTestRunner(stream=log, verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(GuardTests))
    evidence = dict(source_sha256=EXPECTED, script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                    tests=result.testsRun, failures=len(result.failures), errors=len(result.errors), events=EVENTS,
                    log_sha256=hashlib.sha256((ROOT / 'font-assembly-guard.log').read_bytes()).hexdigest(),
                    boundary='Only actual preflight AST through first switch; subprocess module replaced by recording functions; no Git/child command, repository mutation, build, app test or CI executed')
    (ROOT / 'font-assembly-guard-results.json').write_text(json.dumps(evidence, indent=2) + '\n')
    print(json.dumps(evidence, indent=2))
    sys.exit(not result.wasSuccessful())
