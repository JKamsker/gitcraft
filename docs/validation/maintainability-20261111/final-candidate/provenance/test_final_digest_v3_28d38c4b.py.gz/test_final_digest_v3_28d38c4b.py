"""Recording-only checks of the actual v3 digest AST; never run its module."""
import ast
import hashlib
import io
import json
from pathlib import Path
import re
import subprocess
import sys
import types
import unittest
from unittest.mock import Mock, patch

ROOT = Path('/mnt/e/private/gitcraft-build')
RUNNER = ROOT / 'run-final-candidate-v3.py'
EXPECTED = '28d38c4b81487e39c44a13a5b3cbf423011c276c36f93d33d8b2264dcfaab333'
raw = RUNNER.read_bytes()
if hashlib.sha256(raw).hexdigest() != EXPECTED:
    raise SystemExit('Runner source no longer matches the reviewed immutable hash')
module = ast.parse(raw, filename=str(RUNNER))
nodes = [node for node in module.body if isinstance(node, ast.FunctionDef) and node.name == 'digest']
if len(nodes) != 1 or nodes[0].decorator_list or nodes[0].args.defaults or nodes[0].args.kw_defaults:
    raise SystemExit('Expected exactly one plain digest function')
function = ast.get_source_segment(raw.decode(), nodes[0]) + '\n'
compiled = compile(ast.fix_missing_locations(ast.Module(body=nodes, type_ignores=[])), str(RUNNER), 'exec')
LOWER = '0123456789abcdef' * 4
OTHER = 'fedcba9876543210' * 4
E_PATH = '/mnt/e/private/gitcraft-build/space name.bin'
ARGV = ['/mnt/c/Windows/System32/certutil.exe', '-hashfile', 'E:\\private\\gitcraft-build\\space name.bin', 'SHA256']
SCENARIOS = []


class DigestTests(unittest.TestCase):
    def setUp(self):
        self.command = Mock(name='recorded_certutil')
        namespace = {'Path': Path, 're': re, 'hashlib': hashlib,
                     'subprocess': types.SimpleNamespace(check_output=self.command, STDOUT=subprocess.STDOUT)}
        exec(compiled, namespace)
        self.digest = namespace['digest']

    def scenario(self, name):
        SCENARIOS.append(name)

    def test_valid_case_line_endings_whitespace_and_locale(self):
        variants = {
            'lowercase-lf': (LOWER + '\n').encode(),
            'uppercase-crlf': ('SHA256 header\r\n' + LOWER.upper() + '\r\nSuccess\r\n').encode(),
            'mixed-case-surrounding-space': ('\t ' + LOWER[:32].upper() + LOWER[32:] + ' \t\r\n').encode(),
            'locale-bytes': b'localized \x81 header\r\n' + LOWER.encode() + b'\r\nlocalized \x81 result\r\n',
            'no-final-newline': LOWER.encode(),
        }
        for name, output in variants.items():
            with self.subTest(name=name):
                self.scenario(name)
                self.command.reset_mock()
                self.command.return_value = output
                with patch.object(Path, 'open', side_effect=AssertionError('E path must use native boundary')):
                    self.assertEqual(self.digest(E_PATH), LOWER)
                self.command.assert_called_once_with(ARGV, stderr=subprocess.STDOUT)

    def test_resolved_spaced_path_is_one_argv_element(self):
        self.scenario('resolved-spaced-path-argv')
        self.command.return_value = LOWER.encode()
        self.assertEqual(self.digest('/mnt/e/private/gitcraft-build/unused/../space name.bin'), LOWER)
        self.command.assert_called_once_with(ARGV, stderr=subprocess.STDOUT)

    def test_rejects_malformed_and_duplicate_digest_lines(self):
        variants = {
            'empty': b'', 'headers-only': b'CertUtil success\r\n',
            'nonhex': b'g' * 64, 'length63': b'a' * 63, 'length65': b'a' * 65,
            'internal-space': (LOWER[:32] + ' ' + LOWER[32:]).encode(),
            'prefix': ('sha256: ' + LOWER).encode(), 'suffix': (LOWER + ' value').encode(),
            'duplicate-same': (LOWER + '\n' + LOWER + '\n').encode(),
            'duplicate-different': (LOWER + '\r\n' + OTHER + '\r\n').encode(),
        }
        for name, output in variants.items():
            with self.subTest(name=name):
                self.scenario(name)
                self.command.reset_mock()
                self.command.return_value = output
                with patch.object(Path, 'open', side_effect=AssertionError('No fallback for malformed E output')):
                    with self.assertRaisesRegex(RuntimeError, 'exactly one native SHA256'):
                        self.digest(E_PATH)
                self.command.assert_called_once_with(ARGV, stderr=subprocess.STDOUT)

    def test_failed_tool_cannot_accept_even_a_valid_digest(self):
        self.scenario('nonzero-exit-with-valid-digest')
        error = subprocess.CalledProcessError(1, ARGV, output=LOWER.encode())
        self.command.side_effect = error
        with patch.object(Path, 'open', side_effect=AssertionError('No fallback for tool failure')):
            with self.assertRaises(subprocess.CalledProcessError) as raised:
                self.digest(E_PATH)
        self.assertIs(raised.exception, error)

    def test_missing_tool_fails_closed(self):
        self.scenario('tool-not-found')
        self.command.side_effect = FileNotFoundError('recorded missing executable')
        with patch.object(Path, 'open', side_effect=AssertionError('No fallback for missing tool')):
            with self.assertRaises(FileNotFoundError):
                self.digest(E_PATH)

    def test_no_cached_hash_between_calls(self):
        self.scenario('fresh-hash-every-call')
        self.command.side_effect = [LOWER.encode(), OTHER.encode()]
        self.assertEqual(self.digest(E_PATH), LOWER)
        self.assertEqual(self.digest(E_PATH), OTHER)
        self.assertEqual(self.command.call_count, 2)
        self.assertEqual(self.command.call_args_list[0], self.command.call_args_list[1])

    def test_non_e_paths_use_streaming_hashlib_and_close_stream(self):
        payload = b'non-E synthetic bytes\x00\xff\n'
        paths = ['/virtual/recording-only/non-e.bin', '/mnt/echo/space name.bin',
                 '/mnt/e/../other/space name.bin']
        for path in paths:
            with self.subTest(path=path):
                self.scenario('hashlib-fallback:' + path)
                stream = io.BytesIO(payload)
                with patch.object(Path, 'open', return_value=stream) as opened:
                    self.assertEqual(self.digest(path), hashlib.sha256(payload).hexdigest())
                opened.assert_called_once_with('rb')
                self.assertTrue(stream.closed)
        self.command.assert_not_called()


if __name__ == '__main__':
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(DigestTests)
    with (ROOT / 'digest-v3-28d38c4b-regressions.log').open('w', encoding='utf-8', newline='\n') as log:
        result = unittest.TextTestRunner(stream=log, verbosity=2).run(suite)
    evidence = dict(runner=str(RUNNER), runner_sha256=EXPECTED,
                    extracted_digest_sha256=hashlib.sha256(function.encode()).hexdigest(),
                    regression_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                    tests=result.testsRun, scenarios=len(SCENARIOS), scenario_names=SCENARIOS,
                    failures=len(result.failures), errors=len(result.errors), skipped=len(result.skipped),
                    log_sha256=hashlib.sha256((ROOT / 'digest-v3-28d38c4b-regressions.log').read_bytes()).hexdigest(),
                    boundary='Recorded subprocess.check_output only; no child commands, builds, tests of the application, or CI launched',
                    source_binding='Only the exact digest FunctionDef AST is compiled; runner top-level statements never execute')
    (ROOT / 'digest-v3-28d38c4b-results.json').write_text(json.dumps(evidence, indent=2) + '\n')
    print(json.dumps(evidence, indent=2))
    sys.exit(not result.wasSuccessful())
