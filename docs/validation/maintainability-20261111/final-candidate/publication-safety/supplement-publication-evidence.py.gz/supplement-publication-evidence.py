"""Supplement application evidence with recording-only publication guard proof."""
from pathlib import Path
import gzip
import hashlib
import json

ROOT = Path('/mnt/e/private/gitcraft-build')
DEST = Path('/mnt/e/private/gitcraft-worktrees/final-maintainability/docs/validation/maintainability-20261111/final-candidate')


def sha(data):
    return hashlib.sha256(data).hexdigest()


manifest_raw = (DEST / 'manifest.json').read_bytes()
readme_raw = (DEST / 'README.md').read_bytes()
manifest = json.loads(manifest_raw)
assert manifest['commit'] == '0e6a8e52d1f16e19122a674b314eef70abeb58b9'
assert len(manifest['artifacts']) == 79 and not (DEST / 'publication-safety').exists()
names = [
    'commit-final-evidence-0e6a8e52.py',
    'commit-final-evidence-0e6a8e52-before-push-guard.py',
    'review-final-evidence-commit-helper-blocked.md',
    'review-final-evidence-commit-helper.md',
    'review-publication-guard-257a704f.md',
    'supplement-publication-evidence.py',
]
sources = [(ROOT / name, name, (ROOT / name).read_bytes()) for name in names]
sources += [(p, 'regression/' + p.name, p.read_bytes()) for p in
            sorted((ROOT / 'evidence-commit-regression').iterdir()) if p.is_file()]
sources += [(DEST / 'manifest.json', 'initial-manifest.json', manifest_raw),
            (DEST / 'README.md', 'initial-README.md', readme_raw)]
assert sha(sources[0][2]) == '257a704f8dabda09ca2dbbb2021c45b44d8ffc8077a7f7fc6e699bd52d2e5efc'
assert sha(sources[1][2]) == 'd6a9268f84b44545c64c65e4e1f03737256247b1c309190c985de89b35c6b28b'
for source, name, raw in sources:
    compressed = gzip.compress(raw, mtime=0)
    relative = 'publication-safety/' + name + '.gz'
    target = DEST / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    assert not target.exists()
    target.write_bytes(compressed)
    manifest['artifacts'].append(dict(path=relative, source=str(source),
        sha256=sha(raw), gzip_sha256=sha(compressed), bytes=len(raw)))
manifest['publication_safety'] = dict(helper_sha256=sha(sources[0][2]),
    scope='Recording-only publication guard proof; separate from the 33 application gates',
    initial_manifest_sha256=sha(manifest_raw))
(DEST / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
paragraph = '''
Publication-tool safety evidence is a separate supplement under `publication-safety/`.
Review found that Git fetch and push destinations can differ. The corrected helper
checks every expanded effective push URL against the canonical fork allowlist
before staging, and retains the fetch check. Five recording methods cover 57
configurations, including mixed/foreign/missing/malformed destinations and failed
queries. Removing the actual guard causes the expected rejection failures,
including three foreign/mixed configurations reaching recorded staging; restoring
it passes. No actual Git command runs in those tests. Exact original/fixed helper
sources, blocked/fixed/independent review records, all regression output, and the
initial 79-artifact manifest/README are preserved. These are publication-tool
regressions, not additional application test execution. The final documentation
commit must still be independently checked for unchanged application/gate files.
'''
(DEST / 'README.md').write_bytes(readme_raw + paragraph.encode())
print(json.dumps(dict(artifacts=len(manifest['artifacts']), supplement=len(sources))))
