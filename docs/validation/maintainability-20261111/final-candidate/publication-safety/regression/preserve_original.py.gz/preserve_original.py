"""Reconstruct the reviewed pre-fix bytes and verify their known hash before saving."""
import hashlib
from pathlib import Path

root = Path(__file__).resolve().parent.parent
text = (root / 'commit-final-evidence-0e6a8e52.py').read_text()
text = text.replace('import hashlib, json, os, subprocess', 'import json, os, subprocess')
text = '\n'.join(line for line in text.split('\n') if not line.startswith((
    'TREE=', 'RUNNER_SHA256=', 'FORK_URLS=',
    "assert git('rev-parse','HEAD^{tree}')", 'push_urls=', 'assert push_urls',
    "assert results['tree']", 'assert hashlib.sha256', 'assert all(type(entry')))
text = text.replace(
    'def git(*args, raw=False):\n'
    "    output=subprocess.check_output(['git','-c','core.autocrlf=true','-C',str(REPO),*args],env=env,text=True)\n"
    '    return output if raw else output.strip()',
    'def git(*args):\n'
    "    return subprocess.check_output(['git','-c','core.autocrlf=true','-C',str(REPO),*args],env=env,text=True).strip()")
text = text.replace("assert git('remote','get-url','origin') in FORK_URLS",
                    "assert git('remote','get-url','origin') in ['https://github.com/JKamsker/gitcraft.git','https://github.com/JKamsker/gitcraft']")
expected = 'd6a9268f84b44545c64c65e4e1f03737256247b1c309190c985de89b35c6b28b'
variants = [text.encode(), text.replace('\n', '\r\n').encode()]
matched = [data for data in variants if hashlib.sha256(data).hexdigest() == expected]
assert len(matched) == 1, [(hashlib.sha256(data).hexdigest(), len(data)) for data in variants]
(root / 'commit-final-evidence-0e6a8e52-before-push-guard.py').write_bytes(matched[0])
blocked = (root / 'review-final-evidence-commit-helper.md').read_bytes()
assert hashlib.sha256(blocked).hexdigest() == '56bf7d668eac30789cb3d969f177b42b0c63cf99d6f78bd64339b7d7008bc0de'
(root / 'review-final-evidence-commit-helper-blocked.md').write_bytes(blocked)
print('Preserved exact original helper and blocked review; no helper execution.')
