"""Recording-only execution of the real archive-commit helper pre-mutation AST."""
import ast
import copy
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import subprocess
import sys
import types
import unittest

ROOT = Path(__file__).resolve().parent.parent
HELPER = ROOT / 'commit-final-evidence-0e6a8e52.py'
RUNNER = ROOT / 'run-final-candidate-v4.py'
FORK = 'https://github.com/JKamsker/gitcraft.git'
ALTERNATE = 'https://github.com/JKamsker/gitcraft'
FOREIGN = 'https://github.com/Vancete/gitcraft.git'
CANDIDATE = '0e6a8e52d1f16e19122a674b314eef70abeb58b9'
TREE = '1ae8537f6c9d734e1d9194472d897c09b0dd5654'
RUNNER_BYTES = RUNNER.read_bytes()
SOURCE = HELPER.read_bytes()
ORIGINAL = ast.parse(SOURCE, filename=str(HELPER))
NEGATIVE = False
FOREIGN_REACHED = []


class ReachedMutation(Exception):
    """The fake subprocess recorded git add; no process ran."""


def preflight_ast(remove_guard=False):
    statements = []
    for node in copy.deepcopy(ORIGINAL).body:
        if isinstance(node, (ast.Import, ast.ImportFrom)):
            continue
        statements.append(node)
        if (isinstance(node, ast.Expr) and isinstance(node.value, ast.Call)
                and isinstance(node.value.func, ast.Name)
                and node.value.func.id == 'git'
                and node.value.args and isinstance(node.value.args[0], ast.Constant)
                and node.value.args[0].value == 'add'):
            break
    else:
        raise AssertionError('actual first git add must be found')
    guards = [node for node in statements if isinstance(node, ast.Assert)
              and any(isinstance(child, ast.Name) and child.id == 'push_urls'
                      for child in ast.walk(node.test))]
    assert len(guards) == 1, 'extract the actual single push URL guard'
    if remove_guard:
        statements.remove(guards[0])
    return ast.fix_missing_locations(ast.Module(body=statements, type_ignores=[]))


def record_preflight(push_output, *, result_mutation=None, fetch=FORK, fail_push=False):
    checks = [{'exit': 0} for _ in range(33)]
    results = dict(commit=CANDIDATE, tree=TREE, status='passed', checks=checks,
                   runner_sha256=hashlib.sha256(RUNNER_BYTES).hexdigest())
    if result_mutation:
        result_mutation(results)
    calls, mutations = [], []

    class FixturePath:
        def __init__(self, path):
            self.path = PurePosixPath(path)

        def __truediv__(self, part):
            return FixturePath(self.path / part)

        def __str__(self):
            return str(self.path)

        def resolve(self):
            return self.path

        def read_bytes(self):
            if self.path.name == 'results.json':
                return json.dumps(results).encode()
            if self.path.name == 'manifest.json':
                return json.dumps({'commit': CANDIDATE}).encode()
            if self.path.name == 'run-final-candidate-v4.py':
                return RUNNER_BYTES
            raise AssertionError('unexpected fixture read: ' + str(self.path))

    def check_output(argv, *, env, text):
        assert argv[:5] == ['git', '-c', 'core.autocrlf=true', '-C',
                            '/mnt/e/private/gitcraft-worktrees/final-maintainability']
        assert text is True
        assert env['ORDINARY_KEEP'] == 'unchanged'
        assert 'GIT_WORK_TREE' not in env and 'gIt_InDeX_fIlE' not in env
        args = tuple(argv[5:])
        calls.append(args)
        if args[0] == 'add':
            mutations.append(args)
            raise ReachedMutation()
        responses = {
            ('rev-parse', '--show-toplevel'): '/mnt/e/private/gitcraft-worktrees/final-maintainability',
            ('rev-parse', 'HEAD'): CANDIDATE,
            ('rev-parse', 'HEAD^{tree}'): TREE,
            ('branch', '--show-current'): 'maintainability/validated-v3',
            ('remote', 'get-url', 'origin'): fetch,
            ('ls-remote', 'origin', 'refs/heads/maintainability/validated-v3'):
                CANDIDATE + '\trefs/heads/maintainability/validated-v3',
            ('status', '--porcelain=v1', '--untracked-files=all'):
                '?? docs/validation/maintainability-20261111/final-candidate/manifest.json',
            ('diff', '--name-only'): '',
            ('diff', '--cached', '--name-only'): '',
        }
        if args == ('remote', 'get-url', '--push', '--all', 'origin'):
            if fail_push:
                raise subprocess.CalledProcessError(2, argv)
            return push_output
        assert args in responses, 'unexpected recorded command: ' + repr(args)
        return responses[args] + '\n'

    namespace = dict(Path=FixturePath, json=json, hashlib=hashlib,
                     os=types.SimpleNamespace(environ={
                         'ORDINARY_KEEP': 'unchanged', 'GIT_WORK_TREE': '/foreign',
                         'gIt_InDeX_fIlE': '/foreign-index'}),
                     subprocess=types.SimpleNamespace(check_output=check_output))
    error = None
    try:
        exec(compile(preflight_ast(NEGATIVE), str(HELPER), 'exec'), namespace)
    except (AssertionError, KeyError, subprocess.CalledProcessError, ReachedMutation) as caught:
        error = caught
    return calls, mutations, error


class PushDestinationTests(unittest.TestCase):
    def test_single_and_multiple_allowlisted_urls_reach_recorded_add(self):
        for output in [FORK + '\n', ALTERNATE + '\n', FORK + '\n' + ALTERNATE + '\n',
                       FORK + '\n' + FORK + '\n']:
            with self.subTest(output=output):
                calls, mutations, error = record_preflight(output)
                self.assertIsInstance(error, ReachedMutation)
                self.assertEqual(len(mutations), 1)
                self.assertLess(calls.index(('remote', 'get-url', '--push', '--all', 'origin')),
                                calls.index(mutations[0]))

    def test_disallowed_push_destinations_stop_before_mutation(self):
        cases = {
            'foreign': FOREIGN + '\n',
            'mixed_foreign_first': FOREIGN + '\n' + FORK + '\n',
            'mixed_foreign_last': FORK + '\n' + FOREIGN + '\n',
            'missing': '',
            'blank': '\n',
            'blank_after_fork': FORK + '\n\n',
            'malformed': 'not-a-url\n',
            'space_prefix': ' ' + FORK + '\n',
            'space_suffix': FORK + ' \n',
            'lookalike_host': 'https://github.com.evil/JKamsker/gitcraft.git\n',
            'wrong_repository': 'https://github.com/JKamsker/other.git\n',
        }
        for label, output in cases.items():
            with self.subTest(case=label):
                calls, mutations, error = record_preflight(output)
                if NEGATIVE and label.startswith(('foreign', 'mixed_foreign')) and mutations:
                    FOREIGN_REACHED.append(label)
                self.assertIsInstance(error, AssertionError)
                self.assertFalse(mutations)
                self.assertIn(('remote', 'get-url', '--push', '--all', 'origin'), calls)

    def test_failed_push_url_query_stops_before_mutation(self):
        _, mutations, error = record_preflight(FORK + '\n', fail_push=True)
        self.assertIsInstance(error, subprocess.CalledProcessError)
        self.assertFalse(mutations)

    def test_fetch_guard_remains(self):
        _, mutations, error = record_preflight(FORK + '\n', fetch=FOREIGN)
        self.assertIsInstance(error, AssertionError)
        self.assertFalse(mutations)

    def test_all_recorded_gate_exits_and_source_bindings_are_required(self):
        def fail_at(index, value):
            return lambda result: result['checks'][index].update(exit=value)

        changes = [('exit-' + str(i), fail_at(i, 1)) for i in range(33)]
        changes += [
            ('missing-exit', lambda r: r['checks'][0].pop('exit')),
            ('boolean-exit', fail_at(0, False)),
            ('missing-check', lambda r: r['checks'].pop()),
            ('runner', lambda r: r.update(runner_sha256='0' * 64)),
            ('tree', lambda r: r.update(tree='0' * 40)),
            ('candidate', lambda r: r.update(commit='0' * 40)),
            ('status', lambda r: r.update(status='failed')),
        ]
        for label, change in changes:
            with self.subTest(case=label):
                _, mutations, error = record_preflight(FORK + '\n', result_mutation=change)
                self.assertIsInstance(error, (AssertionError, KeyError))
                self.assertFalse(mutations)


def run_phase(label, negative):
    global NEGATIVE
    NEGATIVE = negative
    stream = io.StringIO()
    if negative:
        suite = unittest.TestSuite([PushDestinationTests(
            'test_disallowed_push_destinations_stop_before_mutation')])
    else:
        suite = unittest.defaultTestLoader.loadTestsFromTestCase(PushDestinationTests)
    result = unittest.TextTestRunner(stream=stream, verbosity=2).run(suite)
    print('\n=== ' + label + ' ===\n' + stream.getvalue(), flush=True)
    return dict(label=label, tests=result.testsRun, failures=len(result.failures),
                errors=len(result.errors), passed=result.wasSuccessful())


def main():
    before = hashlib.sha256(SOURCE).hexdigest()
    print('Helper SHA256: ' + before)
    print('Recording only: real subprocess methods are never installed in the executed AST.')
    phases = [run_phase('fixed', False), run_phase('negative-control-guard-removed', True),
              run_phase('fixed-restored', False)]
    assert phases[0]['passed'] and phases[2]['passed']
    assert not phases[1]['passed'] and phases[1]['errors'] == 0
    assert set(FOREIGN_REACHED) == {'foreign', 'mixed_foreign_first', 'mixed_foreign_last'}
    assert hashlib.sha256(HELPER.read_bytes()).hexdigest() == before
    report = dict(helper_sha256=before, test_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                  runner_sha256=hashlib.sha256(RUNNER_BYTES).hexdigest(), phases=phases,
                  negative_foreign_destinations_reached_recorded_add=FOREIGN_REACHED,
                  actual_processes_executed=0, repository_mutations=0, helper_unchanged=True)
    (Path(__file__).parent / 'results.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
