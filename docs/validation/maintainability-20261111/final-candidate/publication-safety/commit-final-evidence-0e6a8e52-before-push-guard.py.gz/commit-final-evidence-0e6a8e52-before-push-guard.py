"""Preserve only reviewed documentation evidence after the complete candidate pass."""
from pathlib import Path
import json, os, subprocess
ROOT=Path('/mnt/e/private/gitcraft-build')
REPO=Path('/mnt/e/private/gitcraft-worktrees/final-maintainability')
CANDIDATE='0e6a8e52d1f16e19122a674b314eef70abeb58b9'
BRANCH='maintainability/validated-v3'
DOCS='docs/validation/maintainability-20261111/final-candidate/'
IDENTITY='Jonas Kamsker <11245306+JKamsker@users.noreply.github.com>'
env={k:v for k,v in os.environ.items() if not k.upper().startswith('GIT_')}
env.update(GIT_AUTHOR_NAME='Jonas Kamsker',GIT_COMMITTER_NAME='Jonas Kamsker',GIT_AUTHOR_EMAIL='11245306+JKamsker@users.noreply.github.com',GIT_COMMITTER_EMAIL='11245306+JKamsker@users.noreply.github.com')
def git(*args):
    return subprocess.check_output(['git','-c','core.autocrlf=true','-C',str(REPO),*args],env=env,text=True).strip()
assert Path(git('rev-parse','--show-toplevel')).resolve()==REPO.resolve()
assert git('rev-parse','HEAD')==CANDIDATE
assert git('branch','--show-current')==BRANCH
assert git('remote','get-url','origin') in ['https://github.com/JKamsker/gitcraft.git','https://github.com/JKamsker/gitcraft']
assert git('ls-remote','origin','refs/heads/'+BRANCH).split()[0]==CANDIDATE
results=json.loads((ROOT/'validation-0e6a8e52-2ypil253/results.json').read_bytes())
assert results['commit']==CANDIDATE and results['status']=='passed' and len(results['checks'])==33
assert json.loads((REPO/DOCS/'manifest.json').read_bytes())['commit']==CANDIDATE
status=git('status','--porcelain=v1','--untracked-files=all')
assert status and all(line[3:].startswith(DOCS) for line in status.splitlines()),status
assert git('diff','--name-only')=='' and git('diff','--cached','--name-only')==''
git('add','--',DOCS)
paths=git('diff','--cached','--name-only','-z').split('\0')
paths=[x for x in paths if x]
assert paths and all(x.startswith(DOCS) for x in paths)
for name,args in [('working',[]),('index',['--staged'])]:
    with (ROOT/('final-evidence-size-'+name+'.log')).open('w') as log:
        subprocess.run(['python3','ci/rust_file_size.py',*args],cwd=REPO,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
git('diff','--cached','--check')
print(git('commit','-m','Preserve final host validation and independent review evidence'),flush=True)
head=git('rev-parse','HEAD')
assert git('rev-parse','HEAD^')==CANDIDATE
assert git('show','-s','--format=%an <%ae>','HEAD')==IDENTITY
assert git('show','-s','--format=%cn <%ce>','HEAD')==IDENTITY
assert set(git('diff','--name-only',CANDIDATE,'HEAD').splitlines())==set(paths)
assert git('status','--porcelain')==''
print(git('push','origin','HEAD:refs/heads/'+BRANCH),flush=True)
assert git('ls-remote','origin','refs/heads/'+BRANCH).split()[0]==head
record=dict(application_candidate=CANDIDATE,documentation_head=head,branch=BRANCH,author=IDENTITY,changed_paths=paths,application_and_gates_unchanged=True,status='Validated application gates rebound; exact documentation review pending',remote_sha_verified=True)
(ROOT/'final-evidence-commit.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2),flush=True)
