from pathlib import Path
import sys
sys.path.insert(0, 'ci')
from architecture import mask, block_end
for path in Path('src/repo').rglob('*.rs'):
    source=path.read_text()
    original=source
    for before,after in [('ToggleTerminal', 'Toggle'),('CloseTerminal', 'Close'),('SelectTerminal', 'Select')]:
        marker='Action::'+before
        while marker in source:
            start=source.index(marker)
            end=start+len(marker)
            payload=''
            if end<len(source) and source[end]=='(':
                depth=1
                last=end+1
                while depth:
                    depth+=(source[last]=='(')-(source[last]==')')
                    last+=1
                payload=source[end:last]
                end=last
            source=source[:start]+'Action::Terminal(TerminalAct::'+after+payload+')'+source[end:]
    marker='Action::NewTerminal'
    while marker in source:
        start=source.index(marker)
        opening=source.index('{',start)
        end=block_end(mask(source),opening)
        source=source[:start]+'Action::Terminal(TerminalAct::New '+source[opening:end]+')'+source[end:]
    if source!=original:
        # All changed files are descendants of repo; keep one explicit feature import.
        index=source.index('use ')
        source=source[:index]+'use crate::repo::terminals::TerminalAct;\n'+source[index:]
        path.write_text(source)
p=Path('src/repo/mod.rs');s=p.read_text().replace('use crate::terminal::Terminal;\n','')
s=s.replace('    terminals: Vec<Terminal>,\n    active_terminal: usize,\n    terminal_open: bool,\n    terminal_error: Option<String>,', '    terminals: terminals::Terminals,')
s=s.replace('            terminals: Vec::new(),\n            active_terminal: 0,\n            terminal_open: false,\n            terminal_error: None,','            terminals: Default::default(),')
p.write_text(s)
p=Path('src/repo/actions.rs');s=p.read_text().replace('use crate::terminal::ShellSpec;\n','')
s=s.replace('    ToggleTerminal,','    Terminal(TerminalAct),')
s=s.replace('    NewTerminal {\n        shell: Option<ShellSpec>,\n        cwd: Option<PathBuf>,\n    },\n    CloseTerminal(usize),\n    SelectTerminal(usize),\n','')
p.write_text(s)
p=Path('src/repo/apply.rs');s=p.read_text()
s=s.replace('            Action::Terminal(TerminalAct::Toggle) => self.toggle_terminal(ctx),','            Action::Terminal(action) => self.terminals.apply(action, &self.path, ctx),')
s=s.replace('            Action::Terminal(TerminalAct::New { shell, cwd }) => self.start_terminal(shell, cwd, ctx),\n            Action::Terminal(TerminalAct::Close(i)) => self.close_terminal(i),\n            Action::Terminal(TerminalAct::Select(i)) => self.active_terminal = i,\n','')
s=s.replace('use crate::repo::terminals::TerminalAct;\n','')
p.write_text(s)
