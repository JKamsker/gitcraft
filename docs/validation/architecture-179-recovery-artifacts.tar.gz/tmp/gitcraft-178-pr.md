The terminal panel's state was updated independently by normal launches, agents, custom commands, handoff, popouts and the root action dispatcher. A private terminal owner now enforces add/select/close/error/visibility transitions, preserves owned PTYs while hidden, and handles a typed feature action through one root route. Palette contributions and the tab strip live with the feature.

This is the initial baseline + representative ownership phase of #178. The umbrella stays open for typed operation plans and persisted undo compatibility, other feature owners, settings/action composition, async lifetimes and broader performance/platform gates.

- Add a reproducible stdlib architecture survey of raw Git source blobs and a pinned first-parent diff policy, with real-Git configuration/export-attribute fixtures, a field/flow inventory and contributor conventions.
- Reduce `RepoTab` fields 188 → 185, root action variants 165 → 162, constructor lines 208 → 205 and dispatcher lines 422 → 419. Rust privacy prevents collaborators from bypassing the terminal invariants.
- Demonstrate a real follow-up (`TerminalAct::Hide`) with zero edits to central state, constructor, root actions or dispatcher. The existing Hide button becomes idempotent; toolbar/key toggle and popout focus behavior remain.
- Preserve work at `t3/improve-code-quality`; assemble this branch from `dev` with separate baseline, owner and follow-up commits. The implementation tree equals the accepted combined work. The final evidence commit changes documentation/artifacts only; all application files equal tested `0c2b68e1`.

Validation at candidate `bfceb9f456d0ee0f14932a1900e301880399f7bb`:

- Formatting; 5 scanner fixtures; 6 inert owner tests; 1 checkpoint CLI, 6 MCP and 2 OS helper tests; doc tests; fallback host all-target check pass.
- Full Rust library run: **3,338 pass, 3 fail, 10 ignored**. All three failures reproduce with the saved base binary and identical assertions: two existing checkpoint-shell portability failures, one `/var` versus `/private/var` simulated-WSL path failure. They were not skipped.
- All-target Clippy passes with the existing macOS `-A dead_code` allowance. Strict `-D warnings` fails on six unchanged macOS dead-code warnings; strict green is not claimed.
- Local Windows cross-check stops in `ring` because MinGW's C compiler is absent. Linux/Windows CI is left to this final PR; none was started or awaited during implementation.
- Nine paired debug timing/resource smoke cases plus alternating staging repeats show no reproduced slowdown. These are not release, active concurrent-tab, real SSH/WSL or new coverage measurements.

[Architecture and limitations](https://github.com/JKamsker/gitcraft/blob/bfceb9f456d0ee0f14932a1900e301880399f7bb/docs/architecture.md) · [Commit-bound validation and raw logs](https://github.com/JKamsker/gitcraft/blob/bfceb9f456d0ee0f14932a1900e301880399f7bb/docs/validation/architecture-178.md)

Independent adversarial review: **PASS** on exact final candidate `bfceb9f456d0ee0f14932a1900e301880399f7bb`, with no introduced findings. The reviewer independently verified baseline reproduction, source equivalence and all 41 archived evidence hashes. [Immutable review record](https://github.com/JKamsker/gitcraft/blob/66182a7b4b73b7510723f7cc0394f192ff9fb882/bfceb9f456d0ee0f14932a1900e301880399f7bb), also published as `refs/notes/architecture-178` on the candidate.
