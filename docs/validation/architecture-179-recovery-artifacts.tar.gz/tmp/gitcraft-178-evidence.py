import gzip,hashlib,io,json,tarfile
from pathlib import Path
root=Path.cwd()
validation=root/'docs/validation'
validation.mkdir(exist_ok=True)
logs=['baseline-build','after-build','inert-final','suite','baseline-failures','integration','os','doc-tests','clippy-strict','clippy-macos','windows-check','fallback','python','fmt']
items={}
for name in logs:
 p=Path(f'/tmp/gitcraft-178-{name}.log')
 items[name+'.log']=p.read_bytes()
for p in sorted((root/'target/architecture-bench').glob('*.log')):
 items['bench/'+p.name]=p.read_bytes()
items['bench/inputs.json']=(root/'target/architecture-bench/inputs.json').read_bytes()
items['bench/results.json']=(root/'target/architecture-bench/results.json').read_bytes()
items['bench/stage-repeats.json']=(root/'target/architecture-bench/stage-repeats.json').read_bytes()
items['bench/run.py']=Path('/tmp/gitcraft-178-bench.py').read_bytes()
items['bench/repeat-stage.py']=Path('/tmp/gitcraft-178-repeat-stage.py').read_bytes()
with (validation/'architecture-178-logs.tar.gz').open('wb') as raw:
 with gzip.GzipFile(filename='',fileobj=raw,mode='wb',mtime=0) as zipped:
  with tarfile.open(fileobj=zipped,mode='w') as tar:
   for name,data in sorted(items.items()):
    entry=tarfile.TarInfo(name);entry.size=len(data);entry.mode=0o644
    tar.addfile(entry,io.BytesIO(data))
manifest={'application_test_revision':'0c2b68e1a00107a92a14e57c8905b390145d5d70','baseline_revision':'760c79bb69ffc3af5401612bd9c48dcd254eca54','consolidated_source_revision':'a532ed25578a7e3db5bb0af04bd16ecbf0332839','source_tree':'d5bf8dc7712b5cb4e55c64dc4ab04fd727054e05','crates_tree':'e595e26dc893676fd6ed8c060feeeb71c046de2c','sha256':{k:hashlib.sha256(v).hexdigest() for k,v in sorted(items.items())}}
(validation/'architecture-178-evidence.json').write_text(json.dumps(manifest,indent=2)+'\n')
report=json.load(open('/tmp/gitcraft-178-consolidated.json'))
baseline=json.load(open('docs/architecture-baseline.json'))
results={'source_revision':report['revision'],'source_tree':report['tree'],'baseline_revision':baseline['revision'],'method':report['method'],'before':baseline['summary'],'after':report['summary'],'history_window':{'first_parent_commits':len(report['history']['commits_newest_first']),'median_text_files_per_commit':report['history']['median_text_files_per_commit'],'hotspots':{p:report['history']['files'][p] for p in ['src/repo/mod.rs','src/repo/actions.rs','src/repo/apply.rs']}},'feature_followup':{'revision':'a532ed25578a7e3db5bb0af04bd16ecbf0332839','previous':'496f61b2d796565b46364fc9173bdefd06924511','central_files_changed':[]}}
(root/'docs/architecture-results.json').write_text(json.dumps(results,indent=2)+'\n')
