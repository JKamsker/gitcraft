from pathlib import Path
for p in Path('src/repo').rglob('*.rs'):
    if p.name=='terminals.rs':
        continue
    s=p.read_text()
    # Read-only collection access and owned test fixture insertion/cleanup.
    s=s.replace('.terminals.push(term)', '.terminals.opened(Ok(term))')
    s=s.replace('.terminals.iter_mut().any(|t| !t.has_exited())', '.terminals.has_running()')
    s=s.replace('.terminals.iter()', '.terminals.shells().iter()')
    s=s.replace('.terminals.last()', '.terminals.shells().last()')
    s=s.replace('.terminals.get(i)', '.terminals.shells().get(i)')
    s=s.replace('self.terminals.get(self.active_terminal)', 'self.terminals.active()')
    s=s.replace('self.terminal_open = false', 'self.terminals.hide()')
    s=s.replace('tab.terminal_open = true', 'tab.terminals.opened(Err("launch failed".into()))')
    s=s.replace('self.toggle_terminal(ctx)', 'self.terminals.toggle(&self.path, ctx)')
    s=s.replace('self.terminal_open', 'self.terminals.is_open()')
    s=s.replace('tab.terminal_open', 'tab.terminals.is_open()')
    s=s.replace('tab.terminal_error.clone()', 'tab.terminals.error().map(str::to_owned)')
    s=s.replace('tab.terminal_error', 'tab.terminals.error()')
    p.write_text(s)
# Remove repeated launch transitions: ownership is enforced in one method.
p=Path('src/repo/agents/mod.rs');s=p.read_text()
start=s.index('        self.terminals.is_open() = true;')
end=s.index('\n    }',start)
s=s[:start]+'''        self.terminals.opened(spawned.map_err(|e| {
            format!("Could not start {}: {e}", launch.label)
        }));'''+s[end:]
p.write_text(s)
p=Path('src/repo/custom_commands/run.rs');s=p.read_text()
start=s.index('        match Terminal::spawn(&cwd, &spec, ctx)')
end=s.index('\n    }',start)
s=s[:start]+'''        self.terminals.opened(
            Terminal::spawn(&cwd, &spec, ctx)
                .map_err(|e| format!("{name} couldn't be started: {e}")),
        );'''+s[end:]
p.write_text(s)
p=Path('src/repo/agents/handoff.rs');s=p.read_text()
start=s.index('        let ended: Vec<bool>')
end=s.index('        let picked',start)
s=s[:start]+'''        let list = self.terminals.handoff_targets();
'''+s[end:]
s=s.replace('let Some(term) = self.terminals.get_mut(i)', 'let Some(term) = self.terminals.shells().get(i)')
s=s.replace('match term.paste_message(message)', 'match self.terminals.paste_message(i, message)')
s=s.replace('                self.terminals.is_open() = true;\n                self.active_terminal = i;\n','')
p.write_text(s)
# Palette contributions remain at the original positions.
p=Path('src/repo/actions.rs');s=p.read_text()
start=s.index('            (\n                "Toggle terminal".into(),')
end=s.index('\n            if crate::network',start)
s=s[:start]+'            super::terminals::toggle_palette_item(),'+s[end:]
start=s.index('            (\n                "New terminal".into(),')
end=s.index('            ("Reload"',start)
s=s[:start]+'            super::terminals::new_palette_item(),\n'+s[end:]
p.write_text(s)
p=Path('src/repo/palette/mod.rs');s=p.read_text()
start=s.index('            PaletteItem::action("Toggle terminal"')
end=s.index('            PaletteItem::action("Reload"',start)
s=s[:start]+'''        ]);
        items.extend(super::terminals::command_items());
        items.extend([
'''+s[end:]
s=s.replace('use crate::repo::terminals::TerminalAct;\n','')
p.write_text(s)
