from pathlib import Path
import os,subprocess,json,tempfile
sha=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
base=Path('/tmp/gitcraft-ci-followup-'+sha[:8]);base.mkdir(exist_ok=True)
env=dict(os.environ,PATH='/tmp/gitcraft-git252/install/bin:/tmp/gitcraft-lfs/root/usr/bin:'+os.environ['PATH'],GIT_CONFIG_GLOBAL='/dev/null',GIT_CONFIG_NOSYSTEM='1')
artifacts=[]
for line in Path('/tmp/gitcraft-pr183-ci-followup-build.log').read_text().splitlines():
 try: item=json.loads(line)
 except ValueError: continue
 if item.get('reason')=='compiler-artifact' and item.get('executable') and item.get('profile',{}).get('test'): artifacts.append(item)
library=next(x['executable'] for x in artifacts if x['target']['src_path'].endswith('/src/lib.rs') and x['target']['name']=='gitcraft')
results=[]
checks=[('responsive-'+str(i),'repo::detail::responsive_tests::responsive_composer_matrix_reserves_identity_and_keeps_one_toolbar',True) for i in range(10)]
checks += [('responsive-suite','repo::detail::responsive_tests::',False),('palette','app::palette::tests::thousands_of_branches_open_and_filter_quickly',True)]
for label,test,exact in checks:
 scratch=tempfile.mkdtemp(prefix='gitcraft-ci-followup-')
 runtime=dict(env,TMPDIR=scratch,XDG_CONFIG_HOME=scratch+'/config',XDG_DATA_HOME=scratch+'/data',XDG_CACHE_HOME=scratch+'/cache')
 args=['bwrap','--unshare-pid','--die-with-parent','--bind','/','/','--dev','/dev','--proc','/proc','--',library,test,'--test-threads=1','--nocapture']+(['--exact'] if exact else [])
 log=base/(label+'.log')
 with log.open('w') as f: code=subprocess.run(args,env=runtime,stdout=f,stderr=subprocess.STDOUT).returncode
 content=log.read_text()
 if '0 passed;' in content and code==0: code=100
 results.append(dict(label=label,exit=code,command=args,log=str(log)))
 (base/'results.json').write_text(json.dumps(dict(commit=sha,checks=results),indent=2)+'\n')
 print(label,code,flush=True)
 if code: raise SystemExit(code)
