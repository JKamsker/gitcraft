from pathlib import Path
import os,subprocess,json,tempfile
sha=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
base=Path('/tmp/gitcraft-final-'+sha[:8]);base.mkdir(exist_ok=True)
env=dict(os.environ,PKG_CONFIG_PATH='/tmp/gitcraft-pr179-build-deps/root/usr/lib/x86_64-linux-gnu/pkgconfig',CARGO_TARGET_DIR='/home/jonas/.t3/worktrees/gitcraft/t3-29525ec5/target',CARGO_BUILD_JOBS='4',CARGO_PROFILE_TEST_DEBUG='0',PATH='/tmp/gitcraft-git252/install/bin:/tmp/gitcraft-lfs/root/usr/bin:'+os.environ['PATH'],GIT_CONFIG_GLOBAL='/dev/null',GIT_CONFIG_NOSYSTEM='1')
results=[]
def run(label,args,custom_env=env):
 log=base/(label+'.log')
 with log.open('w') as f: code=subprocess.run(args,env=custom_env,stdout=f,stderr=subprocess.STDOUT).returncode
 results.append(dict(label=label,exit=code,log=str(log)));(base/'results.json').write_text(json.dumps(dict(commit=sha,checks=results),indent=2)+'\n');print(label,code,flush=True);return code
for label,args in [('fmt',['cargo','fmt','--all','--','--check']),('check',['cargo','check','--locked','--all-targets']),('clippy',['cargo','clippy','--locked','--all-targets','--','-D','warnings']),('build-tests',['cargo','test','--locked','--no-run','--message-format=json'])]:
 if run(label,args):raise SystemExit(1)
artifacts=[]
for line in (base/'build-tests.log').read_text().splitlines():
 try:item=json.loads(line)
 except ValueError:continue
 if item.get('reason')=='compiler-artifact' and item.get('executable') and item.get('profile',{}).get('test'):
  artifacts.append((item['target']['name'],item['target']['src_path'],item['executable']))
library=next(path for name,src,path in artifacts if name=='gitcraft' and src.endswith('/src/lib.rs'))
for label,pattern in [('recording-outcomes','processes::recording_outcomes'),('recording-resolver','resolver::process::tests::recording_failure_mapping_and_join_proof_fail_closed')]:
 if run(label,[library,pattern,'--test-threads=1']):raise SystemExit(1)
 assert '0 passed;' not in (base/(label+'.log')).read_text(), 'recording filter matched zero tests'
for name,src,path in artifacts:
 scratch=tempfile.mkdtemp(prefix='gitcraft-final-suite-')
 runtime=dict(env,TMPDIR=scratch,XDG_CONFIG_HOME=scratch+'/config',XDG_DATA_HOME=scratch+'/data',XDG_CACHE_HOME=scratch+'/cache')
 label='runtime-'+name+('-lib' if src.endswith('/src/lib.rs') else '-'+Path(src).stem)
 args=['bwrap','--unshare-pid','--die-with-parent','--bind','/','/','--dev','/dev','--proc','/proc','--',path,'--test-threads=4']
 if path==library:
  args+=['--skip','standalone::save::tests::acl_only_tightening_during_each_save_boundary_refuses_stale_policy_and_retains_recovery','--skip','git::file_comparison::index_transaction::tests::index_owner_comparison_and_real_group_drift_refuse_stale_publication']
 run(label,args,runtime)
for label,test in [('acl-save','standalone::save::tests::acl_only_tightening_during_each_save_boundary_refuses_stale_policy_and_retains_recovery'),('acl-index','git::file_comparison::index_transaction::tests::index_owner_comparison_and_real_group_drift_refuse_stale_publication')]:
 runtime=dict(env,TMPDIR=tempfile.mkdtemp(prefix='gitcraft-final-acl-'))
 run(label,[library,test,'--exact','--test-threads=1'],runtime)
run('doc-tests',['cargo','test','--locked','--doc'])
raise SystemExit(any(item['exit'] for item in results))
