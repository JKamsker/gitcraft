#![allow(dead_code)]
    use crate::forge::Forge;
    #[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
    pub enum CheckState { Passed, Failed, Running, #[default] Skipped }
    #[derive(Clone, Debug, PartialEq, Eq)]
    pub struct Project { pub path: String, pub host: String, pub forge: Forge }
    impl Project { pub fn hosting(&self) {} }
    fn time(_: &str) -> Option<i64> { None }
    fn no_builds(_: Forge) -> String { "Unsupported forge".into() }
    mod github {
        use super::CheckState;
        pub fn state(status: &str, conclusion: &str) -> CheckState {
            match (status, conclusion) {
                ("completed", "success") => CheckState::Passed,
                ("completed", "failure") => CheckState::Failed,
                ("completed", _) => CheckState::Skipped,
                _ => CheckState::Running,
            }
        }
    }
    mod gitlab {
        use super::CheckState;
        pub fn state(_: &str) -> CheckState { CheckState::Skipped }
    }
    pub mod timing;
