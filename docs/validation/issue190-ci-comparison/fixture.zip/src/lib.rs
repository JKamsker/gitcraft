#![allow(dead_code)]
mod forge {
    #[derive(Clone, Copy, Debug, PartialEq, Eq)]
    pub enum Forge { GitHub, GitLab, Forgejo, Gitea, Azure, Bitbucket }
    pub fn tool(_: &(), _: &std::path::Path, _: &[&str]) -> Result<String, String> {
        Err("Network boundaries are disabled in the scoped fixture".into())
    }
}
mod pull_request {
    use serde_json::Value;
    pub fn at<'a>(value: &'a Value, pointer: &str) -> &'a str {
        value.pointer(pointer).and_then(Value::as_str).unwrap_or_default()
    }
    pub fn items<'a>(value: &'a Value, pointer: &str) -> &'a [Value] {
        value.pointer(pointer).and_then(Value::as_array).map_or(&[], Vec::as_slice)
    }
}
mod ci;
mod git {
    pub mod fixture {
        pub struct Repo;
        impl Repo {
            pub fn new(_: &str) -> Result<Self, String> { Err("Git fixtures disabled".into()) }
            pub fn commit(&self, _: &str, _: &[(&str, Option<&str>)]) -> Result<String, String> { Err("Git disabled".into()) }
            pub fn path(&self) -> &std::path::Path { std::path::Path::new(".") }
        }
    }
    pub fn now() -> i64 { 0 }
    pub fn run_env(_: Option<&std::path::Path>, _: &[&str], _: &[(&str, &str)]) -> Result<String, String> {
        Err("Git is disabled in the scoped fixture".into())
    }
    pub fn run(_: Option<&std::path::Path>, _: &[&str]) -> Result<String, String> {
        Err("Git is disabled in the scoped fixture".into())
    }
}
fn retain_public_entry_points() {
    let _ = insights::ci_path::read;
    let _ = insights::ci_path::read_pinned;
}
mod insights {
    #[derive(Clone, Copy, Debug, PartialEq, Eq, PartialOrd, Ord)]
    pub enum Evidence { Observed, Inferred, Unknown }
    impl Evidence { pub fn label(self) -> &'static str { match self { Self::Observed => "observed", Self::Inferred => "inferred", Self::Unknown => "unknown" } } }
    #[derive(Clone, Debug, Default, PartialEq, Eq)]
    pub struct Provenance {
        pub source: String, pub scope: String, pub tips: Vec<(String, String)>,
        pub collected: i64, pub partial: Option<String>, pub stale: Option<String>,
    }
    impl Provenance {
        pub fn new(source: impl Into<String>, scope: impl Into<String>) -> Self { Self { source: source.into(), scope: scope.into(), ..Self::default() } }
        pub fn tip(mut self, name: impl Into<String>, sha: impl Into<String>) -> Self { self.tips.push((name.into(), sha.into())); self }
        pub fn partial(mut self, why: impl Into<String>) -> Self { self.partial = Some(why.into()); self }
    }
    pub mod ci_path;
}
