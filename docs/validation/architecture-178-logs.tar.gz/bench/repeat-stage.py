import os,json,subprocess
from pathlib import Path
root=Path.cwd();out=root/'target/architecture-bench';records=[]
for i,label in enumerate(['after','before','after','before']):
 result=out/f'stage-repeat-{i}.json'
 env=os.environ.copy();env.update(GITCRAFT_BENCH_INPUTS=str(out/'inputs.json'),GITCRAFT_BENCH_OUTPUT=str(result),GITCRAFT_BENCH_FILTER='operations/stage-unstage-cycle',GITCRAFT_BENCH_EXACT='1',GITCRAFT_BENCH_SAMPLES='15',GITCRAFT_BENCH_SAMPLE_MS='100')
 with (out/f'stage-repeat-{i}.log').open('w') as log:
  p=subprocess.run([f'/tmp/gitcraft-178-{label}-tests','repo::cpu_benchmarks::real_world_cpu','--exact','--ignored','--nocapture','--test-threads=1'],env=env,stdout=log,stderr=subprocess.STDOUT)
 assert p.returncode==0
 record={'label':label,'run':i,**json.loads(result.read_text())}
 records.append(record)
 print(label,record['measurements'][0]['median_ms'],flush=True)
 (out/'stage-repeats.json').write_text(json.dumps(records,indent=2)+'\n')
