import json,os,subprocess,hashlib,platform
from pathlib import Path
root=Path('/Users/jonas/.t3/worktrees/gitcraft/t3-6d0d75e7')
out=root/'target/architecture-bench'
inputs=out/'inputs.json'
cases=['startup/create-20-deferred-tabs','ui/palette-items','terminal/parse-build-output','terminal/paint-build-output-frame','repository/reload-metadata','history/layout-1500','diff/open/src/repo/load.rs','operations/stage-unstage-cycle','ui/graph-warm-frame']
binaries={'before':Path('/tmp/gitcraft-178-before-tests'),'after':Path('/tmp/gitcraft-178-after-tests')}
records=[]
for case in cases:
    for label,binary in binaries.items():
        stem=label+'-'+case.replace('/','-')
        result=out/(stem+'.json')
        env=os.environ.copy()
        env.update(GITCRAFT_BENCH_INPUTS=str(inputs),GITCRAFT_BENCH_OUTPUT=str(result),GITCRAFT_BENCH_FILTER=case,GITCRAFT_BENCH_EXACT='1',GITCRAFT_BENCH_SAMPLES='9',GITCRAFT_BENCH_SAMPLE_MS='50')
        with (out/(stem+'.log')).open('w') as log:
            ran=subprocess.run(['/usr/bin/time','-l',str(binary),'repo::cpu_benchmarks::real_world_cpu','--exact','--ignored','--nocapture','--test-threads=1'],env=env,cwd=root,stdout=log,stderr=subprocess.STDOUT)
        record={'case':case,'label':label,'exit':ran.returncode,'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest()}
        if ran.returncode==0:
            data=json.loads(result.read_text())
            record['measurements']=data['measurements']
            assert len(record['measurements'])==1, (case,record['measurements'])
            for line in (out/(stem+'.log')).read_text().splitlines():
                if 'maximum resident set size' in line:
                    record['max_rss_bytes']=int(line.strip().split()[0])
        records.append(record)
        print(case,label,ran.returncode,flush=True)
        (out/'results.json').write_text(json.dumps({'profile':'test/debug (dependencies opt-level=2), not release performance evidence','platform':platform.platform(),'input_sha256':hashlib.sha256(inputs.read_bytes()).hexdigest(),'before_revision':'760c79bb69ffc3af5401612bd9c48dcd254eca54','after_revision':'0c2b68e1a00107a92a14e57c8905b390145d5d70','records':records},indent=2)+'\n')
        if ran.returncode:
            raise SystemExit(ran.returncode)
