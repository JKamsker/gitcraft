import json,subprocess,os
artifacts=[json.loads(l) for l in open('/tmp/gitcraft-51-final-artifacts.jsonl') if l.startswith('{')]
exe=next(d['executable'] for d in artifacts if d.get('reason')=='compiler-artifact' and d.get('executable') and d['target']['name']=='gitcraft')
patterns=['repo::branch_bands::','repo::graph_view::minimap::','git::activity::','repo::history_activity::','git::atlas::','repo::atlas::','git::growth::','repo::growth::','repo::postcards::','git::postcards::','git::visualization_tests::','repo::graph_walk::','repo::celebration::','repo::graph_motion::','repo::history_reader::','audio::tests::']
failed=[]
with open('/tmp/gitcraft-51-focused-results.log','w') as log:
 for pattern in patterns:
  log.write('\nFILTER '+pattern+'\n');log.flush()
  p=subprocess.run([exe,pattern,'--nocapture'],stdout=log,stderr=subprocess.STDOUT)
  print(pattern,p.returncode,flush=True)
  if p.returncode: failed.append(pattern)
print('FAILED',failed,flush=True)
raise SystemExit(bool(failed))
