use std::sync::Arc; use egui::load::SizeHint; use resvg::usvg; const SOURCE_LIMIT:usize=256*1024; const PIXELS:u64=1024*1024;
fn render(bytes: &[u8], hint: SizeHint) -> Result<egui::ColorImage, String> {
    render_with_parser(bytes, hint, |bytes, options| {
        usvg::Tree::from_data(bytes, options).map_err(|_| "SVG parsing failed".into())
    })
}
// The parser boundary is injectable so refusals can be proved without ever expanding
// hostile paint graphs. Active parsing/rasterization is bounded work, not preemptible.
fn render_with_parser(
    bytes: &[u8],
    hint: SizeHint,
    parse: impl FnOnce(&[u8], &usvg::Options<'_>) -> Result<usvg::Tree, String>,
) -> Result<egui::ColorImage, String> {
    if bytes.len() > SOURCE_LIMIT {
        return Err("SVG exceeds 256 KiB; use source view".into());
    }
    // Reject XML entities/DTD, compressed SVG, expansion primitives and expensive effect
    // graphs before usvg sees them. Limits bound parsing and render work, not just output.
    let text = std::str::from_utf8(bytes).map_err(|_| "SVG must be uncompressed UTF-8")?;
    if text.contains("<!DOCTYPE") || text.contains("<!ENTITY") {
        return Err("SVG declarations are unsupported; use source view".into());
    }
    let doc = roxmltree::Document::parse(text).map_err(|_| "Invalid SVG")?;
    let mut nodes = 0;
    let mut complexity = 0usize;
    for n in doc.descendants().filter(|n| n.is_element()) {
        nodes += 1;
        complexity = complexity.saturating_add(
            1 + n
                .attributes()
                .filter(|a| matches!(a.name(), "d" | "points"))
                .map(|a| a.value().len() / 16)
                .sum::<usize>(),
        );
        if nodes > 4096 || n.ancestors().count() > 64 {
            return Err("SVG complexity exceeds preview limits; use source view".into());
        }
        if matches!(
            n.tag_name().name(),
            // Markers and clip paths expand recursively during parsing or painting,
            // including references from inline styles or escaped CSS properties.
            // Refuse definitions irrespective of reference syntax before CSS/usvg.
            "use" | "marker" | "clipPath" | "filter" | "mask" | "pattern" | "foreignObject"
        ) {
            return Err(
                "SVG expansion/effect graphs are unsupported in previews; use source view".into(),
            );
        }
    }
    let mut options = usvg::Options::default();
    options.image_href_resolver.resolve_string = Box::new(|_, _| None);
    // Only small, decoded and re-encoded raster images. Nested SVG/data URLs cannot
    // recursively expand; raster headers cannot request unbounded decoder allocations.
    let decoded_pixels = std::sync::atomic::AtomicU64::new(0);
    options.image_href_resolver.resolve_data = Box::new(move |mime, bytes, _| {
        use image::ImageEncoder;
        if bytes.len() > 128 * 1024 || !matches!(mime, "image/png" | "image/jpeg") {
            return None;
        }
        let mut reader = image::ImageReader::new(std::io::Cursor::new(bytes.as_ref()))
            .with_guessed_format()
            .ok()?;
        let mut limits = image::Limits::default();
        limits.max_image_width = Some(1024);
        limits.max_image_height = Some(1024);
        limits.max_alloc = Some(8 * 1024 * 1024);
        reader.limits(limits);
        let (width, height) = image::ImageReader::new(std::io::Cursor::new(bytes.as_ref()))
            .with_guessed_format()
            .ok()?
            .into_dimensions()
            .ok()?;
        let pixels = u64::from(width) * u64::from(height);
        if pixels > PIXELS
            || decoded_pixels
                .fetch_add(pixels, std::sync::atomic::Ordering::Relaxed)
                .saturating_add(pixels)
                > 2 * PIXELS
        {
            return None;
        }
        let decoded = reader.decode().ok()?.to_rgba8();
        if u64::from(decoded.width()) * u64::from(decoded.height()) > PIXELS {
            return None;
        }
        let mut png = Vec::new();
        image::codecs::png::PngEncoder::new(&mut png)
            .write_image(
                &decoded,
                decoded.width(),
                decoded.height(),
                image::ExtendedColorType::Rgba8,
            )
            .ok()?;
        Some(usvg::ImageKind::PNG(Arc::new(png)))
    });
    let tree = parse(bytes, &options)?;
    let size = tree.size();
    let requested = match hint {
        SizeHint::Size { width, height, .. } => width.max(height) as f32,
        SizeHint::Height(h) | SizeHint::Width(h) => h as f32,
        _ => size.width().max(size.height()),
    }
    .clamp(1., 1024.);
    let mut scale = requested / size.width().max(size.height());
    // Bound overdraw/geometry work too: complex documents use a smaller thumbnail.
    let budget = (16 * PIXELS / complexity.max(1) as u64).clamp(1024, PIXELS) as f32;
    let pixels = size.width() * size.height() * scale * scale;
    if pixels > budget {
        scale *= (budget / pixels).sqrt();
    }
    let width = (size.width() * scale).ceil().max(1.) as u32;
    let height = (size.height() * scale).ceil().max(1.) as u32;
    let mut pixmap = resvg::tiny_skia::Pixmap::new(width, height).ok_or("SVG allocation failed")?;
    resvg::render(
        &tree,
        usvg::Transform::from_scale(scale, scale),
        &mut pixmap.as_mut(),
    );
    Ok(egui::ColorImage::from_rgba_premultiplied(
        [width as usize, height as usize],
        pixmap.data(),
    ))
}
    fn nested_clip_paths_are_refused_before_parser_for_attributes_and_css() -> Result<(), String> {
        for depth in [1, 4, 8] {
            for route in ["attribute", "inline", "css", "escaped-css"] {
                let mut definitions = String::new();
                let mut styles = String::new();
                for i in 0..depth {
                    let child = if i + 1 < depth {
                        let target = i + 1;
                        let reference = match route {
                            "attribute" => format!("clip-path='url(#c{target})'"),
                            "inline" => format!("style='clip-path:url(#c{target})'"),
                            _ => {
                                let property = if route == "css" {
                                    "clip-path"
                                } else {
                                    r"cl\69 p-path"
                                };
                                styles.push_str(&format!(".p{i} {{{property}:url(#c{target})}}"));
                                format!("class='p{i}'")
                            }
                        };
                        // Each level visits the next clip twice, despite linear XML size.
                        format!("<rect width='8' height='8' {reference}/>").repeat(2)
                    } else {
                        "<rect width='8' height='8'/>".into()
                    };
                    definitions.push_str(&format!("<clipPath id='c{i}'>{child}</clipPath>"));
                }
                let svg = format!(
                    "<svg xmlns='http://www.w3.org/2000/svg' width='8' height='8'><style>{styles}</style><defs>{definitions}</defs><rect width='8' height='8' clip-path='url(#c0)'/></svg>"
                );
                assert!(svg.len() < 4096);
                let mut parser_entered = false;
                let error = render_with_parser(svg.as_bytes(), SizeHint::default(), |_, _| {
                    parser_entered = true;
                    Err("Parser must not receive recursive clipping".into())
                })
                .err()
                .ok_or("Clip graph unexpectedly accepted")?;
                assert!(error.contains("expansion/effect") && error.contains("source view"));
                assert!(!parser_entered, "depth={depth}, route={route}");
            }
        }
        Ok(())
    }

    fn nested_distinct_markers_are_refused_before_parser_for_attributes_and_css()
    -> Result<(), String> {
        for depth in [1, 4, 8] {
            for route in ["attribute", "inline", "css", "escaped-css"] {
                let mut definitions = String::new();
                let mut styles = String::new();
                for i in 0..depth {
                    let target = if i + 1 < depth { i + 1 } else { i };
                    let reference = match route {
                        "attribute" => format!("marker-mid='url(#m{target})'"),
                        "inline" => format!("style='marker-mid:url(#m{target})'"),
                        _ => {
                            let property = if route == "css" {
                                "marker-mid"
                            } else {
                                r"m\61 rker-mid"
                            };
                            styles.push_str(&format!(".p{i} {{{property}:url(#m{target})}}"));
                            format!("class='p{i}'")
                        }
                    };
                    let child = if i + 1 < depth {
                        format!("<path d='M0 0 L1 1 L2 0 L3 1' {reference}/>")
                    } else {
                        "<circle r='1'/>".into()
                    };
                    definitions.push_str(&format!(
                        "<marker id='m{i}' markerWidth='4' markerHeight='4'>{child}</marker>"
                    ));
                }
                let svg = format!(
                    "<svg xmlns='http://www.w3.org/2000/svg' width='8' height='8'><style>{styles}</style><defs>{definitions}</defs><path d='M0 0L1 1L2 0L3 1' marker-mid='url(#m0)'/></svg>"
                );
                assert!(svg.len() < 4096);
                let mut parser_entered = false;
                let result = render_with_parser(svg.as_bytes(), SizeHint::default(), |_, _| {
                    parser_entered = true;
                    Err("Parser must never receive expansion input".into())
                });
                let error = result.err().ok_or("Marker preview unexpectedly accepted")?;
                assert!(error.contains("expansion/effect") && error.contains("source view"));
                assert!(!parser_entered, "depth={depth}, route={route}");
            }
        }
        Ok(())
    }

    fn preflight_refusal_precedes_parser_allocation_and_ordinary_style_still_renders()
    -> Result<(), String> {
        let over_budget = format!(
            "<svg xmlns='http://www.w3.org/2000/svg'>{}</svg>",
            "<g/>".repeat(4096)
        );
        let mut parser_entered = false;
        let error = render_with_parser(over_budget.as_bytes(), SizeHint::default(), |_, _| {
            parser_entered = true;
            Err("Unexpected parser allocation".into())
        })
        .err()
        .ok_or("Injected source budget should refuse")?;
        assert!(!parser_entered);
        assert!(error.contains("complexity") && error.contains("source view"));
        let ordinary = br#"<svg xmlns="http://www.w3.org/2000/svg" width="8" height="8"><style>.paint {fill:magenta}</style><rect class="paint" width="8" height="8" style="opacity:1"/></svg>"#;
        let image = render(ordinary, SizeHint::default())?;
        assert!(image.pixels.iter().any(|p| p.a() > 0));
        Ok(())
    }
fn main() -> Result<(),String> {
nested_clip_paths_are_refused_before_parser_for_attributes_and_css()?; println!("PASS nested_clip_paths_are_refused_before_parser_for_attributes_and_css");
nested_distinct_markers_are_refused_before_parser_for_attributes_and_css()?; println!("PASS nested_distinct_markers_are_refused_before_parser_for_attributes_and_css");
preflight_refusal_precedes_parser_allocation_and_ordinary_style_still_renders()?; println!("PASS preflight_refusal_precedes_parser_allocation_and_ordinary_style_still_renders");
let mut entered=false; let error=render_with_parser(include_bytes!("/private/tmp/gitcraft-fileviews-svg-r4-131cd833/prior-clip-depth-1.svg"),SizeHint::default(),|_,_|{entered=true;Err("unexpected parser entry".into())}).err().ok_or("old repro accepted")?; assert!(!entered);assert!(error.contains("source view")); println!("PASS exact prior repro depth 1 refused before parser");
let mut entered=false; let error=render_with_parser(include_bytes!("/private/tmp/gitcraft-fileviews-svg-r4-131cd833/prior-clip-depth-4.svg"),SizeHint::default(),|_,_|{entered=true;Err("unexpected parser entry".into())}).err().ok_or("old repro accepted")?; assert!(!entered);assert!(error.contains("source view")); println!("PASS exact prior repro depth 4 refused before parser");
let mut entered=false; let error=render_with_parser(include_bytes!("/private/tmp/gitcraft-fileviews-svg-r4-131cd833/prior-clip-depth-8.svg"),SizeHint::default(),|_,_|{entered=true;Err("unexpected parser entry".into())}).err().ok_or("old repro accepted")?; assert!(!entered);assert!(error.contains("source view")); println!("PASS exact prior repro depth 8 refused before parser");
Ok(())}
