#[path="config-source.rs"] pub mod config;
use config::SETTINGS;
const PERSONAL: &[&str] = &["user.name", "user.email", "user.signingKey"];
mod git { use std::path::Path; pub fn run(_:Option<&Path>,_:&[&str])->Result<String,String>{Err("no commands allowed in pure harness".into())} pub fn is_auth_error(err: &str) -> bool {
    let e = err.to_lowercase();
    [
        "terminal prompts disabled",
        "could not read username",
        "could not read password",
        "authentication failed",
        "invalid username or password",
        "http basic: access denied",
        "the requested url returned error: 401",
        "the requested url returned error: 403",
    ]
    .iter()
    .any(|s| e.contains(s))
}

 }
struct Report { lines: Vec<String>, success: bool }
mod connection_doctor { pub(crate) fn endpoint(value: &str) -> String {
    let value = value.trim();
    if value.is_empty() {
        return "none".into();
    }
    let (scheme, rest) = value.split_once("://").unwrap_or(("proxy", value));
    let authority = rest
        .split(['/', '?', '#'])
        .next()
        .unwrap_or_default()
        .rsplit('@')
        .next()
        .unwrap_or_default();
    if authority.is_empty()
        || authority
            .chars()
            .any(|c| c.is_control() || c.is_whitespace())
        || !scheme
            .bytes()
            .all(|b| b.is_ascii_alphanumeric() || matches!(b, b'+' | b'-'))
    {
        "configured (value withheld)".into()
    } else {
        format!("{scheme}://{authority}")
    }
}
 }
#[derive(Default)]struct Remote { url:String }
#[derive(Default)]struct RepoTab {path:std::path::PathBuf,remotes:Vec<Remote>,credentials:Option<String>,parked:Vec<Box<RepoTab>>}
impl RepoTab {     pub(crate) fn forget_https_memory(&mut self, path: &std::path::Path, url: &str) {
        let host = crate::connection_doctor::endpoint(url);
        if self.path == path
            || self.remotes.iter().any(|r| {
                r.url.starts_with("https://") && crate::connection_doctor::endpoint(&r.url) == host
            })
        {
            self.credentials = None;
        }
    }
 }
pub fn settings_rows(all: &[config::Origin]) -> Vec<String> {
    SETTINGS
        .iter()
        .filter(|s| !PERSONAL.iter().any(|p| p.eq_ignore_ascii_case(s.key)))
        .filter_map(|s| {
            let winner = config::values_of(all, s.key).into_iter().last()?;
            let value = winner.shown_value();
            // A path (an editor, a program, a folder) can name its user: only that it is set.
            let value = if value.contains(['/', '\\']) {
                "(a path)"
            } else {
                value
            };
            let file = winner
                .file
                .as_deref()
                .map(|f| f.rsplit(['/', '\\']).next().unwrap_or(f))
                .unwrap_or("-");
            Some(format!(
                "{} = {value} · {} · {file}",
                s.key,
                winner.scope.label(),
            ))
        })
        .collect()
}

pub(crate) fn issue_url(report: &str) -> String {
    let mut body = String::from("Please describe what happened and how to reproduce it.\n\n");
    for line in report.lines() {
        if encode(&(body.clone() + line)).len() > 6500 {
            body.push_str("\n[Remaining diagnostics are on the clipboard.]\n");
            break;
        }
        body.push_str(line);
        body.push('\n');
    }
    format!(
        "https://github.com/JKamsker/gitcraft/issues/new?title=Bug%20report&body={}",
        encode(&body)
    )
}
fn encode(text: &str) -> String {
    let mut out = String::new();
    for b in text.bytes() {
        if b.is_ascii_alphanumeric() || b"-_.~".contains(&b) {
            out.push(b as char);
        } else {
            out.push_str(&format!("%{b:02X}"));
        }
    }
    out
}

pub fn redact_home(text: &str, home: &str) -> String {
    let home = home.trim_end_matches(['/', '\\']);
    if home.len() < 2 {
        return text.to_owned();
    }
    let mut out = text.to_owned();
    for form in [home.to_owned(), home.replace('\\', "/")] {
        out = replace_whole(&out, &form, "~");
    }
    out
}

/// `text` with every `needle` (ASCII case ignored) that ends where a path component does
/// replaced by `with`.
fn replace_whole(text: &str, needle: &str, with: &str) -> String {
    let lower = text.to_ascii_lowercase();
    let wanted = needle.to_ascii_lowercase();
    let mut out = String::with_capacity(text.len());
    let mut at = 0;
    while let Some(found) = lower[at..].find(&wanted) {
        let start = at + found;
        let end = start + wanted.len();
        let whole = text[end..]
            .chars()
            .next()
            .is_none_or(|c| matches!(c, '/' | '\\' | '`') || c.is_whitespace());
        out.push_str(&text[at..start]);
        out.push_str(if whole { with } else { &text[start..end] });
        at = end;
    }
    out.push_str(&text[at..]);
    out
}

/// `text` with the folder named after any user written `~`: what follows `/home/`, `/Users/`
/// or `\Users\` (also `/mnt/c/Users/`, `/c/Users/`, `C:/Users/`), and `/root`, on whichever
/// machine (WSL, SSH, Windows) the path is.
pub fn redact_users(text: &str) -> String {
    let lower = text.to_ascii_lowercase();
    let mut out = String::with_capacity(text.len());
    let mut at = 0;
    while at < text.len() {
        let next = ["/home/", "/users/", "\\users\\"]
            .iter()
            .filter_map(|m| lower[at..].find(m).map(|i| (at + i, m.len())))
            .min();
        let Some((start, len)) = next else {
            break;
        };
        // Back to the start of the path: a drive (`C:`), `/mnt/c`, `/c`.
        let path_start = text[at..start]
            .rfind(|c: char| c.is_whitespace() || matches!(c, '`' | '"' | '\'' | '(' | '='))
            .map_or(at, |i| at + i + 1);
        let name_end = text[start + len..]
            .find(|c: char| matches!(c, '/' | '\\' | '`') || c.is_whitespace())
            .map_or(text.len(), |i| start + len + i);
        out.push_str(&text[at..path_start]);
        out.push('~');
        at = name_end;
    }
    out.push_str(&text[at..]);
    replace_whole(&out, "/root", "~")
}

fn classify(success: bool, trace: &str, tls: bool, elapsed: std::time::Duration) -> Report {
    let t = trace.to_lowercase();
    let failure = if t.contains("407") {
        Some((1, "407: the proxy wants a password"))
    } else if t.contains("could not resolve")
        || t.contains("name or service not known")
        || t.contains("could not resolve hostname")
    {
        Some((0, "DNS: the host or proxy could not be resolved"))
    } else if t.contains("host key verification failed") {
        Some((
            2,
            "SSH host verification failed; verify the server's host key on the repository machine",
        ))
    } else if t.contains("certificate")
        || t.contains("ssl connect")
        || t.contains("tls") && t.contains("failed")
    {
        Some((
            2,
            "TLS: certificate chain or handshake failed; check the configured CA and hostname",
        ))
    } else if git::is_auth_error(trace) || t.contains("publickey") || t.contains("access denied") {
        Some((
            3,
            "Authentication: the server refused this account or no unattended sign-in is available",
        ))
    } else if t.contains("failed to connect")
        || t.contains("connection refused")
        || t.contains("timed out")
        || t.contains("no route")
    {
        Some((1, "TCP: could not connect to the server or proxy"))
    } else {
        None
    };
    let mut lines = Vec::new();
    let names = [
        "DNS",
        "TCP",
        if tls {
            "TLS chain (Git's configured CA trust)"
        } else {
            "SSH transport handshake"
        },
        "Authentication",
    ];
    for (i, name) in names.into_iter().enumerate() {
        let state = if success {
            if i == 3 {
                "accepted for this read (the repository may be public)"
            } else {
                "completed through the configured transport"
            }
        } else if failure.is_some_and(|(step, _)| i < step) {
            "completed before the failure"
        } else if failure.is_some_and(|(step, _)| i == step) {
            "failed"
        } else {
            "not confirmed"
        };
        lines.push(format!("{name}: {state}"));
    }
    if !success {
        lines.push(failure.map(|(_,m)|m.to_owned()).unwrap_or_else(||"Git could not complete ls-remote; inspect the repository operation log for details. No transport stage can be safely inferred.".into()));
    }
    lines.push(format!(
        "ls-remote: {} in {:.2} s",
        if success { "completed" } else { "failed" },
        elapsed.as_secs_f64()
    ));
    Report { lines, success }
}

fn main(){
 let input="local\0file:.git/config\0core.editor\nenv API_TOKEN=FIXTURE_SECRET nvim\0";
 let rows=settings_rows(&config::parse_origins(input));
 let report=redact_users(&redact_home(&rows.join("\n"),"/home/fixture"));
 println!("DIAGNOSTIC_ROWS={report}");
 let url=issue_url(&report);println!("PREFILLED_URL={url}");
 assert!(url.contains("FIXTURE_SECRET"));
 let trace="== Info: SSL connection using TLSv1.3\n== Info: Server certificate:\n== Info: SSL certificate verify ok.\n<= Recv header: HTTP/2 401\nfatal: Authentication failed for 'https://fixture.invalid/repo'";
 let r=classify(false,trace,true,std::time::Duration::from_secs(1));
 println!("DOCTOR_AUTH_FAILURE success={} lines={:?}",r.success,r.lines);
 assert!(r.lines[2].ends_with("failed"));assert!(r.lines[3].ends_with("not confirmed"));
 let url="https://fixture.invalid/team/repo";
 let mut tab=RepoTab{path:"/fixture/main".into(),remotes:vec![Remote{url:url.into()}],credentials:Some("OLD_ACCOUNT_FIXTURE".into()),parked:vec![Box::new(RepoTab{path:"/fixture/linked".into(),remotes:vec![Remote{url:url.into()}],credentials:Some("OLD_ACCOUNT_FIXTURE".into()),..Default::default()})]};
 tab.forget_https_memory(std::path::Path::new("/fixture/main"),url);
 println!("HTTPS_SIGNOUT main_cleared={} parked_still_authenticated={}",tab.credentials.is_none(),tab.parked[0].credentials.is_some());
 assert!(tab.credentials.is_none());assert!(tab.parked[0].credentials.is_some());
}
