from pathlib import Path
import subprocess,hashlib,json
src=Path('/Users/jonas/.t3/worktrees/gitcraft/t3-5b9a0fe3/src');out=Path('/tmp/gitcraft-51-setup-review-r1-evidence')
s=(src/'repo/operations.rs').read_text();a=s.index('    pub(super) fn switch_https(');b=s.index('    /// Remembers the credentials',a);function=s[a:b]
head=r'''
mod egui { pub struct Context; }
mod settings { pub mod network_page { pub fn valid_https(url:&str)->bool { url.starts_with("https://") && !url.chars().any(char::is_control) && url.len()<32768 } } }
mod diagnostics { pub mod crash {pub fn scrub(s:&str)->String{s.into()}} }
mod git {pub fn https_reject(_:&std::path::Path,_:&str)->Result<(),String>{Ok(())}}
mod model {
use crate::{egui,git};
#[derive(Debug)]struct Dialog(String);
impl Dialog {fn credentials(url:&str,_:bool)->Self{Self(url.into())}}
struct RepoTab {path:std::path::PathBuf,busy_op:Option<String>,credentials:Option<String>,status:Option<(String,bool)>,dialog:Option<Dialog>,pending:Option<Box<dyn FnOnce(&mut RepoTab,&egui::Context)>>}
impl RepoTab {
 fn then_or<T:Send+'static>(&self,_ctx:&egui::Context,_mutation:bool,_failed:impl FnOnce(String)->T+Send+'static,_work:impl FnOnce()->T+Send+'static,_then:impl FnOnce(&mut RepoTab,T,&egui::Context)+Send+'static) { unreachable!() }
}
}
'''
# Store the exact production completion in a tiny deterministic event queue. Only this
# queue adapter and data types are modeled; the switch_https function remains byte-exact.
head=head.replace('(&self,_ctx:', '(&mut self,_ctx:').replace('{ unreachable!() }','{ let result=_work(); self.pending=Some(Box::new(move|tab,ctx|_then(tab,result,ctx))); }')
pos=head.index('\n}\n}',head.index('impl RepoTab {\n fn then_or'))
head=head[:pos]+ '\n'+function+head[pos:]
main=r'''
impl RepoTab {
 pub fn check(){let ctx=egui::Context;let mut tab=RepoTab{path:"/fixture/repo".into(),busy_op:None,credentials:Some("PROFILE_A_FIXTURE".into()),status:None,dialog:None,pending:None};
 tab.switch_https("https://fixture.invalid/old-account".into(),&ctx);
 // Connection-edit invalidation clears this UI before an old continuation arrives.
 tab.credentials=None;tab.dialog=None;
 let complete=tab.pending.take().expect("queued completion");complete(&mut tab,&ctx);
 println!("STALE_HTTPS_COMPLETION_REOPENED_DIALOG={}",tab.dialog.as_ref().map(|d|d.0.as_str()).unwrap_or("none"));
 assert!(tab.dialog.is_some());}
}
'''
# Add check inside the model module, then call its public wrapper.
head=head[:-2]+main+'\npub fn run(){RepoTab::check()}\n}\nfn main(){model::run()}\n'
path=out/'stale-switch-repro.rs';path.write_text(head)
(out/'stale-switch-function.sha256').write_text(hashlib.sha256(function.encode()).hexdigest()+'\n')
r=subprocess.run(['rustc','+1.95.0','--edition=2024',str(path),'-o',str(out/'stale-switch-repro')],text=True,capture_output=True);(out/'stale-switch-build.log').write_text(r.stdout+r.stderr);r.check_returncode()
r=subprocess.run([str(out/'stale-switch-repro')],text=True,capture_output=True);(out/'stale-switch.log').write_text(r.stdout+r.stderr);print(r.stdout+r.stderr);r.check_returncode()
