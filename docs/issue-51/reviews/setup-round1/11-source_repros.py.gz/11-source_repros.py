from pathlib import Path
import subprocess,hashlib,json
src=Path('/Users/jonas/.t3/worktrees/gitcraft/t3-5b9a0fe3/src');out=Path('/tmp/gitcraft-51-setup-review-r1-evidence')
def between(p,a,b):
 s=(src/p).read_text();return s[s.index(a):s.index(b,s.index(a))]
config=(src/'git/doctor/config.rs').read_text();(out/'config-source.rs').write_text(config)
functions={
'settings_rows':between('diagnostics.rs','pub fn settings_rows(', '/// The system:'),
'issue_url_and_encode':between('diagnostics.rs','pub(crate) fn issue_url(', '#[cfg(test)]\nmod issue_tests'),
'user_redactors':between('diagnostics.rs','pub fn redact_home(', '#[cfg(test)]\nmod tests'),
'classify':between('connection_doctor.rs','fn classify(', '#[cfg(test)]\nmod tests'),
'is_auth_error':between('git/command.rs','pub fn is_auth_error(', '/// What a call is run with on top of'),
'forget_https_memory':between('repo/operations.rs','    pub(crate) fn forget_https_memory(', '    pub(super) fn switch_https('),
'endpoint':between('connection_doctor.rs','pub(crate) fn endpoint(', 'fn config('),
}
head='''#[path="config-source.rs"] pub mod config;
use config::SETTINGS;
const PERSONAL: &[&str] = &["user.name", "user.email", "user.signingKey"];
mod git { use std::path::Path; pub fn run(_:Option<&Path>,_:&[&str])->Result<String,String>{Err("no commands allowed in pure harness".into())} IS_AUTH }
struct Report { lines: Vec<String>, success: bool }
mod connection_doctor { ENDPOINT }
#[derive(Default)]struct Remote { url:String }
#[derive(Default)]struct RepoTab {path:std::path::PathBuf,remotes:Vec<Remote>,credentials:Option<String>,parked:Vec<Box<RepoTab>>}
impl RepoTab { FORGET }
'''.replace('IS_AUTH',functions['is_auth_error']).replace('ENDPOINT',functions['endpoint']).replace('FORGET',functions['forget_https_memory'])
main=r'''
fn main(){
 let input="local\0file:.git/config\0core.editor\nenv API_TOKEN=FIXTURE_SECRET nvim\0";
 let rows=settings_rows(&config::parse_origins(input));
 let report=redact_users(&redact_home(&rows.join("\n"),"/home/fixture"));
 println!("DIAGNOSTIC_ROWS={report}");
 let url=issue_url(&report);println!("PREFILLED_URL={url}");
 assert!(url.contains("FIXTURE_SECRET"));
 let trace="== Info: SSL connection using TLSv1.3\n== Info: Server certificate:\n== Info: SSL certificate verify ok.\n<= Recv header: HTTP/2 401\nfatal: Authentication failed for 'https://fixture.invalid/repo'";
 let r=classify(false,trace,true,std::time::Duration::from_secs(1));
 println!("DOCTOR_AUTH_FAILURE success={} lines={:?}",r.success,r.lines);
 assert!(r.lines[2].ends_with("failed"));assert!(r.lines[3].ends_with("not confirmed"));
 let url="https://fixture.invalid/team/repo";
 let mut tab=RepoTab{path:"/fixture/main".into(),remotes:vec![Remote{url:url.into()}],credentials:Some("OLD_ACCOUNT_FIXTURE".into()),parked:vec![Box::new(RepoTab{path:"/fixture/linked".into(),remotes:vec![Remote{url:url.into()}],credentials:Some("OLD_ACCOUNT_FIXTURE".into()),..Default::default()})]};
 tab.forget_https_memory(std::path::Path::new("/fixture/main"),url);
 println!("HTTPS_SIGNOUT main_cleared={} parked_still_authenticated={}",tab.credentials.is_none(),tab.parked[0].credentials.is_some());
 assert!(tab.credentials.is_none());assert!(tab.parked[0].credentials.is_some());
}
'''
code=head+functions['settings_rows']+functions['issue_url_and_encode']+functions['user_redactors']+functions['classify']+main
path=out/'source-repros.rs';path.write_text(code)
(out/'source-function-hashes.json').write_text(json.dumps({k:hashlib.sha256(v.encode()).hexdigest() for k,v in functions.items()},indent=2))
cmd=['rustc','+1.95.0','--edition=2024',str(path),'-o',str(out/'source-repros')]
r=subprocess.run(cmd,capture_output=True,text=True);(out/'source-repros-build.log').write_text(r.stdout+r.stderr);r.check_returncode()
r=subprocess.run([str(out/'source-repros')],capture_output=True,text=True);(out/'source-repros.log').write_text(r.stdout+r.stderr);print(r.stdout+r.stderr);r.check_returncode()
