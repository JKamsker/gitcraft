import pathlib,tempfile,subprocess,os,socket,struct,threading,json,base64,select
out=pathlib.Path('/tmp/gitcraft-51-setup-review-r1-evidence')
root=pathlib.Path(tempfile.mkdtemp(prefix='gc51r1-',dir='/tmp'))
key=root/'work-key';key.write_text('owned synthetic placeholder; no private credential\n')
config=root/'ssh_config';sockpath=root/'master'
config.write_text(f'Host fixture\n HostName fixture.invalid\n User git\n ControlMaster auto\n ControlPath {sockpath}\n ProxyCommand /usr/bin/false\n BatchMode yes\n')
server=socket.socket(socket.AF_UNIX);server.bind(str(sockpath));server.listen(1);server.settimeout(10)
record=[]
def word(n):return struct.pack('>I',n)
def packet(conn,*values):
 data=b''.join(values);conn.sendall(word(len(data))+data)
def receive(conn):
 hdr=conn.recv(4)
 if len(hdr)!=4:raise RuntimeError('short header '+repr(hdr))
 n=struct.unpack('>I',hdr)[0];data=b''
 while len(data)<n:data+=conn.recv(n-len(data))
 record.append({'type':hex(struct.unpack('>I',data[:4])[0]),'payload_hex':data.hex()})
 return data
def own_master():
 try:
  conn,_=server.accept();conn.settimeout(8)
  with conn:
   packet(conn,word(1),word(4));receive(conn)
   msg=receive(conn);kind,rid=struct.unpack('>II',msg[:8])
   if kind==0x10000004:
    packet(conn,word(0x80000005),word(rid),word(os.getpid()));msg=receive(conn);kind,rid=struct.unpack('>II',msg[:8])
   if kind!=0x10000002:raise RuntimeError('not session '+hex(kind))
   # OpenSSH sends three owned stdio descriptors, each with a one-byte marker.
   passed=[]
   for _ in range(3):
    data,anc,flags,addr=conn.recvmsg(1,socket.CMSG_SPACE(4))
    for level,typ,value in anc:
     if level==socket.SOL_SOCKET and typ==socket.SCM_RIGHTS:
      for at in range(0,len(value),4):passed.append(struct.unpack('i',value[at:at+4])[0])
   packet(conn,word(0x80000006),word(rid),word(7))
   # Synthetic already-authenticated master owns the session; no SSH connection exists.
   for fd in passed:os.close(fd)
   packet(conn,word(0x80000004),word(7),word(0))
 except Exception as e:record.append({'error':str(e)})
thread=threading.Thread(target=own_master);thread.start()
env=os.environ.copy();env['SHELL']='/bin/false';env['PATH']='/usr/bin:/bin';env.pop('SSH_AUTH_SOCK',None)
bin=out/'gitcraft'
cmd=[str(bin),'--gitcraft-profile-ssh',base64.urlsafe_b64encode(str(key).encode()).decode().rstrip('='),'-F',str(config),'fixture','git-receive-pack \'fixture-repo\'']
r=subprocess.run(cmd,env=env,capture_output=True,text=True,timeout=12)
thread.join(10);server.close()
result={'root':str(root),'command':cmd,'exit':r.returncode,'stdout':r.stdout,'stderr':r.stderr,'mux_packets':record,'alive_thread':thread.is_alive()}
(out/'mux-repro.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
