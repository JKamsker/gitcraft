use std::collections::BTreeMap;
use serde::{Serialize,Deserialize};
const ROOT:&str="refs/gitcraft/intents/";const CACHE_ROOT:&str="refs/gitcraft/intent-remotes/";const CARD_LIMIT:usize=8192;const IMPORT_LIMIT:usize=4*1024*1024;
#[derive(Clone,Serialize,Deserialize)]
struct Card {
    id: String,
    author: String,
    email: String,
    path: String,
    symbol: String,
    message: String,
    created: u64,
    expires: u64,
}
#[derive(Clone)]
struct Seen {
    reference: String,
    card: Card,
    local: bool,
}
#[derive(Default)]
struct Reading {
    rows: Vec<Seen>,
    quarantine: Vec<String>,
}
fn source_roots(source: Option<&str>) -> Result<Vec<String>, String> {
    let mut roots = vec![ROOT.to_owned()];
    if let Some(source) = source {
        if source.is_empty()
            || source.len() > 64
            || !source
                .bytes()
                .all(|b| b.is_ascii_alphanumeric() || b == b'-')
        {
            return Err("Invalid intent cache identity".into());
        }
        roots.push(format!("{CACHE_ROOT}{source}/"));
    }
    Ok(roots)
}
fn validate(card: &Card, reference: &str, root: &str, at: u64) -> Result<(), String> {
    let hex = |s: &str| s.len() == 32 && s.bytes().all(|b| b.is_ascii_hexdigit());
    let relative = reference
        .strip_prefix(root)
        .ok_or("Intent is outside the selected source")?;
    let (author, id) = relative
        .split_once('/')
        .ok_or("Invalid intent ref identity")?;
    if !hex(author)
        || !hex(id)
        || id != card.id
        || author != format!("{:x}", md5::compute(&card.email))
    {
        return Err("Intent identity does not match its source ref".into());
    }
    let short = |text: &str, max: usize| text.len() <= max && !text.chars().any(|c| c.is_control());
    if card.path.is_empty()
        || !short(&card.path, 512)
        || card.path.starts_with('/')
        || card.path.contains(['\\', ':'])
        || card
            .path
            .trim_end_matches('/')
            .split('/')
            .any(|p| p.is_empty() || matches!(p, "." | "..") || p.eq_ignore_ascii_case(".git"))
        || card.author.trim().is_empty()
        || !short(&card.author, 128)
        || card.email.trim().is_empty()
        || !short(&card.email, 254)
        || !short(&card.symbol, 256)
        || card.message.trim().is_empty()
        || !short(&card.message, 1024)
    {
        return Err("Intent fields exceed the short-note bounds or contain an unsafe path/control character".into());
    }
    if card.created > at.saturating_add(300)
        || card.expires < card.created
        || card.expires > card.created.saturating_add(86400)
    {
        return Err("Intent expiry must be within 24 hours of its creation".into());
    }
    Ok(())
}
fn collect_selected(
    source: Option<&str>,
    at: u64,
    mut list: impl FnMut(&str) -> Result<Vec<(String, String)>, String>,
    mut blob: impl FnMut(&str, usize) -> Result<String, String>,
) -> Result<Reading, String> {
    let mut reading = Reading::default();
    let mut cards = BTreeMap::<(String, String), Seen>::new();
    let mut bytes: usize = 0;
    let mut rejected = 0;
    for root in source_roots(source)? {
        // List only this source. Foreign cache content is never parsed or deduplicated.
        let refs = list(&root)?;
        if refs.len() > 5000 {
            return Err("More than 5000 refs in the selected intent source; archive old notes before loading".into());
        }
        for (reference, object) in refs {
            if !reference.starts_with(&root) {
                continue;
            }
            // Reaching the exact budget is complete only if no relevant refs remain,
            // including in the next selected source. Refuse before reading another blob
            // so a partial collection cannot be installed or marked freshly synced.
            if bytes >= IMPORT_LIMIT {
                return Err("Selected intent metadata exceeds the 4MiB import budget; read refused because more notes remain".into());
            }
            let result: Result<Seen, String> = (|| {
                let text = blob(&object, CARD_LIMIT.min(IMPORT_LIMIT - bytes))?;
                bytes = bytes.saturating_add(text.len());
                if text.len() > CARD_LIMIT || bytes > IMPORT_LIMIT {
                    return Err("Intent exceeds the metadata import budget".into());
                }
                let card: Card =
                    serde_json::from_str(&text).map_err(|e| format!("Invalid intent JSON: {e}"))?;
                validate(&card, &reference, &root, at)?;
                Ok(Seen {
                    reference: reference.clone(),
                    card,
                    local: root == ROOT,
                })
            })();
            match result {
                Ok(seen) => {
                    cards.insert((root.clone(), seen.reference.clone()), seen);
                }
                Err(error) => {
                    rejected += 1;
                    if reading.quarantine.len() < 32 {
                        reading.quarantine.push(format!("{reference}: {error}"));
                    }
                }
            }
        }
    }
    if rejected > reading.quarantine.len() {
        reading.quarantine.push(format!(
            "{} additional invalid records omitted",
            rejected - reading.quarantine.len()
        ));
    }
    reading.rows = cards.into_values().collect();
    Ok(reading)
}
fn main(){
 let email="team@example.test";let author=format!("{:x}",md5::compute(email));let selected=format!("{CACHE_ROOT}selected/");let mut reads=0;
 let result=collect_selected(Some("selected"),150,|root|{if root==ROOT{Ok(vec![])}else{assert_eq!(root,selected);Ok((0..513).map(|n|(format!("{selected}{author}/{n:032x}"),n.to_string())).collect())}},|object,budget|{
  reads+=1;assert!(budget>=8192);let n=object.parse::<usize>().unwrap();let mut v=serde_json::json!({"id":format!("{n:032x}"),"author":"Teammate","email":email,"path":"src","symbol":"token","message":"changing lifetime","created":100,"expires":200,"padding":""});let initial=serde_json::to_string(&v).unwrap().len();v["padding"]=serde_json::Value::String("x".repeat(CARD_LIMIT-initial));let text=serde_json::to_string(&v).unwrap();assert_eq!(text.len(),CARD_LIMIT);Ok(text)
 });
 let error=result.err().unwrap();assert!(error.contains("4MiB") && error.contains("more notes remain"));assert_eq!(reads,512);println!("PASS: 513 valid selected cards refused explicitly after {reads} bounded reads: {error}");
}
