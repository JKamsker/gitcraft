# Review workflows: finite B3/B4 residual correction handoff

Candidate **3e43ced28232183108491acb76bca08a2166f15f**, parent **fe88e1dc52828c278515e2a7fa9cb6c6347ad1c4**. One coherent correction commit; author and committer Jonas Kamsker <11245306+JKamsker@users.noreply.github.com>. Pushed to `https://github.com/JKamsker/gitcraft`, branch `t3/implement-review-workflow-ideas`; `git ls-remote` independently returned the same full SHA. Working tree clean. Status: implemented and locally validated within permitted pure/recording/build scope; independent acceptance and runtime remain separate.

## Only two residuals changed

- **B3:** `sharing::Target::capture` now obtains its selected name's effective fetch/push URLs through the same bound private `CommandSource` used for transfer. `capture_destination` compares the frozen effective fetch endpoint with `observed.url` (the displayed fetch URL, including Git URL rewriting), refusing selected A/captured B even if B is internally stable. It retains the exact split push endpoint, literal route arguments, context checks and private source. The earlier live `remotes` identity check is removed because it cannot bind the later snapshot. No shared command-source/provider/profile/process changes.
- **B4:** `collect_selected` no longer silently breaks at the exact aggregate limit. Before reading another relevant record in the same or next source it returns an explicit 4MiB refusal. An exactly full collection with no remaining relevant records succeeds. Existing error completion clears sync freshness; no partial `Reading` is installed as a successful fresh sync. The cap, source isolation and quarantine behavior remain.

Changed files only: `src/repo/review_workflow/sharing.rs`, `src/repo/review_workflow/intents.rs`. No dependencies. No other R2 finding was reopened; four Core and nine Content/UI source closures remain as recorded in their reports, without claiming new execution of their gates.

## Exact permitted validation

Run at the byte-identical application files committed as 3e43ced28232183108491acb76bca08a2166f15f; source/object equality and the executable hash are recorded in `/tmp/gitcraft-workflows-core-r3-evidence/status.json`.

1. `TMPDIR=/private/tmp PATH=/tmp/gitcraft-integration-tools:$PATH SHELL=/tmp/gitcraft-integration-tools/validation-shell CARGO_BUILD_JOBS=2 cargo +1.95.0 test --locked --lib r3_pure_` — **2 passed**, 0 failed, 3207 application entries filtered out. These tests invoke no application/discovery constructors or real Git/process operations. Sharing records A→B refusal before push/context acceptance, preserves unchanged split literal routes, and propagates post-capture context refusal. Intent tests cover exactly512×8192-byte valid records, a513th record in the same source, a next-source record after local exhaustion, bounded reads and stale/error completion.
2. Four individually selected existing pure tests — **4 passed**: artifact cache CAS/source confinement; selected-source same-ID isolation; malformed/oversize/field quarantine; selection-generation completion ownership. Exact executable commands and outputs: `/tmp/gitcraft-workflows-core-r3-evidence/existing-pure.json`, `/tmp/gitcraft-workflows-core-r3-evidence/existing-pure.log`. No broad feature/full-suite filter executed.
3. Corrected **byte-extracted production** `Target::capture` plus `capture_destination` with the reviewer's recording-only source mocks — **PASS**, selected A refuses consistently frozen B. Corrected byte-extracted production `collect_selected` in the reviewer's513×8192-byte valid JSON probe — **PASS**, explicit refusal after512 reads. Original reviewer evidence remains untouched. Probe source and extraction hashes: `/tmp/gitcraft-workflows-core-r3-evidence/extractions.json`; output logs alongside. Compiled with `rustc +1.95.0 --edition=2024 -D warnings -A dead_code` (dead-code allowance applies to unused mock scaffolding), and B4 additionally uses `-L dependency=target/debug/deps --extern serde=target/debug/deps/libserde-3c3812a996168d5a.rlib --extern serde_json=target/debug/deps/libserde_json-51b929621ccde7c6.rlib --extern md5=target/debug/deps/libmd5-0dffc097f6f78e26.rlib`. Both executables exited0 with assertions enabled. No real Git/helper/container/transport calls occur in these probes.
4. `CARGO_BUILD_JOBS=2 cargo +1.95.0 check --locked` — **PASS**, six baseline macOS dead-code warnings.
5. `CARGO_BUILD_JOBS=2 cargo +1.95.0 clippy --locked --lib -- -D warnings -A dead_code` — **PASS**, explicitly qualified; not unqualified strict lint.
6. `cargo +1.95.0 fmt --all -- --check` and `git diff --check` — **PASS**.

Logs: `/tmp/gitcraft-51-workflows-r3-{pure,check,clippy,fmt}.log`. All log/source/probe/executable SHA256 values and remote receipt are in `/tmp/gitcraft-workflows-core-r3-evidence/status.json`.

## Finite remaining handoff

1. Parent coordinates integration of **this single commit** separately; no root/integration branch was merged here.
2. Parent confirmation targets **only these two residual deltas**; prior scoped R2 closures stand. No further implementation item is being deferred in this two-fix scope.
3. Existing held runtime/combined validation remains held. No actual Git/helper/Docker/HTTP/SSH/process fixtures/discovery constructors, cancellation/timeout/selector fixtures, native UI, full suite, CI, PR or subagents ran. Authorized repository metadata/source reads and commit/push preservation are distinct from application fixtures. These pure recordings establish source ordering and bounded collector behavior, not live routing or runtime containment.

Coding slot released with this handoff.
