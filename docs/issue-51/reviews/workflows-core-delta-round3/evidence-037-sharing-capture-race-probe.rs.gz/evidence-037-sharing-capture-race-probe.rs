use std::{path::Path, sync::{Arc,Mutex}};
static CONFIG: Mutex<&str> = Mutex::new("A");
mod git {
    use super::*;
    #[derive(Clone,PartialEq,Eq)] pub struct Remote {pub name:String,pub url:String}
    pub struct CommandSource {pub frozen:String}
    pub fn remotes(_: &Path)->Result<Vec<Remote>,String> {Ok(vec![Remote{name:"origin".into(),url:CONFIG.lock().unwrap().to_string()}])}
    impl CommandSource {
        pub fn capture(_: &Path)->Result<Arc<Self>,String> {
            // Recording boundary: configuration changes after the UI identity read,
            // before the production capture begins its own consistent snapshot.
            *CONFIG.lock().unwrap()="B";
            Ok(Arc::new(Self{frozen:CONFIG.lock().unwrap().to_string()}))
        }
        pub fn bind(&self,args:&[&str])->Vec<String> {let mut v=vec![self.frozen.clone()];v.extend(args.iter().map(|s|s.to_string()));v}
        pub fn check_context(&self)->Result<(),String> {if *CONFIG.lock().unwrap()==self.frozen {Ok(())}else{Err("changed".into())}}
    }
    pub fn run(_:Option<&Path>,args:&[&str])->Result<String,String>{Ok(format!("{}\n",args[0]))}
}
struct Target {name:String,fetch:String,push:String,source:Arc<git::CommandSource>}
impl Target {
    pub fn capture(repo: &Path, observed: &git::Remote) -> Result<Self, String> {
        let captured_url = |source: &Arc<git::CommandSource>, push| {
            let args = if push {
                vec![
                    "remote",
                    "get-url",
                    "--push",
                    "--all",
                    observed.name.as_str(),
                ]
            } else {
                vec!["remote", "get-url", "--all", observed.name.as_str()]
            };
            let args = source.bind(&args);
            let urls = git::run(
                Some(repo),
                &args.iter().map(String::as_str).collect::<Vec<_>>(),
            )?;
            let rows: Vec<_> = urls.lines().collect();
            match rows.as_slice() {
                [url] if !url.is_empty() => Ok((*url).to_owned()),
                _ => Err(
                    "Review-artifact sharing requires exactly one fetch and one push URL"
                        .to_owned(),
                ),
            }
        };
        let (source, fetch, push) = capture_destination(
            observed,
            || git::CommandSource::capture(repo),
            captured_url,
            |source| source.check_context(),
        )?;
        Ok(Self {
            source,
            name: observed.name.clone(),
            fetch,
            push,
        })
    }
}
fn capture_destination<S>(
    observed: &git::Remote,
    capture: impl FnOnce() -> Result<S, String>,
    mut endpoint: impl FnMut(&S, bool) -> Result<String, String>,
    check: impl FnOnce(&S) -> Result<(), String>,
) -> Result<(S, String, String), String> {
    let source = capture()?;
    let fetch = endpoint(&source, false)?;
    // Remote.url is the displayed fetch URL (including Git's URL rewrites).
    if fetch != observed.url {
        return Err("Sharing remote changed; refresh repository remotes and try again".into());
    }
    let push = endpoint(&source, true)?;
    check(&source)?;
    Ok((source, fetch, push))
}
fn main() {
 let observed=git::Remote{name:"origin".into(),url:"A".into()};
 let error=Target::capture(Path::new("/recording-only"), &observed).err().expect("must refuse captured B for selected A");
 assert!(error.contains("changed"));
 println!("Observed A; exact production Target::capture refused consistently frozen B: {error}");
}
