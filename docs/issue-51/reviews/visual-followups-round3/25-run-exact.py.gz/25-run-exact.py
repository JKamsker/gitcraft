import pathlib,json,subprocess,shutil,os,hashlib,time
root=pathlib.Path('/tmp/gitcraft-51-visual-followups-r3-evidence')
rows=[json.loads(l) for l in (root/'exact-build.jsonl').read_text().splitlines()]
artifacts=[r for r in rows if r.get('reason')=='compiler-artifact' and r.get('executable') and r.get('target',{}).get('name')=='gitcraft' and r.get('profile',{}).get('test')]
assert len(artifacts)==1, artifacts
exe=root/'exact-tests';shutil.copy2(artifacts[0]['executable'],exe)
env=os.environ.copy(); env.update(TMPDIR='/private/tmp',SHELL='/tmp/gitcraft-integration-tools/validation-shell',PATH='/tmp/gitcraft-integration-tools:'+env['PATH'],CARGO_BUILD_JOBS='2')
results=[]
for i,f in enumerate(['repo::authorship_view::tests::the_lens_through_the_tab','repo::graph_view::minimap::tests::','repo::celebration::tests::','repo::postcards::','git::postcards::tests::','graph::tests::']):
 argv=[str(exe),f,'--nocapture','--test-threads=1']; start=time.monotonic()
 out=subprocess.run(argv,cwd=root/'source',env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 name=f'exact-group-{i}.log'; (root/name).write_bytes(out.stdout)
 result={'argv':argv,'returncode':out.returncode,'duration_seconds':time.monotonic()-start,'log':name,'sha256':hashlib.sha256(out.stdout).hexdigest()};results.append(result)
 print(f,out.returncode,out.stdout.decode(errors='replace').split('test result:')[-1].strip(),flush=True)
 if out.returncode: break
(root/'exact-execution.json').write_text(json.dumps({'executable':str(exe),'executable_sha256':hashlib.sha256(exe.read_bytes()).hexdigest(),'candidate':'4a9a22c806126a813d9d5633a699dd7cafa135da','environment':{k:env[k] for k in ['TMPDIR','SHELL','CARGO_BUILD_JOBS']},'PATH_prefix':'/tmp/gitcraft-integration-tools','groups':results},indent=2))
