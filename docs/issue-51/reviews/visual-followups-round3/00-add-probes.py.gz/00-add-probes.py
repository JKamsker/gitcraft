from pathlib import Path
root=Path('/tmp/gitcraft-51-visual-followups-r3-evidence/probe-source')
probes={
'src/repo/graph_view/minimap.rs':r'''
#[cfg(test)]
mod independent_review_r3 {
    use super::*;
    use std::{sync::{Arc,mpsc},time::{Duration,Instant}};
    fn attribution() -> crate::authorship::Attribution {
        crate::authorship::Attribution { who:crate::authorship::Who::Agent, agents:vec![], source:crate::authorship::Source::Author, lines:Default::default() }
    }
    #[test]
    fn actual_agent_actions_retire_late_minimap_models_on_apply_refresh_and_clear() -> Result<(),String> {
        let ctx=egui::Context::default();
        let mut tab=RepoTab::new_deferred("/nonexistent/review-r3-minimap".into(),&ctx);
        tab.commits=["a","b"].into_iter().map(|h| Arc::new(crate::git::Commit{hash:h.into(),..Default::default()})).collect();
        tab.graph=crate::graph::layout(&tab.commits);
        tab.search.matches=std::collections::HashSet::from(["b".into()]).into();
        let old=build(&tab.graph,"",&tab.search.matches,&||true)?;
        tab.history_minimap.bins=old.bins;tab.history_minimap.rows=old.rows;tab.history_minimap.dirty=false;
        assert!(!tab.history_minimap.bins[0].hit && tab.history_minimap.bins[1].hit);
        for (stage,expected) in [(0,vec![true,false]),(1,vec![false,true]),(2,vec![false,false])] {
            let (entered,entry)=mpsc::channel();let (release,released)=mpsc::channel();
            tab.history_minimap.reader.queue(move |_| {
                entered.send(()).map_err(|e|e.to_string())?;
                released.recv_timeout(Duration::from_secs(5)).map_err(|e|e.to_string())?;
                // Deliberately complete an obsolete job despite its retired token.
                Ok(Model{rows:777,bins:vec![Bin{hit:true,..Default::default()}]})
            });
            tab.history_minimap.reader.poll(&tab.tx,&ctx);
            entry.recv_timeout(Duration::from_secs(5)).map_err(|e|e.to_string())?;
            match stage {
                0=>{tab.authorship.map=std::collections::HashMap::from([("a".into(),attribution())]).into();tab.apply(crate::repo::Action::AgentFilter(true),&ctx);},
                1=>{tab.authorship.map=std::collections::HashMap::from([("b".into(),attribution())]).into();tab.filter_agent_commits(false,&ctx);},
                _=>tab.apply(crate::repo::Action::AgentFilter(false),&ctx),
            }
            assert!(tab.history_minimap.dirty);
            release.send(()).map_err(|e|e.to_string())?;
            let start=Instant::now();
            loop {
                tab.prepare_minimap(&ctx);
                assert_ne!(tab.history_minimap.rows,777,"stale completion accepted at stage {stage}");
                if !tab.history_minimap.reader.busy() {break;}
                if start.elapsed()>Duration::from_secs(5){return Err("minimap probe timed out".into());}
                std::thread::yield_now();
            }
            assert_eq!(tab.history_minimap.rows,2);
            assert_eq!(tab.history_minimap.bins.iter().map(|b|b.hit).collect::<Vec<_>>(),expected);
        }
        Ok(())
    }
}
''',
'src/repo/celebration.rs':r'''
#[cfg(test)]
mod independent_review_r3 {
    use super::*;
    #[test]
    fn delayed_merge_then_noop_pull_emits_one_cue_and_invalid_first_commit_is_rejected() {
        let ctx=egui::Context::default();
        crate::settings::Settings{celebration_sound:true,..Default::default()}.set(&ctx);
        crate::audio::take_recorded();
        let mut tab=RepoTab::new_deferred("/nonexistent/review-r3-celebration".into(),&ctx);
        tab.refs.head="a".into();
        tab.celebration_begin("Merge",&[vec!["merge".into(),"topic".into()]],&ctx);
        tab.celebration_observed_heads("a".into(),"m".into());tab.celebration_done(true);
        // UI remains at a until both successful operation completions are queued.
        tab.celebration_begin("Pull",&crate::repo::ops(&[crate::repo::pull::PullMode::Merge.args()]),&ctx);
        tab.celebration_observed_heads("m".into(),"m".into());tab.celebration_done(true);
        tab.history=vec![std::sync::Arc::new(crate::git::Commit{hash:"m".into(),parents:vec!["a".into(),"topic".into()],..Default::default()})];
        tab.celebration_loaded(tab.reads+1,&ctx);
        assert_eq!(crate::audio::take_recorded(),[crate::audio::Cue::Celebration]);
        tab.celebration_loaded(tab.reads+2,&ctx);assert!(crate::audio::take_recorded().is_empty());
        tab.refs=Default::default();tab.history.clear();
        tab.celebration_begin("Commit",&[vec!["commit".into()]],&ctx);
        assert!(matches!(tab.celebration.candidate,Some(Event::FirstCommit)));
        // UI looked empty, but worker saw an existing root before an amend/no-op.
        tab.celebration_observed_heads("root".into(),"root".into());tab.celebration_done(true);
        tab.history=vec![std::sync::Arc::new(crate::git::Commit{hash:"root".into(),..Default::default()})];
        tab.celebration_loaded(tab.reads+1,&ctx);
        assert!(crate::audio::take_recorded().is_empty());assert!(tab.celebration.pending.is_empty());
        tab.refs.head="stale".into();
        tab.celebration_begin("Merge",&[vec!["merge".into(),"topic".into()]],&ctx);
        tab.celebration_observed_heads(String::new(),"root".into());tab.celebration_done(true);
        tab.celebration_loaded(tab.reads+1,&ctx);assert!(crate::audio::take_recorded().is_empty());
    }
}
''',
'src/repo/postcards/render.rs':r'''
#[cfg(test)]
mod independent_review_r3 {
    use super::*;
    #[test]
    fn exact_edge_boundary_and_full_render_refusal_precede_composition() -> Result<(),String> {
        let merge=|n:usize|crate::git::Commit{hash:"merge".into(),parents:(0..n).map(|i|format!("{i:040x}")).collect(),..Default::default()};
        let graph=bounded_graph(&[merge(1024)],MAX_PARENT_EDGES,&||true)?;
        assert_eq!(graph.width,1024);assert_eq!(graph.rows[0].outgoing.len(),1024);
        let mut rows:Vec<_>=(0..200).map(|i|crate::git::Commit{hash:format!("r{i}"),parents:(0..5).map(|p|format!("p{p}")).collect(),..Default::default()}).collect();
        assert!(bounded_graph(&rows,1024,&||true).is_ok());
        rows[199].parents.extend((5..30).map(|p|format!("p{p}")));
        assert!(bounded_graph(&rows,1024,&||true).err().unwrap().contains("parent edges"));
        assert!(bounded_graph(&vec![crate::git::Commit::default();201],1024,&||true).is_err());
        let snapshot=Snapshot{name:"Review".into(),date:"2026-11-08".into(),range:"excluded..merge".into(),commits:vec![merge(1025)],messages:vec![],contributors:vec![],anonymized:true};
        let calls=std::cell::Cell::new(0);
        let error=render(&snapshot,&||{calls.set(calls.get()+1);true}).err().unwrap();
        assert!(error.contains("1024 parent edges"));assert_eq!(calls.get(),2);
        let calls=std::cell::Cell::new(0);
        let snapshot=Snapshot{commits:vec![merge(1024)],..snapshot};
        let error=render(&snapshot,&||{calls.set(calls.get()+1);calls.get()<3}).err().unwrap();
        assert!(error.contains("cancelled"));assert_eq!(calls.get(),3);
        Ok(())
    }
}
'''
}
for rel,code in probes.items():
 path=root/rel; path.write_text(path.read_text()+code)
 print(rel)
