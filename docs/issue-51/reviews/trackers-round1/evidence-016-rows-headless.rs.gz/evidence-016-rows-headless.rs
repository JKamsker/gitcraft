use egui::{Ui,RichText};
#[derive(Clone)]struct Issue{number:u64,title:String,labels:Vec<String>,url:String,key:String}
impl Issue{fn key(&self)->String{self.key.clone()}}
mod theme{use egui::*;pub struct Tokens{pub row_selected:Color32,pub radius_sm:f32,pub accent:Color32,pub text:Color32,pub text_dim:Color32}impl Tokens{pub fn get(_: &Context)->Self{Self{row_selected:Color32::GRAY,radius_sm:3.,accent:Color32::WHITE,text:Color32::WHITE,text_dim:Color32::GRAY}}}pub fn mono(n:f32)->FontId{FontId::monospace(n)}}
use theme::Tokens;
mod widgets{pub fn chip(ui:&mut egui::Ui,s:&str,_:egui::Color32){ui.label(s);}}
fn issue_row(ui: &mut Ui, issue: &Issue, chosen: bool) -> bool {
    let t = Tokens::get(ui.ctx());
    let fill = if chosen {
        t.row_selected
    } else {
        egui::Color32::TRANSPARENT
    };
    let inner = egui::Frame::new()
        .fill(fill)
        .corner_radius(t.radius_sm)
        .inner_margin(egui::Margin::symmetric(8, 5))
        .show(ui, |ui| {
            ui.set_width(ui.available_width());
            ui.horizontal_wrapped(|ui| {
                ui.label(
                    RichText::new(issue.key())
                        .font(theme::mono(12.0))
                        .color(t.accent),
                );
                ui.label(RichText::new(&issue.title).color(t.text));
                for label in &issue.labels {
                    widgets::chip(ui, label, t.text_dim);
                }
            });
        });
    if chosen {
        inner.response.scroll_to_me(None);
    }
    let response = ui.interact(
        inner.response.rect,
        ui.id().with(("issue-row", issue.number)),
        egui::Sense::click(),
    );
    response
        .on_hover_cursor(egui::CursorIcon::PointingHand)
        .on_hover_text(&issue.url)
        .clicked()
}

fn frame(ctx:&egui::Context,rows:&[Issue],events:Vec<egui::Event>)->(Vec<egui::Rect>,Vec<bool>){let mut rects=vec![];let mut clicks=vec![];let mut out=ctx.run_ui(egui::RawInput{screen_rect:Some(egui::Rect::from_min_size(egui::Pos2::ZERO,egui::vec2(600.,400.))),events,..Default::default()},|ui|{egui::CentralPanel::default().show(ui,|ui|{for i in rows{clicks.push(issue_row(ui,i,false));let id=ui.id().with(("issue-row",i.number));rects.push(ctx.read_response(id).unwrap().rect);}});});out.textures_delta.clear();drop(out);(rects,clicks)}
fn main(){let rows=["ENG-9","OPS-9"].map(|k|Issue{number:0,title:"Work".into(),labels:vec![],url:format!("https://linear.app/issue/{k}"),key:k.into()});let ctx=egui::Context::default();frame(&ctx,&rows,vec![]);let(rects,_)=frame(&ctx,&rows,vec![]);println!("rects={rects:?}");for target in 0..2{let p=rects[target].center();frame(&ctx,&rows,vec![egui::Event::PointerMoved(p),egui::Event::PointerButton{pos:p,button:egui::PointerButton::Primary,pressed:true,modifiers:Default::default()}]);let(_,clicks)=frame(&ctx,&rows,vec![egui::Event::PointerButton{pos:p,button:egui::PointerButton::Primary,pressed:false,modifiers:Default::default()}]);println!("pointer click target={target} -> row clicks={clicks:?}");} }
