#![allow(dead_code)]
mod git {
use std::path::Path;
pub struct ChangedFile{pub path:String,pub old_path:Option<String>,pub status:char}
pub fn run(repo:Option<&Path>,args:&[&str])->Result<String,String>{let mut c=std::process::Command::new("git");if let Some(r)=repo{c.arg("-C").arg(r);}let p=c.args(args).output().map_err(|e|e.to_string())?;if !p.status.success(){return Err(String::from_utf8_lossy(&p.stderr).into_owned());}Ok(String::from_utf8_lossy(&p.stdout).into_owned())}
pub fn run_ok_codes(repo:Option<&Path>,args:&[&str],codes:&[i32])->Result<String,String>{let mut c=std::process::Command::new("git");if let Some(r)=repo{c.arg("-C").arg(r);}let p=c.args(args).output().map_err(|e|e.to_string())?;if !codes.contains(&p.status.code().unwrap_or(-1)){return Err(String::from_utf8_lossy(&p.stderr).into_owned());}Ok(String::from_utf8_lossy(&p.stdout).into_owned())}
pub fn run_input(repo:Option<&Path>,args:&[&str],input:&str)->Result<String,String>{use std::io::Write;let mut c=std::process::Command::new("git");if let Some(r)=repo{c.arg("-C").arg(r);}let mut child=c.args(args).stdin(std::process::Stdio::piped()).stdout(std::process::Stdio::piped()).spawn().map_err(|e|e.to_string())?;child.stdin.take().unwrap().write_all(input.as_bytes()).map_err(|e|e.to_string())?;let p=child.wait_with_output().map_err(|e|e.to_string())?;Ok(String::from_utf8_lossy(&p.stdout).into_owned())}
pub fn diff_files(repo:&Path,a:&str,b:Option<&str>)->Result<Vec<ChangedFile>,String>{let p=run(Some(repo),&["diff","--name-status","-z","-M",a,b.unwrap(),"--"])?;let mut f=p.split('\0');let mut result=vec![];while let Some(s)=f.next(){if s.is_empty(){break;}let p=f.next().unwrap();let old=if s.starts_with(['R','C']){Some(p.to_owned())}else{None};let path=if old.is_some(){f.next().unwrap()}else{p};result.push(ChangedFile{path:path.into(),old_path:old,status:s.chars().next().unwrap()});}Ok(result)}
}
mod pull_request {
#[derive(Clone,Copy,Debug,PartialEq,Eq)]pub enum DiffSide{Left,Right}
pub struct Comment{pub pending:bool}pub struct Thread{pub comments:Vec<Comment>,pub outdated:bool,pub line:Option<u64>,pub start_line:Option<u64>,pub path:String,pub side:DiffSide,pub id:String}pub struct Extras{pub threads:Vec<Thread>}pub struct PrDetails{pub url:String,pub number:u64,pub head_oid:String,pub extras:Extras}
}
mod repo{
pub mod pr_review{#[derive(Debug)]pub struct LineTarget{pub path:String,pub line:u64,pub side:crate::pull_request::DiffSide}}
pub mod operations{pub fn is_expectation(_: &[String])->bool{false}}
mod review_workflow{
mod store{use serde::{Serialize,de::DeserializeOwned};static S:std::sync::Mutex<Option<String>>=std::sync::Mutex::new(None);pub fn load<T:DeserializeOwned>(_:&std::path::Path,_:&str,_:&str)->Result<Option<T>,String>{S.lock().unwrap().as_ref().map(|s|serde_json::from_str(s).map_err(|e|e.to_string())).transpose()}pub fn save<T:Serialize>(_:&std::path::Path,_:&str,_:&str,v:&T)->Result<(),String>{*S.lock().unwrap()=Some(serde_json::to_string(v).map_err(|e|e.to_string())?);Ok(())}}
#[path="/Users/jonas/.t3/worktrees/gitcraft/t3-940761ce/src/repo/review_workflow/anchors.rs"]mod anchors;
#[path="/Users/jonas/.t3/worktrees/gitcraft/t3-940761ce/src/repo/review_workflow/echo_push.rs"]mod echo_push;
pub fn run(args:&[String]){use crate::pull_request::*;let repo=std::path::Path::new(&args[1]);let d=|head:&str,outdated|PrDetails{url:"https://forge/pr/1".into(),number:1,head_oid:head.into(),extras:Extras{threads:vec![Thread{comments:vec![],outdated,line:Some(3),start_line:Some(2),path:"comment.rs".into(),side:DiffSide::Right,id:"thread".into()}]}};for (head,outdated)in[(&args[2],false),(&args[3],true),(&args[4],true)]{let moved=anchors::relocate_threads(repo,&d(head,outdated),&args[2]).unwrap();println!("head={head} relocated={moved:?}");}
let steps=vec![vec!["push".into(),"origin".into(),"HEAD:refs/heads/main".into()]];let pairs=echo_push::sources(repo,&steps).unwrap();println!("split fetch/push source pairs={pairs:?}");for(base,head)in pairs{let p=crate::git::run(Some(repo),&["diff","--no-ext-diff","--no-textconv",&base,&head,"--"]).unwrap();println!("echo computed diff bytes={}",p.len());}let changed_repo=vec![vec!["--git-dir=/tmp/other.git".into(),"push".into(),"origin".into(),"HEAD:refs/heads/main".into()]];println!("other gitdir accepted={:?}",echo_push::sources(repo,&changed_repo));}
}
pub fn run(args:&[String]){review_workflow::run(args)}
}
fn main(){repo::run(&std::env::args().collect::<Vec<_>>())}
