import os,subprocess,json,shlex
from pathlib import Path
root=Path('/private/tmp/gitcraft-workflows-review-core-r1')
bindir=root/'docker-recording-bin';bindir.mkdir(exist_ok=True)
program=bindir/'docker'
program.write_text('''#!/usr/bin/python3
import sys,json
from pathlib import Path
root=Path('/private/tmp/gitcraft-workflows-review-core-r1')
a=sys.argv[1:]
with (root/'cleanup-recording.jsonl').open('a') as f:f.write(json.dumps({'argv':a})+'\\n')
if a[0]=='inspect':
 print('0123456789abcdef0123456789abcdef')
 # Model replacement AFTER inspection of the owned container, before rm by name.
 (root/'recorded-container-state').write_text('foreign-replacement-id')
elif a[:2]==['rm','--force']:
 with (root/'cleanup-recording.jsonl').open('a') as f:f.write(json.dumps({'resolved_name_target':(root/'recorded-container-state').read_text(),'requested':a[2]})+'\\n')
else:sys.exit(99)
''')
program.chmod(0o700)
q=shlex.quote
name='gitcraft-reproducer-recording';token='0123456789abcdef0123456789abcdef'
# Exact production cleanup format from reproducer.rs:142-148.
script='owner=$(docker inspect --format '+q('{{ index .Config.Labels "gitcraft.owner" }}')+' '+q(name)+' 2>/dev/null) || exit 0; [ "$owner" = '+q(token)+' ] || exit 73; docker rm --force '+q(name)
env=dict(os.environ,PATH=str(bindir)+':/usr/bin:/bin')
r=subprocess.run(['/bin/sh','-c',script],env=env)
(root/'cleanup-probe-result.json').write_text(json.dumps({'mode':'recording-only fake docker; no Docker execution or signals','production_script':script,'returncode':r.returncode}))
