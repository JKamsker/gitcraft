from pathlib import Path
import tempfile,subprocess,json
root=Path('/private/tmp/gitcraft-workflows-review-core-r1')
with tempfile.TemporaryDirectory(prefix='gitcraft-backport-evidence-probe-',dir='/private/tmp') as d:
 p=Path(d)
 def git(*a,input=None,check=True):
  r=subprocess.run(['/opt/homebrew/bin/git','-C',d,*a],input=input,stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=check)
  return r.stdout.decode().strip(),r.returncode
 git('init','-q','-b','main');git('config','user.name','Owned fixture');git('config','user.email','fixture@example.invalid');git('config','commit.gpgSign','false')
 (p/'base.txt').write_text('base\n');git('add','.');git('commit','-qm','base');base,_=git('rev-parse','HEAD')
 (p/'fix.txt').write_text('fix\n');git('add','.');git('commit','-qm','fix');fix,_=git('rev-parse','HEAD')
 git('checkout','-qb','release',base);(p/'release.txt').write_text('release\n');git('add','.');git('commit','-qm','release');release,_=git('rev-parse','HEAD')
 git('-c','core.hooksPath=/dev/null','cherry-pick','--no-commit',fix);tree,_=git('write-tree')
 # Exact storage shape: input commit refs; JSON blob ref contains applied tree only as text.
 for role,rev in [('fix',fix),('target',release)]:git('update-ref','refs/gitcraft/backport-inputs/probe/0/'+role,rev)
 evidence=json.dumps([{'original':fix,'tip':release,'applied':tree,'test':{'tree':tree,'code':0}}]).encode()
 blob,_=git('hash-object','-w','--stdin',input=evidence);git('update-ref','refs/gitcraft/workflow/probe/evidence',blob)
 git('reset','--hard','-q',release);git('reflog','expire','--expire=now','--all');git('gc','--prune=now')
 _,rc=git('cat-file','-e',tree+'^{tree}',check=False)
 (root/'backport-evidence-reachability.json').write_text(json.dumps({'probe':'owned Git fixture reproducing production evidence reachability shape; not a direct contracts::run invocation','fix':fix,'target':release,'applied_tree':tree,'evidence_blob':blob,'applied_tree_cat_file_after_prune_exit':rc,'evidence_blob_cat_file_after_prune_exit':git('cat-file','-e',blob,check=False)[1]}))
