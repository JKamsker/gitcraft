use std::path::Path;
#[derive(Debug)] enum Patch { Same(String), Adapted(String), Reverted(String), NotChecked }
mod git {use std::path::Path;pub fn is_ancestor(repo:&Path,a:&str,b:&str)->bool {std::process::Command::new("git").arg("-C").arg(repo).args(["merge-base","--is-ancestor",a,b]).status().is_ok_and(|s|s.success())}}
fn status(
    ids: &[(String, String)],
    fix: &str,
    reverse: &str,
    adaptation: Option<&str>,
    repo: &Path,
    tip: &str,
) -> Patch {
    let found = ids.iter().position(|(id, _)| id == fix);
    let reverted = ids.iter().position(|(id, _)| id == reverse);
    if let Some(revert) = reverted
        && found.is_none_or(|fix| revert < fix)
    {
        return Patch::Reverted(ids[revert].1.clone());
    }
    if let Some(found) = found {
        return Patch::Same(ids[found].1.clone());
    }
    if let Some(adapted) = adaptation
        && git::is_ancestor(repo, adapted, tip)
    {
        return Patch::Adapted(adapted.into());
    }
    Patch::NotChecked
}
fn main(){let ids=vec![("fe035e8bb8487d58bfc89f8bbddaa5ba36b07ef8".to_owned(),"26406b0641ba07a6959794eaeb1748ac995f96e9".to_owned()),("eea2939ece2f8b66c79c80f98930ee5cd2ec11d4".to_owned(),"f2bf1b4c3ecf391721615267289cdc6985d7d6cc".to_owned()),("56f6caeba5f39c05c95194a36573b9b55f68a52e".to_owned(),"a088c2c36673280c4695c30be257dd10db31280b".to_owned())];println!("{:?}",status(&ids,"c88227137153b9080dc70b88aecfa1a848ad4b31","66d33377945011e4654403f121c9c3509630c679",Some("f2bf1b4c3ecf391721615267289cdc6985d7d6cc"),Path::new("/var/folders/0z/snd05v_n21jd6pkhvg2h0vlc0000gp/T/gitcraft-workflow-ui-repro-_6jua9de"),"26406b0641ba07a6959794eaeb1748ac995f96e9"));}
