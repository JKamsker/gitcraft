from pathlib import Path
import tempfile,subprocess,json
root=Path('/private/tmp/gitcraft-workflows-review-core-r1')
with tempfile.TemporaryDirectory(prefix='gitcraft-sharing-route-probe-',dir='/private/tmp') as d:
 p=Path(d); client=p/'client';a=p/'selected.git';b=p/'replacement.git';client.mkdir()
 def git(repo,*args,check=True):
  r=subprocess.run(['/opt/homebrew/bin/git','-C',str(repo),*args],stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=check)
  return r.stdout.decode().strip(),r.returncode
 git(a.parent,'init','--bare','-q',str(a));git(b.parent,'init','--bare','-q',str(b));git(client,'init','-q','-b','main');git(client,'config','user.name','Owned fixture');git(client,'config','user.email','fixture@example.invalid');git(client,'config','commit.gpgSign','false')
 (client/'x').write_text('fixture\n');git(client,'add','.');git(client,'commit','-qm','fixture');tip,_=git(client,'rev-parse','HEAD')
 ref='refs/gitcraft/intents/owned/one';git(client,'update-ref',ref,tip);git(client,'remote','add','team',str(a))
 captured_fetch,_=git(client,'remote','get-url','--all','team');captured_push,_=git(client,'remote','get-url','--push','--all','team')
 preguard=(captured_fetch==str(a) and captured_push==str(a))
 # External configuration edit in the actual window between Target::guard and Git push.
 git(client,'remote','set-url','team',str(b))
 _,push_code=git(client,'push','team','refs/gitcraft/intents/owned/*:refs/gitcraft/intents/owned/*')
 after_fetch,_=git(client,'remote','get-url','--all','team');after_push,_=git(client,'remote','get-url','--push','--all','team')
 (root/'route-window.json').write_text(json.dumps({'probe':'local bare repos; exact production mutable-name argv and pre/post guard algorithm, not direct intent UI invocation','preguard_passed':preguard,'push_exit':push_code,'selected_destination_ref_exists':git(a,'rev-parse','--verify',ref,check=False)[1]==0,'replacement_destination_ref_exists':git(b,'rev-parse','--verify',ref,check=False)[1]==0,'postguard_would_error':after_fetch!=captured_fetch or after_push!=captured_push,'production_error':'Sharing destination changed during the operation; nothing was sent to the replacement destination'}))
