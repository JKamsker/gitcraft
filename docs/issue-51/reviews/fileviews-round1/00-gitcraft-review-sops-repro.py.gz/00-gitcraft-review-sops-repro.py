from pathlib import Path
import subprocess,tempfile,json
r=Path(tempfile.mkdtemp(prefix='gitcraft-review-sops-repro-'))
def git(*args):return subprocess.run(['git','-C',str(r),*args],capture_output=True,text=True)
for args in [('init','-q'),('config','user.name','Review'),('config','user.email','review@test.invalid'),('config','commit.gpgSign','false')]:
 p=git(*args);assert p.returncode==0,p.stderr
tool=r/'conversion-tool';tool.write_text('#!/bin/sh\nprintf called\\n >> "'+str(r/'marker')+'"\nprintf "fixture-private-conversion\\n"\n');tool.chmod(0o700)
(r/'.gitattributes').write_text('secret.json diff=review-sops\n');git('config','diff.review-sops.textconv',str(tool));git('add','.gitattributes');git('commit','-qm','attrs')
(r/'secret.json').write_text(json.dumps({'secret':'ENC[fake]','sops':{'version':'3.10.0','mac':'ENC[mac]'}}))
for name,extra in [('candidate untracked argv',[]),('with no-textconv',['--no-textconv'])]:
 (r/'marker').unlink(missing_ok=True);o=git('diff',*extra,'--no-color','--no-ext-diff','--src-prefix=a/','--dst-prefix=b/','--no-index','--','/dev/null','secret.json');print(name,'return',o.returncode,'textconv_ran',(r/'marker').exists(),'private_in_patch','fixture-private-conversion' in o.stdout)
git('add','secret.json');git('commit','-qm','secret');(r/'marker').unlink(missing_ok=True)
o=git('log','--no-show-signature','--encoding=UTF-8','--format=','-n','1','--no-color','--no-ext-diff','--src-prefix=a/','--dst-prefix=b/','-L1,1:secret.json','--end-of-options','HEAD');print('candidate line_diff argv','return',o.returncode,'textconv_ran',(r/'marker').exists(),'private_in_patch','fixture-private-conversion' in o.stdout)
print('fixture',r)
