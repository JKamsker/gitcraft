#![allow(dead_code)]
mod git {
#[derive(Clone,Copy)]pub enum Area{Staged,Unstaged,Untracked,Conflicted}
pub struct StatusFile{pub path:String,pub old_path:Option<String>,pub code:char,pub area:Area}
pub struct ChangedFile{pub path:String,pub old_path:Option<String>,pub status:char}
pub fn parse_name_status(_: &str)->Vec<ChangedFile>{unimplemented!()}
pub mod file_comparison{
pub struct Version{pub bytes:Vec<u8>,pub warning:Option<String>}
pub fn raw_output(_: &std::path::Path,_:&[&str],_:&dyn Fn()->bool)->Result<Vec<u8>,String>{unimplemented!()}
pub fn raw_working(_: &std::path::Path,_:&str,_:&dyn Fn()->bool)->Result<Version,String>{Ok(Version{bytes:vec![],warning:Some("Not a safely readable regular file/link within 2 MiB; no staging actions are available".into())})}
}}
mod repo{pub enum DiffKey{Remerge{},Commit{hash:String,path:String},Range{from:String,to:Option<String>,path:String},Work(crate::git::StatusFile)}}
mod encrypted{
#[path="/Users/jonas/.t3/worktrees/gitcraft/t3-e06bdc42/src/repo/diff/encrypted/reader.rs"]mod reader;
pub fn run(){let key=crate::repo::DiffKey::Work(crate::git::StatusFile{path:"secret.json".into(),old_path:None,code:'?',area:crate::git::Area::Untracked});let result=reader::read_sides(std::path::Path::new("/review-fixture"),&key);println!("exact read_sides with unsupported/oversize Version: {result:?}");}
}
fn main(){encrypted::run()}
