
#![allow(dead_code)]
mod egui {
 #[derive(Default)] pub struct Ui { pub buttons:Vec<String> }
 pub trait Widget { fn button(&self)->Option<&str>{None} }
 pub struct Response;impl Response{pub fn clicked(&self)->bool{false}}
 impl Ui {
  pub fn collapsing(&mut self,_:String,f:impl FnOnce(&mut Ui)){f(self)}
  pub fn label(&mut self,_:RichText){}
  pub fn add(&mut self,_:Label){}
  pub fn add_enabled(&mut self,_:bool,w:impl Widget)->Response{if let Some(s)=w.button(){self.buttons.push(s.into())};Response}
 }
 pub struct RichText;impl RichText{pub fn new(_:impl AsRef<str>)->Self{Self}pub fn strong(self)->Self{self}}
 pub struct Label;impl Label{pub fn new(_:impl AsRef<str>)->Self{Self}pub fn selectable(self,_:bool)->Self{self}}
 pub struct Button(String);impl Button{pub fn new(s:&str)->Self{Self(s.into())}}impl Widget for Button{fn button(&self)->Option<&str>{Some(&self.0)}}
 pub struct TextEdit;impl TextEdit{pub fn multiline(_:&mut String)->Self{Self}pub fn hint_text(self,_:&str)->Self{self}pub fn desired_rows(self,_:usize)->Self{self}}impl Widget for TextEdit{}
}
mod pull_request{#[derive(Clone,Copy,PartialEq)]pub enum DiffSide{Left,Right}}
mod pr_threads{
 use super::pull_request::DiffSide;
 #[derive(Clone)]pub struct ThreadComment{pub author:String,pub body:String}
 #[derive(Clone)]pub struct Thread{pub id:String,pub path:String,pub line:Option<u64>,pub side:DiffSide,pub outdated:bool,pub resolved:bool,pub can_resolve:bool,pub can_unresolve:bool,pub can_reply:bool,pub comments:Vec<ThreadComment>}
 pub struct PrExtras{pub native_policy:bool,pub threads:Vec<Thread>}
}
mod repo{
 pub struct Action;
 pub mod review{
  use crate::{pr_threads::Thread,pull_request::DiffSide};
  pub enum PrAct{SetResolved(String,bool),ReplyConversation(String)}
  #[derive(Default)]pub struct PrDraft{pub posting:bool,pub comment:String}
  pub fn pr_acts(_: &mut Vec<super::Action>,_:PrAct){}
pub(crate) fn thread_is_on(thread: &Thread, path: &str, side: DiffSide, line: u64) -> bool {
    !thread.outdated && thread.path == path && thread.side == side && thread.line == Some(line)
}
pub mod native {
//! Conversation discussions without a file coordinate still have native reply/resolution controls.
use super::{PrAct, PrDraft, pr_acts};
use crate::egui;
use crate::{pr_threads::PrExtras, repo::Action};
pub(crate) fn show(
    ui: &mut egui::Ui,
    draft: &mut PrDraft,
    extras: &PrExtras,
    acts: &mut Vec<Action>,
) {
    if !extras.native_policy {
        return;
    }
    for thread in extras
        .threads
        .iter()
        .filter(|thread| thread.path.is_empty())
    {
        ui.collapsing(
            format!(
                "Discussion · {}{}",
                thread.comments.first().map_or("", |c| c.author.as_str()),
                if thread.resolved { " · resolved" } else { "" }
            ),
            |ui| {
                for comment in &thread.comments {
                    ui.label(egui::RichText::new(&comment.author).strong());
                    ui.add(egui::Label::new(&comment.body).selectable(true));
                }
                if thread.can_resolve
                    && ui
                        .add_enabled(!draft.posting, egui::Button::new("Resolve discussion"))
                        .clicked()
                {
                    pr_acts(acts, PrAct::SetResolved(thread.id.clone(), true));
                }
                if thread.can_unresolve
                    && ui
                        .add_enabled(!draft.posting, egui::Button::new("Reopen discussion"))
                        .clicked()
                {
                    pr_acts(acts, PrAct::SetResolved(thread.id.clone(), false));
                }
                if thread.can_reply {
                    ui.add_enabled(
                        !draft.posting,
                        egui::TextEdit::multiline(&mut draft.comment)
                            .hint_text("Reply to this discussion")
                            .desired_rows(2),
                    );
                    if ui
                        .add_enabled(
                            !draft.posting && !draft.comment.trim().is_empty(),
                            egui::Button::new("Reply to discussion"),
                        )
                        .clicked()
                    {
                        pr_acts(acts, PrAct::ReplyConversation(thread.id.clone()));
                    }
                }
            },
        );
    }
}

}
  }
 }
 use pull_request::DiffSide;
 use pr_threads::{PrExtras,Thread,ThreadComment};
 fn thread(outdated:bool,path:&str)->Thread{Thread{id:"discussion".into(),path:path.into(),line:Some(2),side:DiffSide::Right,outdated,resolved:false,can_resolve:true,can_unresolve:false,can_reply:true,comments:vec![ThreadComment{author:"reviewer".into(),body:"Please fix".into()}]}}
 #[test] fn outdated_line_has_no_native_or_line_panel_controls(){
  let th=thread(true,"a.rs");let mut ui=egui::Ui::default();
  repo::review::native::show(&mut ui,&mut Default::default(),&PrExtras{native_policy:true,threads:vec![th.clone()]},&mut vec![]);
  assert!(ui.buttons.is_empty());
  assert!(!repo::review::thread_is_on(&th,"a.rs",DiffSide::Right,2));
  println!("outdated unresolved line: native buttons={:?}; line-panel match=false; can_resolve={}; can_reply={}",ui.buttons,th.can_resolve,th.can_reply);
 }
 #[test] fn controls_are_available_for_current_line_and_general_discussion(){
  assert!(repo::review::thread_is_on(&thread(false,"a.rs"),"a.rs",DiffSide::Right,2));
  let mut ui=egui::Ui::default();repo::review::native::show(&mut ui,&mut Default::default(),&PrExtras{native_policy:true,threads:vec![thread(false,"")]},&mut vec![]);
  assert_eq!(ui.buttons,["Resolve discussion","Reply to discussion"]);
  println!("control case general discussion buttons={:?}; current line-panel match=true",ui.buttons);
 }
