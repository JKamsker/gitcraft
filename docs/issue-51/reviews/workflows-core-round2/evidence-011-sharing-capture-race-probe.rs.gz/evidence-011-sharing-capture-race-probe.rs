use std::{path::Path, sync::{Arc,Mutex}};
static CONFIG: Mutex<&str> = Mutex::new("A");
mod git {
    use super::*;
    #[derive(Clone,PartialEq,Eq)] pub struct Remote {pub name:String,pub url:String}
    pub struct CommandSource {pub frozen:String}
    pub fn remotes(_: &Path)->Result<Vec<Remote>,String> {Ok(vec![Remote{name:"origin".into(),url:CONFIG.lock().unwrap().to_string()}])}
    impl CommandSource {
        pub fn capture(_: &Path)->Result<Arc<Self>,String> {
            // Recording boundary: configuration changes after the UI identity read,
            // before the production capture begins its own consistent snapshot.
            *CONFIG.lock().unwrap()="B";
            Ok(Arc::new(Self{frozen:CONFIG.lock().unwrap().to_string()}))
        }
        pub fn bind(&self,args:&[&str])->Vec<String> {let mut v=vec![self.frozen.clone()];v.extend(args.iter().map(|s|s.to_string()));v}
        pub fn check_context(&self)->Result<(),String> {if *CONFIG.lock().unwrap()==self.frozen {Ok(())}else{Err("changed".into())}}
    }
    pub fn run(_:Option<&Path>,args:&[&str])->Result<String,String>{Ok(format!("{}\n",args[0]))}
}
struct Target {name:String,fetch:String,push:String,source:Arc<git::CommandSource>}
impl Target {
    pub fn capture(repo: &Path, observed: &git::Remote) -> Result<Self, String> {
        if !git::remotes(repo)?.iter().any(|r| r == observed) {
            return Err("Sharing remote changed; refresh repository remotes and try again".into());
        }
        let source = git::CommandSource::capture(repo)?;
        let captured_url = |push| {
            let args = if push {
                vec![
                    "remote",
                    "get-url",
                    "--push",
                    "--all",
                    observed.name.as_str(),
                ]
            } else {
                vec!["remote", "get-url", "--all", observed.name.as_str()]
            };
            let args = source.bind(&args);
            let urls = git::run(
                Some(repo),
                &args.iter().map(String::as_str).collect::<Vec<_>>(),
            )?;
            let rows: Vec<_> = urls.lines().collect();
            match rows.as_slice() {
                [url] if !url.is_empty() => Ok((*url).to_owned()),
                _ => Err(
                    "Review-artifact sharing requires exactly one fetch and one push URL"
                        .to_owned(),
                ),
            }
        };
        let fetch = captured_url(false)?;
        let push = captured_url(true)?;
        source.check_context()?;
        Ok(Self {
            source,
            name: observed.name.clone(),
            fetch,
            push,
        })
    }
}
fn main(){
    let observed=git::Remote{name:"origin".into(),url:"A".into()};
    let t=Target::capture(Path::new("/recording-only"),&observed).unwrap();
    assert_eq!(observed.url,"A"); assert_eq!(t.fetch,"B"); assert_eq!(t.push,"B");
    t.source.check_context().unwrap();
    println!("Observed {} at {}; production capture accepted fetch={} push={} with unchanged captured context",t.name,observed.url,t.fetch,t.push);
}
