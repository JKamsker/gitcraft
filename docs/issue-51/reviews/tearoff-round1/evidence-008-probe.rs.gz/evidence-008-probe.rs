#![allow(dead_code)]
use std::collections::BTreeMap;
use egui::{Context,ViewportId,ViewportBuilder,Rect,Pos2,Event,Modifiers,PointerButton};
include!("/tmp/gitcraft-tearoff-r1-evidence/drop_target.rs");
fn main(){
 // Production drop_target: callers currently construct these from each viewport's own point scale.
 let a=ViewportId::ROOT;let b=ViewportId::from_hash_of("target");
 let physical_target=Rect::from_min_size(egui::pos2(1600.,100.),egui::vec2(800.,40.));
 let actual_desktop=egui::pos2(1700.,120.);
 let mixed=BTreeMap::from([(b,physical_target/2.)]);
 assert_eq!(drop_target(a,actual_desktop,&mixed),None);
 assert_eq!(drop_target(a,actual_desktop,&BTreeMap::from([(b,physical_target)])),Some(b));
 println!("PURE production drop_target: equivalent physical hit misses when target rect uses its 2x point scale.");
 // egui child lifecycle: reentrant fallback redeclares full windows but omits immediate-panel IDs.
 let ctx=Context::default();ctx.set_embed_viewports(false);
 let shell=ViewportId::from_hash_of("full-shell");let panel=ViewportId::from_hash_of("existing-panel");
 let out=ctx.run_ui(Default::default(),|ui|{
  ui.ctx().show_viewport_deferred(shell,ViewportBuilder::default(),|_,_|{});
  ui.ctx().show_viewport_deferred(panel,ViewportBuilder::default(),|_,_|{});
 });assert!(out.viewport_output.contains_key(&panel));out.drop_without_applying_deltas();
 let out=ctx.run_ui(Default::default(),|ui|ui.ctx().show_viewport_deferred(shell,ViewportBuilder::default(),|_,_|{}));
 assert!(out.viewport_output.contains_key(&shell));assert!(!out.viewport_output.contains_key(&panel));out.drop_without_applying_deltas();
 println!("HEADLESS egui lifecycle: redeclaring cached full shell alone prunes omitted panel child ID.");
 let ctx=Context::default();
 let mut frame=|events:Vec<Event>|{let out=ctx.run_ui(egui::RawInput{events,..Default::default()},|_|{});out.drop_without_applying_deltas();};
 frame(vec![Event::PointerMoved(egui::pos2(40.,20.)),Event::PointerButton{pos:egui::pos2(40.,20.),button:PointerButton::Primary,pressed:true,modifiers:Modifiers::NONE}]);
 frame(vec![Event::PointerGone]);frame(vec![]);
 assert!(ctx.input(|i|i.pointer.primary_down()));assert!(ctx.pointer_interact_pos().is_none());
 println!("HEADLESS input limitation: after PointerGone plus a pass, primary remains down while source has no interact position.");
}
