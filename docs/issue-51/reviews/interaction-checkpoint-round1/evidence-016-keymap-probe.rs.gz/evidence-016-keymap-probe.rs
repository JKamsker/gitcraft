#![allow(dead_code,unused_imports)]
#[path="/tmp/gitcraft-interaction-r1-evidence/keymap/mod.rs"] mod keymap;
mod manual {pub fn command()->&'static str {if cfg!(target_os="macos"){"Cmd"}else{"Ctrl"}}}
mod theme {pub struct Tokens{pub danger:egui::Color32} impl Tokens{pub fn get(_: &egui::Context)->Self{Self{danger:egui::Color32::RED}}}}
mod settings {
 #[derive(Clone,Default)] pub struct Settings{pub key_bindings:crate::keymap::Overrides}
 impl Settings{pub fn get(ctx:&egui::Context)->Self{ctx.data(|d|d.get_temp(egui::Id::new("probe-settings"))).unwrap_or_default()}pub fn set(&self,ctx:&egui::Context){ctx.data_mut(|d|d.insert_temp(egui::Id::new("probe-settings"),self.clone()));}}
}
use egui::{Key,Event,Modifiers,Pos2,Shape};
fn key(key:Key)->Vec<Event>{vec![Event::Key{key,physical_key:Some(key),modifiers:Modifiers::NONE,pressed:true,repeat:false},Event::Key{key,physical_key:Some(key),modifiers:Modifiers::NONE,pressed:false,repeat:false}]}
fn text(shape:&Shape,label:&str)->Option<Pos2>{match shape{Shape::Text(t)if t.galley.job.text==label=>Some(t.visual_bounding_rect().center()),Shape::Vec(v)=>v.iter().find_map(|s|text(s,label)),_=>None}}
fn main(){
 let ctx=egui::Context::default(); let mut o=keymap::Overrides::new(); let mut time=0.;
 let mut frame=|events:Vec<Event>,o:&mut keymap::Overrides|{time+=0.1;ctx.run_ui(egui::RawInput{time:Some(time),screen_rect:Some(egui::Rect::from_min_size(Pos2::ZERO,egui::vec2(1600.,1800.))),events,..Default::default()},|ui|keymap::editor::page(o,ui))};
 let initial=frame(vec![],&mut o);let change=initial.shapes.iter().find_map(|s|text(&s.shape,"Change")).expect("change button"); initial.drop_without_applying_deltas();
 frame(vec![Event::PointerMoved(change),Event::PointerButton{pos:change,button:egui::PointerButton::Primary,pressed:true,modifiers:Modifiers::NONE}],&mut o).drop_without_applying_deltas();
 frame(vec![Event::PointerButton{pos:change,button:egui::PointerButton::Primary,pressed:false,modifiers:Modifiers::NONE}],&mut o).drop_without_applying_deltas();
 assert!(keymap::editor::capturing(&ctx));
 println!("HEADLESS: clicking first Change sets capturing=true.");
 let next=frame(key(Key::F8),&mut o);
 let visible=next.shapes.iter().filter_map(|s|if let Shape::Text(t)=&s.shape{Some(t.galley.job.text.clone())}else{None}).collect::<Vec<_>>();
 assert!(!visible.iter().any(|s|s=="Save binding"),"capture unexpectedly displayed: {visible:?}");
 assert!(!keymap::editor::capturing(&ctx)); assert!(o.is_empty());
 println!("HEADLESS: next F8 frame has no Save binding/capture panel; capturing=false and overrides remain empty.");
 next.drop_without_applying_deltas();
}
