#![allow(dead_code,unused_imports)]
#[path="keymap/mod.rs"] mod keymap;
mod manual {pub fn command()->&'static str{if cfg!(target_os="macos"){"Cmd"}else{"Ctrl"}}}
mod theme {pub struct Tokens{pub danger:egui::Color32}impl Tokens{pub fn get(_: &egui::Context)->Self{Self{danger:egui::Color32::RED}}}}
mod settings {
 #[derive(Clone,Default)]pub struct Settings{pub key_bindings:crate::keymap::Overrides}
 impl Settings{pub fn get(ctx:&egui::Context)->Self{ctx.data(|d|d.get_temp(egui::Id::new("probe-settings"))).unwrap_or_default()}pub fn put_for_test(&self,ctx:&egui::Context){ctx.data_mut(|d|d.insert_temp(egui::Id::new("probe-settings"),self.clone()));}}
}
use egui::{Event,Key,Modifiers,Pos2,Shape};
fn key_mod(k:Key,m:Modifiers)->Vec<Event>{[true,false].into_iter().map(|pressed|Event::Key{key:k,physical_key:Some(k),pressed,repeat:false,modifiers:m}).collect()}
fn key(k:Key)->Vec<Event>{key_mod(k,Modifiers::NONE)}
fn text(s:&Shape,label:&str)->Option<Pos2>{match s{Shape::Text(t)if t.galley.job.text==label=>Some(t.visual_bounding_rect().center()),Shape::Vec(v)=>v.iter().find_map(|s|text(s,label)),_=>None}}
struct Probe{ctx:egui::Context,o:keymap::Overrides,time:f64}
impl Probe{
 fn new()->Self{let mut s=Self{ctx:egui::Context::default(),o:Default::default(),time:0.};s.run(vec![]);s}
 fn frame(&mut self,events:Vec<Event>)->egui::FullOutput{self.time+=0.1;self.ctx.run_ui(egui::RawInput{time:Some(self.time),screen_rect:Some(egui::Rect::from_min_size(Pos2::ZERO,egui::vec2(1600.,1800.))),events,..Default::default()},|ui|keymap::editor::page(&mut self.o,ui))}
 fn run(&mut self,events:Vec<Event>){self.frame(events).drop_without_applying_deltas()}
 fn click(&mut self,label:&str){let out=self.frame(vec![]);let pos=out.shapes.iter().find_map(|s|text(&s.shape,label)).expect(label);out.drop_without_applying_deltas();self.run(vec![Event::PointerMoved(pos),Event::PointerButton{pos,button:egui::PointerButton::Primary,pressed:true,modifiers:Modifiers::NONE}]);self.run(vec![Event::PointerButton{pos,button:egui::PointerButton::Primary,pressed:false,modifiers:Modifiers::NONE}]);}
 fn visible(&mut self,label:&str)->bool{let o=self.frame(vec![]);let found=o.shapes.iter().any(|s|text(&s.shape,label).is_some());o.drop_without_applying_deltas();found}
 fn change_keyboard(&mut self){self.run(key(Key::Tab));self.run(key(Key::Tab));self.run(key(Key::Enter));assert!(keymap::editor::capturing(&self.ctx));}
}
fn main(){
 let mut p=Probe::new();p.change_keyboard();p.run(key(Key::F8));for _ in 0..3{p.run(vec![]);}assert!(p.visible("Capture shortcut: F8"));p.run(key(Key::Tab));p.run(key(Key::Enter));assert_eq!(p.o.get("new_tab"),Some(&vec![keymap::Stroke::new(Key::F8,Modifiers::NONE)]));assert!(!keymap::editor::capturing(&p.ctx));
 let saved=serde_json::to_string(&p.o).unwrap();let restored=serde_json::from_str(&saved).unwrap();let ctx=egui::Context::default();settings::Settings{key_bindings:restored}.put_for_test(&ctx);assert_eq!(keymap::label(&ctx,keymap::Command::NewTab),"F8");ctx.run_ui(egui::RawInput{events:key(Key::F8),..Default::default()},|_|{keymap::active(&ctx,vec![keymap::Scope::Window]);assert_eq!(keymap::pressed(&ctx,keymap::Scope::Window),vec![keymap::Command::NewTab]);}).drop_without_applying_deltas();println!("PASS keyboard Change -> F8 -> idle frames -> Tab -> Enter Save; exact Overrides serde roundtrip feeds production label/resolver NewTab.");
 let mut p=Probe::new();p.change_keyboard();p.run(key(Key::F8));for _ in 0..3{p.run(key(Key::Tab));}p.run(key(Key::Space));assert!(p.o.is_empty());assert!(!keymap::editor::capturing(&p.ctx));println!("PASS keyboard Cancel with Space preserves overrides.");
 let mut p=Probe::new();p.change_keyboard();p.run(key(Key::F8));p.run(key(Key::Tab));p.run(key(Key::Escape));assert!(p.o.is_empty());assert!(!keymap::editor::capturing(&p.ctx));println!("PASS Escape from Save cancels without mutation.");
 let mut p=Probe::new();p.change_keyboard();p.run(key_mod(Key::W,Modifiers::COMMAND));p.click("Save binding");assert!(p.o.is_empty());assert!(keymap::editor::capturing(&p.ctx));let mut p=Probe::new();p.change_keyboard();p.run(key_mod(Key::W,Modifiers::COMMAND));p.run(key(Key::Tab));p.run(key(Key::Enter));assert!(p.visible("Capture shortcut: No keys"));p.click("Save binding");assert_eq!(p.o.get("new_tab"),Some(&vec![]));println!("PASS conflicting Cmd/Ctrl-W cannot Save; keyboard Clear then explicit unbind Save works.");
 let mut p=Probe::new();p.change_keyboard();for k in[Key::F8,Key::F9,Key::F10,Key::F11,Key::F12]{p.run(key(k));}assert!(p.visible("Capture shortcut: F8 → F9 → F10 → F11"));p.click("Save binding");assert_eq!(p.o["new_tab"].len(),4);println!("PASS fifth captured stroke is bounded.");
 let mut p=Probe::new();p.change_keyboard();p.click("Add Shift+Tab key");p.click("Save binding");assert_eq!(p.o["new_tab"],vec![keymap::Stroke::new(Key::Tab,Modifiers::SHIFT)]);println!("PASS explicit Shift-Tab capture saves navigation binding.");
 let mut p=Probe::new();p.change_keyboard();for _ in 0..2{p.ctx.run_ui(egui::RawInput::default(),|_|{}).drop_without_applying_deltas();}assert!(!keymap::editor::capturing(&p.ctx));println!("PASS absent editor releases capture ownership.");
}
