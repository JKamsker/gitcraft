#![allow(dead_code,unused_imports)]
#[path="/private/tmp/gitcraft-interaction-r2-586d0894/src/repo/popout/window.rs"] mod window;
#[path="/private/tmp/gitcraft-interaction-r2-586d0894/src/a11y/mod.rs"] mod a11y;
mod theme{pub struct Tokens{pub dock:egui::Color32,pub accent:egui::Color32,pub radius_sm:f32}impl Tokens{pub fn get(_: &egui::Context)->Self{Self{dock:egui::Color32::BLACK,accent:egui::Color32::RED,radius_sm:0.}}}}
mod app{pub fn window_icon()->egui::IconData{egui::IconData{rgba:vec![0,0,0,255],width:1,height:1}}}
use std::{cell::RefCell,collections::HashMap,rc::Rc};
use egui::{Id,Rect,ViewportId,ViewportClass,Shape};
fn ring(s:&Shape,r:Rect)->bool{match s{Shape::Rect(s)=>s.rect==r.shrink(1.)&&s.stroke==egui::Stroke::new(2.,egui::Color32::RED),Shape::Vec(v)=>v.iter().any(|s|ring(s,r)),_=>false}}
fn main(){
 assert_eq!(std::env::var("GITCRAFT_REDUCE_MOTION").as_deref(),Ok("1"),"forbid system preference discovery");
 let ctx=egui::Context::default();ctx.set_embed_viewports(false);
 let rects=Rc::new(RefCell::new(HashMap::<ViewportId,Rect>::new()));let rings=Rc::new(RefCell::new(HashMap::<ViewportId,Vec<bool>>::new()));
 let rects_r=rects.clone();let rings_r=rings.clone();
 egui::Context::set_immediate_viewport_renderer(move|ctx,mut viewport|{
  let child=viewport.ids.this;let mut input=egui::RawInput{viewport_id:child,..Default::default()};input.viewports.insert(child,egui::ViewportInfo{parent:Some(ViewportId::ROOT),focused:Some(true),..Default::default()});
  let out=ctx.run_ui(input,|ui|(viewport.viewport_ui_cb)(ui));let r=rects_r.borrow()[&child];rings_r.borrow_mut().entry(child).or_default().push(out.shapes.iter().any(|s|ring(&s.shape,r)));out.drop_without_applying_deltas();
 });
 let children=[ViewportId::from_hash_of("review-child-A"),ViewportId::from_hash_of("review-child-B")];
 let mut remembered=Vec::new();
 for pass in 0..2{
  let mut rootrect=Rect::NOTHING;
  let out=ctx.run_ui(egui::RawInput::default(),|ui|{
   let root=ui.allocate_response(egui::vec2(120.,30.),egui::Sense::click());rootrect=root.rect;root.request_focus();a11y::a11y(&root,egui::WidgetType::Button,"Root row");
   for child in children{
    window::show(ui.ctx(),child,"Synthetic review child",|ui,class|{
     assert!(class==ViewportClass::Immediate);let row=Id::new(("owned-row",child));if pass==1{ui.memory_mut(|m|m.surrender_focus(row));}
     let r=ui.interact(Rect::from_min_size(ui.cursor().min,egui::vec2(180.,32.)),row,egui::Sense::click());rects.borrow_mut().insert(child,r.rect);if pass==0{r.request_focus();}else{assert!(!r.has_focus());remembered.push(a11y::keyboard_on(&r));}a11y::a11y(&r,egui::WidgetType::Button,"Child row");
    });
   }
   a11y::end_frame(ui.ctx());
  });
  assert!(out.shapes.iter().any(|s|ring(&s.shape,rootrect)),"root ring must survive both child flushes");out.drop_without_applying_deltas();
 }
 for child in children{assert_eq!(rings.borrow()[&child],vec![true,false]);}assert_eq!(remembered,vec![true,true]);println!("PASS actual shared callback flushes each of two child rings before ROOT; focus remembers child rows independently; ROOT ring survives.");
 let ctx=egui::Context::default();assert!(ctx.embed_viewports());let mut rect=Rect::NOTHING;let mut layer=egui::LayerId::background();
 let out=ctx.run_ui(egui::RawInput::default(),|ui|{
  window::show(ui.ctx(),ViewportId::from_hash_of("review-embedded"),"Embedded",|ui,class|{assert!(class==ViewportClass::EmbeddedWindow);let r=ui.allocate_response(egui::vec2(180.,32.),egui::Sense::click());rect=r.rect;layer=r.layer_id;r.request_focus();a11y::a11y(&r,egui::WidgetType::Button,"Embedded row");});
  assert!(!ui.ctx().graphics(|g|g.get(layer).is_some_and(|p|p.all_entries().any(|s|ring(&s.shape,rect)))),"embedded callback must leave ring undrawn until parent flush");
  a11y::end_frame(ui.ctx());
 });assert!(out.shapes.iter().any(|s|ring(&s.shape,rect)));out.drop_without_applying_deltas();println!("PASS embedded shared callback retains parent's focus ring for parent end_frame.");
}
