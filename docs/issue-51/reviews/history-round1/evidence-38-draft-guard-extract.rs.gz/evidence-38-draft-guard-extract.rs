fn run_fragment(path:&std::path::Path,ops:&[Vec<String>],kind:(),creds:Option<&git::Credentials>,quiet:bool,control:Option<&std::sync::Arc<git::OpControl>>)->(Result<String,String>,(),usize){
    // Checked before anything runs, so a refused undo changes nothing.
    if let Err(e) = check_expected(path, ops, control) {
        return (Err(e), kind, 0);
    }
    // Preserve both index and worktree layers before operations that can replace files.
    if ops.iter().any(|op| {
        git::subcommand(&op.iter().map(String::as_str).collect::<Vec<_>>())
            .is_some_and(|s| matches!(s, "checkout" | "switch" | "rebase"))
    }) {
        let active = || {
            !crate::tasks::cancellation().is_cancelled()
                && !control.is_some_and(|c| c.is_cancelled())
        };
        let snapshot = (|| {
            if git::drafts::enabled_while(path, &active)? {
                git::drafts::capture(path, "Before checkout / rebase", &active)?;
            }
            Ok::<_, String>(())
        })();
        if let Err(error) = snapshot {
            return (Err(format!("Working draft safety check: {error}")), kind, 0);
        }
    }
    let mut result = Ok(String::new());
    let mut stopped = ops.len();
    let mut tried = Vec::new();
    for (i, op) in ops.iter().enumerate() {
        if is_expectation(op) {
            continue;
        }
        if let [mark, says, args @ ..] = &op[..]
            && mark == TRY
        {
            let args: Vec<&str> = args.iter().map(String::as_str).collect();
            if let Err(e) = git::run_unattended(Some(path), &args, creds) {
                tried.push(format!("{says} ({})", headline(&e)));
            }
            continue;
        }
        let args: Vec<&str> = op.iter().map(String::as_str).collect();
        result = (|| {
            if let [mark, original @ ..] = op.as_slice()
                && mark == crate::gerrit::AMEND
            {
                let prepared = crate::gerrit::amend_args(path, original)?;
                let args: Vec<&str> = prepared.iter().map(String::as_str).collect();
                return run_step(path, &args, creds, quiet, control);
            }
            if let [mark, id] = op.as_slice()
                && mark == crate::push_preflight::APPROVED
            {
                let plan = crate::push_preflight::registered(id)?;
                return crate::push_preflight::execute_controlled(path, &plan, creds, control);
            }
            if let [mark, id, fix] = op.as_slice()
                && mark == crate::push_preflight::FIX
            {
                let plan = crate::push_preflight::registered(id)?;
                return crate::push_preflight::fix(path, &plan, fix);
            }
            run_step(path, &args, creds, quiet, control)
        })();
        if result.is_err() {
            stopped = i;
            break;
        }
    }

(result,kind,stopped)
}
