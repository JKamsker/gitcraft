#!/bin/sh
printf "%s\n" "$@" > /tmp/gitcraft-51-history-core-r1-evidence/receivepack-args.txt
exit 1
