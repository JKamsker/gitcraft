#![allow(dead_code,unused_imports)]
mod settings {pub mod profiles {
#[derive(Clone)] pub struct Signing {pub sign_commits:bool}
#[derive(Clone)] pub struct UserProfile {pub own_signing:bool,pub signing:Signing}
impl UserProfile {pub fn expected_author(&self,_url:&str)->(&str,&str){("Test","test@example.invalid")}}
}}
mod gerrit {pub const CHECK:&str="\0gerrit";}
mod remote {pub fn sh_quote(s:&str)->String {format!("'{}'",s.replace('\'',"'\\''"))}}
mod git {
use std::{path::Path,process::Command};
pub struct LfsPointer {pub oid:String}
pub fn parse_lfs_pointer(_s:&str)->Option<LfsPointer>{None}
pub fn human_size(s:u64)->String{s.to_string()}
pub fn forecast_run(dir:&Path,args:&[&str],env:&[(&'static str,String)],ok:&[i32],active:&dyn Fn()->bool)->Result<String,String>{
assert!(active());
let mut c=Command::new(std::env::var("REVIEW_GIT").unwrap());
c.current_dir(dir).args(args).env("GIT_CONFIG_GLOBAL","/dev/null").env("GIT_CONFIG_NOSYSTEM","1").env("GIT_TERMINAL_PROMPT","0").env("GIT_OPTIONAL_LOCKS","0");
for key in ["GIT_DIR","GIT_COMMON_DIR","GIT_WORK_TREE","GIT_INDEX_FILE","GIT_ATTR_SOURCE","GIT_CONFIG_COUNT","GIT_CONFIG_PARAMETERS","GIT_OBJECT_DIRECTORY","GIT_ALTERNATE_OBJECT_DIRECTORIES"] {c.env_remove(key);}
for (k,v) in env {c.env(k,v);}
let o=c.output().map_err(|e|e.to_string())?;
if ok.contains(&o.status.code().unwrap_or(-1))&&o.stderr.is_empty(){Ok(String::from_utf8_lossy(&o.stdout).into())}else{Err(format!("git failed {:?} {:?}",args,String::from_utf8_lossy(&o.stderr)))}
}}
#[path="scanner-extract.rs"] mod push_preflight;
fn main(){let repo=std::env::args().nth(1).unwrap();let p=settings::profiles::UserProfile{own_signing:false,signing:settings::profiles::Signing{sign_commits:false}};
let plan=push_preflight::scan(std::path::Path::new(&repo),vec![vec!["push".into()]],p,&||true).unwrap();
println!("head={} commits={} findings={}",plan.head,plan.commits.len(),plan.findings.len());
for c in plan.commits {println!("commit={} subject={}",c.oid,c.subject);}
for f in plan.findings {println!("finding={:?} commit={} path={} detail={}",f.kind,f.commit,f.path,f.detail);}
}
