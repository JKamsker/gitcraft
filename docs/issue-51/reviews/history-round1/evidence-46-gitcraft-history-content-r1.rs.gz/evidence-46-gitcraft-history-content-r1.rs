#![allow(dead_code)]
use std::{path::Path,process::{Command,Stdio},io::Write,time::{Instant,Duration}};
pub struct Reader<'a>{repo:&'a Path,active:&'a dyn Fn()->bool,began:Instant}
impl<'a> Reader<'a>{
 pub fn new(repo:&'a Path,active:&'a dyn Fn()->bool)->Self{Self{repo,active,began:Instant::now()}}
 pub fn active(&self)->bool{(self.active)()&&self.began.elapsed()<Duration::from_secs(120)}
 pub fn run(&self,args:&[&str],input:Vec<u8>,ok:&[i32])->Result<Vec<u8>,String>{
  if !self.active(){return Err("inactive".into());}let mut c=Command::new("git");c.arg("-C").arg(self.repo).args(["--no-lazy-fetch","--no-replace-objects","--no-optional-locks","-c","core.hooksPath=/dev/null","-c","core.fsmonitor=false"]);c.args(args);
  for k in ["GIT_DIR","GIT_COMMON_DIR","GIT_WORK_TREE","GIT_INDEX_FILE","GIT_OBJECT_DIRECTORY","GIT_ALTERNATE_OBJECT_DIRECTORIES","GIT_NAMESPACE","GIT_REPLACE_REF_BASE","GIT_SHALLOW_FILE","GIT_CONFIG_COUNT","GIT_CONFIG_PARAMETERS"]{c.env_remove(k);}
  c.stdin(Stdio::piped()).stdout(Stdio::piped()).stderr(Stdio::piped());let mut h=c.spawn().map_err(|e|e.to_string())?;h.stdin.take().unwrap().write_all(&input).map_err(|e|e.to_string())?;let o=h.wait_with_output().map_err(|e|e.to_string())?;if !ok.contains(&o.status.code().unwrap_or(-1)){return Err(String::from_utf8_lossy(&o.stderr).into());}Ok(o.stdout)
 }
}
pub fn oid(s:&str)->bool{matches!(s.len(),40|64)&&s.bytes().all(|b|b.is_ascii_hexdigit())}
#[path="/Users/jonas/.t3/worktrees/gitcraft/t3-4a6c0b9e/src/git/investigations/cochange.rs"] mod cochange;
#[path="/Users/jonas/.t3/worktrees/gitcraft/t3-4a6c0b9e/src/git/investigations/dossier.rs"] mod dossier;
#[path="/Users/jonas/.t3/worktrees/gitcraft/t3-4a6c0b9e/src/git/investigations/symbols.rs"] mod symbols;
#[path="/Users/jonas/.t3/worktrees/gitcraft/t3-4a6c0b9e/src/git/investigations/views.rs"] mod views;
fn main()->Result<(),String>{let args:Vec<_>=std::env::args().collect();let repo=Path::new(&args[2]);
 match args[1].as_str(){
 "symbol"=>{let result=symbols::investigate(repo,&args[3],&args[4],&args[5],None,256,&||true)?;println!("{result:#?}");}
 "cochange"=>{let h=cochange::load(repo,&args[3],&||true)?;let staged=std::collections::BTreeSet::from([args[4].clone()]);println!("history={h:#?}\nhints={:#?}",cochange::rank(&h,&staged,&staged));}
 "dossier"=>{println!("{:#?}",dossier::trace(repo,&args[3],&args[4],args[5].parse().unwrap(),&||true)?);}
 _=>return Err("mode".into())
 }Ok(())}
