from pathlib import Path
import os,subprocess,json
p=Path('/tmp/gitcraft-51-history-core-r1-evidence');r=p/'replace-fixture';env={k:v for k,v in os.environ.items() if not k.startswith('GIT_')};env.update(GIT_CONFIG_GLOBAL='/dev/null',GIT_CONFIG_NOSYSTEM='1',GIT_TERMINAL_PROMPT='0')
git='/opt/homebrew/bin/git'
alias='gitcraft-preflight-fixture-0';placeholder='gitcraft-preflight-address://'+alias;A=str(p/'intended-A.git');B=str(p/'uncontacted-B.git');marker=p/'receivepack-args.txt';shim=p/'record-receive-pack.sh'
shim.write_text('#!/bin/sh\nprintf "%s\\n" "$@" > '+str(marker)+'\nexit 1\n');shim.chmod(0o700)
config=['-c','url.'+A+'.insteadOf='+placeholder,'-c','remote.'+alias+'.url='+placeholder,'-c','remote.'+alias+'.receivepack='+str(shim)]
results=[]
for kind,rule in [('ordinary_chain',A),('placeholder_push_rule','gitcraft-preflight-address://')]:
 extra=['-c','url.'+B+'.pushInsteadOf='+rule]
 check=subprocess.run([git,*config,*extra,'ls-remote','--get-url',alias],cwd=r,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 marker.unlink(missing_ok=True)
 # Recording-only receiver exits immediately; neither target exists and no receiver Git runs.
 dispatch=subprocess.run([git,*config,*extra,'push','--dry-run','--no-verify',alias,'HEAD:refs/heads/review'],cwd=r,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 target=marker.read_text().strip() if marker.exists() else None
 results.append({'case':kind,'validation':check.stdout.decode().strip(),'validation_passes':check.returncode==0 and check.stdout.decode().strip()==A,'recorded_receiver_target':target,'different_from_approved':target!=A,'dispatch_exit':dispatch.returncode,'evidence_class':'local recording-only receive-pack shim, exits before Git receiver; --dry-run; no network or actual push'})
(p/'transport-results.json').write_text(json.dumps(results,indent=2));print(json.dumps(results,indent=2))
