#!/bin/sh
printf called > /tmp/gitcraft-51-history-core-r1-evidence/ghost-upload-helper-called
exit 1
