from pathlib import Path
p=Path('/tmp/gitcraft-51-history-core-r1-evidence');s=Path('src/repo/operations.rs').read_text()
fragment=s[s.index('    // Checked before anything runs, so a refused undo changes nothing.',s.index('pub(super) fn run_steps_counted')):s.index('    if result.is_ok() && !tried.is_empty()',s.index('pub(super) fn run_steps_counted'))]
(p/'draft-guard-extract.rs').write_text('fn run_fragment(path:&std::path::Path,ops:&[Vec<String>],kind:(),creds:Option<&git::Credentials>,quiet:bool,control:Option<&std::sync::Arc<git::OpControl>>)->(Result<String,String>,(),usize){\n'+fragment+'\n(result,kind,stopped)\n}\n')
(p/'draft-guard-harness.rs').write_text(r'''#![allow(dead_code,unused_variables,unused_mut)]
use std::cell::RefCell;
thread_local!{static STATE:RefCell<(String,usize,Vec<String>)>=RefCell::new(("approved-head".into(),0,vec![]));}
const TRY:&str="\0try";
fn is_expectation(op:&[String])->bool{op[0]=="expect"}
fn check_expected(_: &std::path::Path,_:&[Vec<String>],_:Option<&std::sync::Arc<git::OpControl>>)->Result<(),String>{STATE.with(|s|{let mut x=s.borrow_mut();x.1+=1;if x.0=="approved-head"{Ok(())}else{Err("stale HEAD".into())}})}
fn headline(e:&str)->&str{e}
fn run_step(_:&std::path::Path,args:&[&str],_:Option<&git::Credentials>,_:bool,_:Option<&std::sync::Arc<git::OpControl>>)->Result<String,String>{STATE.with(|s|{let mut x=s.borrow_mut();let h=x.0.clone();x.2.push(format!("{:?} executed against {}",args,h));});Ok("executed".into())}
mod tasks{pub struct Cancellation;impl Cancellation{pub fn is_cancelled(&self)->bool{false}}pub fn cancellation()->Cancellation{Cancellation}}
mod git{
pub struct Credentials;pub struct OpControl;impl OpControl{pub fn is_cancelled(&self)->bool{false}}
pub fn subcommand<'a>(args:&'a [&'a str])->Option<&'a str>{args.first().copied()}
pub fn run_unattended(_:Option<&std::path::Path>,_:&[&str],_:Option<&Credentials>)->Result<String,String>{Ok("".into())}
pub mod drafts{
pub fn enabled_while(_:&std::path::Path,_:&dyn Fn()->bool)->Result<bool,String>{Ok(true)}
pub fn capture(_:&std::path::Path,_:&str,_:&dyn Fn()->bool)->Result<(),String>{
// Model terminal movement after the expectations, before a successful coherent capture.
crate::STATE.with(|s|s.borrow_mut().0="later-head-not-approved".into());Ok(())}
}}
mod gerrit{pub const AMEND:&str="\0amend";pub fn amend_args(_:&std::path::Path,args:&[String])->Result<Vec<String>,String>{Ok(args.to_vec())}}
mod push_preflight{pub const APPROVED:&str="\0approved";pub const FIX:&str="\0fix";pub fn registered(_:&str)->Result<(),String>{Ok(())}pub fn execute_controlled(_:&std::path::Path,_:&(),_:Option<&crate::git::Credentials>,_:Option<&std::sync::Arc<crate::git::OpControl>>)->Result<String,String>{Ok("".into())}pub fn fix(_:&std::path::Path,_:&(),_:&str)->Result<String,String>{Ok("".into())}}
include!("draft-guard-extract.rs");
fn main(){let result=run_fragment(std::path::Path::new("unused"),&[vec!["expect".into(),"approved-head".into()],vec!["rebase".into(),"-i".into(),"pinned-base".into()]],(),None,false,None);println!("operation_result={:?}",result.0);STATE.with(|s|{let x=s.borrow();println!("expectation_checks={} recorded={:?}",x.1,x.2);assert_eq!(x.1,1);assert!(x.2[0].contains("later-head-not-approved"));});println!("RESULT: successful safety capture can invalidate prechecked guards; expectations are skipped afterwards; no Git/mutation executed");}
''')
