#![allow(dead_code,unused_variables)]
use std::path::PathBuf;
mod egui {pub struct Context;}
#[derive(Clone)] enum Undo {HeadMove{mode:&'static str}}
enum Refresh {All}
fn expect_symref(r:&str,b:&str)->Vec<String>{vec!["expect-symref".into(),r.into(),b.into()]}
fn expect_ref_at(r:&str,b:&str)->Vec<String>{vec!["expect-ref".into(),r.into(),b.into()]}
type Ready=(Vec<String>,String,Vec<(String,String)>);
fn moved_refs_undo(_:Vec<String>,_:&str,_:&[(String,String)],_:&[Vec<String>])->Undo{Undo::HeadMove{mode:"--keep"}}
struct Refs{current:Option<String>,head:String}
#[derive(Clone)] struct Editor{head:String,id:u64,starting:bool,onto_label:String,update_refs:bool}
impl Editor{
fn problem(&self)->Option<String>{None}
fn command_with_refs(&self,_:&std::path::Path)->Result<(Vec<String>,Vec<(String,String)>),String>{Ok((vec!["rebase".into()],vec![]))}
    pub fn moved(&self, head: &str) -> Option<String> {
        (!self.head.is_empty() && self.head != head).then(|| {
            "The branch has moved since these commits were read: rebasing would drop the new ones. Cancel and start again."
                .to_owned()
        })
    }
}
struct RepoTab{refs:Refs,rebase:Option<Editor>,busy_op:Option<String>,status:Option<(String,bool)>,path:PathBuf,recorded:Vec<Vec<String>>}
impl RepoTab{
fn with_rebase_command(&mut self,editor:Editor,ctx:&egui::Context,then:impl FnOnce(&mut Self,Result<(Vec<String>,String),String>,&egui::Context)){
 then(self,Ok((vec!["rebase".into(),"-i".into(),"pinned-base".into()],editor.head)),ctx);
}
fn then<T>(&mut self,ctx:&egui::Context,work:impl FnOnce()->Result<T,String>,done:impl FnOnce(&mut Self,Result<T,String>,&egui::Context)){let result=work();done(self,result,ctx);}
fn run_undoable(&mut self,_:&str,steps:Vec<Vec<String>>,_:Refresh,_:Undo,_:&egui::Context){self.recorded=steps;}
}
include!("rebase-control-extract.rs");
fn main(){
let head="0123456789abcdef0123456789abcdef01234567".to_string();
let mut tab=RepoTab{refs:Refs{current:Some("approved-A".into()),head:head.clone()},rebase:Some(Editor{head,id:91,starting:false,onto_label:"base".into(),update_refs:false}),busy_op:None,status:None,path:PathBuf::from("unused"),recorded:vec![]};
let approved_editor=tab.rebase.as_ref().unwrap().id;
println!("approved_branch={} approved_editor={}",tab.refs.current.as_ref().unwrap(),approved_editor);
// An external checkout to B followed by the normal tab ref reload keeps HEAD/editor ID.
tab.refs.current=Some("unexpected-B".into());
assert_eq!(tab.rebase.as_ref().unwrap().id,approved_editor);
assert!(tab.rebase.as_ref().unwrap().moved(&tab.refs.head).is_none());
tab.run_rebase(&egui::Context);
println!("recorded_steps={:?}",tab.recorded);
assert!(tab.recorded.iter().any(|s|s==&vec!["expect-symref".to_string(),"HEAD".into(),"refs/heads/unexpected-B".into()]));
println!("RESULT: candidate emits a guard for B, not approved A; no Git or mutation was executed");
}
