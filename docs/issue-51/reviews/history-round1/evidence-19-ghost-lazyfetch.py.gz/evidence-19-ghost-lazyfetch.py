import os,subprocess,json
from pathlib import Path
p=Path('/tmp/gitcraft-51-history-core-r1-evidence');r=p/'ghost-fixture';r.mkdir();git='/opt/homebrew/bin/git'
e={k:v for k,v in os.environ.items() if not k.startswith('GIT_')};e.update(GIT_CONFIG_GLOBAL='/dev/null',GIT_CONFIG_NOSYSTEM='1',GIT_TERMINAL_PROMPT='0',GIT_AUTHOR_NAME='Test',GIT_AUTHOR_EMAIL='test@example.invalid',GIT_COMMITTER_NAME='Test',GIT_COMMITTER_EMAIL='test@example.invalid')
def run(args):return subprocess.run([git,*args],cwd=r,env=e,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
def g(args):
 c=run(args);assert c.returncode==0,(args,c.stderr);return c.stdout.decode().strip()
g(['init','-q','-b','main']);g(['config','core.hooksPath','/dev/null']);(r/'file').write_text('old\n');g(['add','file']);g(['commit','-qm','old']);old=g(['rev-parse','HEAD']);(r/'file').write_text('new\n');g(['add','file']);g(['commit','-qm','new']);new=g(['rev-parse','HEAD']);blob=g(['rev-parse','HEAD:file']);
marker=p/'ghost-upload-helper-called';shim=p/'record-upload-pack.sh';shim.write_text('#!/bin/sh\nprintf called > '+str(marker)+'\nexit 1\n');shim.chmod(0o700)
g(['remote','add','origin',str(r)]);g(['config','extensions.partialClone','origin']);g(['config','remote.origin.promisor','true']);g(['config','remote.origin.uploadpack',str(shim)])
(r/'.git/objects'/blob[:2]/blob[2:]).unlink()
args=['diff','-M','--numstat','-z','--end-of-options',old,new,'--']
# Safe negative control before invoking the exact timeline diff argv.
a=run(['--no-lazy-fetch',*args]);negative=marker.exists()
b=run(args);positive=marker.exists()
result={'exact_timeline_argv':args,'no_lazy_fetch_control_exit':a.returncode,'control_invoked_helper':negative,'candidate_exit':b.returncode,'candidate_invoked_owned_recording_helper':positive,'candidate_error':b.stderr.decode(),'network':False,'actual_receiver':False,'evidence_class':'exact Git argv from git::diff_files, local recording-only upload-pack exits before receiver'}
(p/'ghost-lazyfetch-results.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2));assert not negative and positive
