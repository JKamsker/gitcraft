from pathlib import Path
import os, subprocess, json, hashlib
out=Path('/tmp/gitcraft-51-history-core-r1-evidence'); git='/opt/homebrew/bin/git'
env={k:v for k,v in os.environ.items() if not k.startswith('GIT_')}; env.update(GIT_CONFIG_GLOBAL='/dev/null',GIT_CONFIG_NOSYSTEM='1',GIT_TERMINAL_PROMPT='0',GIT_AUTHOR_NAME='Test',GIT_AUTHOR_EMAIL='test@example.invalid',GIT_COMMITTER_NAME='Test',GIT_COMMITTER_EMAIL='test@example.invalid',REVIEW_GIT=git)
r=out/'replace-fixture'; r.mkdir(exist_ok=False)
def g(args,inp=None,cwd=r):
 p=subprocess.run([git,*args],cwd=cwd,env=env,input=inp,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 if p.returncode:raise RuntimeError((args,p.stderr))
 return p.stdout
for a in [['init','-q','-b','main'],['config','core.hooksPath','/dev/null'],['config','user.name','Test'],['config','user.email','test@example.invalid']]:g(a)
(r/'safe').write_text('safe\n');g(['add','safe']);g(['commit','-qm','base']);base=g(['rev-parse','HEAD']).decode().strip()
g(['remote','add','origin',str(out/'never-contacted.git')]);g(['config','branch.main.remote','origin']);g(['config','branch.main.merge','refs/heads/main']);g(['update-ref','refs/remotes/origin/main',base])
(r/'payload').write_text('api_key = "SYNTHETIC_REVIEW_CANARY_123456"\n');g(['add','payload']);g(['commit','-qm','normal outgoing']);head=g(['rev-parse','HEAD']).decode().strip()
# Construct an ordinary replacement commit with the base tree and same parent.
tree=g(['rev-parse',base+'^{tree}']).decode().strip();replacement=g(['commit-tree',tree,'-p',base,'-m','sanitized replacement']).decode().strip();g(['replace',head,replacement])
p=subprocess.run([str(out/'scanner-harness'),str(r)],env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE); assert p.returncode==0,p.stderr
(out/'replace-scan.txt').write_bytes(p.stdout)
# Record the same object-reading commands as scan, then pack the immutable source identity.
ordinary=g(['cat-file','commit',head]); original=g(['--no-replace-objects','cat-file','commit',head]);
pack=g(['--no-replace-objects','pack-objects','--stdout','--revs'],(head+'\n^'+base+'\n').encode())
# Thin-free export includes base? No boundary excluding base causes missing parent on index-pack; unpack without connectivity check is valid.
export=out/'pack-fixture.git';g(['init','--bare','-q',str(export)]);g(['index-pack','--stdin'],pack,cwd=export)
raw=g(['cat-file','blob',head+':payload'],cwd=export)
results={'candidate':'0de454f05f8fbdf932fc841b5d696bfc7d9b0cca','git_version':g(['--version']).decode().strip(),'head':head,'replacement':replacement,'base':base,'scanner_output':p.stdout.decode(),'scanner_reads_replacement':b'sanitized replacement' in ordinary,'raw_commit_is_original':b'normal outgoing' in original,'exported_original_contains_synthetic_canary':b'SYNTHETIC_REVIEW_CANARY_123456' in raw,'network_push_executed':False,'pack_sha256':hashlib.sha256(pack).hexdigest()}
(out/'replace-results.json').write_text(json.dumps(results,indent=2));print(json.dumps(results,indent=2))
# Recording-only credential helper proof: exact candidate helper evaluated by git credential fill for two fictitious authorities.
src=Path('src/git/command.rs').read_text(); import re
helper=re.search(r'const ENV_HELPER: &str = (".*");',src).group(1); helper=json.loads(helper)
ce=env|{'GITCRAFT_GIT_USERNAME':'fixture-user','GITCRAFT_GIT_PASSWORD':'fixture-canary-password'}
answers=[]
for host in ['intended.example.invalid','unrelated.example.invalid']:
 c=subprocess.run([git,'-c','credential.helper=','-c',helper,'credential','fill'],input=('protocol=https\nhost='+host+'\n\n').encode(),env=ce,cwd=r,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 answers.append({'host':host,'code':c.returncode,'supplied_fixture_credential':b'password=fixture-canary-password' in c.stdout})
(out/'credential-results.json').write_text(json.dumps({'source_helper':helper,'answers':answers,'network':False},indent=2));print(json.dumps(answers))
