use std::collections::BTreeSet;
#[derive(Clone)]
pub struct Hunk {
    pub patch: String,
    pub digest: String,
    pub reviewed: bool,
}
fn digest(bytes: &[u8]) -> String {
    use sha2::{Digest, Sha256};
    Sha256::digest(bytes)
        .iter()
        .map(|b| format!("{b:02x}"))
        .collect()
}
fn split(raw: &str, known: &BTreeSet<String>) -> Vec<Hunk> {
    let mut out = Vec::new();
    let mut file = String::new();
    let mut header = String::new();
    let mut body = String::new();
    let flush = |out: &mut Vec<Hunk>, header: &String, body: &mut String, file: &String| {
        if body.is_empty() {
            return;
        }
        let stable = body
            .lines()
            .filter(|s| !s.starts_with("@@ "))
            .collect::<Vec<_>>()
            .join("\n");
        let key = digest(format!("{file}\n{stable}").as_bytes());
        out.push(Hunk {
            patch: format!("{header}{body}"),
            reviewed: known.contains(&key),
            digest: key,
        });
        body.clear();
    };
    for line in raw.split_inclusive('\n') {
        if line.starts_with("diff --git ") {
            flush(&mut out, &header, &mut body, &file);
            file = line.to_owned();
            header = line.to_owned();
        } else if line.starts_with("@@ ") || line.starts_with("GIT binary patch") {
            flush(&mut out, &header, &mut body, &file);
            body.push_str(line);
        } else if body.is_empty() {
            header.push_str(line);
        } else {
            body.push_str(line);
        }
    }
    flush(&mut out, &header, &mut body, &file);
    if !header.is_empty() && out.last().is_none_or(|h| !h.patch.starts_with(&header)) {
        let key = digest(header.as_bytes());
        out.push(Hunk {
            patch: header,
            reviewed: known.contains(&key),
            digest: key,
        });
    }
    out
}
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum Built {
    Running,
    Passed,
    Failed(i32),
}

fn read_status(text: Option<&str>) -> Built {
    match text.map(str::trim).map(str::parse::<i32>) {
        Some(Ok(0)) => Built::Passed,
        Some(Ok(code)) => Built::Failed(code),
        _ => Built::Running,
    }
}


#[test]
fn reviewing_first_identical_hunk_also_hides_second_location() {
 let raw="diff --git a/a.txt b/a.txt\nindex 111..222 100644\n--- a/a.txt\n+++ b/a.txt\n@@ -1,7 +1,7 @@\n a\n b\n c\n-old\n+new\n d\n e\n f\n@@ -20,7 +20,7 @@\n a\n b\n c\n-old\n+new\n d\n e\n f\n";
 let first=split(raw,&BTreeSet::new());
 assert_eq!(first.len(),2);
 assert_ne!(first[0].patch,first[1].patch);
 let known=BTreeSet::from([first[0].digest.clone()]);
 let reopened=split(raw,&known);
 assert!(reopened[0].reviewed);
 assert!(reopened[1].reviewed,"second distinct location inherits review");
 println!("FIRST-ONLY REVIEW falsely hides BOTH locations: {}",reopened[0].digest);
}
#[test]
fn changed_permission_header_stays_hidden() {
 let old="diff --git a/a.txt b/a.txt\nindex 111..222 100644\n--- a/a.txt\n+++ b/a.txt\n@@ -1 +1 @@\n-old\n+new\n";
 let changed="diff --git a/a.txt b/a.txt\nold mode 100644\nnew mode 100755\nindex 111..222\n--- a/a.txt\n+++ b/a.txt\n@@ -1 +1 @@\n-old\n+new\n";
 let first=split(old,&BTreeSet::new());
 let known=BTreeSet::from([first[0].digest.clone()]);
 let next=split(changed,&known);
 assert_eq!(next.len(),1);
 assert_ne!(next[0].patch,first[0].patch);
 assert!(next[0].reviewed,"new executable-bit change inherits prior review");
 println!("NEW executable permission change marked reviewed: {}",next[0].digest);
}
#[test]
fn missing_empty_and_unreadable_status_have_no_terminal_failure_state() {
 for status in [None,Some(""),Some("interrupted"),Some("999999999999999999999")] {assert_eq!(read_status(status),Built::Running);}
 assert_eq!(read_status(Some("0")),Built::Passed);
 assert_eq!(read_status(Some("1")),Built::Failed(1));
 println!("missing/empty/invalid receipts all => Running");
}

mod rollback_recording {
 use std::cell::RefCell;
 #[derive(Default)] struct World { name:Option<Vec<u8>>, spare:Option<Vec<u8>>, inject:bool, events:Vec<String> }
 thread_local! {static WORLD: RefCell<World> = RefCell::new(World::default());}
 struct Item {dir:(),name:String,spare:String,before:Option<Vec<u8>>,after:Option<Vec<u8>>,applied:bool}
 enum RenameFlags { EXCHANGE, NOREPLACE }
 fn renameat_with(_: &(), from:&str, _: &(), to:&str, flags:RenameFlags) -> Result<(),String> {
  WORLD.with(|s| {let mut w=s.borrow_mut();w.events.push(format!("rename {from} -> {to}"));match flags {
   RenameFlags::EXCHANGE => {let previous=w.name.take();w.name=w.spare.take();w.spare=previous;}
   RenameFlags::NOREPLACE => {if to=="spare" {if w.spare.is_some(){return Err("exists".into())} w.spare=w.name.take();}else{if w.name.is_some(){return Err("exists".into())} w.name=w.spare.take();}}
  }Ok(())})
 }
 impl Item {
  fn owned(&self)->Result<bool,String> {WORLD.with(|s| {let mut w=s.borrow_mut();let yes=w.name==self.after;w.events.push(format!("owned observes {yes}"));if w.inject {w.name=Some(b"external editor save".to_vec());w.inject=false;w.events.push("external writer changes name AFTER observation".into());}Ok(yes)})}
        fn rollback(&mut self) -> Result<(), String> {
            if !self.applied {
                return Ok(());
            }
            if !self.owned()? {
                return Err(format!(
                    "{} was edited concurrently; its new contents and the owned backup {} are retained",
                    self.name, self.spare
                ));
            }
            // The displaced file itself is the rollback payload, including a racing
            // writer's bytes. Never remove or replace it during rollback.
            match (&self.before, &self.after) {
                (Some(_), Some(_)) => renameat_with(
                    &self.dir,
                    self.spare.as_str(),
                    &self.dir,
                    self.name.as_str(),
                    RenameFlags::EXCHANGE,
                ),
                (Some(_), None) => renameat_with(
                    &self.dir,
                    self.spare.as_str(),
                    &self.dir,
                    self.name.as_str(),
                    RenameFlags::NOREPLACE,
                ),
                (None, Some(_)) => renameat_with(
                    &self.dir,
                    self.name.as_str(),
                    &self.dir,
                    self.spare.as_str(),
                    RenameFlags::NOREPLACE,
                ),
                (None, None) => return Ok(()),
            }
            .map_err(|e| format!("Rollback requires attention; backup {}: {e}", self.spare))?;
            self.applied = false;
            Ok(())
        }
 }
 #[test]
 fn exact_rollback_control_flow_reports_success_after_replacing_external_current_path() {
  WORLD.with(|s|*s.borrow_mut()=World{name:Some(b"our inverse".to_vec()),spare:Some(b"before".to_vec()),inject:true,events:vec![]});
  let mut item=Item{dir:(),name:"name".into(),spare:"spare".into(),before:Some(b"before".to_vec()),after:Some(b"our inverse".to_vec()),applied:true};
  assert_eq!(item.rollback(),Ok(()));assert!(!item.applied);
  WORLD.with(|s|{let w=s.borrow();assert_eq!(w.name.as_deref(),Some(b"before".as_slice()));assert_eq!(w.spare.as_deref(),Some(b"external editor save".as_slice()));println!("RECORDED rollback schedule: {:?}; returns Ok, external current contents moved to spare",w.events);});
 }
}
