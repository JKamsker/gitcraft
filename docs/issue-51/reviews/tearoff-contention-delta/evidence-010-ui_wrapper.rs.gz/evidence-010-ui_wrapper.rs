    fn ui(&mut self, ui: &mut Ui, frame: &mut eframe::Frame) {
        self.ui_tick(ui, Some(frame));
    }
