    fn logic(&mut self, ctx: &egui::Context, frame: &mut eframe::Frame) {
        self.logic_tick(ctx, Some(frame));
    }
