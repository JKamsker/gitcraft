    fn ui_tick(&mut self, ui: &mut Ui, frame: Option<&mut eframe::Frame>) {
        {
            let Ok(mut app) = self.app.try_lock() else {
                Self::defer_close(ui.ctx(), &mut self.deferred_close);
                Self::children(&self.app, &self.cache, ui.ctx());
                ui.ctx().request_repaint_after(Duration::from_millis(50));
                return;
            };
            if ui.ctx().embed_viewports() {
                for (_, mut window) in std::mem::take(&mut app.windows.parked) {
                    app.tabs.append(&mut window.tabs);
                }
            }
            app.window_ui(ui, frame);
        }
        Self::children(&self.app, &self.cache, ui.ctx());
    }
