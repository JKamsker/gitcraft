    pub(super) fn close_root_with_children(&mut self, ctx: &egui::Context) {
        self.root_close_request(ctx, ctx.input(|i| i.viewport().close_requested()));
    }
