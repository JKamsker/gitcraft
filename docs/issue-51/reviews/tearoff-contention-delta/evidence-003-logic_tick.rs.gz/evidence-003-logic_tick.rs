    fn logic_tick(&mut self, ctx: &egui::Context, frame: Option<&eframe::Frame>) {
        if let Ok(mut app) = self.app.try_lock() {
            if std::mem::take(&mut self.deferred_close) && !app.root_close_request(ctx, true) {
                // The request was delayed only while a native picker borrowed App.
                // Explicit Quit and an ordinary last-window close still complete.
                ctx.send_viewport_cmd(egui::ViewportCommand::Close);
            }
            app.tick_model(ctx, frame);
        } else {
            Self::defer_close(ctx, &mut self.deferred_close);
            ctx.request_repaint_after(Duration::from_millis(50));
        }
    }
