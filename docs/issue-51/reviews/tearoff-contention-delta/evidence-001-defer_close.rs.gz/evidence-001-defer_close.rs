    fn defer_close(ctx: &egui::Context, pending: &mut bool) {
        if ctx.viewport_id() == ViewportId::ROOT && ctx.input(|i| i.viewport().close_requested()) {
            ctx.send_viewport_cmd(egui::ViewportCommand::CancelClose);
            *pending = true;
        }
    }
