    fn root_close_request(&mut self, ctx: &egui::Context, requested: bool) -> bool {
        if !self.windows.quit_requested
            && self.windows.current == ViewportId::ROOT
            && (!self.windows.parked.is_empty() || self.window_has_dialog())
            && requested
        {
            ctx.send_viewport_cmd(egui::ViewportCommand::CancelClose);
            if !self.window_has_dialog() {
                ctx.send_viewport_cmd(egui::ViewportCommand::Visible(false));
                self.windows.root_hidden = true;
            }
            return true;
        }
        false
    }
