#![allow(dead_code)]
use std::{collections::BTreeMap,sync::{Arc,Mutex},time::Duration};
use egui::{Ui,ViewportId,ViewportCommand};
mod eframe {pub struct Frame;pub trait App {fn logic(&mut self,ctx:&egui::Context,frame:&mut Frame);fn ui(&mut self,ui:&mut egui::Ui,frame:&mut Frame);}}
mod adapter {
use super::*;
struct View {tabs:Vec<()>}
struct Windows {current:ViewportId,parked:BTreeMap<ViewportId,View>,quit_requested:bool,root_hidden:bool}
struct RecordedApp {windows:Windows,tabs:Vec<()>}
impl RecordedApp {
 fn window_has_dialog(&self)->bool{false}
 fn tick_model(&mut self,ctx:&egui::Context,_:Option<&eframe::Frame>){self.close_root_with_children(ctx);}
 fn window_ui(&mut self,ui:&mut Ui,_:Option<&mut eframe::Frame>){self.close_root_with_children(ui.ctx());}
    pub(super) fn close_root_with_children(&mut self, ctx: &egui::Context) {
        self.root_close_request(ctx, ctx.input(|i| i.viewport().close_requested()));
    }
    fn root_close_request(&mut self, ctx: &egui::Context, requested: bool) -> bool {
        if !self.windows.quit_requested
            && self.windows.current == ViewportId::ROOT
            && (!self.windows.parked.is_empty() || self.window_has_dialog())
            && requested
        {
            ctx.send_viewport_cmd(egui::ViewportCommand::CancelClose);
            if !self.window_has_dialog() {
                ctx.send_viewport_cmd(egui::ViewportCommand::Visible(false));
                self.windows.root_hidden = true;
            }
            return true;
        }
        false
    }
}
struct DesktopApp {app:Arc<Mutex<RecordedApp>>,cache:(),deferred_close:bool}
impl DesktopApp {
 fn children(_: &Arc<Mutex<RecordedApp>>,_:&(),_:&egui::Context){}
    fn logic_tick(&mut self, ctx: &egui::Context, frame: Option<&eframe::Frame>) {
        if let Ok(mut app) = self.app.try_lock() {
            if std::mem::take(&mut self.deferred_close) && !app.root_close_request(ctx, true) {
                // The request was delayed only while a native picker borrowed App.
                // Explicit Quit and an ordinary last-window close still complete.
                ctx.send_viewport_cmd(egui::ViewportCommand::Close);
            }
            app.tick_model(ctx, frame);
        } else {
            Self::defer_close(ctx, &mut self.deferred_close);
            ctx.request_repaint_after(Duration::from_millis(50));
        }
    }
    fn defer_close(ctx: &egui::Context, pending: &mut bool) {
        if ctx.viewport_id() == ViewportId::ROOT && ctx.input(|i| i.viewport().close_requested()) {
            ctx.send_viewport_cmd(egui::ViewportCommand::CancelClose);
            *pending = true;
        }
    }
    fn ui_tick(&mut self, ui: &mut Ui, frame: Option<&mut eframe::Frame>) {
        {
            let Ok(mut app) = self.app.try_lock() else {
                Self::defer_close(ui.ctx(), &mut self.deferred_close);
                Self::children(&self.app, &self.cache, ui.ctx());
                ui.ctx().request_repaint_after(Duration::from_millis(50));
                return;
            };
            if ui.ctx().embed_viewports() {
                for (_, mut window) in std::mem::take(&mut app.windows.parked) {
                    app.tabs.append(&mut window.tabs);
                }
            }
            app.window_ui(ui, frame);
        }
        Self::children(&self.app, &self.cache, ui.ctx());
    }
}
impl eframe::App for DesktopApp {
    fn logic(&mut self, ctx: &egui::Context, frame: &mut eframe::Frame) {
        self.logic_tick(ctx, Some(frame));
    }
    fn ui(&mut self, ui: &mut Ui, frame: &mut eframe::Frame) {
        self.ui_tick(ui, Some(frame));
    }
}
pub fn check(){
 use eframe::App as _;
 for through_ui in [false,true] {
  for (quit,children) in [(false,true),(true,true),(false,false)] {
   let ctx=egui::Context::default();ctx.set_embed_viewports(false);
   let owner=Arc::new(Mutex::new(RecordedApp{windows:Windows{current:ViewportId::ROOT,parked:if children {BTreeMap::from([(ViewportId::from_hash_of("live-child"),View{tabs:vec![()]})])}else{BTreeMap::new()},quit_requested:quit,root_hidden:false},tabs:vec![()]}));
   let mut d=DesktopApp{app:owner.clone(),cache:(),deferred_close:false};let mut frame=eframe::Frame;
   let held=owner.lock().unwrap();let mut raw=egui::RawInput::default();let info=raw.viewports.entry(ViewportId::ROOT).or_default();info.minimized=Some(true);info.events.push(egui::ViewportEvent::Close);
   if through_ui {let out=ctx.run_ui(raw,|ui|d.ui(ui,&mut frame));assert!(out.viewport_output[&ViewportId::ROOT].commands.contains(&ViewportCommand::CancelClose));out.drop_without_applying_deltas();}
   else {let out=ctx.run_logic(&raw,|ctx|d.logic(ctx,&mut frame));assert!(out.viewport_commands[&ViewportId::ROOT].contains(&ViewportCommand::CancelClose));}
   assert!(d.deferred_close);drop(held);
   let out=ctx.run_logic(&egui::RawInput::default(),|ctx|d.logic(ctx,&mut frame));let cmds=&out.viewport_commands[&ViewportId::ROOT];
   if !quit&&children {assert!(cmds.contains(&ViewportCommand::CancelClose));assert!(cmds.contains(&ViewportCommand::Visible(false)));assert!(!cmds.contains(&ViewportCommand::Close));assert_eq!(owner.lock().unwrap().windows.parked.len(),1);}
   else {assert!(cmds.contains(&ViewportCommand::Close));assert!(!cmds.contains(&ViewportCommand::CancelClose));}
   assert!(!d.deferred_close);
   let out=ctx.run_logic(&egui::RawInput::default(),|ctx|d.logic(ctx,&mut frame));assert!(!out.viewport_commands.get(&ViewportId::ROOT).is_some_and(|c|c.contains(&ViewportCommand::Close)));assert!(!d.deferred_close);
  }
  println!("PASS exact {} entry: held-owner Close cancelled/remembered; replay keeps children, permits explicit Quit and last-window close; no duplicate replay.",if through_ui{"ROOT UI"}else{"logic"});
 }
}
}
fn main(){adapter::check();}
