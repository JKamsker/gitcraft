#![allow(dead_code)]
extern crate self as egui;
#[derive(Clone,Default)] pub struct Context;
impl Context { pub fn request_repaint(&self) {} }
mod remote { pub fn is_remote(_: &std::path::Path)->bool {false} }
mod safe_read {
 pub fn read_inside(root:&std::path::Path,file:&str,limit:u64)->Option<Vec<u8>> {
  let b=std::fs::read(root.join(file)).ok()?;(b.len() as u64<=limit).then_some(b)
 }
}
mod shell_path {pub fn apply(_: &mut std::process::Command) {}}
mod git {
 #[derive(Clone)] pub struct Remote {pub name:String,pub url:String}
 pub static VALUE:std::sync::Mutex<Result<String,String>>=std::sync::Mutex::new(Ok(String::new()));
 pub static CALLS:std::sync::atomic::AtomicUsize=std::sync::atomic::AtomicUsize::new(0);
 pub fn run_unattended_within(_: &std::path::Path,args:&[&str],limit:std::time::Duration)->Result<String,String> {
  assert_eq!(args,["config","--local","--no-includes","--get-all","remote.fork.url"]);
  assert_eq!(limit,std::time::Duration::from_secs(20));CALLS.fetch_add(1,std::sync::atomic::Ordering::SeqCst);
  VALUE.lock().unwrap().clone()
 }
}
mod processes {
 pub type Chunk=Box<dyn FnMut(&[u8])+Send>;
 #[derive(Default)] pub struct Options {pub timeout:Option<std::time::Duration>,pub background:bool,pub output_limit:usize,pub stderr:Option<Chunk>,pub stdout:Option<Chunk>}
 pub struct Output {pub stdout:Vec<u8>,pub status:std::process::ExitStatus,pub stopped:Option<String>}
 pub static RECORDS:std::sync::Mutex<Vec<Vec<String>>>=std::sync::Mutex::new(Vec::new());
 pub fn run(command:std::process::Command,mut options:Options)->Result<Output,String> {
  use std::os::unix::process::ExitStatusExt;
  assert_eq!(command.get_program(),"never-executed-act");
  assert!(command.get_current_dir().unwrap().join("workflow.yml").is_file());
  let args:Vec<_>=command.get_args().map(|s|s.to_string_lossy().into_owned()).collect();
  for pair in [["--remote-name","fork"],["--github-instance","github.com"],["--env","GITHUB_REPOSITORY=owner/repo"],["--env","GITHUB_REPOSITORY_OWNER=owner"]] {assert!(args.windows(2).any(|a|a==pair),"{pair:?}");}
  for k in ["GH_TOKEN","GITHUB_TOKEN","GH_ENTERPRISE_TOKEN","GITLAB_TOKEN","GLAB_TOKEN","GITEA_TOKEN","TEA_TOKEN","AZURE_DEVOPS_EXT_PAT"] {assert!(command.get_envs().any(|(n,v)|n==k&&v.is_none()));}
  assert_eq!(options.output_limit,8<<20);assert_eq!(options.timeout,Some(std::time::Duration::from_secs(60)));
  // Simulate a post-validation remote edit without invoking Git. Immutable argv must retain pins.
  *crate::git::VALUE.lock().unwrap()=Ok("https://github.com/changed/repository.git\n".into());
  options.stdout.as_mut().unwrap()(b"live stdout\n");options.stderr.as_mut().unwrap()(b"live stderr\n");
  RECORDS.lock().unwrap().push(args);
  Ok(Output {stdout:b"live stdout\n".to_vec(),status:std::process::ExitStatus::from_raw(0),stopped:None})
 }
}
#[path="/tmp/gitcraft-act-r2-12e7641c-t2c19ce3/src/repo/local_ci/context.rs"] mod context;
#[path="/tmp/gitcraft-act-r2-12e7641c-t2c19ce3/src/repo/local_ci/model.rs"] mod model;
#[path="/tmp/gitcraft-act-r2-12e7641c-t2c19ce3/src/repo/local_ci/run.rs"] mod run;
fn capture(url:&str)->Result<context::Context,String> {context::Context::capture("fork",&[git::Remote {name:"fork".into(),url:url.into()}])}
fn select()->run::Selection {
 let workflow=model::parse(".github/workflows/test.yml".into(),"on: push\njobs: {test: {runs-on: ubuntu-latest, steps: [{run: echo hi}]}}\n".into()).unwrap();
 let matrix=workflow.matrices("test").unwrap().remove(0);
 run::Selection {workflow,context:capture("https://github.com/owner/repo.git").unwrap(),event:"push".into(),job:"test".into(),matrix,payload:"{}".into(),platforms:"ubuntu-latest=trusted/image:v1".into(),architecture:"linux/amd64".into(),minutes:0}
}
fn main() {
 let w=model::parse("w.yml".into(),"on: push\njobs: {test: {strategy: {matrix: {os: [linux, windows], exclude: [{os: linux}], include: [{os: linux, foo: one}, {bar: two}]}}}}".into()).unwrap();
 let e=w.matrices("test").unwrap();assert_eq!(e.len(),2);assert_eq!(e[0]["bar"].as_str(),Some("two"));assert_eq!(e[1]["os"].as_str(),Some("linux"));assert_eq!(e[1]["bar"],yaml_rust2::Yaml::BadValue);
 let w2=model::parse("w.yml".into(),w.snapshot("push","test",&e[1],"r2").unwrap()).unwrap();assert_eq!(w2.matrices("test").unwrap(),vec![e[1].clone()]);
 let w=model::parse("w.yml".into(),"on: push\njobs: {test: {strategy: {matrix: {fruit: [apple, pear], animal: [cat, dog], include: [{color: green}, {color: pink, animal: cat}, {fruit: apple, shape: circle}, {fruit: banana}, {fruit: banana, animal: cat}]}}}}".into()).unwrap();
 let e=w.matrices("test").unwrap();assert_eq!(e.len(),6);assert_eq!(e[0]["color"].as_str(),Some("pink"));assert_eq!(e[1]["color"].as_str(),Some("green"));assert_eq!(e[4]["animal"],yaml_rust2::Yaml::BadValue);
 println!("PASS P: deferred extra row and exact snapshot; official six-entry include example");
 for u in ["https://github.com/owner/repo.git","git@github.com:owner/repo.git","ssh://git@github.com/owner/repo.git"] {let c=capture(u).unwrap();assert_eq!(c.repository,"owner/repo");assert!(c.display().contains(u));c.revalidate_with(|_|Ok(format!("{u}\n"))).unwrap();}
 for u in ["https://enterprise.example/owner/repo","git@alias:owner/repo","https://github.com:443/owner/repo","https://user:secret@github.com/owner/repo","https://github.com/owner/repo?token=secret","https://github.com/owner/repo/path","https://github.com/owner/repo#secret"] {assert!(capture(u).is_err(),"{u}");}
 assert!(context::Context::capture("missing",&[]).is_err());
 let c=capture("https://github.com/owner/repo.git").unwrap();for reply in [Ok("https://github.com/other/repo.git\n".into()),Ok("https://github.com/owner/repo.git\nhttps://github.com/owner/repo.git\n".into()),Err("secret raw error".into())] {assert!(!c.revalidate_with(|_|reply.clone()).unwrap_err().contains("secret"));}
 println!("PASS P/R: direct URL scope, displayed identity, exact config argv, changed/multiple/missing refusal");
 let own=run::Scratch::new().unwrap();let task_home=own.0.join("owned-home");std::fs::create_dir(&task_home).unwrap();
 // Owned single-process synthetic env, restored by process exit; no child fixture.
 unsafe {std::env::set_var("HOME",&task_home);std::env::set_var("XDG_CONFIG_HOME",task_home.join("xdg"));std::env::set_var("APPDATA",task_home.join("appdata"));}
 let work=own.0.join("worktree with spaces");std::fs::create_dir_all(work.join(".github/workflows")).unwrap();std::fs::write(work.join(&select().workflow.file),&select().workflow.source).unwrap();
 let log=std::sync::Arc::new(std::sync::Mutex::new(run::Log::default()));
 let invoke=||run::execute_with(work.clone(),select(),log.clone(),Context,std::ffi::OsStr::new("never-executed-act"));
 *git::VALUE.lock().unwrap()=Ok("https://github.com/changed/repo.git\n".into());assert!(invoke().unwrap_err().contains("changed"));assert!(processes::RECORDS.lock().unwrap().is_empty());
 *git::VALUE.lock().unwrap()=Err("secret".into());assert!(!invoke().unwrap_err().contains("secret"));assert!(processes::RECORDS.lock().unwrap().is_empty());
 *git::VALUE.lock().unwrap()=Ok("https://github.com/owner/repo.git\n".into());invoke().unwrap();assert_eq!(processes::RECORDS.lock().unwrap().len(),1);assert_eq!(log.lock().unwrap().text,"live stdout\nlive stderr\n");
 println!("PASS R/M: worker config refusal precedes recording act; pinned argv survives synthetic later edit; live callbacks, no duplicate final stdout");
 let mut opt=run::options(&select(),&log,&Context);for _ in 0..300 {opt.stdout.as_mut().unwrap()(&[b'x';8192]);}let l=log.lock().unwrap();assert!(l.truncated);assert!(l.text.len()<=2<<20);assert!(l.rows.len()<=32768);drop(l);
 println!("PASS M: repeated 8 KiB callbacks retain bounded text/rows");
 std::fs::write(work.join(&select().workflow.file),"changed").unwrap();assert!(invoke().unwrap_err().contains("changed since selection"));assert_eq!(processes::RECORDS.lock().unwrap().len(),1);
 println!("PASS R: stale workflow refusal before any further endpoint");
 println!("LIMITS: stubs for Git, process service, egui, shell path, safe_read; no children, act, Docker, cancellation, HTTP or credential execution");
}
