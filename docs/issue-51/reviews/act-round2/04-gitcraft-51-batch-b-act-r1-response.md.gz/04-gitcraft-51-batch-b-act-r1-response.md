# Actions R1 correction candidate

Candidate: 12e7641c917d92482788f5f8a3449ffca425f83f, t3/issue51-batch-b. Required author/committer verified and fork remote branch SHA equals candidate. Status: preserved WIP / focused checks validated / independent R2 pending. Includes rich correction 53832430 (separate R2) and requested shared credential API integration ad85d184 + 37092103 (transport blocker remains owner-managed).

## Finding responses / source coverage

R1-1: src/repo/local_ci/model.rs:160 keeps unmatched includes in extras until completion, so later includes only modify remaining original combinations. Tests at tests.rs:317 cover exclude/reintroduce/later include, exact selected snapshot and official six-entry example. Primary protocol reference: https://github.com/nektos/act/blob/2540ba6c49dfbafe167d655e4044921cd2ed19e7/pkg/model/workflow.go#L409.

R1-2: context.rs:11 requires an actual cached configured remote; accepts explicit direct GitHub.com HTTPS or git SSH URLs, validates a plain owner/repo and rejects credentials, URL parameters, other hosts, custom ports and aliases with explicit supported-scope explanation. UI mod.rs:339 shows accepted fetch URL + github.com + owner/repo. Its display identity invalidates trust; mod.rs:465 refuses changed displayed context before worker submission. Captured Context binds exact name/URL/slug. Worker run.rs:262 confirms a single literal local URL through no-includes Git config, with 20-second deadline and inherited task cancellation. Missing/changed/ambiguous/include-only URL refuses launch without exposing raw Git error text. run.rs:134 pins --github-instance github.com and explicit GITHUB_REPOSITORY / GITHUB_REPOSITORY_OWNER environment arguments, preventing act fallback or a later remote edit from silently changing these repository fields. This pin uses pinned official act source pkg/runner/run_context.go:970 and model/github_context.go:168 (only derives remote when explicit repository is empty). No atomic Git-config lock or frozen worktree promise; current application files are intentionally used. Remote fetch-vs-push distinction remains visible; hosted routing unchanged. Enterprise execution is explicitly refused, not claimed supported. Tests at tests.rs:344 and :485 record exact config query/changed+missing+ambiguous replies, accepted/rejected URL forms, pinned args and stale displayed state without subprocesses.

R1-3: ci_view/mod.rs:124 invokes local_ci_context_default on hosted and local entry; local_ci/mod.rs:405 applies current branch push remote then origin/first fallback only while no explicit override or operation. Text edit marks override. Rendering also updates late-loaded defaults. tests.rs:431 covers hosted first, override preservation and local first.

R1-4: processes.rs adopts ONLY Options.stdout: Option<Chunk>, default None, exact consume helper and stdout normal/post-ready/drain dispatch from owner fb56988503377bd8cfcd36cc35c0cfc63c36c931. Chunk remains Box<dyn FnMut(&[u8]) + Send>; bounded capture untouched. No other supervisor/remote termination APIs adopted. local_ci/run.rs:314 installs both stdout/stderr callbacks into bounded shared UI Log and requests repaint; completed stdout no longer appended a second time. tests.rs:467 invokes callbacks manually before any Output/result and checks bounds. No process-service runtime/pipe/cancellation proof from this gate.

## Exact candidate gates

Commands include environment CARGO_BUILD_JOBS=2 TMPDIR=/private/tmp PATH=/tmp/gitcraft-integration-tools:$PATH SHELL=/tmp/gitcraft-integration-tools/validation-shell.

- cargo +1.95.0 test --lib repo::local_ci:: -- --test-threads=2: 12 passed, 1 ignored. Pure model/recording closures/headless UI/manual callbacks only. Log /tmp/gitcraft-51-act-r1-corrected-12e7641c-0.log.
- cargo +1.95.0 clippy --lib -- -D warnings -A dead_code: FAIL on imported setup-owned src/app/clone.rs:224 collapsible_if. Log ...-1.log. Not represented as a passing qualified lint.
- cargo +1.95.0 clippy --lib -- -D warnings -A dead_code -A clippy::collapsible_if: PASS, narrowly further-qualified gate. Log ...-2.log. No strict lint claim.

Structured commands/status and logs also in /tmp/gitcraft-51-batch-b-validation.json. Current worktree clean; no CI/PR invocation or dev/master/tag push.

## Execution inventory and limits

Earlier 052721ed evidence contains seven focused checks and one separately invoked actual owned fake-act subprocess gate before current hold. It did not run act or Docker. No cancellation runtime gate claimed. Earlier rich metadata gates include synthetic archives and loopback HTTP fixtures; no real registry or forge writes. Rich Find tests are pure/headless. At 37092103, credential_scope filter inadvertently ran one pure scope test plus one actual owned Git credential-fill test (eight dummy endpoint cases) through process service; all passed, reported immediately to parent and not counted as recording-only or hold clearance. Parent acknowledged correction. It proves neither redirect isolation nor production LFS credential lookup safety; shared transport blocker is still open. No more child fixtures, actual process, network, act/Docker, cancellation tests were executed for corrected Act candidate. Existing ignored fake-act fixture was adjusted for mandatory local-remote validation but was NOT rerun.

Real act/container compatibility, actual streaming timing/pipe draining, cancellation, Docker resource lifecycle, Windows/Linux/GHES and live external runtimes remain unexecuted. Runtime hold unchanged; parent owns combined checks/review and shared supervisor/setup correction integration. Full batch B remaining b4, Jira/Linear, GitLab, Azure/Bitbucket, devcontainers are not claimed complete by this correction unit.
