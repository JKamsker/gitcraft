# Jira / Linear unit (implementation candidate, unreviewed)

Application commit: 9d8f54cf9c58ad70182a88e961dc40ec2356c02e. Exact Jonas author/committer and origin write URL JKamsker/gitcraft verified; remote refs/heads/t3/issue51-batch-b matched. Prior rich538 / Act12e accepted scoped fixes preserved. GitLab652 remains independently blocked only by GL-R1-1, corrected in a following unit.

Original #43 start-from-issue requirement coverage:
- Browse assigned unresolved Jira Cloud issues: src/trackers/mod.rs Client::viewer/listed, own account email verified, currentUser JQL via POST /rest/api/3/search/jql, opaque nextPageToken, source-qualified stable issue ID and key. Repeated/missing continuation refuses; list explicitly capped at existing 100 with picker notice.
- Browse assigned active Linear issues: same module, exact https://api.linear.app/graphql with personal API key; viewer.id/email, viewer.assignedIssues cursor pagination, completed/canceled excluded, each returned assignee verified; GraphQL errors reject partial data.
- Reachable sources: existing Start work from an issue command (now available without a recognized forge), picker source selector Repository forge/Jira/Linear, retry/filter/keyboard/selection retained. Row-index selection avoids external UUIDs or team-number collisions being mistaken for forge numbers. Existing forge issue parsing receives only tracker=None.
- Branch/worktree: existing issue_work::start_issue/start_ops reused; tracker identifiers become readable branch prefixes, all existing base selection/worktree/dirty-change warnings remain. Original Git branch/worktree runtime tests compile but were NOT run.
- Acceptance criteria remain visible: Jira description ADF text/task/table/link/code/heading and optional customfield_N criteria render to reading text; unsupported nodes are explicitly marked and deep/oversize documents return errors, not false missing criteria. Linear Markdown flows into the existing criteria extraction/card. Branch config persists safe source identity plus criteria/read date, legacy numeric links remain readable. Refresh binds source origin/account/stable viewer+issue IDs and ignores changed-profile/unlinked callbacks.
- PR links back: external issue links produce `Relates to KEY: URL`, never `Closes #0`; legacy forge links keep `Closes #N`.
- Profile account/credentials: additive defaulted Choices.jira/linear under immutable Context propagation. Settings Profile connections edits origin/email/optional Jira criteria field, transient password input, worker-only keyring save/forget, reference-only serialization. No git Credentials helper reuse. Direct HTTPS client refuses redirects and sends selected header only to configured origin; this is code/recording coverage, not live credential acceptance.

Supported limits: Jira Cloud REST3 email+API-token and Linear personal API key only; no Jira Data Center or Linear OAuth configuration. Secure store disabled in portable mode is an explicit error. The list shows the first 100. Blocking HTTP uses a 30-second request bound and cancellation checks between requests/after response; it does not claim immediate socket interruption. No secret export, live tracker, actual keyring, Git/helper, network, native/process, browser, CI or PR fixture executed. Shared credential-policy acceptance remains parent/owner work and is not recertified by this feature.

Immutable gates (all PASS):
- cargo +1.95.0 test --offline --lib trackers::tests:: -- --test-threads=2 (6 pure/recording)
- cargo +1.95.0 test --offline --lib repo::issue_work::picker::tests:: -- --test-threads=2 (4 pure)
- cargo +1.95.0 test --offline --lib repo::issue_work::link::tests:: -- --test-threads=2 (5 pure)
- cargo +1.95.0 check --offline --all-targets
- cargo +1.95.0 clippy --offline --lib -- -D warnings -A dead_code (qualified, not strict)
Logs: /tmp/gitcraft-51-trackers-9d8f54cf-{0..4}.log; commands/SHA/exit classifications in /tmp/gitcraft-51-batch-b-validation.json. CARGO_BUILD_JOBS=2 and required TMPDIR/PATH/SHELL normalization used.

Official source semantics consulted read-only:
https://developer.atlassian.com/cloud/jira/platform/rest/v3/api-group-issue-search/#api-rest-api-3-search-jql-post
https://linear.app/developers/graphql
https://linear.app/developers/filtering
https://linear.app/developers/pagination

Finite remaining original batch-B checklist: GL-R1-1 outdated/unmapped discussion controls; Azure DevOps+Bitbucket native providers; b4 email receive/prepare/reroll/preview/send; per-worktree devcontainer start/rebuild/terminal/editor. No new adjacent work added.
