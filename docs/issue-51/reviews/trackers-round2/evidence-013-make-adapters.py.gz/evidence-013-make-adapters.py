from pathlib import Path
import hashlib,json
s=Path('/tmp/gitcraft-trackers-r2-f9f4-source'); e=Path('/tmp/gitcraft-trackers-r2-f9f4-evidence')
def function(text,needle):
 a=text.index(needle); brace=text.index('{',a);n=1;i=brace+1
 while n:
  n+=(text[i]=='{')-(text[i]=='}');i+=1
 return text[a:i]
forge=(s/'src/forge/mod.rs').read_text(); picker=(s/'src/repo/issue_work/picker.rs').read_text(); tracker=(s/'src/trackers/mod.rs').read_text(); link=(s/'src/repo/issue_work/link.rs').read_text()
identity=function(forge,'    pub(crate) fn identity('); row=function(picker,'fn issue_row('); parse=function(tracker,'    fn parse('); adf=function(tracker,'fn adf('); required=function(tracker,"fn required<'a>(")
old=Path('/tmp/gitcraft-trackers-r1-9d8f-evidence/rows-headless.rs').read_text();start=old.index('fn issue_row(');end=old.index('\nfn frame',start);old=old[:start]+row+old[end:]
old=old.replace('#[derive(Clone)]struct Issue{number:u64,title:String,labels:Vec<String>,url:String,key:String}', '#[derive(Clone)]struct Identity{kind:String,origin:String,id:String}\n#[derive(Clone)]struct Issue{number:u64,title:String,labels:Vec<String>,url:String,key:String,tracker:Option<Identity>}')
old=old.replace('impl Issue{fn key(&self)->String{self.key.clone()}}','impl Issue{fn key(&self)->String{self.key.clone()}'+identity+'}')
old=old.replace('i.number));','i.identity()));').replace('key:k.into()}', 'key:k.into(),tracker:Some(Identity{kind:"linear".into(),origin:"https://api.linear.app".into(),id:k.into()})}')
old=old.replace('println!("pointer click target={target} -> row clicks={clicks:?}");','println!("pointer click target={target} -> row clicks={clicks:?}");assert_eq!(clicks,vec![target==0,target==1]);')
(e/'rows-headless.rs').write_text(old)
criteria=(s/'src/repo/issue_work/criteria.rs').read_text(); criteria=criteria[criteria.index('/// At most'):criteria.index('#[cfg(test)]')]; a=criteria.index('pub(crate) fn plain(');brace=criteria.index('{',a);n=1;i=brace+1
while n:
 n+=(criteria[i]=='{')-(criteria[i]=='}');i+=1
criteria=criteria[:a]+criteria[i:]
head='''#![allow(dead_code)]
use serde_json::{Value,json};
#[derive(Clone,Copy)]enum Kind{Jira,Linear}
struct Account{origin:String,user:String,acceptance_field:String}
struct Client{kind:Kind,account:Account}
#[derive(Clone)]struct Identity{kind:Kind,origin:String,account:String,viewer:String,id:String,key:String}
struct Issue{number:u64,title:String,body:String,url:String,labels:Vec<String>,tracker:Option<Identity>,acceptance:Option<String>}
'''
linkstruct=link[link.index('#[derive(Clone, Debug, Default'):link.index('impl IssueLink')].replace('#[derive(Clone, Debug, Default, PartialEq, Eq)]','#[derive(Clone)]')
linkstruct=linkstruct.replace('crate::trackers::Identity','Identity')
of=function(link,'    pub(crate) fn of(')
main=r'''
fn main(){
let mut c=Client{kind:Kind::Jira,account:Account{origin:"https://site.atlassian.net".into(),user:"alice@example.org".into(),acceptance_field:"customfield_10001".into()}};
let mut v=json!({"id":"10001","key":"APP-42","fields":{"summary":"Work","description":{"type":"doc","content":[{"type":"heading","attrs":{"level":2},"content":[{"type":"text","text":"Acceptance criteria"}]},{"type":"paragraph","content":[{"type":"text","text":"old description requirement"}]}]},"customfield_10001":{"type":"doc","content":[{"type":"heading","attrs":{"level":2},"content":[{"type":"text","text":"New requirements"}]},{"type":"taskList","content":[{"type":"taskItem","attrs":{"state":"TODO"},"content":[{"type":"text","text":"selected custom-field requirement"}]}]}]}}});
let issue=c.parse(&v,"viewer").unwrap();let link=link::IssueLink::of(&issue);
assert_eq!(issue.body,"## Acceptance criteria\nold description requirement");assert!(!issue.body.contains("selected custom-field"));assert_eq!(link.criteria,"## New requirements\n\n- [ ] selected custom-field requirement");assert_eq!(link.kept,criteria::Kept::Criteria);assert!(criteria::lines(&link.criteria).iter().any(|l|matches!(l,criteria::Line::Task{text,..} if text=="selected custom-field requirement")));println!("configured field -> kept card data {:?}; original description preserved",link.criteria);
c.account.acceptance_field.clear();assert_eq!(link::IssueLink::of(&c.parse(&v,"viewer").unwrap()).criteria,"old description requirement");println!("unset field -> existing description extraction");
c.account.acceptance_field="customfield_10001".into();v["fields"]["customfield_10001"]=Value::Null;let empty=link::IssueLink::of(&c.parse(&v,"viewer").unwrap());assert_eq!(empty.kept,criteria::Kept::Criteria);assert!(empty.criteria.is_empty());assert!(criteria::lines(&empty.criteria).is_empty());println!("null selected field -> explicitly empty criteria");
v["fields"].as_object_mut().unwrap().remove("customfield_10001");assert!(c.parse(&v,"viewer").unwrap_err_or_string().contains("configured criteria field"));
}
'''
# Avoid requiring Debug on inert Issue for error assertion.
main=main.replace('assert!(c.parse(&v,"viewer").unwrap_err_or_string().contains("configured criteria field"));','assert!(matches!(c.parse(&v,"viewer"),Err(e) if e.contains("configured criteria field")));println!("absent selected field -> explicit error");\nv["fields"]["customfield_10001"]=json!("日本語".repeat(2000));let capped=link::IssueLink::of(&c.parse(&v,"viewer").unwrap());assert_eq!(capped.criteria.chars().count(),4002);assert!(capped.criteria.ends_with("\\n…"));\nv["fields"]["customfield_10001"]=json!("- [ ] requirement\\n".repeat(100));let capped=link::IssueLink::of(&c.parse(&v,"viewer").unwrap());assert_eq!(capped.criteria.lines().count(),61);assert!(capped.criteria.ends_with("…"));println!("selected field -> existing 4000-character/60-line card caps and visible ellipsis");')
(e/'criteria-pure.rs').write_text(head+required+'\nimpl Client{'+parse+'}\n'+adf+'\nmod criteria{'+criteria+'}\nmod link{use super::{Identity,Issue};use super::criteria::Kept;'+linkstruct+'impl IssueLink{'+of+'}fn today()->String{"recorded-date".into()}}\n'+main)
(e/'source-seams.json').write_text(json.dumps({k:hashlib.sha256(v.encode()).hexdigest() for k,v in {'issue_row':row,'Issue::identity':identity,'Client::parse':parse,'adf':adf,'required':required,'IssueLink::of':of}.items()},indent=2)+'\n')
