#![allow(dead_code)]
use serde_json::{Value,json};
#[derive(Clone,Copy)]enum Kind{Jira,Linear}
struct Account{origin:String,user:String,acceptance_field:String}
struct Client{kind:Kind,account:Account}
#[derive(Clone)]struct Identity{kind:Kind,origin:String,account:String,viewer:String,id:String,key:String}
struct Issue{number:u64,title:String,body:String,url:String,labels:Vec<String>,tracker:Option<Identity>,acceptance:Option<String>}
fn required<'a>(v: &'a Value, path: &str) -> Result<&'a str, String> {
    v.pointer(path)
        .and_then(Value::as_str)
        .filter(|s| !s.is_empty())
        .ok_or_else(|| format!("Tracker response is missing {path}"))
}
impl Client{    fn parse(&self, v: &Value, viewer: &str) -> Result<Issue, String> {
        let id = required(v, "/id")?.to_owned();
        let mut acceptance = None;
        let (key, title, body, url, labels) = match self.kind {
            Kind::Jira => {
                let key = required(v, "/key")?.to_owned();
                if !key.bytes().all(|b| b.is_ascii_alphanumeric() || b == b'-') {
                    return Err("Jira returned an invalid issue key".into());
                }
                let body = adf(v.pointer("/fields/description").unwrap_or(&Value::Null))?;
                if !self.account.acceptance_field.is_empty() {
                    let value=v.pointer(&format!("/fields/{}",self.account.acceptance_field)).ok_or("Jira did not return the configured criteria field; verify the field and account permissions")?;
                    acceptance = Some(adf(value)?);
                }
                (
                    key.clone(),
                    required(v, "/fields/summary")?.to_owned(),
                    body,
                    format!("{}/browse/{key}", self.account.origin.trim_end_matches('/')),
                    v.pointer("/fields/labels")
                        .and_then(Value::as_array)
                        .map(|a| {
                            a.iter()
                                .filter_map(Value::as_str)
                                .map(str::to_owned)
                                .collect()
                        })
                        .unwrap_or_default(),
                )
            }
            Kind::Linear => {
                let url = required(v, "/url")?.to_owned();
                let u = url::Url::parse(&url).map_err(|_| "Invalid Linear issue URL")?;
                if u.scheme() != "https"
                    || u.host_str() != Some("linear.app")
                    || !u.username().is_empty()
                    || u.password().is_some()
                {
                    return Err("Linear returned an unexpected issue URL".into());
                }
                (
                    required(v, "/identifier")?.to_owned(),
                    required(v, "/title")?.to_owned(),
                    v.get("description")
                        .and_then(Value::as_str)
                        .unwrap_or_default()
                        .to_owned(),
                    url,
                    v.pointer("/labels/nodes")
                        .and_then(Value::as_array)
                        .map(|a| {
                            a.iter()
                                .filter_map(|l| l.get("name").and_then(Value::as_str))
                                .map(str::to_owned)
                                .collect()
                        })
                        .unwrap_or_default(),
                )
            }
        };
        Ok(Issue {
            number: 0,
            acceptance,
            title,
            body,
            url,
            labels,
            tracker: Some(Identity {
                kind: self.kind,
                origin: self.account.origin.trim_end_matches('/').into(),
                account: self.account.user.clone(),
                viewer: viewer.into(),
                id,
                key,
            }),
        })
    }}
fn adf(v: &Value) -> Result<String, String> {
    fn walk(v: &Value, depth: usize, out: &mut String) -> Result<(), String> {
        if depth > 64 || out.len() > 4 * 1024 * 1024 {
            return Err("Jira document exceeds the supported reading bound".into());
        }
        if v.is_null() {
            return Ok(());
        }
        if let Some(s) = v.as_str() {
            out.push_str(s);
            return Ok(());
        }
        let kind = v
            .get("type")
            .and_then(Value::as_str)
            .ok_or("Unsupported Jira document value")?;
        match kind {
            "text" => out.push_str(v.get("text").and_then(Value::as_str).unwrap_or_default()),
            "hardBreak" => out.push('\n'),
            "rule" => out.push_str("\n---\n"),
            "mention" | "emoji" => out.push_str(
                v.pointer("/attrs/text")
                    .or_else(|| v.pointer("/attrs/shortName"))
                    .and_then(Value::as_str)
                    .unwrap_or("[mention]"),
            ),
            "heading" => out.push_str(&format!(
                "\n{} ",
                "#".repeat(
                    v.pointer("/attrs/level")
                        .and_then(Value::as_u64)
                        .unwrap_or(2)
                        .min(6) as usize
                )
            )),
            "listItem" => out.push_str("\n- "),
            "taskItem" => out.push_str(
                if v.pointer("/attrs/state").and_then(Value::as_str) == Some("DONE") {
                    "\n- [x] "
                } else {
                    "\n- [ ] "
                },
            ),
            "codeBlock" => out.push_str("\n```\n"),
            "tableCell" | "tableHeader" => out.push_str(" | "),
            "inlineCard" | "blockCard" => out.push_str(
                v.pointer("/attrs/url")
                    .and_then(Value::as_str)
                    .unwrap_or("[card]"),
            ),
            "doc" | "paragraph" | "bulletList" | "orderedList" | "taskList" | "table"
            | "tableRow" | "blockquote" | "panel" => {}
            other => out.push_str(&format!("[Unsupported Jira node: {other}] ")),
        }
        if let Some(children) = v.get("content").and_then(Value::as_array) {
            for c in children {
                walk(c, depth + 1, out)?;
            }
        }
        match kind {
            "paragraph" | "heading" | "tableRow" => out.push('\n'),
            "codeBlock" => out.push_str("\n```\n"),
            _ => {}
        }
        if kind == "text"
            && let Some(marks) = v.get("marks").and_then(Value::as_array)
        {
            for m in marks {
                if m.get("type").and_then(Value::as_str) == Some("link")
                    && let Some(href) = m.pointer("/attrs/href").and_then(Value::as_str)
                {
                    out.push_str(&format!(" ({href})"));
                }
            }
        }
        Ok(())
    }
    let mut out = String::new();
    walk(v, 0, &mut out)?;
    Ok(out.trim().to_owned())
}
mod criteria{/// At most this many characters are kept.
const MAX_CHARS: usize = 4000;
/// At most this many lines.
const MAX_LINES: usize = 60;
/// What the end of a description that was cut says.
const CUT: &str = "…";

/// Which part of the description was kept.
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub(crate) enum Kept {
    /// The section headed "Acceptance criteria" (or "Definition of done").
    #[default]
    Criteria,
    /// Its task list, gathered from wherever it is.
    Tasks,
    /// All of it.
    Description,
}

impl Kept {
    /// How it's kept in git's config.
    pub(crate) fn key(self) -> &'static str {
        match self {
            Kept::Criteria => "criteria",
            Kept::Tasks => "tasks",
            Kept::Description => "description",
        }
    }

    /// What [`Kept::key`] gave. A link written before there was one says nothing: the card
    /// calls what it kept the criteria then, as it always did.
    pub(crate) fn from_key(key: &str) -> Kept {
        match key.trim() {
            "tasks" => Kept::Tasks,
            "description" => Kept::Description,
            _ => Kept::Criteria,
        }
    }

    /// "the acceptance criteria", for the card's tooltips.
    pub(crate) fn what(self) -> &'static str {
        match self {
            Kept::Criteria => "the acceptance criteria",
            Kept::Tasks => "the task list",
            Kept::Description => "the description",
        }
    }
}

/// The part of `body` (an issue's Markdown) to keep in view, and which part it is: the section
/// headed "Acceptance criteria" (a `#` heading, a line in bold or one ending in `:`), else every
/// task-list item (`- [ ] …`), else all of it; HTML comments (which issue templates are full of)
/// left out. Empty when there is nothing.
pub(crate) fn extract(body: &str) -> (Kept, String) {
    let body = without_comments(&body.replace("\r\n", "\n"));
    let lines: Vec<&str> = body.lines().collect();
    let (kept, picked) = match criteria_section(&lines) {
        Some(section) => (Kept::Criteria, section),
        None => match tasks(&lines) {
            Some(items) => (Kept::Tasks, items),
            None => (Kept::Description, lines.clone()),
        },
    };
    (kept, cap(&trim_blank(&picked).join("\n")))
}

/// Whether a task is ticked.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(crate) enum Tick {
    Open,
    Done,
    /// GitLab's `- [~]`: it no longer applies.
    Dropped,
}

/// One line of what is kept, as the card shows it.
#[derive(Clone, Debug, PartialEq, Eq)]
pub(crate) enum Line {
    /// A task-list item.
    Task {
        tick: Tick,
        text: String,
    },
    /// An item of a plain list.
    Bullet(String),
    Text(String),
    Blank,
}

/// `text` (what [`extract`] kept) line by line, list markers and heading marks taken off.
pub(crate) fn lines(text: &str) -> Vec<Line> {
    text.lines().map(line).collect()
}

fn line(raw: &str) -> Line {
    let text = raw.trim();
    if text.is_empty() {
        return Line::Blank;
    }
    if let Some((tick, rest)) = task(text) {
        return Line::Task {
            tick,
            text: rest.to_owned(),
        };
    }
    if let Some(rest) = list_item(text) {
        return Line::Bullet(rest.to_owned());
    }
    Line::Text(text.trim_start_matches('#').trim().to_owned())
}

/// `markdown` (one line of it) as the text it reads as: links as their text, no `**`, `_` or
/// backticks around words. As it was when Markdown makes nothing of it (`---`).


/// What follows a list marker (`-`, `*`, `+`, `1.`, `1)`), if `text` starts with one.
fn list_item(text: &str) -> Option<&str> {
    if let Some(rest) = text.strip_prefix(['-', '*', '+'])
        && rest.starts_with(' ')
    {
        return Some(rest.trim_start());
    }
    let digits = text.find(|c: char| !c.is_ascii_digit())?;
    let rest = text[digits..].strip_prefix(['.', ')'])?;
    (digits > 0 && rest.starts_with(' ')).then(|| rest.trim_start())
}

/// Whether `text` is a task-list item, and if so how it's ticked and what it says.
fn task(text: &str) -> Option<(Tick, &str)> {
    let rest = list_item(text.trim_start())?;
    let tick = match rest.get(..3)? {
        "[ ]" => Tick::Open,
        "[x]" | "[X]" => Tick::Done,
        "[~]" => Tick::Dropped,
        _ => return None,
    };
    Some((tick, rest[3..].trim()))
}

/// The rank of a line in bold: below every `#` heading.
const BOLD: usize = 7;
/// The rank of a line ending in `:`, below all: one can start the section ("Acceptance
/// criteria:"), but none ends one ("When offline:" is a line of it).
const COLON: usize = 8;

/// The lines under the "Acceptance criteria" heading, up to the next heading of its kind (one
/// of the same level or higher, for a `#` heading; a `#` heading or a line in bold, for the
/// others). `None` when there is no such section, or nothing in it.
fn criteria_section<'a>(lines: &[&'a str]) -> Option<Vec<&'a str>> {
    let headings = headings(lines);
    let (start, level) = headings
        .iter()
        .find(|(i, _)| is_criteria_title(&heading_text(lines[*i])))
        .copied()?;
    let ends_at = level.min(BOLD);
    let end = headings
        .iter()
        .find(|(i, l)| *i > start && *l <= ends_at)
        .map_or(lines.len(), |(i, _)| *i);
    let section = trim_blank(&lines[start + 1..end]);
    (!section.is_empty()).then_some(section)
}

/// Whether each of `lines` is in fenced code (its fences too).
fn fenced(lines: &[&str]) -> Vec<bool> {
    let mut in_fence = false;
    lines
        .iter()
        .map(|raw| {
            let text = raw.trim();
            if text.starts_with("```") || text.starts_with("~~~") {
                in_fence = !in_fence;
                return true;
            }
            in_fence
        })
        .collect()
}

/// The headings among `lines`, outside fenced code: (line, level). A `#` heading has its
/// number of `#`s; a line all in bold, or one ending in `:` that isn't a list item, ranks below
/// them all ([`BOLD`], [`COLON`]).
fn headings(lines: &[&str]) -> Vec<(usize, usize)> {
    let code = fenced(lines);
    let mut found = Vec::new();
    for (i, raw) in lines.iter().enumerate() {
        if code[i] {
            continue;
        }
        let text = raw.trim();
        if let Some(level) = hash_level(text) {
            found.push((i, level));
        } else if is_bold_line(text) {
            found.push((i, BOLD));
        } else if text.ends_with(':') && list_item(text).is_none() {
            found.push((i, COLON));
        }
    }
    found
}

/// `## x` → 2: the level of a `#` heading.
fn hash_level(text: &str) -> Option<usize> {
    let level = text.chars().take_while(|c| *c == '#').count();
    let rest = &text[level..];
    ((1..=6).contains(&level) && (rest.is_empty() || rest.starts_with(' '))).then_some(level)
}

fn is_bold_line(text: &str) -> bool {
    let inner = text
        .strip_prefix("**")
        .and_then(|t| t.strip_suffix("**"))
        .or_else(|| text.strip_prefix("__").and_then(|t| t.strip_suffix("__")));
    inner.is_some_and(|t| !t.trim().is_empty())
}

/// A heading's words: `## Acceptance Criteria:` → `acceptance criteria`.
fn heading_text(raw: &str) -> String {
    raw.trim()
        .trim_start_matches('#')
        .trim_matches(|c: char| c == '*' || c == '_' || c == ':' || c.is_whitespace())
        .to_lowercase()
}

/// Wherever it says so in the heading: `3. Acceptance criteria`, `✅ Definition of Done`.
fn is_criteria_title(text: &str) -> bool {
    ["acceptance criteri", "definition of done"]
        .iter()
        .any(|title| text.contains(title))
}

/// Every task-list item outside fenced code, or `None` without one.
fn tasks<'a>(lines: &[&'a str]) -> Option<Vec<&'a str>> {
    let code = fenced(lines);
    let items: Vec<&str> = lines
        .iter()
        .zip(code)
        .filter(|(l, code)| !code && task(l).is_some())
        .map(|(l, _)| *l)
        .collect();
    (!items.is_empty()).then_some(items)
}

/// `lines` without the blank ones at either end.
fn trim_blank<'a>(lines: &[&'a str]) -> Vec<&'a str> {
    let blank = |l: &&str| l.trim().is_empty();
    let start = lines.iter().position(|l| !blank(l)).unwrap_or(lines.len());
    let end = lines
        .iter()
        .rposition(|l| !blank(l))
        .map_or(start, |i| i + 1);
    lines[start..end].to_vec()
}

/// `text` without its `<!-- … -->` comments (an unclosed one runs to the end).
fn without_comments(text: &str) -> String {
    let mut out = String::with_capacity(text.len());
    let mut rest = text;
    while let Some(start) = rest.find("<!--") {
        out.push_str(&rest[..start]);
        rest = match rest[start..].find("-->") {
            Some(end) => &rest[start + end + 3..],
            None => "",
        };
    }
    out.push_str(rest);
    out
}

/// `text` cut to [`MAX_LINES`] lines and [`MAX_CHARS`] characters (on a character's
/// boundary), marked as cut when it was.
pub(super) fn cap(text: &str) -> String {
    let mut cut = false;
    let mut kept: String = text
        .lines()
        .enumerate()
        .take_while(|(i, _)| {
            cut |= *i >= MAX_LINES;
            *i < MAX_LINES
        })
        .map(|(_, l)| l.trim_end())
        .collect::<Vec<_>>()
        .join("\n");
    if kept.chars().count() > MAX_CHARS {
        kept = kept.chars().take(MAX_CHARS).collect();
        cut = true;
    }
    if cut {
        kept = format!("{}\n{CUT}", kept.trim_end());
    }
    kept
}

}
mod link{use super::{Identity,Issue};use super::criteria::Kept;#[derive(Clone)]
pub(crate) struct IssueLink {
    pub tracker: Option<Identity>,
    pub number: u64,
    pub title: String,
    pub url: String,
    pub criteria: String,
    pub kept: Kept,
    /// The day it was read, empty for a link written before gitcraft kept it.
    pub read: String,
}

impl IssueLink{    pub(crate) fn of(issue: &Issue) -> IssueLink {
        let (kept, criteria) = issue.acceptance.as_ref().map_or_else(
            || super::criteria::extract(&issue.body),
            |field| (Kept::Criteria, super::criteria::cap(field.trim())),
        );
        IssueLink {
            tracker: issue.tracker.clone(),
            number: issue.number,
            title: issue.title.trim().to_owned(),
            url: issue.url.clone(),
            criteria,
            kept,
            read: today(),
        }
    }}fn today()->String{"recorded-date".into()}}

fn main(){
let mut c=Client{kind:Kind::Jira,account:Account{origin:"https://site.atlassian.net".into(),user:"alice@example.org".into(),acceptance_field:"customfield_10001".into()}};
let mut v=json!({"id":"10001","key":"APP-42","fields":{"summary":"Work","description":{"type":"doc","content":[{"type":"heading","attrs":{"level":2},"content":[{"type":"text","text":"Acceptance criteria"}]},{"type":"paragraph","content":[{"type":"text","text":"old description requirement"}]}]},"customfield_10001":{"type":"doc","content":[{"type":"heading","attrs":{"level":2},"content":[{"type":"text","text":"New requirements"}]},{"type":"taskList","content":[{"type":"taskItem","attrs":{"state":"TODO"},"content":[{"type":"text","text":"selected custom-field requirement"}]}]}]}}});
let issue=c.parse(&v,"viewer").unwrap();let link=link::IssueLink::of(&issue);
assert_eq!(issue.body,"## Acceptance criteria\nold description requirement");assert!(!issue.body.contains("selected custom-field"));assert_eq!(link.criteria,"## New requirements\n\n- [ ] selected custom-field requirement");assert_eq!(link.kept,criteria::Kept::Criteria);assert!(criteria::lines(&link.criteria).iter().any(|l|matches!(l,criteria::Line::Task{text,..} if text=="selected custom-field requirement")));println!("configured field -> kept card data {:?}; original description preserved",link.criteria);
c.account.acceptance_field.clear();assert_eq!(link::IssueLink::of(&c.parse(&v,"viewer").unwrap()).criteria,"old description requirement");println!("unset field -> existing description extraction");
c.account.acceptance_field="customfield_10001".into();v["fields"]["customfield_10001"]=Value::Null;let empty=link::IssueLink::of(&c.parse(&v,"viewer").unwrap());assert_eq!(empty.kept,criteria::Kept::Criteria);assert!(empty.criteria.is_empty());assert!(criteria::lines(&empty.criteria).is_empty());println!("null selected field -> explicitly empty criteria");
v["fields"].as_object_mut().unwrap().remove("customfield_10001");assert!(matches!(c.parse(&v,"viewer"),Err(e) if e.contains("configured criteria field")));println!("absent selected field -> explicit error");
v["fields"]["customfield_10001"]=json!("日本語".repeat(2000));let capped=link::IssueLink::of(&c.parse(&v,"viewer").unwrap());assert_eq!(capped.criteria.chars().count(),4002);assert!(capped.criteria.ends_with("\n…"));
v["fields"]["customfield_10001"]=json!("- [ ] requirement\n".repeat(100));let capped=link::IssueLink::of(&c.parse(&v,"viewer").unwrap());assert_eq!(capped.criteria.lines().count(),61);assert!(capped.criteria.ends_with("…"));println!("selected field -> existing 4000-character/60-line card caps and visible ellipsis");
}
