from pathlib import Path
import json,hashlib
s=Path('/tmp/gitcraft-history-integration-r3-99808ef2');e=Path('/tmp/gitcraft-history-integration-r3-evidence');e.mkdir(exist_ok=True)
def read(p):return (s/p).read_text()
def between(t,a,b):return t[t.index(a):t.index(b,t.index(a))]
def fn(t,name):
 a=t.index(name);b=t.index('\n}\n',a)+3;return t[a:b]
c=read('src/git/command.rs');o=read('src/repo/operations.rs');ep=read('src/git/command/endpoints.rs');pf=read('src/push_preflight.rs');hooks=read('src/git/hooks.rs')
for name,p in [('scope.rs','src/git/credential_scope.rs'),('policy.rs','src/git/command/credential_policy.rs')]:
 (e/name).write_text(read(p).split('#[cfg(test)]')[0])
code=r'''#![allow(dead_code,unused_imports)]
use std::sync::Arc;
mod connections {
 #[derive(Clone,Debug,PartialEq,Eq)]pub struct Choices{pub ssh_key:String}
 #[derive(Clone,Debug,PartialEq,Eq)]pub struct Context{pub error:Option<String>,pub choices:Choices,pub git_config:Option<std::path::PathBuf>}
 pub fn current()->Context{Context{error:None,choices:Choices{ssh_key:"selected-key".into()},git_config:Some("/recorded/profile.gitconfig".into())}}
}
mod practice {pub fn is_repository(p:&std::path::Path)->bool{p==std::path::Path::new("/recorded/practice")}}
mod diagnostics{pub mod crash{pub fn scrub(s:&str)->String{s.into()}}}
mod remote {
 use std::path::Path;#[derive(Clone)]pub enum Host{Ssh(String)}pub struct Target{pub host:Host,pub path:String}
 pub struct Request{pub cwd:Option<String>,pub script:String,pub env:Vec<(String,String)>,pub unset:Vec<String>,pub stdin:Option<Vec<u8>>,pub long:bool,pub timeout:Option<std::time::Duration>,pub test:bool,pub apart:bool}
 pub fn is_remote(p:&Path)->bool{p.to_string_lossy().starts_with("remote:")}
 pub fn sh_quote(s:&str)->String{format!("'{}'",s.replace('\'',"'\"'\"'"))}
}
mod git {
 use std::{path::{Path,PathBuf},process::Command,sync::Mutex};use crate::remote::{self,Target};
 #[derive(Clone)]pub struct Credentials{pub username:String,pub password:String,pub scope:Option<CredentialScope>}
 #[path="/tmp/gitcraft-history-integration-r3-evidence/scope.rs"]mod credential_scope;pub use credential_scope::{CredentialScope,CREDENTIAL_HELPER};
 #[path="/tmp/gitcraft-history-integration-r3-evidence/policy.rs"]mod credential_policy;use credential_policy::*;
 pub mod hooks {
 const TRACE_VAR:&str="GIT_TRACE2_EVENT";const MARK:&str="@@gitcraft-hook-events@@";
'''+fn(hooks,'pub(super) fn traced_script_with_program(')+r'''
 }
'''
# Exact production builder data/policy functions; no executable-discovering builder is embedded.
for a,b in [('pub(super) const GIT_ENV:', '/// A tab\'s explicit repository'),('pub(super) const REPOSITORY_ENV_REMOVED:', 'pub(super) fn git_cmd()'),('#[derive(Clone, Default)]\npub(super) struct Extra','/// How long a diff or merge tool')]:code+=between(c,a,b)
for n in ['fn user_global_config(','fn after_options','pub(super) fn with_profile(','pub(super) fn apply_command_extras(']:code+=fn(c,n)
code+=between(c,'const TOOL_FOR:', '/// Runs git')
code+=between(c,'pub(super) const CONNECTION_REDIRECT_ENV:','/// The request that runs git')
code+=fn(c,'pub(super) fn remote_request(')
code+=between(c,'pub(crate) struct PushTarget','pub(crate) fn push_preflight_with(')
code+=fn(c,'fn reviewed_push_extra(')+fn(c,'fn preflight_credentials(')
code+=between(c,'const PREFLIGHT_REMOVE:','fn execute_preflight(')
code+=r'''fn goes_over_network(a:&[&str])->bool{after_options(a).first()==Some(&"push")}
'''
code+=between(ep,'#[derive(Clone, Debug, serde::Serialize','impl RouteBinding {')
code+='impl RouteBinding{'+between(ep,'    pub fn authorizes_endpoint','    pub fn verify')+'}\n'
code+=between(ep,'#[derive(Clone)]\npub(crate) struct AuthFailure','fn safe_http_url')
code+=r'''pub struct OpControl{failure:Mutex<Option<AuthFailure>>} impl OpControl{pub fn new()->Self{Self{failure:Mutex::new(None)}}pub fn authentication_failed(&self,f:AuthFailure){*self.failure.lock().unwrap()=Some(f)}pub fn auth_failure(&self)->Option<AuthFailure>{self.failure.lock().unwrap().clone()}}
 pub fn check_command_policy(){
 let words=["push","--porcelain","--force-with-lease=refs/heads/main:old","--","private","oid:refs/heads/main"];
 let creds=Credentials::for_url("https://push.invalid/team/repo","alice".into(),"DUMMY_ONLY".into()).unwrap();
 let target=||PushTarget{address:"https://push.invalid/team/repo",alias:"private",original_remote:"original",skip_hooks:false,lfs_config:&[],lfs_objects:&[],receive_pack:""};
 let extra=reviewed_push_extra(Path::new("/recorded/repo"),&words,target(),"/recorded/hooks".into(),Some(&creds)).unwrap();
 let mut selected=Command::new("/recorded/actual/git");selected.env("GIT_DIR","foreign");clear_repository_environment(&mut selected);
 let command=apply_command_extras(selected,Some(Path::new("/recorded/repo")),&extra,&words);
 let env=command.get_envs().map(|(k,v)|(k.to_string_lossy().into_owned(),v.map(|v|v.to_string_lossy().into_owned()))).collect::<std::collections::BTreeMap<_,_>>();
 assert_eq!(env["GIT_DIR"],None);assert_eq!(env["GIT_CONFIG_GLOBAL"],Some("/recorded/profile.gitconfig".into()));assert_eq!(env["GIT_CONFIG_COUNT"],Some("10".into()));assert_eq!(env["GITCRAFT_GIT_ORIGINAL"],Some("/recorded/actual/git".into()));assert_eq!(env["GIT_NO_REPLACE_OBJECTS"],Some("1".into()));
 assert_eq!(env["GIT_SSH_COMMAND"],None);assert_eq!(env["GIT_CONFIG_VALUE_9"],Some("/recorded/hooks".into()));
 let args=command.get_args().map(|a|a.to_string_lossy().into_owned()).collect::<Vec<_>>();assert!(args.ends_with(&words.map(String::from)));assert_eq!(args.iter().filter(|s|s.as_str()=="gitcraft-credential-transport").count(),1);assert!(!args.join(" ").contains("DUMMY_ONLY"));
 for trace in [false,true]{let mut x=extra.clone();x.trace_hooks=trace;let req=remote_request(&Target{host:remote::Host::Ssh("never-contacted.invalid".into()),path:"/recorded/repo".into()},&x,&words);assert!(req.script.starts_with(CREDENTIAL_REMOTE_PIN));assert!(req.script.contains("\"$GITCRAFT_GIT_ORIGINAL\""));assert!(req.unset.contains(&"GIT_CONFIG_COUNT".into()));assert!(req.env.contains(&("GIT_CONFIG_COUNT".into(),"10".into())));}
 let x=Extra{normalize_repository:true,unset:vec!["GIT_INDEX_FILE"],env:vec![("GIT_INDEX_FILE","/recorded/private.index".into())],..Default::default()};let cmd=apply_command_extras(Command::new("/recorded/git"),Some(Path::new("/recorded/practice")),&x,&["status"]);let env=cmd.get_envs().collect::<std::collections::BTreeMap<_,_>>();assert!(!env.contains_key(std::ffi::OsStr::new("GIT_CONFIG_GLOBAL")));assert_eq!(env[std::ffi::OsStr::new("GIT_INDEX_FILE")],Some(std::ffi::OsStr::new("/recorded/private.index")));
 }
}
mod push_preflight{use std::{collections::BTreeMap,sync::{Mutex,OnceLock,atomic::{AtomicU64,Ordering}}};
'''+between(pf,'const AUTH_ENDPOINT:', '#[cfg(test)]\npub(super) fn recording_input')+'}\n'
code+=r'''use git::hooks;
const EXPECT_HTTPS_ROUTE:&str="--gitcraft-expect-https-route";
'''
for n in ['fn run_reviewed_push(','fn reviewed_auth_failure(','fn check_https_routes(','fn with_rechecked_preparation(']:code+=fn(o,n)
code+=r'''
#[cfg(test)]mod tests{
 use super::*;use std::cell::Cell;
 fn route()->git::RouteBinding{serde_json::from_value(serde_json::json!({"args":["push","--","original","oid:refs/heads/main"],"routes":["https://push.invalid/team/repo"],"configuration":"captured"})).unwrap()}
 #[test]fn exact_command_policy_preserves_owned_config_selected_program_and_practice_exception(){git::check_command_policy()}
 #[test]fn original_route_capture_precedes_dispatch_and_missing_proof_never_dispatches(){let b=route();let called=Cell::new(false);let c=Arc::new(git::OpControl::new());let r=run_reviewed_push(&b.args,|a|{assert_eq!(a,b.args.iter().map(String::as_str).collect::<Vec<_>>());Err("no proof".into())},||{called.set(true);Ok(String::new())},Some(&c));assert!(r.is_err());assert!(!called.get());assert!(c.auth_failure().is_none());}
 #[test]fn exact_receipt_binds_authoritative_route_context_and_is_one_shot(){let b=route();let c=Arc::new(git::OpControl::new());let receipt=push_preflight::remember_auth_endpoint("https://push.invalid/team/repo");let capture=Cell::new(false);let r=run_reviewed_push(&b.args,|a|{assert_eq!(a[2],"original");capture.set(true);Ok(b.clone())},||{assert!(capture.get());Err(receipt.clone())},Some(&c));assert_eq!(r,Err(receipt.clone()));let f=c.auth_failure().unwrap();assert_eq!(f.context,connections::current());assert_eq!(f.endpoints,["https://push.invalid/team/repo"]);assert_eq!(f.binding,Some(b));assert!(f.confirmed);assert!(push_preflight::take_auth_endpoint(&receipt).is_none());}
 #[test]fn foreign_and_expired_receipts_do_not_authorize_recovery(){let b=route();for url in ["https://fetch.invalid/team/repo","https://push.invalid/other","http://push.invalid/team/repo","https://push.invalid/team/repo/info/lfs"]{let receipt=push_preflight::remember_auth_endpoint(url);assert!(reviewed_auth_failure(&receipt,b.clone(),connections::current()).is_none());assert!(push_preflight::take_auth_endpoint(&receipt).is_none());}let stale=push_preflight::remember_auth_endpoint("https://push.invalid/team/repo");push_preflight::take_auth_endpoint(&stale);assert!(reviewed_auth_failure(&stale,b,connections::current()).is_none());}
 #[test]fn route_proof_is_rechecked_after_draft_and_malformed_proof_refuses(){let b=route();let ops=vec![vec![EXPECT_HTTPS_ROUTE.into(),serde_json::to_string(&b).unwrap()]];let n=Cell::new(0);let current=Cell::new(true);let r=with_rechecked_preparation(||check_https_routes(&ops,|x|{assert_eq!(x,&b);n.set(n.get()+1);if current.get(){Ok(())}else{Err("changed during draft".into())}}),||{current.set(false);Ok(())});assert!(r.is_err());assert_eq!(n.get(),2);assert!(check_https_routes(&[vec![EXPECT_HTTPS_ROUTE.into(),"invalid".into()]],|_|panic!("malformed proof must not dispatch")).is_err());}
}
'''
(e/'review.rs').write_text(code)
(e/'seams.json').write_text(json.dumps({'source_root':str(s),'exact_items':['scope/policy production modules before cfg(test)','command data and fixed-Command policy/extras/environment/remote request/private push helpers','RouteBinding data + authorizes_endpoint','AuthFailure data','reviewed receipt store','run_reviewed_push','reviewed_auth_failure','check_https_routes','with_rechecked_preparation'],'inert_substitutions':['fixed connections Context','practice membership predicate','remote request types and quoting','recording OpControl Mutex','diagnostic scrub identity'],'excluded':['git_cmd/local_command/repository_command execution','metadata acquisition','application constructors','actual process/transport/native requests','shell string execution']},indent=2)+'\n')
print(e/'review.rs')
