#![allow(dead_code,unused_imports)]
use std::sync::Arc;
mod connections {
 #[derive(Clone,Debug,PartialEq,Eq)]pub struct Choices{pub ssh_key:String}
 #[derive(Clone,Debug,PartialEq,Eq)]pub struct Context{pub error:Option<String>,pub choices:Choices,pub git_config:Option<std::path::PathBuf>}
 pub fn current()->Context{Context{error:None,choices:Choices{ssh_key:"selected-key".into()},git_config:Some("/recorded/profile.gitconfig".into())}}
}
mod practice {pub fn is_repository(p:&std::path::Path)->bool{p==std::path::Path::new("/recorded/practice")}}
mod diagnostics{pub mod crash{pub fn scrub(s:&str)->String{s.into()}}}
mod remote {
 use std::path::Path;#[derive(Clone)]pub enum Host{Ssh(String)}pub struct Target{pub host:Host,pub path:String}
 pub struct Request{pub cwd:Option<String>,pub script:String,pub env:Vec<(String,String)>,pub unset:Vec<String>,pub stdin:Option<Vec<u8>>,pub long:bool,pub timeout:Option<std::time::Duration>,pub test:bool,pub apart:bool}
 pub fn is_remote(p:&Path)->bool{p.to_string_lossy().starts_with("remote:")}
 pub fn sh_quote(s:&str)->String{format!("'{}'",s.replace('\'',"'\"'\"'"))}
}
mod git {
 use std::{path::{Path,PathBuf},process::Command,sync::Mutex};use crate::remote::{self,Target};
 #[derive(Clone)]pub struct Credentials{pub username:String,pub password:String,pub scope:Option<CredentialScope>}
 #[path="/tmp/gitcraft-history-integration-r3-evidence/scope.rs"]mod credential_scope;pub use credential_scope::{CredentialScope,CREDENTIAL_HELPER};
 #[path="/tmp/gitcraft-history-integration-r3-evidence/policy.rs"]mod credential_policy;use credential_policy::*;
 pub mod hooks {
 const TRACE_VAR:&str="GIT_TRACE2_EVENT";const MARK:&str="@@gitcraft-hook-events@@";
pub(super) fn traced_script_with_program(words: &str, program: &str) -> String {
    format!(
        concat!(
            ": {program} {words}\n",
            "t=\"${{T:+$T/hook-events}}\"\n",
            "if [ -n \"$t\" ] && : >\"$t\" 2>/dev/null; then {var}=\"$t\" {program} {words}\n",
            "else t=; {program} {words}; fi\n",
            "r=$?\n",
            "if [ -n \"$t\" ]; then\n",
            "  printf '\\n%s\\n' '{mark}' >&2; grep -F '\"child_' \"$t\" >&2; rm -f \"$t\"\n",
            "fi\n",
            "exit $r",
        ),
        program = program,
        var = TRACE_VAR,
        words = words,
        mark = MARK,
    )
}

 }
pub(super) const GIT_ENV: [(&str, &str); 4] = [
    ("GIT_TERMINAL_PROMPT", "0"),
    ("GIT_OPTIONAL_LOCKS", "0"),
    ("GIT_EDITOR", "true"),
    ("LANGUAGE", "C"),
];

/// Interactive rebases set `sequence.editor` themselves; an inherited one would win.
pub(super) const GIT_ENV_REMOVED: [&str; 1] = ["GIT_SEQUENCE_EDITOR"];

pub(super) const REPOSITORY_ENV_REMOVED: &[&str] = &[
    "GIT_DIR",
    "GIT_COMMON_DIR",
    "GIT_WORK_TREE",
    "GIT_INDEX_FILE",
    "GIT_OBJECT_DIRECTORY",
    "GIT_ALTERNATE_OBJECT_DIRECTORIES",
    "GIT_NAMESPACE",
    "GIT_SHALLOW_FILE",
    "GIT_REPLACE_REF_BASE",
    "GIT_CONFIG",
    "GIT_CONFIG_COUNT",
    "GIT_CONFIG_PARAMETERS",
    "GIT_ATTR_SOURCE",
];

/// Pure environment portion of the shared selected-repository command builder.
fn clear_repository_environment(cmd: &mut Command) {
    for name in REPOSITORY_ENV_REMOVED {
        cmd.env_remove(name);
    }
}

#[derive(Clone, Default)]
pub(super) struct Extra {
    /// Normalize before installing intentional command-owned environment.
    normalize_repository: bool,
    unset: Vec<&'static str>,
    output_limit: Option<usize>,
    stdout_file: Option<PathBuf>,
    pre: Vec<&'static str>,
    owned_pre: Vec<String>,
    env: Vec<(&'static str, String)>,
    /// What git reads on its input; nothing when `None`.
    stdin: Option<Vec<u8>>,
    /// It may take minutes (a large bundle): on another machine, run where that is allowed.
    long: bool,
    /// It starts a program the user works in (a diff or merge tool) and waits until it closes.
    tool: bool,
    /// Find out which hook failed, if one does (see [`super::hooks`]).
    trace_hooks: bool,
    /// On another machine: a test of a parallel bisect (see [`run_for_test`]).
    test: Option<std::time::Duration>,
    /// How long it may run on another machine before it is stopped there.
    timeout: Option<std::time::Duration>,
}

fn user_global_config(args: &[&str]) -> bool {
    let rest = after_options(args);
    (rest.first() == Some(&"config") && rest.contains(&"--global"))
        // `maintenance start` / `register` write `maintenance.repo` to the global config.
        || (rest.first() == Some(&"maintenance")
            && matches!(rest.get(1), Some(&("start" | "register" | "unregister" | "stop"))))
}
fn after_options<'a>(args: &'a [&'a str]) -> &'a [&'a str] {
    let mut rest = args;
    loop {
        match rest {
            ["-c" | "-C", _, tail @ ..] => rest = tail,
            [word, tail @ ..] if word.starts_with('-') => rest = tail,
            _ => return rest,
        }
    }
}
pub(super) fn with_profile(cmd: &mut Command, args: &[&str]) {
    if user_global_config(args) {
        return;
    }
    let context = crate::connections::current();
    if context.error.is_some() {
        cmd.arg("-c").arg("=invalid-profile");
        return;
    }
    if !context.choices.ssh_key.is_empty() {
        cmd.env_remove("GIT_SSH_COMMAND")
            .env_remove("GIT_SSH")
            .env_remove("GIT_SSH_VARIANT");
    }
    let path = context.git_config;
    if let Some(path) = path {
        cmd.env("GIT_CONFIG_GLOBAL", path);
    }
}
pub(super) fn apply_command_extras(
    mut cmd: Command,
    dir: Option<&Path>,
    extra: &Extra,
    args: &[&str],
) -> Command {
    for name in &extra.unset {
        cmd.env_remove(name);
    }
    if extra.normalize_repository && !dir.is_some_and(crate::practice::is_repository) {
        normalize_connection_command(&mut cmd, args);
    }
    cmd.args(&extra.pre).args(&extra.owned_pre);
    for (name, value) in &extra.env {
        cmd.env(name, value);
    }
    if extra
        .owned_pre
        .iter()
        .any(|arg| arg == "gitcraft-credential-transport")
    {
        let selected = cmd.get_program().to_owned();
        cmd.env("GITCRAFT_GIT_ORIGINAL", selected);
    }
    cmd.args(args);
    cmd
}
const TOOL_FOR: std::time::Duration = std::time::Duration::from_secs(12 * 3600);

pub(super) const CONNECTION_REDIRECT_ENV: &[&str] = &[
    "GIT_DIR",
    "GIT_WORK_TREE",
    "GIT_COMMON_DIR",
    "GIT_INDEX_FILE",
    "GIT_OBJECT_DIRECTORY",
    "GIT_ALTERNATE_OBJECT_DIRECTORIES",
    "GIT_NAMESPACE",
    "GIT_CONFIG",
    "GIT_CONFIG_GLOBAL",
    "GIT_CONFIG_SYSTEM",
    "GIT_CONFIG_COUNT",
    "GIT_CONFIG_PARAMETERS",
    "GIT_CONFIG_NOSYSTEM",
];
fn normalize_connection_command(cmd: &mut Command, args: &[&str]) {
    for name in CONNECTION_REDIRECT_ENV {
        cmd.env_remove(name);
    }
    for (name, _) in std::env::vars_os() {
        let text = name.to_string_lossy();
        if text.starts_with("GIT_CONFIG_KEY_") || text.starts_with("GIT_CONFIG_VALUE_") {
            cmd.env_remove(name);
        }
    }
    // Intentional immutable profile config is reinstalled after inherited config is removed.
    with_profile(cmd, args);
}

pub(super) fn remote_request(target: &Target, extra: &Extra, args: &[&str]) -> remote::Request {
    let words: Vec<String> = extra
        .pre
        .iter()
        .copied()
        .chain(extra.owned_pre.iter().map(String::as_str))
        .chain(args.iter().copied())
        .map(remote::sh_quote)
        .collect();
    let credential_transport = extra
        .owned_pre
        .iter()
        .any(|arg| arg == "gitcraft-credential-transport");
    let pin = if credential_transport {
        CREDENTIAL_REMOTE_PIN
    } else {
        ""
    };
    let script = if extra.trace_hooks {
        let program = if credential_transport {
            "\"$GITCRAFT_GIT_ORIGINAL\""
        } else {
            "git"
        };
        format!(
            "{pin}{}",
            super::hooks::traced_script_with_program(&words.join(" "), program)
        )
    } else if credential_transport {
        format!("{pin}exec \"$GITCRAFT_GIT_ORIGINAL\" {}", words.join(" "))
    } else {
        format!("exec git {}", words.join(" "))
    };
    remote::Request {
        cwd: Some(target.path.clone()),
        script,
        env: GIT_ENV
            .iter()
            .map(|(n, v)| ((*n).to_owned(), (*v).to_owned()))
            .chain(extra.env.iter().map(|(n, v)| ((*n).to_owned(), v.clone())))
            .collect(),
        unset: GIT_ENV_REMOVED
            .iter()
            .chain(REPOSITORY_ENV_REMOVED.iter())
            .chain(
                extra
                    .normalize_repository
                    .then_some(CONNECTION_REDIRECT_ENV)
                    .into_iter()
                    .flatten(),
            )
            .chain(extra.unset.iter())
            .map(|n| (*n).to_owned())
            .collect(),
        stdin: extra.stdin.clone(),
        // A tool stays open as long as the user works in it, apart from ordinary git reads.
        long: extra.tool || extra.long || goes_over_network(args),
        timeout: extra
            .timeout
            .or(extra.test)
            .or_else(|| extra.tool.then_some(TOOL_FOR)),
        test: extra.test.is_some(),
        apart: false,
    }
}
pub(crate) struct PushTarget<'a> {
    pub address: &'a str,
    pub skip_hooks: bool,
    pub alias: &'a str,
    pub original_remote: &'a str,
    pub lfs_config: &'a [(String, String)],
    pub lfs_objects: &'a [String],
    pub receive_pack: &'a str,
}

fn reviewed_push_extra(
    dir: &Path,
    words: &[&str],
    target: PushTarget<'_>,
    hooks_path: String,
    creds: Option<&Credentials>,
) -> Result<Extra, String> {
    let PushTarget {
        address,
        alias: opaque,
        original_remote,
        lfs_config,
        receive_pack,
        ..
    } = target;
    let placeholder = format!("gitcraft-preflight-address://{opaque}");
    let mut values = vec![
        (format!("url.{address}.insteadOf"), placeholder.clone()),
        (format!("remote.{opaque}.url"), String::new()),
        (format!("remote.{opaque}.url"), placeholder.clone()),
        // An explicit pushurl disables pushInsteadOf for this private remote.
        // Otherwise a push-only rule for the placeholder prefix can bypass the
        // ordinary URL expansion proof while leaving its config stamp unchanged.
        (format!("remote.{opaque}.pushurl"), String::new()),
        (format!("remote.{opaque}.pushurl"), placeholder.clone()),
        (format!("remote.{original_remote}.url"), String::new()),
        (format!("remote.{original_remote}.url"), placeholder.clone()),
        (format!("remote.{original_remote}.pushurl"), String::new()),
        (format!("remote.{original_remote}.pushurl"), placeholder),
        ("core.hooksPath".into(), hooks_path),
    ];
    for (source, value) in lfs_config {
        if value.is_empty() {
            continue;
        }
        let target = source
            .strip_prefix(&format!("remote.{original_remote}."))
            .map(|key| format!("remote.{opaque}.{key}"))
            .unwrap_or_else(|| source.clone());
        values.push((target.clone(), value.clone()));
        if target != *source {
            values.push((source.clone(), value.clone()));
        }
    }
    if !receive_pack.is_empty() {
        values.push((format!("remote.{opaque}.receivepack"), receive_pack.into()));
    }
    const VARS: [(&str, &str); 16] = [
        ("GIT_CONFIG_KEY_0", "GIT_CONFIG_VALUE_0"),
        ("GIT_CONFIG_KEY_1", "GIT_CONFIG_VALUE_1"),
        ("GIT_CONFIG_KEY_2", "GIT_CONFIG_VALUE_2"),
        ("GIT_CONFIG_KEY_3", "GIT_CONFIG_VALUE_3"),
        ("GIT_CONFIG_KEY_4", "GIT_CONFIG_VALUE_4"),
        ("GIT_CONFIG_KEY_5", "GIT_CONFIG_VALUE_5"),
        ("GIT_CONFIG_KEY_6", "GIT_CONFIG_VALUE_6"),
        ("GIT_CONFIG_KEY_7", "GIT_CONFIG_VALUE_7"),
        ("GIT_CONFIG_KEY_8", "GIT_CONFIG_VALUE_8"),
        ("GIT_CONFIG_KEY_9", "GIT_CONFIG_VALUE_9"),
        ("GIT_CONFIG_KEY_10", "GIT_CONFIG_VALUE_10"),
        ("GIT_CONFIG_KEY_11", "GIT_CONFIG_VALUE_11"),
        ("GIT_CONFIG_KEY_12", "GIT_CONFIG_VALUE_12"),
        ("GIT_CONFIG_KEY_13", "GIT_CONFIG_VALUE_13"),
        ("GIT_CONFIG_KEY_14", "GIT_CONFIG_VALUE_14"),
        ("GIT_CONFIG_KEY_15", "GIT_CONFIG_VALUE_15"),
    ];
    if values.len() > VARS.len() {
        return Err("Too many pinned transport settings; no push was run.".into());
    }
    let mut extra = Extra {
        pre: Vec::new(),
        unset: PREFLIGHT_REMOVE.to_vec(),
        env: vec![
            ("GIT_CONFIG_COUNT", values.len().to_string()),
            ("GIT_NO_REPLACE_OBJECTS", "1".into()),
        ],
        ..Default::default()
    };
    for ((key, value), (key_var, value_var)) in values.into_iter().zip(VARS) {
        extra.env.extend([(key_var, key), (value_var, value)]);
    }
    preflight_credentials(dir, &mut extra, words, address, creds)?;
    Ok(extra)
}
fn preflight_credentials(
    dir: &Path,
    extra: &mut Extra,
    words: &[&str],
    address: &str,
    creds: Option<&Credentials>,
) -> Result<(), String> {
    let Some(creds) = creds else {
        return Ok(());
    };
    // Validate the captured account even when this is another reviewed endpoint.
    // An unbound or edited cached secret must not acquire a new endpoint scope.
    creds.helper_environment()?;
    if creds
        .scope
        .as_ref()
        .is_some_and(|scope| scope.matches_url(address))
    {
        let policy = credential_command_policy(Some(dir), creds, words)?;
        extra.normalize_repository = true;
        extra.owned_pre.extend(policy.arguments);
        extra.env.extend(policy.environment);
    }
    Ok(())
}
const PREFLIGHT_REMOVE: &[&str] = &[
    "GIT_DIR",
    "GIT_COMMON_DIR",
    "GIT_WORK_TREE",
    "GIT_INDEX_FILE",
    "GIT_OBJECT_DIRECTORY",
    "GIT_ALTERNATE_OBJECT_DIRECTORIES",
    "GIT_NAMESPACE",
    "GIT_SHALLOW_FILE",
    "GIT_CONFIG_PARAMETERS",
    "GIT_CONFIG",
    "GIT_CONFIG_COUNT",
    "GIT_ATTR_SOURCE",
];
fn goes_over_network(a:&[&str])->bool{after_options(a).first()==Some(&"push")}
#[derive(Clone, Debug, serde::Serialize, serde::Deserialize, PartialEq, Eq)]
pub(crate) struct RouteBinding {
    pub args: Vec<String>,
    routes: Vec<String>,
    configuration: String,
}
impl RouteBinding{    pub fn authorizes_endpoint(&self, url: &str) -> bool {
        crate::git::CredentialScope::for_url(url, "endpoint-check")
            .is_ok_and(|scope| self.routes.iter().any(|route| scope.matches_url(route)))
    }
}
#[derive(Clone)]
pub(crate) struct AuthFailure {
    pub context: crate::connections::Context,
    pub endpoints: Vec<String>,
    pub confirmed: bool,
    pub binding: Option<RouteBinding>,
    pub lfs: bool,
}
pub struct OpControl{failure:Mutex<Option<AuthFailure>>} impl OpControl{pub fn new()->Self{Self{failure:Mutex::new(None)}}pub fn authentication_failed(&self,f:AuthFailure){*self.failure.lock().unwrap()=Some(f)}pub fn auth_failure(&self)->Option<AuthFailure>{self.failure.lock().unwrap().clone()}}
 pub fn check_command_policy(){
 let words=["push","--porcelain","--force-with-lease=refs/heads/main:old","--","private","oid:refs/heads/main"];
 let creds=Credentials::for_url("https://push.invalid/team/repo","alice".into(),"DUMMY_ONLY".into()).unwrap();
 let target=||PushTarget{address:"https://push.invalid/team/repo",alias:"private",original_remote:"original",skip_hooks:false,lfs_config:&[],lfs_objects:&[],receive_pack:""};
 let extra=reviewed_push_extra(Path::new("/recorded/repo"),&words,target(),"/recorded/hooks".into(),Some(&creds)).unwrap();
 let mut selected=Command::new("/recorded/actual/git");selected.env("GIT_DIR","foreign");clear_repository_environment(&mut selected);
 let command=apply_command_extras(selected,Some(Path::new("/recorded/repo")),&extra,&words);
 let env=command.get_envs().map(|(k,v)|(k.to_string_lossy().into_owned(),v.map(|v|v.to_string_lossy().into_owned()))).collect::<std::collections::BTreeMap<_,_>>();
 assert_eq!(env["GIT_DIR"],None);assert_eq!(env["GIT_CONFIG_GLOBAL"],Some("/recorded/profile.gitconfig".into()));assert_eq!(env["GIT_CONFIG_COUNT"],Some("10".into()));assert_eq!(env["GITCRAFT_GIT_ORIGINAL"],Some("/recorded/actual/git".into()));assert_eq!(env["GIT_NO_REPLACE_OBJECTS"],Some("1".into()));
 assert_eq!(env["GIT_SSH_COMMAND"],None);assert_eq!(env["GIT_CONFIG_VALUE_9"],Some("/recorded/hooks".into()));
 let args=command.get_args().map(|a|a.to_string_lossy().into_owned()).collect::<Vec<_>>();assert!(args.ends_with(&words.map(String::from)));assert_eq!(args.iter().filter(|s|s.as_str()=="gitcraft-credential-transport").count(),1);assert!(!args.join(" ").contains("DUMMY_ONLY"));
 for trace in [false,true]{let mut x=extra.clone();x.trace_hooks=trace;let req=remote_request(&Target{host:remote::Host::Ssh("never-contacted.invalid".into()),path:"/recorded/repo".into()},&x,&words);assert!(req.script.starts_with(CREDENTIAL_REMOTE_PIN));assert!(req.script.contains("\"$GITCRAFT_GIT_ORIGINAL\""));assert!(req.unset.contains(&"GIT_CONFIG_COUNT".into()));assert!(req.env.contains(&("GIT_CONFIG_COUNT".into(),"10".into())));}
 let x=Extra{normalize_repository:true,unset:vec!["GIT_INDEX_FILE"],env:vec![("GIT_INDEX_FILE","/recorded/private.index".into())],..Default::default()};let cmd=apply_command_extras(Command::new("/recorded/git"),Some(Path::new("/recorded/practice")),&x,&["status"]);let env=cmd.get_envs().collect::<std::collections::BTreeMap<_,_>>();assert!(!env.contains_key(std::ffi::OsStr::new("GIT_CONFIG_GLOBAL")));assert_eq!(env[std::ffi::OsStr::new("GIT_INDEX_FILE")],Some(std::ffi::OsStr::new("/recorded/private.index")));
 }
}
mod push_preflight{use std::{collections::BTreeMap,sync::{Mutex,OnceLock,atomic::{AtomicU64,Ordering}}};
const AUTH_ENDPOINT: &str = "[gitcraft-reviewed-auth:";
fn auth_endpoints() -> &'static Mutex<BTreeMap<u64, String>> {
    static ENDPOINTS: OnceLock<Mutex<BTreeMap<u64, String>>> = OnceLock::new();
    ENDPOINTS.get_or_init(Default::default)
}
pub(crate) fn remember_auth_endpoint(url: &str) -> String {
    static IDS: AtomicU64 = AtomicU64::new(1);
    let id = IDS.fetch_add(1, Ordering::Relaxed);
    if let Ok(mut endpoints) = auth_endpoints().lock() {
        while endpoints.len() >= 64 {
            if let Some(first) = endpoints.keys().next().copied() {
                endpoints.remove(&first);
            }
        }
        endpoints.insert(id, url.into());
    }
    // The log/status carries an opaque receipt, never URL userinfo/query values.
    format!("Authentication failed for the reviewed push target. {AUTH_ENDPOINT}{id}]")
}
pub(crate) fn take_auth_endpoint(error: &str) -> Option<String> {
    let id = error
        .split_once(AUTH_ENDPOINT)?
        .1
        .strip_suffix(']')?
        .parse::<u64>()
        .ok()?;
    auth_endpoints().lock().ok()?.remove(&id)
}
pub(crate) fn is_reviewed_auth_error(error: &str) -> bool {
    error.contains(AUTH_ENDPOINT)
}

}
use git::hooks;
const EXPECT_HTTPS_ROUTE:&str="--gitcraft-expect-https-route";
fn run_reviewed_push(
    original: &[String],
    capture: impl FnOnce(&[&str]) -> Result<git::RouteBinding, String>,
    execute: impl FnOnce() -> Result<String, String>,
    control: Option<&Arc<git::OpControl>>,
) -> Result<String, String> {
    let context = crate::connections::current();
    let args: Vec<_> = original.iter().map(String::as_str).collect();
    let binding = capture(&args).map_err(|error| {
        format!(
            "Could not verify the reviewed push's destinations; command not started: {}",
            crate::diagnostics::crash::scrub(&error)
        )
    })?;
    let result = execute();
    if let Err(error) = &result
        && let Some(failure) = reviewed_auth_failure(error, binding, context)
        && let Some(control) = control
    {
        control.authentication_failed(failure);
    }
    result
}
fn reviewed_auth_failure(
    error: &str,
    binding: git::RouteBinding,
    context: crate::connections::Context,
) -> Option<git::AuthFailure> {
    let endpoint = crate::push_preflight::take_auth_endpoint(error)?;
    if !binding.authorizes_endpoint(&endpoint) {
        return None;
    }
    Some(git::AuthFailure {
        context,
        endpoints: vec![endpoint],
        confirmed: true,
        binding: Some(binding),
        lfs: false,
    })
}
fn check_https_routes(
    ops: &[Vec<String>],
    mut verify: impl FnMut(&git::RouteBinding) -> Result<(), String>,
) -> Result<(), String> {
    for op in ops {
        if let [marker, json] = op.as_slice()
            && marker == EXPECT_HTTPS_ROUTE
        {
            let binding = serde_json::from_str::<git::RouteBinding>(json)
                .map_err(|_| "Invalid sign-in route proof".to_owned())?;
            verify(&binding)?;
        }
    }
    Ok(())
}
fn with_rechecked_preparation(
    mut verify: impl FnMut() -> Result<(), String>,
    prepare: impl FnOnce() -> Result<(), String>,
) -> Result<(), String> {
    verify()?;
    prepare()?;
    verify()
}

#[cfg(test)]mod tests{
 use super::*;use std::cell::Cell;
 fn route()->git::RouteBinding{serde_json::from_value(serde_json::json!({"args":["push","--","original","oid:refs/heads/main"],"routes":["https://push.invalid/team/repo"],"configuration":"captured"})).unwrap()}
 #[test]fn exact_command_policy_preserves_owned_config_selected_program_and_practice_exception(){git::check_command_policy()}
 #[test]fn original_route_capture_precedes_dispatch_and_missing_proof_never_dispatches(){let b=route();let called=Cell::new(false);let c=Arc::new(git::OpControl::new());let r=run_reviewed_push(&b.args,|a|{assert_eq!(a,b.args.iter().map(String::as_str).collect::<Vec<_>>());Err("no proof".into())},||{called.set(true);Ok(String::new())},Some(&c));assert!(r.is_err());assert!(!called.get());assert!(c.auth_failure().is_none());}
 #[test]fn exact_receipt_binds_authoritative_route_context_and_is_one_shot(){let b=route();let c=Arc::new(git::OpControl::new());let receipt=push_preflight::remember_auth_endpoint("https://push.invalid/team/repo");let capture=Cell::new(false);let r=run_reviewed_push(&b.args,|a|{assert_eq!(a[2],"original");capture.set(true);Ok(b.clone())},||{assert!(capture.get());Err(receipt.clone())},Some(&c));assert_eq!(r,Err(receipt.clone()));let f=c.auth_failure().unwrap();assert_eq!(f.context,connections::current());assert_eq!(f.endpoints,["https://push.invalid/team/repo"]);assert_eq!(f.binding,Some(b));assert!(f.confirmed);assert!(push_preflight::take_auth_endpoint(&receipt).is_none());}
 #[test]fn foreign_and_expired_receipts_do_not_authorize_recovery(){let b=route();for url in ["https://fetch.invalid/team/repo","https://push.invalid/other","http://push.invalid/team/repo","https://push.invalid/team/repo/info/lfs"]{let receipt=push_preflight::remember_auth_endpoint(url);assert!(reviewed_auth_failure(&receipt,b.clone(),connections::current()).is_none());assert!(push_preflight::take_auth_endpoint(&receipt).is_none());}let stale=push_preflight::remember_auth_endpoint("https://push.invalid/team/repo");push_preflight::take_auth_endpoint(&stale);assert!(reviewed_auth_failure(&stale,b,connections::current()).is_none());}
 #[test]fn route_proof_is_rechecked_after_draft_and_malformed_proof_refuses(){let b=route();let ops=vec![vec![EXPECT_HTTPS_ROUTE.into(),serde_json::to_string(&b).unwrap()]];let n=Cell::new(0);let current=Cell::new(true);let r=with_rechecked_preparation(||check_https_routes(&ops,|x|{assert_eq!(x,&b);n.set(n.get()+1);if current.get(){Ok(())}else{Err("changed during draft".into())}}),||{current.set(false);Ok(())});assert!(r.is_err());assert_eq!(n.get(),2);assert!(check_https_routes(&[vec![EXPECT_HTTPS_ROUTE.into(),"invalid".into()]],|_|panic!("malformed proof must not dispatch")).is_err());}
}
