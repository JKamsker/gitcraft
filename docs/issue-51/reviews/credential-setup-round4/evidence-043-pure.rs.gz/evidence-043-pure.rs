#![allow(dead_code,unused_imports)]
mod harness {
use std::{path::{Path,PathBuf},process::Command};
#[derive(Clone,Debug)] pub struct Credentials { pub username:String,pub password:String,pub scope:Option<CredentialScope> }
#[path="/tmp/gitcraft-credential-setup-r4-8aaa-source/src/git/credential_scope.rs"] mod credential_scope;
pub use credential_scope::{CredentialScope,CREDENTIAL_HELPER};
pub(crate) mod git {pub use super::{CredentialScope,CREDENTIAL_HELPER};}
mod remote {pub fn is_remote(_: &std::path::Path)->bool { false }}
pub(crate) mod practice {pub fn is_repository(_: &std::path::Path)->bool {false}}
pub(crate) mod connections {
 #[derive(Clone)] pub struct Choices{pub ssh_key:String}
 #[derive(Clone)] pub struct Context {pub error:Option<String>,pub choices:Choices,pub git_config:Option<std::path::PathBuf>}
 pub fn current()->Context {Context{error:None,choices:Choices{ssh_key:String::new()},git_config:Some("/recorded/profile.gitconfig".into())}}
}
#[path="/tmp/gitcraft-credential-setup-r4-8aaa-source/src/git/command/credential_policy.rs"] mod credential_policy;
fn user_global_config(args: &[&str]) -> bool {
    let rest = after_options(args);
    (rest.first() == Some(&"config") && rest.contains(&"--global"))
        // `maintenance start` / `register` write `maintenance.repo` to the global config.
        || (rest.first() == Some(&"maintenance")
            && matches!(rest.get(1), Some(&("start" | "register" | "unregister" | "stop"))))
}

/// `args` from the subcommand on: past the options before it (`-c x=y`, `-C dir`,
/// `--literal-pathspecs`…).
fn after_options<'a>(args: &'a [&'a str]) -> &'a [&'a str] {
    let mut rest = args;
    loop {
        match rest {
            ["-c" | "-C", _, tail @ ..] => rest = tail,
            [word, tail @ ..] if word.starts_with('-') => rest = tail,
            _ => return rest,
        }
    }
}

/// Points `cmd` at the active profile's config, unless `args` is about the user's own.
pub(super) fn with_profile(cmd: &mut Command, args: &[&str]) {
    if user_global_config(args) {
        return;
    }
    let context = crate::connections::current();
    if context.error.is_some() {
        cmd.arg("-c").arg("=invalid-profile");
        return;
    }
    if !context.choices.ssh_key.is_empty() {
        cmd.env_remove("GIT_SSH_COMMAND")
            .env_remove("GIT_SSH")
            .env_remove("GIT_SSH_VARIANT");
    }
    let path = context.git_config;
    if let Some(path) = path {
        cmd.env("GIT_CONFIG_GLOBAL", path);
    }
}


pub(super) fn apply_command_extras(
    mut cmd: Command,
    dir: Option<&Path>,
    extra: &Extra,
    args: &[&str],
) -> Command {
    cmd.args(&extra.pre).args(&extra.owned_pre);
    if extra.normalize_repository && !dir.is_some_and(crate::practice::is_repository) {
        normalize_connection_command(&mut cmd, args);
    }
    for (name, value) in &extra.env {
        cmd.env(name, value);
    }
    if extra
        .owned_pre
        .iter()
        .any(|arg| arg == "gitcraft-credential-transport")
    {
        let selected = cmd.get_program().to_owned();
        cmd.env("GITCRAFT_GIT_ORIGINAL", selected);
    }
    cmd.args(args);
    cmd
}

pub(super) const CONNECTION_REDIRECT_ENV: &[&str] = &[
    "GIT_DIR",
    "GIT_WORK_TREE",
    "GIT_COMMON_DIR",
    "GIT_INDEX_FILE",
    "GIT_OBJECT_DIRECTORY",
    "GIT_ALTERNATE_OBJECT_DIRECTORIES",
    "GIT_NAMESPACE",
    "GIT_CONFIG",
    "GIT_CONFIG_GLOBAL",
    "GIT_CONFIG_SYSTEM",
    "GIT_CONFIG_COUNT",
    "GIT_CONFIG_PARAMETERS",
    "GIT_CONFIG_NOSYSTEM",
];
fn normalize_connection_command(cmd: &mut Command, args: &[&str]) {
    for name in CONNECTION_REDIRECT_ENV {
        cmd.env_remove(name);
    }
    for (name, _) in std::env::vars_os() {
        let text = name.to_string_lossy();
        if text.starts_with("GIT_CONFIG_KEY_") || text.starts_with("GIT_CONFIG_VALUE_") {
            cmd.env_remove(name);
        }
    }
    // Intentional immutable profile config is reinstalled after inherited config is removed.
    with_profile(cmd, args);
}


#[derive(Default)] struct Extra { pre:Vec<&'static str>,owned_pre:Vec<String>,env:Vec<(&'static str,String)>,normalize_repository:bool }


pub fn is_auth_error(err: &str) -> bool {
    let e = err.to_lowercase();
    [
        "terminal prompts disabled",
        "could not read username",
        "could not read password",
        "authentication failed",
        "invalid username or password",
        "http basic: access denied",
        "the requested url returned error: 401",
        "the requested url returned error: 403",
    ]
    .iter()
    .any(|s| e.contains(s))
}

mod endpoints { use super::*; #[derive(Clone)] pub struct RouteBinding {pub args:Vec<String>,pub routes:Vec<String>}
impl RouteBinding{    pub fn authorizes_endpoint(&self, url: &str) -> bool {
        crate::git::CredentialScope::for_url(url, "endpoint-check")
            .is_ok_and(|scope| self.routes.iter().any(|route| scope.matches_url(route)))
    }
}
#[derive(Clone)]
pub(crate) struct AuthFailure {
    pub context: crate::connections::Context,
    pub endpoints: Vec<String>,
    pub confirmed: bool,
    pub binding: Option<RouteBinding>,
    pub lfs: bool,
}
fn safe_http_url(value: &str) -> Option<String> {
    let (scheme, rest) = value.split_once("://")?;
    if !matches!(scheme, "https" | "http") {
        return None;
    }
    let (authority, tail) = rest
        .split_once('/')
        .map_or((rest, String::new()), |(a, p)| (a, format!("/{p}")));
    let authority = authority.rsplit('@').next()?;
    let clean = format!("{scheme}://{authority}{tail}");
    crate::git::CredentialScope::for_url(&clean, "endpoint-check").ok()?;
    Some(clean)
}
impl AuthFailure {
    pub fn needs_separate_account(&self) -> bool {
        if self.lfs {
            return true;
        }
        let Some(binding) = &self.binding else {
            return false;
        };
        if super::after_options(&binding.args.iter().map(String::as_str).collect::<Vec<_>>())
            .first()
            == Some(&"lfs")
        {
            return true;
        }
        // Mixed candidates keep their ordinary bound choices. Foreign entries
        // are separated before offering the dialog, and selection is checked
        // again against the proof at both action entry points.
        !self.endpoints.is_empty()
            && self
                .endpoints
                .iter()
                .all(|url| !binding.authorizes_endpoint(url))
    }
    /// An explicit URL reported by Git/LFS takes precedence over configured candidates.
    /// Otherwise the UI requires a destination choice; it never guesses a fetch URL.
    pub fn from_error(error: &str, attempted: &[String]) -> Self {
        // Only canonical Git auth records and explicit LFS auth-error records count.
        // Untrusted remote banners/help links cannot confirm a destination.
        let mut reported = Vec::new();
        for line in error.lines() {
            let line = line.trim();
            let quoted = line
                .strip_prefix("fatal: Authentication failed for '")
                .and_then(|v| v.strip_suffix('\''))
                .or_else(|| {
                    line.strip_prefix("fatal: unable to access '")
                        .and_then(|v| v.split_once("':"))
                        .filter(|(_, e)| super::is_auth_error(e))
                        .map(|(u, _)| u)
                });
            let lfs = line
                .strip_prefix("LFS: ")
                .filter(|_| {
                    line.to_ascii_lowercase()
                        .contains("authentication required")
                })
                .and_then(|v| v.split_whitespace().next());
            if let Some(url) = quoted.or(lfs).and_then(safe_http_url)
                && !reported.contains(&url)
            {
                reported.push(url);
            }
        }
        let confirmed = reported.len() == 1;
        let mut endpoints = reported;
        if !confirmed {
            for url in attempted.iter().filter_map(|u| safe_http_url(u)) {
                if !endpoints.contains(&url) {
                    endpoints.push(url);
                }
            }
        }
        Self {
            context: crate::connections::current(),
            endpoints,
            confirmed,
            binding: None,
            lfs: error.lines().any(|line| {
                line.trim_start().starts_with("LFS:")
                    || line.contains("git-lfs")
                    || line.contains("Git LFS")
            }),
        }
    }
}

#[derive(Clone)] struct Ticket {binding:Option<RouteBinding>,endpoints:Vec<String>}
impl Ticket{    pub(super) fn authorizes_endpoint(&self, url: &str) -> bool {
        self.binding
            .as_ref()
            .is_some_and(|binding| binding.authorizes_endpoint(url))
            && git::CredentialScope::for_url(url, "endpoint-check")
                .is_ok_and(|scope| self.endpoints.iter().any(|e| scope.matches_url(e)))
    }}
pub fn run(){

let binding=RouteBinding{args:vec!["push".into(),"origin".into()],routes:vec!["https://git.invalid/repo".into(),"https://mirror.invalid/repo".into()]};
for foreign in ["https://lfs.invalid/old","https://lfs.invalid/new","https://git.invalid/other"] {
 let mut failure=AuthFailure::from_error(&format!("fatal: Authentication failed for 'https://git.invalid/repo'\nfatal: Authentication failed for 'https://mirror.invalid/repo'\nfatal: Authentication failed for '{foreign}'"),&[]);
 failure.binding=Some(binding.clone()); assert!(!failure.confirmed);assert!(!failure.needs_separate_account());
        let (bound, foreign): (Vec<_>, Vec<_>) = failure.endpoints.into_iter().partition(|url| {
            failure
                .binding
                .as_ref()
                .is_some_and(|b| b.authorizes_endpoint(url))
        });
        failure.endpoints = bound;

 assert_eq!(failure.endpoints,["https://git.invalid/repo","https://mirror.invalid/repo"]);assert_eq!(foreign.len(),1);
 let ticket=Ticket{binding:Some(binding.clone()),endpoints:vec!["https://git.invalid/repo".into(),"https://lfs.invalid/old".into()]};
 assert!(ticket.authorizes_endpoint("https://git.invalid/repo/"));assert!(!ticket.authorizes_endpoint("https://lfs.invalid/old"));assert!(!ticket.authorizes_endpoint("https://mirror.invalid/repo"));
}
let unbound=Ticket{binding:None,endpoints:vec!["https://git.invalid/repo".into()]};assert!(!unbound.authorizes_endpoint("https://git.invalid/repo"));
let mut secondary=AuthFailure::from_error("fatal: Authentication failed for 'https://lfs.invalid/only'",&[]);secondary.binding=Some(binding.clone());assert!(secondary.needs_separate_account());
println!("PASS exact mixed parser/partition and RouteBinding+Ticket authorization: bound alternatives retained; changed foreign routes and injected foreign ticket entries refused; no proof refused");
}
}
pub fn run(){
endpoints::run();
let original=["push","private-alias","HEAD:refs/heads/main"];
let c=Credentials::for_url("https://git.invalid/repo","alice".into(),"DUMMY_SELECTED".into()).unwrap();
let p=credential_policy::credential_command_policy(Some(Path::new("/nonexistent/recorded")),&c,&original).unwrap();
let mut extra=Extra{normalize_repository:true,owned_pre:p.arguments,env:p.environment,..Default::default()};
extra.env.extend([("HOME","/recorded/home".into()),("GIT_SSL_CAINFO","/recorded/ca.pem".into()),("GIT_CONFIG_COUNT","2".into()),("GIT_CONFIG_KEY_0","http.https://git.invalid/repo/.proactiveAuth".into()),("GIT_CONFIG_VALUE_0","none".into()),("GIT_CONFIG_KEY_1","http.https://git.invalid/repo/.emptyAuth".into()),("GIT_CONFIG_VALUE_1","true".into())]);
let command=apply_command_extras(Command::new("/recorded/repository-machine/git"),Some(Path::new("/nonexistent/recorded")),&extra,&original);
let env=command.get_envs().map(|(k,v)|(k.to_string_lossy().into_owned(),v.map(|v|v.to_string_lossy().into_owned()))).collect::<std::collections::HashMap<_,_>>();
assert_eq!(env["HOME"],Some("/recorded/home".into()));assert_eq!(env["GIT_SSL_CAINFO"],Some("/recorded/ca.pem".into()));assert_eq!(env["GIT_CONFIG_GLOBAL"],Some("/recorded/profile.gitconfig".into()));assert_eq!(env["GITCRAFT_GIT_ORIGINAL"],Some("/recorded/repository-machine/git".into()));
let wrapper=env["GITCRAFT_HTTP_WRAPPER"].as_ref().unwrap(); assert!(wrapper.contains("http.$url.proactiveAuth=basic"));assert!(wrapper.contains("http.$url.emptyAuth=false"));assert!(wrapper.contains("case \"$url\" in https://*)"));assert!(!wrapper.contains("DUMMY_SELECTED"));
let args=command.get_args().map(|a|a.to_string_lossy().into_owned()).collect::<Vec<_>>();assert!(args.ends_with(&original.map(String::from)));assert!(!args.join(" ").contains("DUMMY_SELECTED"));
let alias=args.iter().find(|a|a.starts_with("alias.gitcraft-credential-transport=")).unwrap();
let guard=alias.find("version=$(\"$GITCRAFT_GIT_ORIGINAL\" --version)").unwrap(); assert!(guard<alias.find("--exec-path").unwrap());assert!(guard<alias.find("mktemp -d").unwrap()); assert!(!alias.contains("rmdir"));assert!(alias.contains("rm -f -- ./git-remote-http ./git-remote-https"));
let plain=Credentials::for_url("http://git.invalid/repo","alice".into(),"DUMMY_SELECTED".into()).unwrap();assert!(credential_policy::credential_command_policy(None,&plain,&original).is_err());
println!("PASS exact pure policy/builder: late HTTPS auth pair, pinned executable guard before artifacts, selected home/profile/CA retained, no token argv/file content, preserved relative cleanup, HTTP refusal; no generated shell executed");
}
}
use harness::{connections,git,practice};
fn main(){harness::run()}
