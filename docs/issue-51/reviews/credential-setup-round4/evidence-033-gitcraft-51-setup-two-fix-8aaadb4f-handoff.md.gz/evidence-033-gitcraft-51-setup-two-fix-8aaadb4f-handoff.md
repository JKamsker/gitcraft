# Final two-fix setup handoff — exact 8aaadb4f

Preserved candidate `8aaadb4fb1af291a12368c3ff0160892126885c1`, branch `t3/practice-connections-diagnostics`, worktree `/Users/jonas/.t3/worktrees/gitcraft/t3-5b9a0fe3`. Correct author `Jonas Kamsker <11245306+JKamsker@users.noreply.github.com>`, clean tree, verified fork `https://github.com/JKamsker/gitcraft` remote branch SHA equals candidate. Each coherent fix was committed, pushed and verified before the next unit/check. No PR/CI/subagent or other writer checkout changes.

Status: implementation and allowed gates finished; bounded independent R4 is already reviewing this exact candidate. Neither whole shared API nor native behavior is declared accepted. Scope is frozen to the two demonstrated R3 blockers, with prior154 cleanup retained.

## The two preserved units

| Finding | Full feature commit | Production correction and source |
| --- | --- | --- |
| R3-1 mixed canonical errors can authorize foreign route | `c7421c9d6192457450b87bdf478ea22faf27aee2` | `src/git/command/endpoints.rs:178` adds pure RouteBinding.authorizes_endpoint using existing exact canonical credential identity. `src/repo/https_recovery.rs:15` requires both ticket candidate and authoritative bound route; `:86` separates mixed reported foreign URLs into explicit standalone HTTPS Settings while retaining all ordinary bound choices. `src/repo/operations.rs:201` Switch/Forget and `:264` Sign in check selected membership before workers, credential eviction/rejection events or retry. Switch worker retains a required Some proof and verifies before/after rejection. Completion also checks route membership. Existing context/generation/freshness/serialized worker-route guards remain. |
| R3-2 optional netrc may win before selected helper | `8aaadb4fb1af291a12368c3ff0160892126885c1` | `src/git/command/credential_policy.rs:151` checks the quoted pinned repository-machine executable with --version before --exec-path/mktemp/operation. Recognized upstream numeric X.Y.Z and Apple numeric vendor forms require >=2.46; query failure, old Git, prerelease, unknown vendor/native-MSYS forms refuse transient sign-in with an actionable error. `:141` installs exact actual transport URL proactiveAuth=basic AND emptyAuth=false alongside existing redirect/helper/account/header policy. Constructor and actual wrapper refuse non-HTTPS transient mode; normal manager paths remain. `src/repo/dialogs/remote.rs:141` limits transient UI to HTTPS and explains repository-machine Git floor. No HOME/profile/CA reset or older-Git workaround. |

R3-1 regressions: `https_recovery.rs:198` mixed canonical normal/mirror/foreign errors remain unconfirmed, ordinary candidates remain selectable and both old/new independent secondary URLs are never authorized by unchanged normal proof. `:228` even a ticket explicitly listing a foreign URL cannot schedule Sign in or Switch/Forget; existing normal Alice credential is retained, no rejection event/worker/retry is created, standalone inspection is staged. All headless/pure; no route metadata process runs.

R3-2 regressions: `credential_policy.rs:318` inert supplied-version/status matrix covers below floor, floor, inspected newer numeric versions, old/new Apple forms, malformed/unrecognized/prerelease/Windows strings and query failure; generated placement checks bind the pinned executable before discovery/artifacts. The Rust recording parser interprets emitted guard grammar; **the POSIX shell parser itself was not executed**. `:355` uses actual production apply_command_extras on fixed `/recorded/repository-machine/git`, retains intentional HOME/CA and command-only proactiveAuth=none/emptyAuth=true config, records late exact-URL corrective settings, requires HTTPS and checks dummy token absent from argv/wrapper. It records construction; actual Git precedence is source-backed inference, not runtime evidence.

## Prior cleanup and original feature scope

`154c34b09123be9c97e3fd0945f3ab6dbc02c1f7` remains unchanged. Relative fixed-file cleanup uses the retained owned CWD. No final pathname rmdir/-ef; empty private0700 directories intentionally remain. The finalized netrc design note grants a narrow static pass for this residual only. Abrupt termination may retain wrapper files; no artifact sweeper was added and no cancellation/lifetime execution is claimed.

Original eight-feature checklist/provenance and F1–F6 coverage are preserved in `/tmp/gitcraft-51-setup-corrections-154c34b0-handoff.md`, with original feature SHAs and entry points, plus `/tmp/gitcraft-51-t3-5b9a0fe3-handoff.md` (historical b069 evidence, not current acceptance). This two-fix delta changes only endpoints/recovery/operation authorization, credential policy, one scope protocol getter and credential dialog copy/validation. Practice/glossary, tour, portable setup, profile contexts/SSH/key setup, diagnostics and doctor classification receive no new requirements or claimed new runtime acceptance. Original17 setup commits remain ancestors; no dependency/lockfile changes.

Shared consumer contract remains unchanged: pure credential_command_policy(dir, credentials, original_args); append exact original args, install policy env, standard builders pin selected absolute Git, custom local runner calls policy.bind_git(actual_absolute_git), custom remote runner prefixes shared CREDENTIAL_REMOTE_PIN on repository machine. Command-only alias/config ownership survives normalization before owned Extra.env. Helper_environment alone cannot authorize. `a11f5473` explicit program=program format fix remains included. No consumer policy fork.

## Exact allowed gates

Receipt `/tmp/gitcraft-51-setup-r10-pure-validation.json`, driver `/tmp/gitcraft-51-setup-r10-pure-validate.py`, logs same prefix. All bound to exact candidate with no source edits during execution:

- 23 selected pure/recording test passes across14 filters: `cargo +1.95.0 test --lib <filter> -- --test-threads=2` (full filter list and commands in receipt).
- `cargo +1.95.0 check --all-targets` PASS.
- `cargo +1.95.0 clippy --all-targets -- -D warnings -A dead_code` PASS (qualified baseline allowance, not unqualified strict lint).
- `cargo +1.95.0 fmt --all --check` PASS; `git diff --check` PASS.

Environment: CARGO_BUILD_JOBS=2, TMPDIR=/private/tmp, PATH=/tmp/gitcraft-integration-tools:$PATH, SHELL=/tmp/gitcraft-integration-tools/validation-shell; own target. Earlier exact c742 R9 receipt has seven pure route/parser tests plus check/qualifiedlint/fmt/diff PASS; not substituted for final R10.

Additional **pure source adapter**, not native transport: `/tmp/gitcraft-51-setup-r10-auth-sequence.c` embeds verbatim upstream Git v2.46 init_curl_http_auth, with inert credential_fill/curl setters and no request function. Exact source/function hashes in sibling -source.json. Compiled with `/usr/bin/clang -std=c11 -Wall -Wextra -Werror ...c -o ...` and run once, exit0; log sibling .log. Both auth overrides reach selected full dummy credential setters; negative emptyAuth=true and proactive-omitted vectors do not; a refusing helper stub stops before continuation. The optional-netrc no-username condition is source-derived inference from inspected libcurl, not libcurl execution. This does not prove actual helper PPID or fallback behavior. No actual Git/helper/libcurl/netrc file/HTTP/SSH/native/process fixture or generated shell execution occurred.

Full report/manifest read: `/tmp/gitcraft-51-credential-setup-review-r3.md` and manifest. Final supported design read: `/tmp/gitcraft-51-credential-netrc-design-note.md` and manifest. Those reviews are inputs, not acceptance of these corrections. Their archived original source in `/tmp/gitcraft-credential-netrc-evidence` supplies the adapter. No live account, key or credential-store changes.

## Supported limits and finite remaining checklist

1. Bounded R4 review of c742 +8aaa and retained154 is in progress on exact candidate. Only demonstrated blockers in that delta should return to this writer; no adjacent framework/hardening work is pending here.
2. Runtime hold remains separate. After explicit clearance/containment, parent owns native gates already identified: positive HTTPS vs conflicting dummy netrc, unsupported-version refusal, actual URL config/redirect/helper/LFS ancestry, repository-machine pin and argv/stdin/stdout/status/lifetime/cleanup behavior. This handoff does not execute or authorize them.
3. Parent coordinates existing downstream history/internals/integrations consumer adoption and final combined checks/review. No other writer files were changed. Local Windows transient mode remains explicitly unavailable; remote Unix/SSH/WSL/native compatibility remains unvalidated. Unknown vendors/prereleases are refused rather than assumed supported. Ordinary profile credential-manager use remains available.

The deliberate policy is transient HTTPS username/password Basic on recognized Git>=2.46. It preserves TLS/CA/profile/home, but makes no guarantee about a server's independent client-certificate/cookie/proxy account selection or a sandbox against trusted code reading inherited secrets. Same authorized endpoint in nested designated HTTP is permitted; ordinary LFS credential-fill cannot use helper-only authority. LFS/foreign endpoints use standalone account inspection and explicit manual rerun, not a purported complete LFS route proof. No blanket secondary/submodule refusal, Windows completion, final API acceptance or whole feature-suite pass is claimed.

No additional implementation work is queued in this slot. Coding slot released after delivery; parent may resume internals corrections.
