from pathlib import Path
import hashlib,json
s=Path('/tmp/gitcraft-credential-setup-r4-8aaa-source'); e=Path('/tmp/gitcraft-credential-setup-r4-8aaa-evidence')
end=(s/'src/git/command/endpoints.rs').read_text();rec=(s/'src/repo/https_recovery.rs').read_text();cmd=(s/'src/git/command.rs').read_text()
def between(text,a,b):return text[text.index(a):text.index(b,text.index(a))]
base=Path('/tmp/gitcraft-credential-setup-r3-0319-evidence/pure.rs').read_text().split('pub fn run(){')[0].replace('/tmp/gitcraft-credential-setup-r3-0319-source','/tmp/gitcraft-credential-setup-r4-8aaa-source')
# Exact carried production builder functions are still identical at the new SHA.
for a,b in [('pub(super) fn apply_command_extras(','pub(super) const CONNECTION_REDIRECT_ENV'),('fn after_options','/// Points')]:
 old=between(base,a,b).strip(); new=between(cmd,a,b).strip()
 assert old==new,(a,'mismatch')
route=between(end,'    pub fn authorizes_endpoint','    pub fn verify')
auth=between(end,'#[derive(Clone)]\npub(crate) struct AuthFailure','/// Captures every input')
parser=between(cmd,'pub fn is_auth_error','fn credentials_extra') if 'fn credentials_extra' in cmd else ''
# Delimit the single pure classifier at its closing brace.
parser=cmd[cmd.index('pub fn is_auth_error'):]; parser=parser[:parser.index('\n}\n')+3]
ticket=between(rec,'    pub(super) fn authorizes_endpoint','\n}\nimpl RepoTab')
partition=between(rec,'        let (bound, foreign)','        if !foreign.is_empty()')
code=base+'\n'+parser+'\nmod endpoints { use super::*; #[derive(Clone)] pub struct RouteBinding {pub args:Vec<String>,pub routes:Vec<String>}\nimpl RouteBinding{'+route+'}\n'+auth+'\n#[derive(Clone)] struct Ticket {binding:Option<RouteBinding>,endpoints:Vec<String>}\nimpl Ticket{'+ticket+'}\npub fn run(){\n'+r'''
let binding=RouteBinding{args:vec!["push".into(),"origin".into()],routes:vec!["https://git.invalid/repo".into(),"https://mirror.invalid/repo".into()]};
for foreign in ["https://lfs.invalid/old","https://lfs.invalid/new","https://git.invalid/other"] {
 let mut failure=AuthFailure::from_error(&format!("fatal: Authentication failed for 'https://git.invalid/repo'\nfatal: Authentication failed for 'https://mirror.invalid/repo'\nfatal: Authentication failed for '{foreign}'"),&[]);
 failure.binding=Some(binding.clone()); assert!(!failure.confirmed);assert!(!failure.needs_separate_account());
'''+partition+r'''
 assert_eq!(failure.endpoints,["https://git.invalid/repo","https://mirror.invalid/repo"]);assert_eq!(foreign.len(),1);
 let ticket=Ticket{binding:Some(binding.clone()),endpoints:vec!["https://git.invalid/repo".into(),"https://lfs.invalid/old".into()]};
 assert!(ticket.authorizes_endpoint("https://git.invalid/repo/"));assert!(!ticket.authorizes_endpoint("https://lfs.invalid/old"));assert!(!ticket.authorizes_endpoint("https://mirror.invalid/repo"));
}
let unbound=Ticket{binding:None,endpoints:vec!["https://git.invalid/repo".into()]};assert!(!unbound.authorizes_endpoint("https://git.invalid/repo"));
let mut secondary=AuthFailure::from_error("fatal: Authentication failed for 'https://lfs.invalid/only'",&[]);secondary.binding=Some(binding.clone());assert!(secondary.needs_separate_account());
println!("PASS exact mixed parser/partition and RouteBinding+Ticket authorization: bound alternatives retained; changed foreign routes and injected foreign ticket entries refused; no proof refused");
}
}
pub fn run(){
endpoints::run();
let original=["push","private-alias","HEAD:refs/heads/main"];
let c=Credentials::for_url("https://git.invalid/repo","alice".into(),"DUMMY_SELECTED".into()).unwrap();
let p=credential_policy::credential_command_policy(Some(Path::new("/nonexistent/recorded")),&c,&original).unwrap();
let mut extra=Extra{normalize_repository:true,owned_pre:p.arguments,env:p.environment,..Default::default()};
extra.env.extend([("HOME","/recorded/home".into()),("GIT_SSL_CAINFO","/recorded/ca.pem".into()),("GIT_CONFIG_COUNT","2".into()),("GIT_CONFIG_KEY_0","http.https://git.invalid/repo/.proactiveAuth".into()),("GIT_CONFIG_VALUE_0","none".into()),("GIT_CONFIG_KEY_1","http.https://git.invalid/repo/.emptyAuth".into()),("GIT_CONFIG_VALUE_1","true".into())]);
let command=apply_command_extras(Command::new("/recorded/repository-machine/git"),Some(Path::new("/nonexistent/recorded")),&extra,&original);
let env=command.get_envs().map(|(k,v)|(k.to_string_lossy().into_owned(),v.map(|v|v.to_string_lossy().into_owned()))).collect::<std::collections::HashMap<_,_>>();
assert_eq!(env["HOME"],Some("/recorded/home".into()));assert_eq!(env["GIT_SSL_CAINFO"],Some("/recorded/ca.pem".into()));assert_eq!(env["GIT_CONFIG_GLOBAL"],Some("/recorded/profile.gitconfig".into()));assert_eq!(env["GITCRAFT_GIT_ORIGINAL"],Some("/recorded/repository-machine/git".into()));
let wrapper=env["GITCRAFT_HTTP_WRAPPER"].as_ref().unwrap(); assert!(wrapper.contains("http.$url.proactiveAuth=basic"));assert!(wrapper.contains("http.$url.emptyAuth=false"));assert!(wrapper.contains("case \"$url\" in https://*)"));assert!(!wrapper.contains("DUMMY_SELECTED"));
let args=command.get_args().map(|a|a.to_string_lossy().into_owned()).collect::<Vec<_>>();assert!(args.ends_with(&original.map(String::from)));assert!(!args.join(" ").contains("DUMMY_SELECTED"));
let alias=args.iter().find(|a|a.starts_with("alias.gitcraft-credential-transport=")).unwrap();
let guard=alias.find("version=$(\"$GITCRAFT_GIT_ORIGINAL\" --version)").unwrap(); assert!(guard<alias.find("--exec-path").unwrap());assert!(guard<alias.find("mktemp -d").unwrap()); assert!(!alias.contains("rmdir"));assert!(alias.contains("rm -f -- ./git-remote-http ./git-remote-https"));
let plain=Credentials::for_url("http://git.invalid/repo","alice".into(),"DUMMY_SELECTED".into()).unwrap();assert!(credential_policy::credential_command_policy(None,&plain,&original).is_err());
println!("PASS exact pure policy/builder: late HTTPS auth pair, pinned executable guard before artifacts, selected home/profile/CA retained, no token argv/file content, preserved relative cleanup, HTTP refusal; no generated shell executed");
}
}
use harness::{connections,git,practice};
fn main(){harness::run()}
'''
(e/'pure.rs').write_text(code)
(e/'adapter-source-seams.json').write_text(json.dumps({'source_root':str(s),'exact_imports':['src/git/credential_scope.rs','src/git/command/credential_policy.rs'],'exact_extracted_items':['command::apply_command_extras','command::after_options','command::is_auth_error','endpoints::AuthFailure and safe_http_url','RouteBinding::authorizes_endpoint','Ticket::authorizes_endpoint','offer_failed_https_signin bound/foreign partition'],'inert_substitutions':['Context with fixed profile','practice::is_repository=false','remote::is_remote=false','RouteBinding fields without metadata acquisition','Ticket fields without app constructor'],'not_executed':['Git','shell aliases/helper','network/native','workers/app entry functions']},indent=2)+'\n')
