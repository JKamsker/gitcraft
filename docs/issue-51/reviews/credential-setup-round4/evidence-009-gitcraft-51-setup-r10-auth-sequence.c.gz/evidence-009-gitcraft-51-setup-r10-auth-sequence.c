#include <assert.h>
#include <stdarg.h>
#include <setjmp.h>
#include <stdio.h>
#include <string.h>
typedef int CURL;
enum {PROACTIVE_AUTH_BASIC=1,CURLOPT_USERPWD=1,CURLOPT_HTTPAUTH,CURLOPT_USERNAME,CURLOPT_PASSWORD};
#define CURLAUTH_BASIC 1L
struct credential {char *username,*password,*credential; int wwwauth_headers;};
static struct credential http_auth;
static int proactive,empty_auth,permit_helper,filled,basic_hint;
static const char *curl_username,*curl_password;
static jmp_buf refuse;
static int http_proactive_auth=PROACTIVE_AUTH_BASIC;
static int always_auth_proactively(void) {return proactive;}
static int curl_empty_auth_enabled(void) {return empty_auth;}
static void strvec_push(int *headers,const char *value) {(void)headers;assert(!strcmp(value,"Basic"));basic_hint=1;}
static void credential_fill(struct credential *auth,int proactive_request) {
 assert(proactive_request==1); filled++;
 if(!permit_helper)longjmp(refuse,1);
 auth->username="alice";auth->password="DUMMY_SELECTED";
}
static int curl_easy_setopt(CURL *result,int option,...) {
 (void)result;va_list ap;va_start(ap,option);
 if(option==CURLOPT_HTTPAUTH)assert(va_arg(ap,long)==CURLAUTH_BASIC);
 else {const char *v=va_arg(ap,const char *);if(option==CURLOPT_USERNAME)curl_username=v;else if(option==CURLOPT_PASSWORD)curl_password=v;}
 va_end(ap);return 0;
}
static void init_curl_http_auth(CURL *result)
{
	if ((!http_auth.username || !*http_auth.username) &&
	    (!http_auth.credential || !*http_auth.credential)) {
		int empty_auth = curl_empty_auth_enabled();
		if ((empty_auth != -1 && !always_auth_proactively()) || empty_auth == 1) {
			curl_easy_setopt(result, CURLOPT_USERPWD, ":");
			return;
		} else if (!always_auth_proactively()) {
			return;
		} else if (http_proactive_auth == PROACTIVE_AUTH_BASIC) {
			strvec_push(&http_auth.wwwauth_headers, "Basic");
		}
	}

	credential_fill(&http_auth, 1);

	if (http_auth.password) {
		if (always_auth_proactively()) {
			/*
			 * We got a credential without an authtype and we don't
			 * know what's available.  Since our only two options at
			 * the moment are auto (which defaults to basic) and
			 * basic, use basic for now.
			 */
			curl_easy_setopt(result, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
		}
		curl_easy_setopt(result, CURLOPT_USERNAME, http_auth.username);
		curl_easy_setopt(result, CURLOPT_PASSWORD, http_auth.password);
	}
}
static void reset(int proactive_value,int empty_value,int allowed) {
 memset(&http_auth,0,sizeof(http_auth));proactive=proactive_value;empty_auth=empty_value;
 permit_helper=allowed;filled=basic_hint=0;curl_username=curl_password=NULL;
}
int main(void) {
 CURL recorded=0;
 reset(1,0,1);init_curl_http_auth(&recorded);
 assert(filled==1&&basic_hint&&curl_username&&curl_password);
 assert(!strcmp(curl_username,"alice")&&!strcmp(curl_password,"DUMMY_SELECTED"));
 /* curl optional-netrc's inspected branch requires absent STRING_USERNAME. */
 assert(!(1&&!curl_username));puts("both exact auth overrides: selected full credential installed before optional-netrc branch");
 reset(1,1,1);init_curl_http_auth(&recorded);
 assert(filled==0&&!curl_username&&!curl_password);puts("negative emptyAuth=true: selected full credential not installed");
 reset(0,0,1);init_curl_http_auth(&recorded);
 assert(filled==0&&!curl_username&&!curl_password);puts("negative proactive omitted: selected full credential not installed");
 reset(1,0,0);if(!setjmp(refuse)){init_curl_http_auth(&recorded);assert(0);}
 assert(filled==1&&!curl_username&&!curl_password);puts("missing-owner/wrong-endpoint refusal stub: no request continuation or fallback");
 return 0;
}
