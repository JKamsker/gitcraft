#![allow(dead_code,unused_imports)]
mod theme {
 #[derive(Clone)] pub struct Tokens {pub text:egui::Color32,pub text_dim:egui::Color32,pub text_faint:egui::Color32,pub warning:egui::Color32,pub danger:egui::Color32,pub success:egui::Color32}
 impl Tokens {pub fn get(_: &egui::Context)->Self{Self{text:egui::Color32::WHITE,text_dim:egui::Color32::GRAY,text_faint:egui::Color32::GRAY,warning:egui::Color32::YELLOW,danger:egui::Color32::RED,success:egui::Color32::GREEN}}}
 pub fn medium(size:f32)->egui::FontId {egui::FontId::new(size,egui::FontFamily::Name("review-medium".into()))}
 pub fn install_fonts(ctx: &egui::Context){let mut fonts=egui::FontDefinitions::default();fonts.families.insert(egui::FontFamily::Name("review-medium".into()),fonts.families[&egui::FontFamily::Proportional].clone());ctx.set_fonts(fonts);}
}
mod pull_request {pub fn markdown_options()->pulldown_cmark::Options {use pulldown_cmark::Options; Options::ENABLE_TABLES | Options::ENABLE_TASKLISTS | Options::ENABLE_STRIKETHROUGH | Options::ENABLE_FOOTNOTES | Options::ENABLE_DEFINITION_LIST}}

mod connections{pub type Context=u8;pub fn current()->Context{0}}
mod tasks{#[derive(Default)]pub struct Scope(pub());pub enum Priority{Interactive}pub struct Pool;pub fn pool()->Result<Pool,String>{Ok(Pool)}impl Pool{pub fn submit(&self,_:(),_:Priority,_:Option<()>,f:Box<dyn FnOnce()+Send>)->Result<(),&'static str>{f();Ok(())}}}
mod repo{pub mod highlight{pub const MAX_LINE_CHARS:usize=5000;}
#[path="/tmp/gitcraft-51-rich-r2-harness/find.rs"]pub mod find;
mod metadata{
use crate::{connections,tasks};use std::collections::{BTreeMap,VecDeque};use std::sync::mpsc::{self,Receiver};use std::time::Duration;
#[derive(Clone,Copy,Debug,PartialEq,Eq)]enum Ecosystem{Cargo,Npm,Other}
type Registry=Option<(String,String)>;struct DepChange{name:String,metadata_registry:(Registry,Registry)}
#[path="/tmp/gitcraft-51-rich-r2-53832430/src/repo/diff/rich/dependency_metadata/archive.rs"]mod archive;
#[derive(Clone, Debug, Default, PartialEq, Eq)]
pub(super) struct Metadata {
    pub license: Option<String>,
    pub changelogs: BTreeMap<String, String>,
    pub archive_url: String,
    pub license_file: Option<(String, Result<String, String>)>,
    pub license_note: Option<String>,
    pub skipped: BTreeMap<String, String>,
}
#[derive(Clone, Debug, PartialEq, Eq)]
struct Request {
    ecosystem: Ecosystem,
    old: Registry,
    new: Registry,
}
type Side = Result<Option<Metadata>, String>;
type Answer = (Side, Side);
fn read_both(
    eco: Ecosystem,
    old: &Registry,
    new: &Registry,
    mut read: impl FnMut(Ecosystem, &Registry) -> Side,
) -> Answer {
    // A missing/broken predecessor must never prevent reading the updated release.
    (read(eco, old), read(eco, new))
}
struct Pending {
    rx: Receiver<Answer>,
    _scope: tasks::Scope,
    context: connections::Context,
}
#[derive(Default)]
pub(super) struct State {
    selected: Option<(String, Request)>,
    pending: Option<Pending>,
    cache: VecDeque<(Request, Answer)>,
    result: Option<Answer>,
    generation: u64,
}

fn parse(
    ecosystem: Ecosystem,
    name: &str,
    version: &str,
    archive_url: String,
    bytes: &[u8],
) -> Result<Metadata, String> {
    let mut archive = archive::texts(bytes)?;
    let mut license_file = None;
    let mut license_note = None;
    let files = &mut archive.files;
    let license = match ecosystem {
        Ecosystem::Cargo => {
            let manifest = files.remove("Cargo.toml").ok_or_else(|| {
                archive
                    .skipped
                    .get("Cargo.toml")
                    .cloned()
                    .unwrap_or_else(|| "Package omits a regular Cargo.toml".into())
            })?;
            let doc = manifest
                .parse::<toml_edit::Document<String>>()
                .map_err(|_| "Invalid published Cargo.toml")?;
            let package = doc
                .get("package")
                .ok_or("Published manifest omits package")?;
            if package.get("name").and_then(|x| x.as_str()) != Some(name)
                || package.get("version").and_then(|x| x.as_str()) != Some(version)
            {
                return Err("Published package identity mismatch".into());
            }
            if let Some(path) = package.get("license-file").and_then(|x| x.as_str()) {
                let safe = !path.is_empty()
                    && !path.starts_with('/')
                    && !path.contains('\\')
                    && !path.chars().any(char::is_control)
                    && path.split('/').all(|p| p != "..");
                let normal = path
                    .split('/')
                    .filter(|p| !matches!(*p, "" | "."))
                    .collect::<Vec<_>>()
                    .join("/");
                let content = if safe && !normal.is_empty() {
                    let mut selected = archive::texts_with(bytes, Some(&normal))?;
                    selected.files.remove(&normal).ok_or_else(|| selected.skipped.remove(&normal)
                        .unwrap_or_else(|| "declared licence file is missing, not a regular file, or unavailable in the archive".into()))
                } else {
                    Err("declared licence file path is unsafe or outside the package".into())
                };
                license_file = Some((path.to_owned(), content));
            }
            package
                .get("license")
                .and_then(|x| x.as_str())
                .filter(|s| !s.is_empty())
                .map(str::to_owned)
        }
        Ecosystem::Npm => {
            let manifest: serde_json::Value =
                serde_json::from_str(&files.remove("package.json").ok_or_else(|| {
                    archive
                        .skipped
                        .get("package.json")
                        .cloned()
                        .unwrap_or_else(|| "Package omits a regular package.json".into())
                })?)
                .map_err(|_| "Invalid published package.json")?;
            if manifest["name"].as_str() != Some(name)
                || manifest["version"].as_str() != Some(version)
            {
                return Err("Published package identity mismatch".into());
            }
            let value = manifest.get("license").or_else(|| manifest.get("licenses"));
            fn declared(value: &serde_json::Value) -> Option<String> {
                match value {
                    serde_json::Value::String(s) if !s.is_empty() => Some(s.clone()),
                    serde_json::Value::Object(o) => o.get("type").and_then(declared),
                    serde_json::Value::Array(items) => {
                        let terms = items.iter().map(declared).collect::<Option<Vec<_>>>()?;
                        (!terms.is_empty()).then(|| terms.join(" OR "))
                    }
                    _ => None,
                }
            }
            let license = value.and_then(declared);
            if value.is_some() && license.is_none() {
                license_note = Some("licence declaration uses an unsupported representation; its meaning is unknown".into());
            }
            license
        }
        _ => return Err("Unsupported package registry".into()),
    };
    files.remove("Cargo.toml");
    files.remove("package.json");
    Ok(Metadata {
        license,
        changelogs: std::mem::take(files),
        archive_url,
        license_file,
        license_note,
        skipped: archive.skipped,
    })
}

fn fetch(_:Ecosystem,_:&Registry)->Side{Err("recording-only fetch boundary".into())}
impl Metadata {
    fn license_summary(&self) -> String {
        let mut terms = Vec::new();
        if let Some(expression) = &self.license {
            terms.push(expression.clone());
        }
        if let Some((path, content)) = &self.license_file {
            terms.push(format!(
                "declared file {path}{}",
                if content.is_err() {
                    " (content unavailable)"
                } else {
                    ""
                }
            ));
        }
        if let Some(note) = &self.license_note {
            terms.push(note.clone());
        }
        if terms.is_empty() {
            "not declared in published manifest".into()
        } else {
            terms.join("; ")
        }
    }
    fn license_complete(&self) -> bool {
        self.license_note.is_none()
            && self
                .license_file
                .as_ref()
                .is_none_or(|(_, text)| text.is_ok())
    }
    fn licence_eq(&self, other: &Self) -> bool {
        self.license == other.license && self.license_file == other.license_file
    }
    fn append_document(
        &self,
        doc: &mut crate::repo::find::rendered::Document,
        side: &str,
        t: &crate::theme::Tokens,
    ) {
        doc.text(
            &format!("{side}: published archive · {}", self.archive_url),
            t.text_dim,
        );
        doc.text(
            &format!("{side} licence: {}", self.license_summary()),
            t.warning,
        );
        if let Some((path, content)) = &self.license_file {
            doc.text(&format!("{side} declared licence file: {path}"), t.text);
            match content {
                Ok(text) => doc.text(text, t.text),
                Err(error) => doc.text(error, t.warning),
            }
        }
        if self.changelogs.is_empty() {
            doc.text(&format!("{side}: no readable recognised changelog in retained metadata; other filenames may exist."), t.text_dim);
        }
        for (path, text) in &self.changelogs {
            doc.text(&format!("{side} changelog: {path}"), t.text);
            doc.text(text, t.text);
        }
        for (path, reason) in &self.skipped {
            doc.text(&format!("{side}: {path} · {reason}"), t.warning);
        }
    }
}
fn side_summary(side: &Side) -> String {
    match side {
        Ok(Some(m)) => m.license_summary(),
        Ok(None) => "not recorded as a supported public-registry package".into(),
        Err(error) => format!("unknown ({error})"),
    }
}
fn changed(answer: &Answer) -> bool {
    match answer {
        (Ok(Some(a)), Ok(Some(b))) if a.license_complete() && b.license_complete() => {
            !a.licence_eq(b)
        }
        _ => false,
    }
}
impl State {
    pub fn generation(&self) -> u64 {
        self.generation
    }
    pub fn select(&mut self, eco: Ecosystem, change: &DepChange, ctx: &egui::Context) {
        self.start(
            change.name.clone(),
            Request {
                ecosystem: eco,
                old: change.metadata_registry.0.clone(),
                new: change.metadata_registry.1.clone(),
            },
            ctx,
            false,
        );
    }
    fn start(&mut self, name: String, request: Request, ctx: &egui::Context, retry: bool) {
        self.start_using(name, request, ctx, retry, fetch);
    }
    fn start_using(
        &mut self,
        name: String,
        request: Request,
        ctx: &egui::Context,
        retry: bool,
        mut read: impl FnMut(Ecosystem, &Registry) -> Side + Send + 'static,
    ) {
        self.generation = self.generation.wrapping_add(1);
        self.pending = None;
        self.selected = Some((name, request.clone()));
        if retry {
            self.cache.retain(|(r, _)| r != &request);
        }
        self.result = self
            .cache
            .iter()
            .find(|(r, _)| *r == request)
            .map(|(_, a)| a.clone());
        if request.old.is_none() && request.new.is_none() {
            let error = "Metadata unavailable: the lockfile does not identify a supported public registry; no package name was sent".to_owned();
            self.result = Some((Err(error.clone()), Err(error)));
            return;
        }
        if self.result.is_some() {
            return;
        }
        let (tx, rx) = mpsc::channel();
        let scope = tasks::Scope::default();
        let repaint = ctx.clone();
        let work = request.clone();
        let submitted = tasks::pool().and_then(|pool| {
            pool.submit(
                scope.0.clone(),
                tasks::Priority::Interactive,
                None,
                Box::new(move || {
                    let answer = read_both(work.ecosystem, &work.old, &work.new, &mut read);
                    let _ = tx.send(answer);
                    repaint.request_repaint();
                }),
            )
            .map_err(str::to_owned)
        });
        match submitted {
            Ok(()) => {
                self.pending = Some(Pending {
                    rx,
                    _scope: scope,
                    context: connections::current(),
                })
            }
            Err(e) => self.result = Some((Err(e.clone()), Err(e))),
        }
    }
    pub fn poll(&mut self, ctx: &egui::Context) {
        if self
            .pending
            .as_ref()
            .is_some_and(|p| p.context != connections::current())
        {
            self.pending = None;
            self.result = Some((
                Err("Profile changed; select the package again".into()),
                Err("Profile changed; select the package again".into()),
            ));
            self.generation = self.generation.wrapping_add(1);
        }
        if let Some(pending) = &self.pending {
            match pending.rx.try_recv() {
                Ok(answer) => {
                    self.generation = self.generation.wrapping_add(1);
                    self.pending = None;
                    // Offline, cancelled and transient responses remain retryable. Partial
                    // successes stay visible but never poison the complete-result cache.
                    if answer.0.is_ok()
                        && answer.1.is_ok()
                        && let Some((_, request)) = &self.selected
                    {
                        self.cache.retain(|(r, _)| r != request);
                        self.cache.push_back((request.clone(), answer.clone()));
                        if self.cache.len() > 8 {
                            self.cache.pop_front();
                        }
                    }
                    self.result = Some(answer);
                }
                Err(mpsc::TryRecvError::Disconnected) => {
                    self.pending = None;
                    self.generation = self.generation.wrapping_add(1);
                    self.result = Some((
                        Err("Package metadata task cancelled or stopped".into()),
                        Err("Package metadata task cancelled or stopped".into()),
                    ));
                }
                Err(mpsc::TryRecvError::Empty) => {
                    ctx.request_repaint_after(Duration::from_millis(100))
                }
            }
        }
    }
    fn close(&mut self) {
        self.selected = None;
        self.pending = None;
        self.result = None;
        self.generation = self.generation.wrapping_add(1);
    }
    pub fn append_document(
        &self,
        doc: &mut crate::repo::find::rendered::Document,
        t: &crate::theme::Tokens,
    ) {
        let Some((name, _)) = &self.selected else {
            return;
        };
        doc.text(
            &format!("{name}: published licences and changelogs"),
            t.text,
        );
        if self.pending.is_some() {
            doc.text("Reading the exact published versions…", t.text_dim);
        }
        if let Some(answer) = &self.result {
            doc.text(
                &format!(
                    "Licence{}: {} → {}",
                    if changed(answer) { " changed" } else { "" },
                    side_summary(&answer.0),
                    side_summary(&answer.1)
                ),
                t.warning,
            );
            for (side, result) in [("Before", &answer.0), ("After", &answer.1)] {
                match result {
                    Ok(Some(m)) => m.append_document(doc, side, t),
                    Ok(None) => doc.text(
                        &format!("{side}: metadata unavailable for this source"),
                        t.text_dim,
                    ),
                    Err(error) => doc.text(&format!("{side}: {error}"), t.warning),
                }
            }
        }
    }
    pub fn show(&mut self, ui: &mut egui::Ui) {
        self.poll(ui.ctx());
        let Some((name, request)) = self.selected.clone() else {
            return;
        };
        let mut retry = false;
        ui.horizontal(|ui| {
            ui.strong(format!("{name}: published licences and changelogs"));
            if ui.button("Close / cancel").clicked() {
                self.close();
            }
            if self.pending.is_none()
                && self
                    .result
                    .as_ref()
                    .is_some_and(|(a, b)| a.is_err() || b.is_err())
                && ui.button("Retry metadata").clicked()
            {
                retry = true;
            }
        });
        if retry {
            self.start(name, request, ui.ctx(), true);
        }
        if self.pending.is_some() {
            ui.label("Reading the exact published versions (up to 12 seconds per request)…");
        }
        if let Some(answer) = &self.result {
            ui.label(format!(
                "Licence{}: {} → {}",
                if changed(answer) { " changed" } else { "" },
                side_summary(&answer.0),
                side_summary(&answer.1)
            ));
            egui::ScrollArea::vertical().id_salt("dependency_metadata").max_height(240.0).show(ui,|ui| {
                for (side,result) in [("Before",&answer.0),("After",&answer.1)] {
                    let metadata = match result {
                        Ok(Some(m))=>m,
                        Ok(None)=>{ui.label(format!("{side}: metadata unavailable for this source"));continue;},
                        Err(error)=>{ui.label(format!("{side}: {error}"));continue;},
                    };
                    ui.hyperlink_to(format!("{side}: published archive"),&metadata.archive_url);
                    if let Some((path,content)) = &metadata.license_file {
                        egui::CollapsingHeader::new(format!("{side} declared licence file: {path}")).id_salt((side,"licence-file")).show(ui,|ui| {
                            match content {Ok(text)=>{ui.label(text);},Err(error)=>{ui.label(error);}}
                        });
                    }
                    if metadata.changelogs.is_empty() {ui.label(format!("{side}: changelog unavailable — no readable recognised filename in retained metadata; other filenames may exist."));}
                    for (path,reason) in &metadata.skipped {ui.label(format!("{side}: {path} · {reason}"));}
                    for (path,text) in &metadata.changelogs {
                        egui::CollapsingHeader::new(format!("{side} changelog: {path}")).id_salt((side,path)).show(ui,|ui| {
                            ui.add(egui::Label::new(egui::RichText::new(text).monospace()).wrap());
                        });
                    }
                }
            });
        }
        ui.separator();
    }
}
 fn fixture(files:&[(&str,String)])->Vec<u8>{use std::io::Write; let mut tar=Vec::new();for(name,body)in files{let mut h=[0u8;512];let path=format!("package/{name}");h[..path.len()].copy_from_slice(path.as_bytes());h[124..136].copy_from_slice(format!("{:011o}\0",body.len()).as_bytes());h[148..156].fill(b' ');h[156]=b'0';let sum:usize=h.iter().map(|b|*b as usize).sum();h[148..156].copy_from_slice(format!("{sum:06o}\0 ").as_bytes());tar.extend_from_slice(&h);tar.extend_from_slice(body.as_bytes());tar.resize(tar.len().div_ceil(512)*512,0);}tar.extend_from_slice(&[0u8;1024]);let mut gz=flate2::write::GzEncoder::new(Vec::new(),flate2::Compression::fast());gz.write_all(&tar).unwrap();gz.finish().unwrap()}

#[test]fn r2_license_file_and_oversize_evidence(){let a=fixture(&[("Cargo.toml","[package]\nname='thing'\nversion='1.0.0'\nlicense-file='./legal/terms.txt'".into()),("legal/terms.txt","Actual custom licence".into()),("CHANGELOG.md","x".repeat((512<<10)+1))]);let m=parse(Ecosystem::Cargo,"thing","1.0.0","fixture".into(),&a).unwrap();assert_eq!(m.license_file.as_ref().unwrap().1.as_ref().unwrap(),"Actual custom licence");assert!(m.skipped["CHANGELOG.md"].contains("512 KiB"));assert!(m.license_complete());println!("declared normalized licence retained; oversize changelog explicitly included-but-skipped");}
#[test]fn r2_legacy_and_unknown_npm_licences(){for (decl,want) in [(r#""license":{"type":"MIT"}"#,Some("MIT")),(r#""licenses":[{"type":"MIT"},{"type":"ISC"}]"#,Some("MIT OR ISC")),(r#""license":{"other":"unknown"}"#,None)]{let manifest=format!("{{\"name\":\"p\",\"version\":\"1\",{decl}}}");let a=fixture(&[("package.json",manifest)]);let m=parse(Ecosystem::Npm,"p","1","fixture".into(),&a).unwrap();assert_eq!(m.license.as_deref(),want);if want.is_none(){assert!(m.license_note.is_some());assert!(!m.license_complete());}}}
#[test]fn r2_sides_retry_and_reader_generation(){let ctx=egui::Context::default();let req=Request{ecosystem:Ecosystem::Cargo,old:Some(("p".into(),"1".into())),new:Some(("p".into(),"2".into()))};let calls=std::sync::Arc::new(std::sync::Mutex::new(Vec::new()));let c=calls.clone();let mut s=State::default();s.start_using("p".into(),req.clone(),&ctx,false,move|_,r|{let v=r.as_ref().unwrap().1.clone();c.lock().unwrap().push(v.clone());if v=="1"{Err("transient".into())}else{Ok(Some(Metadata{license:Some("MIT".into()),changelogs:BTreeMap::from([("CHANGES".into(),"RELEASE_NEEDLE".into())]),..Default::default()}))}});let before=s.generation();s.poll(&ctx);assert!(s.generation()>before);assert_eq!(*calls.lock().unwrap(),vec!["1","2"]);assert!(s.cache.is_empty());let mut d=super::find::rendered::Document::default();s.append_document(&mut d,&crate::theme::Tokens::get(&ctx));let text=d.rows.iter().map(|r|r.text.as_str()).collect::<Vec<_>>().join("\n");assert!(text.contains("transient")&&text.contains("RELEASE_NEEDLE"));s.close();s.start_using("p".into(),req.clone(),&ctx,false,|_,_|Ok(Some(Metadata{license:Some("ISC".into()),..Default::default()})));s.poll(&ctx);assert_eq!(s.cache.len(),1);assert!(matches!(&s.result,Some((Ok(Some(_)),Ok(Some(_))))));println!("both sides attempted; good side searchable beside error; close/reselect retries; accepted result generation changes");}
}
mod prose{use egui::{Color32,Stroke};use egui::text::{LayoutJob,TextFormat};use crate::theme::Tokens;const MAX_CHARS:usize=20000;#[derive(Clone,Copy)]enum Change{Kept,Removed,Added}
fn changed(words: &[(Change, String)], font: &egui::FontId, t: &Tokens) -> LayoutJob {
    changed_with_limit(words, font, t, Some(MAX_CHARS))
}
pub(super) fn search_changed(words: &[(Change, String)], t: &Tokens) -> LayoutJob {
    changed_with_limit(words, &egui::FontId::proportional(14.0), t, None)
}
fn append(job: &mut LayoutJob, text: &str, format: TextFormat) {
    if let Some(last) = job.sections.last_mut()
        && last.format == format
        && last.byte_range.end.0 == job.text.len()
    {
        job.text.push_str(text);
        last.byte_range.end = egui::text::ByteIndex(job.text.len());
    } else {
        job.append(text, 0.0, format);
    }
}
fn changed_with_limit(
    words: &[(Change, String)],
    font: &egui::FontId,
    t: &Tokens,
    limit: Option<usize>,
) -> LayoutJob {
    let mut job = LayoutJob::default();
    let mut shown = 0;
    for (change, word) in words {
        if limit.is_some_and(|limit| shown > limit) {
            job.append(" …", 0.0, TextFormat::simple(font.clone(), t.text_faint));
            break;
        }
        shown += word.len();
        // The space before a word stays plain; only the word is marked.
        let lead = word.len() - word.trim_start().len();
        let (space, body) = word.split_at(lead);
        if !space.is_empty() {
            append(&mut job, space, TextFormat::simple(font.clone(), t.text));
        }
        let (background, strike) = match change {
            Change::Kept => (Color32::TRANSPARENT, Stroke::NONE),
            Change::Removed => (t.danger.gamma_multiply(0.35), Stroke::new(1.0, t.text_dim)),
            Change::Added => (t.success.gamma_multiply(0.35), Stroke::NONE),
        };
        append(
            &mut job,
            body,
            TextFormat {
                font_id: font.clone(),
                color: t.text,
                background,
                strikethrough: strike,
                ..Default::default()
            },
        );
    }
    job
}

#[test]fn r2_complete_changed_prose_tail(){let mut words=vec![(Change::Kept,"é ".into());11000];words.push((Change::Added,"TAIL_NEEDLE".into()));let t=Tokens::get(&egui::Context::default());assert!(!changed(&words,&egui::FontId::proportional(14.0),&t).text.contains("TAIL_NEEDLE"));let j=search_changed(&words,&t);assert!(j.text.ends_with("TAIL_NEEDLE"));assert!(j.sections.len()<10);println!("complete changed-prose tail retained and styles coalesced");}
}
}
