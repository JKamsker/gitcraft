#![allow(dead_code)]
extern crate self as egui;
#[derive(Clone,Default)] pub struct Context;
impl Context { pub fn request_repaint(&self) {} }
mod remote { pub fn is_remote(_: &std::path::Path)->bool { false } }
mod safe_read {
 pub fn read_inside(root:&std::path::Path,file:&str,limit:u64)->Option<Vec<u8>> {
  let b=std::fs::read(root.join(file)).ok()?; (b.len() as u64 <= limit).then_some(b)
 }
}
mod shell_path { pub fn apply(_: &mut std::process::Command) {} }
mod processes {
 pub type Chunk=Box<dyn FnMut(&[u8])+Send>;
 #[derive(Default)] pub struct Options {pub timeout:Option<std::time::Duration>,pub background:bool,pub output_limit:usize,pub stderr:Option<Chunk>}
 pub struct Output {pub stdout:Vec<u8>,pub status:std::process::ExitStatus,pub stopped:Option<String>}
 pub static RECORDS:std::sync::Mutex<Vec<Vec<String>>>=std::sync::Mutex::new(Vec::new());
 pub fn run(command:std::process::Command,mut options:Options)->Result<Output,String> {
  use std::os::unix::process::ExitStatusExt;
  let args:Vec<_>=command.get_args().map(|s|s.to_string_lossy().into_owned()).collect();
  assert_eq!(command.get_program(),"never-executed-recording-act");
  assert!(command.get_current_dir().unwrap().join("workflow.yml").is_file());
  for key in ["GH_TOKEN","GITHUB_TOKEN","GH_ENTERPRISE_TOKEN","GITLAB_TOKEN","GLAB_TOKEN","GITEA_TOKEN","TEA_TOKEN","AZURE_DEVOPS_EXT_PAT"] {
   assert!(command.get_envs().any(|(k,v)|k==key && v.is_none()),"missing removal: {key}");
  }
  assert_eq!(options.timeout,Some(std::time::Duration::from_secs(60)));
  if let Some(f)=&mut options.stderr {f(b"streamed-stderr\n");}
  RECORDS.lock().unwrap().push(args);
  Ok(Output {stdout:b"buffered-stdout\n".to_vec(),status:std::process::ExitStatus::from_raw(0),stopped:None})
 }
}
#[path="/var/folders/0z/snd05v_n21jd6pkhvg2h0vlc0000gp/T/gitcraft-act-r1-052721ed-ygjmojz0/src/repo/local_ci/model.rs"] mod model;
#[path="/var/folders/0z/snd05v_n21jd6pkhvg2h0vlc0000gp/T/gitcraft-act-r1-052721ed-ygjmojz0/src/repo/local_ci/run.rs"] mod run;
fn select()->run::Selection {
 let workflow=model::parse(".github/workflows/test.yml".into(),"on: push\njobs: {test: {runs-on: ubuntu-latest, steps: [{run: echo hi}]}}\n".into()).unwrap();
 let matrix=workflow.matrices("test").unwrap().remove(0);
 run::Selection {workflow,remote:"missing-context".into(),event:"push".into(),job:"test".into(),matrix,payload:"{}".into(),platforms:"ubuntu-latest=trusted/image:v1".into(),architecture:"linux/amd64".into(),minutes:0}
}
fn main() {
 let own=run::Scratch::new().unwrap(); let home=own.0.join("home");std::fs::create_dir(&home).unwrap();
 // This is a single-thread recording-only harness; it never creates a child or process service.
 unsafe {std::env::set_var("HOME",&home);std::env::set_var("XDG_CONFIG_HOME",home.join("xdg"));std::env::set_var("APPDATA",home.join("appdata"));}
 let work=own.0.join("worktree with spaces");std::fs::create_dir_all(work.join(".github/workflows")).unwrap();
 std::fs::write(work.join(&select().workflow.file),&select().workflow.source).unwrap();
 let log=std::sync::Arc::new(std::sync::Mutex::new(run::Log::default()));
 let result=run::execute_with(work.clone(),select(),log.clone(),Context,std::ffi::OsStr::new("never-executed-recording-act"));
 assert!(result.is_ok()); let records=processes::RECORDS.lock().unwrap();let args=&records[0];
 assert!(args.windows(2).any(|a|a==["--remote-name","missing-context"]));assert!(!args.contains(&"--github-instance".into()));
 println!("CONFIRMED: nonexistent remote accepted; no --github-instance; no validation subprocess or remote read");
 println!("PASS: exact recording command preserves worktree with spaces, token removals, explicit private files and one-minute timeout clamp");
 println!("ARGS: {args:?}");drop(records);
 assert!(log.lock().unwrap().text.contains("streamed-stderr"));assert!(log.lock().unwrap().text.contains("buffered-stdout"));
 std::fs::write(work.join(&select().workflow.file),"changed").unwrap();
 let e=run::execute_with(work.clone(),select(),log.clone(),Context,std::ffi::OsStr::new("never-executed-recording-act")).unwrap_err();assert!(e.contains("changed since selection"));assert_eq!(processes::RECORDS.lock().unwrap().len(),1);
 println!("PASS: changed workflow rejected before recording command endpoint");
 std::fs::write(work.join(&select().workflow.file),&select().workflow.source).unwrap();std::fs::write(home.join(".actrc"),"--bind\n").unwrap();
 let e=run::execute_with(work,select(),log,Context,std::ffi::OsStr::new("never-executed-recording-act")).unwrap_err();assert!(e.contains("Ambient act configuration"));assert_eq!(processes::RECORDS.lock().unwrap().len(),1);
 println!("PASS: synthetic ambient HOME/.actrc refused before recording command endpoint");
}
