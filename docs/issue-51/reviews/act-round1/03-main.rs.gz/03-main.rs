#[path = "/var/folders/0z/snd05v_n21jd6pkhvg2h0vlc0000gp/T/gitcraft-act-r1-052721ed-ygjmojz0/src/repo/local_ci/model.rs"]
mod model;
fn parse_matrix(matrix: &str) -> model::Workflow {
    model::parse("w.yml".into(), format!("on: push\njobs:\n  test:\n    runs-on: ubuntu-latest\n    strategy:\n      matrix:\n{matrix}")).unwrap()
}
fn main() {
    let w=parse_matrix("        fruit: [apple, pear]\n        animal: [cat, dog]\n        include:\n          - {color: green}\n          - {color: pink, animal: cat}\n          - {fruit: apple, shape: circle}\n          - {fruit: banana}\n          - {fruit: banana, animal: cat}\n");
    let e=w.matrices("test").unwrap();
    assert_eq!(e.len(),6);
    assert_eq!(e[0]["color"].as_str(),Some("pink"));
    assert_eq!(e[1]["color"].as_str(),Some("green"));
    assert_eq!(e[4]["animal"],yaml_rust2::Yaml::BadValue);
    println!("PASS: official GitHub six-entry include example");
    let w=parse_matrix("        os: [linux, windows]\n        exclude: [{os: linux}]\n        include:\n          - {os: linux, foo: one}\n          - {bar: two}\n");
    let e=w.matrices("test").unwrap();
    println!("REPRO: excluded row reintroduced by include then followed by broad include");
    for row in &e { println!("{}",model::text(row)); }
    let linux=e.iter().find(|e|e["os"].as_str()==Some("linux")).unwrap();
    assert_eq!(linux["bar"].as_str(),Some("two"));
    println!("CONFIRMED: reintroduced linux row incorrectly receives later bar=two (act defers extra includes)");
    let snapshot=w.snapshot("push","test",linux,"r1").unwrap();
    let selected=model::parse("w.yml".into(),snapshot).unwrap();
    assert_eq!(selected.matrices("test").unwrap(),vec![linux.clone()]);
    println!("CONFIRMED: altered row is materialized unchanged into the single-entry execution snapshot");
}
