use std::{path::{Path,PathBuf},sync::atomic::{AtomicBool,AtomicUsize,Ordering},cell::RefCell,collections::BTreeMap};
static CHECKS: AtomicUsize=AtomicUsize::new(0);
struct Control { cancelled: AtomicBool }
struct Runner<'a>{ control: &'a Control, refs: RefCell<BTreeMap<String,String>>, deletions: RefCell<usize> }
struct Dependency { repo: PathBuf, fetch_url: String }
impl Runner<'_>{ fn in_repo(&self,_:&Path,args:&[&str])->Result<String,String>{
 if self.control.cancelled.load(Ordering::Relaxed) { return Err("Cancelled".into()); }
 if args[0]=="fetch" { let ns=args[args.len()-2].split(':').nth(1).unwrap().trim_end_matches('*').to_owned()+"main"; self.refs.borrow_mut().insert(ns,"a".repeat(40)); ROWS.with(|v| *v.borrow_mut()=self.refs.borrow().iter().map(|(n,o)|format!("{n} {o}\n")).collect()); self.control.cancelled.store(true,Ordering::Relaxed); return Err("Cancelled after owned refs materialized".into()); }
 *self.deletions.borrow_mut()+=1; self.refs.borrow_mut().remove(args[2]); Ok(String::new())
}}
thread_local!{static ROWS: RefCell<String>=const{RefCell::new(String::new())};}
fn text(_:&Path,args:&[&str])->Result<String,String>{ assert_eq!(args[0],"for-each-ref"); ROWS.with(|v|Ok(v.borrow().clone())) }
fn advertised(runner: &Runner<'_>, node: &Dependency) -> Result<Vec<String>, String> {
    let stamp = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map_err(|e| e.to_string())?
        .as_nanos();
    let ns = format!(
        "refs/gitcraft/dependency-check/{stamp}-{}-{}",
        std::process::id(),
        CHECKS.fetch_add(1, Ordering::Relaxed)
    );
    let fetch = runner.in_repo(
        &node.repo,
        &[
            "fetch",
            "--no-recurse-submodules",
            "--no-tags",
            "--no-write-fetch-head",
            "--",
            &node.fetch_url,
            &format!("+refs/heads/*:{ns}/heads/*"),
            &format!("+refs/tags/*:{ns}/tags/*"),
        ],
    );
    let rows = text(
        &node.repo,
        &["for-each-ref", "--format=%(refname) %(objectname)", &ns],
    )?;
    let mut tips = Vec::new();
    let mut cleanup_error = None;
    for row in rows.lines() {
        let (name, oid) = row.split_once(' ').ok_or("Invalid dependency ref record")?;
        tips.push(oid.into());
        if let Err(e) = runner.in_repo(&node.repo, &["update-ref", "-d", name, oid]) {
            cleanup_error = Some(e);
        }
    }
    fetch?;
    if let Some(e) = cleanup_error {
        return Err(format!(
            "Could not remove owned dependency-check refs: {e}. No parent push was attempted."
        ));
    }
    Ok(tips)
}
fn main(){ let control=Control{cancelled:AtomicBool::new(false)}; let runner=Runner{control:&control,refs:RefCell::new(BTreeMap::new()),deletions:RefCell::new(0)}; let n=Dependency{repo:PathBuf::from("owned-synthetic-repo"),fetch_url:"owned-synthetic-host".into()}; let result=advertised(&runner,&n); println!("result={result:?} attempted_delete_commands={} owned_refs_remaining={}",runner.deletions.borrow(),runner.refs.borrow().len()); assert!(result.is_err()); assert_eq!(*runner.deletions.borrow(),0); assert_eq!(runner.refs.borrow().len(),1); }
