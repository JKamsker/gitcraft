from pathlib import Path
import tempfile,subprocess,os,json
root=Path('/private/tmp/gitcraft-internals-review-core-r1')
helper='credential.helper=!f() { test "$1" = get && printf \'username=%s\\npassword=%s\\n\' "$GITCRAFT_GIT_USERNAME" "$GITCRAFT_GIT_PASSWORD"; }; f'
alias='alias.gitcraft-repository-write=!f() { unset GIT_DIR GIT_COMMON_DIR GIT_WORK_TREE GIT_INDEX_FILE GIT_OBJECT_DIRECTORY GIT_ALTERNATE_OBJECT_DIRECTORIES GIT_NAMESPACE GIT_REPLACE_REF_BASE GIT_SHALLOW_FILE GIT_CONFIG_COUNT GIT_CONFIG_PARAMETERS; git "$@"; }; f'
with tempfile.TemporaryDirectory(prefix='gitcraft-credential-scope-probe-',dir='/private/tmp') as d:
 subprocess.run(['/opt/homebrew/bin/git','-C',d,'init','-q'],check=True)
 env=dict(os.environ,GITCRAFT_GIT_USERNAME='DUMMY_HOST_A_USER',GITCRAFT_GIT_PASSWORD='DUMMY_HOST_A_TOKEN',GIT_CONFIG_NOSYSTEM='1',GIT_CONFIG_GLOBAL='/dev/null',GIT_TERMINAL_PROMPT='0')
 result=[]
 for host in ['selected-a.invalid','unrelated-b.invalid']:
  # Exact Runner alias and unscoped helper; credential fill performs NO network transport.
  r=subprocess.run(['/opt/homebrew/bin/git','-C',d,'-c',alias,'gitcraft-repository-write','-c','credential.helper=','-c',helper,'credential','fill'],input=('protocol=https\nhost='+host+'\n\n').encode(),stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=env,check=True)
  result.append({'requested_host':host,'response':r.stdout.decode().strip(),'network':'none; credential protocol only; values are dummy markers'})
 (root/'credential-scope.json').write_text(json.dumps(result))
