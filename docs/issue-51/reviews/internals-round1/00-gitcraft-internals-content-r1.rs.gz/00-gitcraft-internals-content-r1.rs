#![allow(dead_code)]
use std::{path::Path,sync::Arc};
mod remote {
 pub fn resolve(repo:&std::path::Path,p:&str)->std::path::PathBuf {if std::path::Path::new(p).is_absolute(){p.into()}else{repo.join(p)}}
 pub fn read_to_string(p:&std::path::Path)->std::io::Result<String>{std::fs::read_to_string(p)}
}
mod git {
 use super::*;
 pub struct Credentials;
 pub struct OpControl; impl OpControl {pub fn is_cancelled(&self)->bool{false} pub fn record(&self,_:()){} }
 pub const CANCELLED:&str="cancelled";
 pub fn profile_config()->Option<std::path::PathBuf>{None}
 fn cmd(repo:Option<&Path>,args:&[&str],input:Option<&[u8]>,clear:bool)->Result<std::process::Output,String>{
  use std::io::Write;
  let mut c=std::process::Command::new("git");if let Some(p)=repo{c.arg("-C").arg(p);}c.args(args);
  if clear {for k in ["GIT_DIR","GIT_COMMON_DIR","GIT_WORK_TREE","GIT_INDEX_FILE","GIT_OBJECT_DIRECTORY","GIT_ALTERNATE_OBJECT_DIRECTORIES","GIT_NAMESPACE","GIT_REPLACE_REF_BASE","GIT_SHALLOW_FILE","GIT_CONFIG_COUNT","GIT_CONFIG_PARAMETERS"]{c.env_remove(k);}}
  c.stdin(std::process::Stdio::piped()).stdout(std::process::Stdio::piped()).stderr(std::process::Stdio::piped());
  let mut h=c.spawn().map_err(|e|e.to_string())?;if let Some(i)=input {h.stdin.take().unwrap().write_all(i).map_err(|e|e.to_string())?;} else {drop(h.stdin.take());}h.wait_with_output().map_err(|e|e.to_string())
 }
 pub fn run(repo:Option<&Path>,a:&[&str])->Result<String,String>{run_ok_codes(repo,a,&[0])}
 pub fn run_ok_codes(repo:Option<&Path>,a:&[&str],codes:&[i32])->Result<String,String>{let (_,b)=run_code(repo,a,codes)?;String::from_utf8(b).map_err(|e|e.to_string())}
 pub fn run_code(repo:Option<&Path>,a:&[&str],codes:&[i32])->Result<(i32,Vec<u8>),String>{let o=cmd(repo,a,None,false)?;if !codes.contains(&o.status.code().unwrap_or(-1)){return Err(String::from_utf8_lossy(&o.stderr).into());}Ok((o.status.code().unwrap(),o.stdout))}
 pub fn run_input(repo:Option<&Path>,a:&[&str],i:&str)->Result<String,String>{let o=cmd(repo,a,Some(i.as_bytes()),false)?;if !o.status.success(){return Err(String::from_utf8_lossy(&o.stderr).into());}String::from_utf8(o.stdout).map_err(|e|e.to_string())}
 pub struct Captured {pub code:Option<i32>,pub stderr:String,pub stdout:String}
 pub fn run_captured(repo:&Path,a:&[&str],i:Option<&[u8]>)->Result<Captured,String>{let o=cmd(Some(repo),a,i,false)?;Ok(Captured{code:o.status.code(),stderr:String::from_utf8_lossy(&o.stderr).into(),stdout:String::from_utf8_lossy(&o.stdout).into()})}
 pub fn run_watched_recorded(repo:Option<&Path>,a:&[&str],_:Option<&Credentials>,_:bool,_:&Arc<OpControl>)->(Result<String,String>,()) {(run(repo,a),())}
 pub mod repository_tools {
  use super::*;
  pub fn read(repo:&Path,a:&[&str],i:Vec<u8>,_:usize)->Result<Vec<u8>,String>{let o=super::cmd(Some(repo),a,Some(&i),true)?;if !o.status.success(){return Err(String::from_utf8_lossy(&o.stderr).into());}Ok(o.stdout)}
  pub mod object {pub fn valid_oid(s:&str)->bool{matches!(s.len(),40|64)&&s.bytes().all(|b|b.is_ascii_hexdigit())}}
  #[path="/Users/jonas/.t3/worktrees/gitcraft/t3-3a66e6f0/src/git/repository_tools/guard.rs"] pub mod guard;
  #[path="/Users/jonas/.t3/worktrees/gitcraft/t3-3a66e6f0/src/git/repository_tools/replacements.rs"] pub mod replacements;
  #[path="/Users/jonas/.t3/worktrees/gitcraft/t3-3a66e6f0/src/git/repository_tools/all_refs.rs"] pub mod all_refs;
  #[path="/Users/jonas/.t3/worktrees/gitcraft/t3-3a66e6f0/src/git/repository_tools/reftable.rs"] pub mod reftable;
 }
}
fn main()->Result<(),String>{
 let a:Vec<_>=std::env::args().collect();let repo=Path::new(&a[1]);let decoy=Path::new(&a[2]);let first=&a[3];let second=&a[4];
 if a.get(5).is_some_and(|s|s=="migrate") {
  let c=Arc::new(git::OpControl);let runner=git::repository_tools::guard::Runner{repo,control:&c,credentials:None};
  let before=git::run(Some(repo),&["for-each-ref","--include-root-refs","--format=%(refname) %(objectname) %(symref)"])?;
  println!("before including root refs: {before}");
  let storage=git::repository_tools::reftable::inspect(repo)?;println!("to reftable: {:?}",git::repository_tools::reftable::migrate(&runner,&storage,"reftable"));
  let storage=git::repository_tools::reftable::inspect(repo)?;println!("to files: {:?}",git::repository_tools::reftable::migrate(&runner,&storage,"files"));
  let after=git::run(Some(repo),&["for-each-ref","--include-root-refs","--format=%(refname) %(objectname) %(symref)"])?;assert_eq!(before,after);println!("root, symbolic, noncommit and namespace refs independently equal after roundtrip");return Ok(());
 }
 // Recreate target's clean graph in this disposable fixture.
 let _=git::run(Some(repo),&["replace","-d",first]);
 let correct=git::repository_tools::all_refs::read(repo,"")?;
 println!("ordinary target refs: {:?}",correct.refs);
 unsafe{std::env::set_var("GIT_DIR",decoy.join(".git"));}
 let redirected=git::repository_tools::all_refs::read(repo,"")?;
 println!("GIT_DIR redirected refs: {:?}",redirected.refs);
 println!("redirected all-refs includes decoy-only replace ref: {}",redirected.refs.iter().any(|r|r.name==format!("refs/replace/{second}")));
 let hist=git::repository_tools::replacements::read(repo)?;
 println!("replacement snapshot identity (must be target): {}",hist.snapshot.identity.trim());
 let control=Arc::new(git::OpControl);let runner=git::repository_tools::guard::Runner{repo,control:&control,credentials:None};
 let result=git::repository_tools::replacements::graft(&runner,&hist,first,second);
 println!("cycle-forming graft result: {:?}",result);
 unsafe{std::env::remove_var("GIT_DIR");}
 println!("actual target graph: {}",git::run(Some(repo),&["rev-list","--parents","--all"])?);
 assert!(result.is_ok());
 let storage=git::repository_tools::reftable::inspect(repo)?; println!("migration inspect: format={} capability={} blocked={:?}",storage.format,storage.migrates,storage.blocked);
 let _=git::run(Some(repo),&["replace","-d",first]);
 let graft=repo.join(".git/info/grafts");std::fs::write(&graft,format!("#{}\n","x".repeat(8*1024*1024))).map_err(|e|e.to_string())?;
 let large=git::repository_tools::replacements::read(repo)?; println!("legacy graft bytes retained for UI: {}",large.legacy.len()); std::fs::remove_file(graft).map_err(|e|e.to_string())?;
 Ok(())
}
