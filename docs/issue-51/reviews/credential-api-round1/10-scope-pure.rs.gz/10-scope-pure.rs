use std::io::{self,Write};
#[path="/tmp/gitcraft-credential-api-r1-source/credentials/src/git/credential_scope.rs"] mod credential_scope;
pub struct Credentials { pub username:String,pub password:String,pub scope:Option<credential_scope::CredentialScope> }
fn main(){
let scope=credential_scope::CredentialScope::for_url("https://host-a.invalid/team/repo.git","alice").unwrap();
assert!(scope.matches_url("https://HOST-A.invalid:443/team/repo.git"));
for u in ["https://host-b.invalid/team/repo.git","http://host-a.invalid/team/repo.git","https://host-a.invalid:444/team/repo.git","https://host-a.invalid/team/other.git","https://host-a.invalid/team/repo.git/info/lfs"]{assert!(!scope.matches_url(u));}
assert!(credential_scope::CredentialScope::for_url("https://host-a.invalid/%0ainjected","alice").is_err());
assert!(Credentials{username:"alice".into(),password:"DUMMY".into(),scope:None}.helper_environment().is_err());
let mut c=Credentials::for_url("https://host-a.invalid/team/repo.git","alice".into(),"DUMMY".into()).unwrap();c.username="bob".into();assert!(c.helper_environment().is_err());
println!("pure scope: protocol/host/port/path/LFS distinctions, decoded-control refusal, legacy None and account mutation refusal pass");
}
