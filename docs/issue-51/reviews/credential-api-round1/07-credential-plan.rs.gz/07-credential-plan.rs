use std::io::{self,Write};
#[path="/tmp/gitcraft-credential-api-r1-source/credentials/src/git/credential_scope.rs"] mod credential_scope;
pub struct Credentials { pub username:String,pub password:String,pub scope:Option<credential_scope::CredentialScope> }
fn main(){let args:Vec<String>=std::env::args().collect(); let c=Credentials::for_url(&args[1],"DUMMY_ALICE".into(),"DUMMY_SELECTED_TOKEN".into()).unwrap(); let mut out=io::stdout().lock();out.write_all(b"HELPER\0").unwrap();out.write_all(credential_scope::CREDENTIAL_HELPER.as_bytes()).unwrap();out.write_all(b"\0").unwrap();for(k,v)in c.helper_environment().unwrap(){out.write_all(k.as_bytes()).unwrap();out.write_all(b"\0").unwrap();out.write_all(v.as_bytes()).unwrap();out.write_all(b"\0").unwrap();}}
