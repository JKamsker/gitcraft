use std::path::{Path,PathBuf};use std::process::Command;
mod practice {pub fn is_repository(_: &std::path::Path)->bool{false}}
mod connections {pub struct Choices{pub ssh_key:String}pub struct Context{pub error:Option<String>,pub choices:Choices,pub git_config:Option<std::path::PathBuf>}pub fn current()->Context{Context{error:None,choices:Choices{ssh_key:String::new()},git_config:std::env::var_os("PROBE_PROFILE").map(Into::into)}}}
fn git_cmd()->Command{Command::new("git")}
fn practice_command(_: &Path)->Command{panic!("not a practice fixture")}
#[derive(Default)]pub struct Extra{pre:Vec<&'static str>,env:Vec<(&'static str,String)>,normalize_repository:bool}
mod command {use super::*;
fn user_global_config(args: &[&str]) -> bool {
    let rest = after_options(args);
    (rest.first() == Some(&"config") && rest.contains(&"--global"))
        // `maintenance start` / `register` write `maintenance.repo` to the global config.
        || (rest.first() == Some(&"maintenance")
            && matches!(rest.get(1), Some(&("start" | "register" | "unregister" | "stop"))))
}


fn after_options<'a>(args: &'a [&'a str]) -> &'a [&'a str] {
    let mut rest = args;
    loop {
        match rest {
            ["-c" | "-C", _, tail @ ..] => rest = tail,
            [word, tail @ ..] if word.starts_with('-') => rest = tail,
            _ => return rest,
        }
    }
}


pub(super) fn with_profile(cmd: &mut Command, args: &[&str]) {
    if user_global_config(args) {
        return;
    }
    let context = crate::connections::current();
    if context.error.is_some() {
        cmd.arg("-c").arg("=invalid-profile");
        return;
    }
    if !context.choices.ssh_key.is_empty() {
        cmd.env_remove("GIT_SSH_COMMAND")
            .env_remove("GIT_SSH")
            .env_remove("GIT_SSH_VARIANT");
    }
    let path = context.git_config;
    if let Some(path) = path {
        cmd.env("GIT_CONFIG_GLOBAL", path);
    }
}


pub(super) fn local_command(dir: Option<&Path>, extra: &Extra, args: &[&str]) -> Command {
    let mut cmd = repository_command(dir, args);
    cmd.args(&extra.pre);
    for (name, value) in &extra.env {
        cmd.env(name, value);
    }
    cmd.args(args);
    if extra.normalize_repository && !dir.is_some_and(crate::practice::is_repository) {
        normalize_connection_command(&mut cmd, args);
    }
    cmd
}

pub(super) const CONNECTION_REDIRECT_ENV: &[&str] = &[
    "GIT_DIR",
    "GIT_WORK_TREE",
    "GIT_COMMON_DIR",
    "GIT_INDEX_FILE",
    "GIT_OBJECT_DIRECTORY",
    "GIT_ALTERNATE_OBJECT_DIRECTORIES",
    "GIT_NAMESPACE",
    "GIT_CONFIG",
    "GIT_CONFIG_GLOBAL",
    "GIT_CONFIG_SYSTEM",
    "GIT_CONFIG_COUNT",
    "GIT_CONFIG_PARAMETERS",
    "GIT_CONFIG_NOSYSTEM",
];
fn normalize_connection_command(cmd: &mut Command, args: &[&str]) {
    for name in CONNECTION_REDIRECT_ENV {
        cmd.env_remove(name);
    }
    for (name, _) in std::env::vars_os() {
        let text = name.to_string_lossy();
        if text.starts_with("GIT_CONFIG_KEY_") || text.starts_with("GIT_CONFIG_VALUE_") {
            cmd.env_remove(name);
        }
    }
    // Intentional immutable profile config is reinstalled after inherited config is removed.
    with_profile(cmd, args);
}


pub(super) fn repository_command(dir: Option<&Path>, args: &[&str]) -> Command {
    if let Some(dir) = dir.filter(|dir| crate::practice::is_repository(dir)) {
        return practice_command(dir);
    }
    let mut cmd = git_cmd();
    with_profile(&mut cmd, args);
    if let Some(dir) = dir {
        cmd.arg("-C").arg(dir);
    }
    cmd
}

pub fn probe(){let args:Vec<String>=std::env::args().collect();let op=["config","--get",args[2].as_str()];let mut cmd=local_command(Some(Path::new(&args[1])),&Extra{normalize_repository:true,..Default::default()},&op);let out=cmd.output().unwrap();println!("code={:?}",out.status.code());println!("stdout={}",String::from_utf8_lossy(&out.stdout).trim_end());println!("stderr={}",String::from_utf8_lossy(&out.stderr).trim_end());}

}
fn main(){command::probe()}
