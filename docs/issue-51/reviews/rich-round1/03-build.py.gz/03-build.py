from pathlib import Path
import hashlib, json, subprocess
root=Path('/tmp/gitcraft-51-rich-r1-270a8a3')
out=Path('/tmp/gitcraft-51-rich-r1-harness'); out.mkdir(exist_ok=True)
evidence={}
def read(p):
    data=(root/p).read_text(); evidence[p]=hashlib.sha256(data.encode()).hexdigest(); return data
# Copy the exact Find engine; omit application routing/bar and existing tests.
s=read('src/repo/find/mod.rs')
for line in ['mod bar;\n','mod keys;\n','mod sources;\n','#[cfg(test)]\nmod tests;\n','pub(crate) use sources::search_diff;\n']:
    s=s.replace(line,'')
for m in ['marks','matcher','order','scan']:
    s=s.replace('mod '+m+';', '#[path="'+str(root/'src/repo/find'/f'{m}.rs')+'"] mod '+m+';')
s=s.replace('pub(in crate::repo) mod rendered;', '#[path="'+str(root/'src/repo/find/rendered.rs')+'"] pub(in crate::repo) mod rendered;')
(out/'find.rs').write_text(s)
# Exact archive parser + exact parse function; no HTTP or task execution.
m=read('src/repo/diff/rich/dependency_metadata/mod.rs')
parse=m[m.index('fn parse('):m.index('fn fetch(')]
archive=read('src/repo/diff/rich/dependency_metadata/archive.rs')
(out/'archive.rs').write_text(archive)
pv=read('src/repo/diff/rich/prose_view.rs')
changed=pv[pv.index('fn changed('):] # last function, no tests
source='''#![allow(dead_code,unused_imports)]
mod theme {
 #[derive(Clone)] pub struct Tokens {pub text:egui::Color32,pub text_dim:egui::Color32,pub text_faint:egui::Color32,pub warning:egui::Color32,pub danger:egui::Color32,pub success:egui::Color32}
 impl Tokens {pub fn get(_: &egui::Context)->Self{Self{text:egui::Color32::WHITE,text_dim:egui::Color32::GRAY,text_faint:egui::Color32::GRAY,warning:egui::Color32::YELLOW,danger:egui::Color32::RED,success:egui::Color32::GREEN}}}
 pub fn medium(size:f32)->egui::FontId {egui::FontId::proportional(size)}
 pub fn install_fonts(_: &egui::Context){}
}
mod pull_request {pub fn markdown_options()->pulldown_cmark::Options {use pulldown_cmark::Options; Options::ENABLE_TABLES | Options::ENABLE_TASKLISTS | Options::ENABLE_STRIKETHROUGH | Options::ENABLE_FOOTNOTES | Options::ENABLE_DEFINITION_LIST}}
mod repo {pub mod highlight {pub const MAX_LINE_CHARS:usize=5000;} #[path="/tmp/gitcraft-51-rich-r1-harness/find.rs"] pub mod find;}
mod metadata {
 use std::collections::BTreeMap;
 #[derive(Debug,PartialEq)] enum Ecosystem{Cargo,Npm,Other}
 #[derive(Debug)] struct Metadata{license:Option<String>,changelogs:BTreeMap<String,String>,archive_url:String}
 #[path="/tmp/gitcraft-51-rich-r1-harness/archive.rs"] mod archive;
'''+parse+'''
 fn fixture(files:&[(&str,String)])->Vec<u8>{use std::io::Write; let mut tar=Vec::new();for(name,body)in files{let mut h=[0u8;512];let path=format!("package/{name}");h[..path.len()].copy_from_slice(path.as_bytes());h[124..136].copy_from_slice(format!("{:011o}\\0",body.len()).as_bytes());h[148..156].fill(b' ');h[156]=b'0';let sum:usize=h.iter().map(|b|*b as usize).sum();h[148..156].copy_from_slice(format!("{sum:06o}\\0 ").as_bytes());tar.extend_from_slice(&h);tar.extend_from_slice(body.as_bytes());tar.resize(tar.len().div_ceil(512)*512,0);}tar.extend_from_slice(&[0u8;1024]);let mut gz=flate2::write::GzEncoder::new(Vec::new(),flate2::Compression::fast());gz.write_all(&tar).unwrap();gz.finish().unwrap()}
 #[test] fn r1_license_file_is_discarded(){let b=fixture(&[("Cargo.toml","[package]\\nname='thing'\\nversion='1.0.0'\\nlicense-file='LICENSE'".into()),("LICENSE","Permission is hereby granted MIT license".into()),("CHANGELOG.md","Actual release notes".into())]);let m=parse(Ecosystem::Cargo,"thing","1.0.0","fixture".into(),&b).unwrap();assert_eq!(m.license,None);assert_eq!(m.changelogs.len(),1);println!("LICENSE content present; returned license=None, retained={:?}",m.changelogs.keys());}
 #[test] fn r1_large_changelog_is_silently_absent(){let b=fixture(&[("Cargo.toml","[package]\\nname='thing'\\nversion='1.0.0'\\nlicense='MIT'".into()),("CHANGELOG.md","a".repeat((512<<10)+1))]);let m=parse(Ecosystem::Cargo,"thing","1.0.0","fixture".into(),&b).unwrap();assert!(m.changelogs.is_empty());println!("CHANGELOG.md is present (524289 bytes); returned empty changelogs => UI claims not included");}
}
mod prose {
 use egui::{Color32,Stroke};use egui::text::{LayoutJob,TextFormat};use crate::theme::Tokens;
 const MAX_CHARS:usize=20000;
 #[derive(Clone,Copy)] enum Change{Kept,Removed,Added}
'''+changed+'''
 #[test] fn r1_changed_prose_tail_is_missing(){let words=(0..11000).map(|_|(Change::Kept,"a ".into())).chain([(Change::Added,"TAIL_NEEDLE".into())]).collect::<Vec<_>>();let job=changed(&words,&egui::FontId::proportional(14.0),&Tokens::get(&egui::Context::default()));assert!(!job.text.contains("TAIL_NEEDLE"));println!("Changed prose input 22011 chars; search receives {} chars, omits TAIL_NEEDLE",job.text.len());}
}
mod review_tests {
 use crate::repo::find::{Find,Query,rendered::Document};
 fn count(text:&str,query:Query)->usize{let ctx=egui::Context::default();let mut find=Find{open:true,query,..Find::default()};for _ in 0..2{ctx.run_ui(egui::RawInput::default(),|ui|find.rendered(ui,"fixture".into(),|t|{let mut d=Document::default();d.text(text,t.text);d})).drop_without_applying_deltas();}find.count()}
 #[test] fn r1_boundary_loses_match(){let s=format!("{}needle{}","x".repeat(4997),"x".repeat(10));assert!(s.contains("needle"));let n=count(&s,Query{text:"needle".into(),..Query::default()});assert_eq!(n,0);println!("Complete visible logical row contains needle at chars 4997..5003, Find count={n}");}
 #[test] fn r1_boundary_invents_whole_word(){let s=format!("{}needle", "x".repeat(5000));let n=count(&s,Query{text:"needle".into(),whole_word:true,..Query::default()});assert_eq!(n,1);println!("No real word boundary before needle; Find whole-word count={n}");}
 #[test] fn r1_cached_document_ignores_replacement(){let ctx=egui::Context::default();let mut find=Find{open:true,query:Query{text:"old".into(),..Query::default()},..Find::default()};for text in ["old","new"]{let output=ctx.run_ui(egui::RawInput::default(),|ui|find.rendered(ui,"markdown:Work:1:false".into(),|t|{let mut d=Document::default();d.text(text,t.text);d}));let shown=output.shapes.iter().filter_map(|s|if let egui::Shape::Text(t)=&s.shape{Some(t.galley.text())}else{None}).collect::<Vec<_>>().join("\\n");assert!(shown.contains("old"));println!("Replacement source={text}; shapes={shown:?}");output.drop_without_applying_deltas();}}
}
'''
# Add review_tests inside Find module so fixture can construct private state.
idx=source.index('mod review_tests {')
test=source[idx:].replace('use crate::repo::find::{Find,Query,rendered::Document};','use super::{Find,Query,rendered::Document};')
(out/'find.rs').write_text(s+'\n'+test)
source=source[:idx]
(out/'main.rs').write_text(source)
for p in ['src/repo/find/rendered.rs','src/repo/find/marks.rs','src/repo/find/matcher.rs','src/repo/find/order.rs','src/repo/find/scan.rs']: read(p)
(out/'source-hashes.json').write_text(json.dumps({'commit':'270a8a3b33402847f6d04cd8b8e70d625f33f4cb','sources':evidence},indent=2))
deps=Path('/Users/jonas/.t3/worktrees/gitcraft/t3-a61f0eaa/target/debug/deps')
chosen={'egui':'0e410d2928238130','pulldown_cmark':'3497bed0d8b8d072','flate2':'23b9c9bed0c734f3','toml_edit':'3fffab5746061d02','serde_json':'51b929621ccde7c6','regex':'b2455dc97a02a3c1'}
args=['rustc','+1.95.0','--edition=2024','--test',str(out/'main.rs'),'-L','dependency='+str(deps),'-o',str(out/'r1-harness')]
for lib,h in chosen.items(): args+=['--extern',f'{lib}={deps}/lib{lib}-{h}.rlib']
r=subprocess.run(args,capture_output=True,text=True);(out/'build.log').write_text(r.stdout+r.stderr);print(r.stdout+r.stderr);print('BUILD EXIT',r.returncode)
if not r.returncode:
 r=subprocess.run([str(out/'r1-harness'),'r1_','--nocapture','--test-threads=1'],capture_output=True,text=True);(out/'results.log').write_text(r.stdout+r.stderr);print(r.stdout+r.stderr);print('RUN EXIT',r.returncode)
