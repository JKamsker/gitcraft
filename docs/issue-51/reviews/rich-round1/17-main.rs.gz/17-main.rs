#![allow(dead_code,unused_imports)]
mod theme {
 #[derive(Clone)] pub struct Tokens {pub text:egui::Color32,pub text_dim:egui::Color32,pub text_faint:egui::Color32,pub warning:egui::Color32,pub danger:egui::Color32,pub success:egui::Color32}
 impl Tokens {pub fn get(_: &egui::Context)->Self{Self{text:egui::Color32::WHITE,text_dim:egui::Color32::GRAY,text_faint:egui::Color32::GRAY,warning:egui::Color32::YELLOW,danger:egui::Color32::RED,success:egui::Color32::GREEN}}}
 pub fn medium(size:f32)->egui::FontId {egui::FontId::proportional(size)}
 pub fn install_fonts(_: &egui::Context){}
}
mod pull_request {pub fn markdown_options()->pulldown_cmark::Options {use pulldown_cmark::Options; Options::ENABLE_TABLES | Options::ENABLE_TASKLISTS | Options::ENABLE_STRIKETHROUGH | Options::ENABLE_FOOTNOTES | Options::ENABLE_DEFINITION_LIST}}
mod repo {pub mod highlight {pub const MAX_LINE_CHARS:usize=5000;} #[path="/tmp/gitcraft-51-rich-r1-harness/find.rs"] pub mod find;}
mod metadata {
 use std::collections::BTreeMap;
 #[derive(Debug,PartialEq)] enum Ecosystem{Cargo,Npm,Other}
 #[derive(Debug)] struct Metadata{license:Option<String>,changelogs:BTreeMap<String,String>,archive_url:String}
 #[path="/tmp/gitcraft-51-rich-r1-harness/archive.rs"] mod archive;
fn parse(
    ecosystem: Ecosystem,
    name: &str,
    version: &str,
    archive_url: String,
    bytes: &[u8],
) -> Result<Metadata, String> {
    let mut files = archive::texts(bytes)?;
    let license = match ecosystem {
        Ecosystem::Cargo => {
            let manifest = files
                .remove("Cargo.toml")
                .ok_or("Package omits Cargo.toml")?;
            let doc = manifest
                .parse::<toml_edit::Document<String>>()
                .map_err(|_| "Invalid published Cargo.toml")?;
            let package = doc
                .get("package")
                .ok_or("Published manifest omits package")?;
            if package.get("name").and_then(|x| x.as_str()) != Some(name)
                || package.get("version").and_then(|x| x.as_str()) != Some(version)
            {
                return Err("Published package identity mismatch".into());
            }
            package
                .get("license")
                .and_then(|x| x.as_str())
                .filter(|s| !s.is_empty())
                .map(str::to_owned)
        }
        Ecosystem::Npm => {
            let manifest: serde_json::Value = serde_json::from_str(
                &files
                    .remove("package.json")
                    .ok_or("Package omits package.json")?,
            )
            .map_err(|_| "Invalid published package.json")?;
            if manifest["name"].as_str() != Some(name)
                || manifest["version"].as_str() != Some(version)
            {
                return Err("Published package identity mismatch".into());
            }
            manifest["license"]
                .as_str()
                .filter(|s| !s.is_empty())
                .map(str::to_owned)
        }
        _ => return Err("Unsupported package registry".into()),
    };
    files.remove("Cargo.toml");
    files.remove("package.json");
    Ok(Metadata {
        license,
        changelogs: files,
        archive_url,
    })
}

 fn fixture(files:&[(&str,String)])->Vec<u8>{use std::io::Write; let mut tar=Vec::new();for(name,body)in files{let mut h=[0u8;512];let path=format!("package/{name}");h[..path.len()].copy_from_slice(path.as_bytes());h[124..136].copy_from_slice(format!("{:011o}\0",body.len()).as_bytes());h[148..156].fill(b' ');h[156]=b'0';let sum:usize=h.iter().map(|b|*b as usize).sum();h[148..156].copy_from_slice(format!("{sum:06o}\0 ").as_bytes());tar.extend_from_slice(&h);tar.extend_from_slice(body.as_bytes());tar.resize(tar.len().div_ceil(512)*512,0);}tar.extend_from_slice(&[0u8;1024]);let mut gz=flate2::write::GzEncoder::new(Vec::new(),flate2::Compression::fast());gz.write_all(&tar).unwrap();gz.finish().unwrap()}
 #[test] fn r1_license_file_is_discarded(){let b=fixture(&[("Cargo.toml","[package]\nname='thing'\nversion='1.0.0'\nlicense-file='LICENSE'".into()),("LICENSE","Permission is hereby granted MIT license".into()),("CHANGELOG.md","Actual release notes".into())]);let m=parse(Ecosystem::Cargo,"thing","1.0.0","fixture".into(),&b).unwrap();assert_eq!(m.license,None);assert_eq!(m.changelogs.len(),1);println!("LICENSE content present; returned license=None, retained={:?}",m.changelogs.keys());}
 #[test] fn r1_large_changelog_is_silently_absent(){let b=fixture(&[("Cargo.toml","[package]\nname='thing'\nversion='1.0.0'\nlicense='MIT'".into()),("CHANGELOG.md","a".repeat((512<<10)+1))]);let m=parse(Ecosystem::Cargo,"thing","1.0.0","fixture".into(),&b).unwrap();assert!(m.changelogs.is_empty());println!("CHANGELOG.md is present (524289 bytes); returned empty changelogs => UI claims not included");}
}
mod prose {
 use egui::{Color32,Stroke};use egui::text::{LayoutJob,TextFormat};use crate::theme::Tokens;
 const MAX_CHARS:usize=20000;
 #[derive(Clone,Copy)] enum Change{Kept,Removed,Added}
fn changed(words: &[(Change, String)], font: &egui::FontId, t: &Tokens) -> LayoutJob {
    let mut job = LayoutJob::default();
    let mut shown = 0;
    for (change, word) in words {
        if shown > MAX_CHARS {
            job.append(" …", 0.0, TextFormat::simple(font.clone(), t.text_faint));
            break;
        }
        shown += word.len();
        // The space before a word stays plain; only the word is marked.
        let lead = word.len() - word.trim_start().len();
        let (space, body) = word.split_at(lead);
        if !space.is_empty() {
            job.append(space, 0.0, TextFormat::simple(font.clone(), t.text));
        }
        let (background, strike) = match change {
            Change::Kept => (Color32::TRANSPARENT, Stroke::NONE),
            Change::Removed => (t.danger.gamma_multiply(0.35), Stroke::new(1.0, t.text_dim)),
            Change::Added => (t.success.gamma_multiply(0.35), Stroke::NONE),
        };
        job.append(
            body,
            0.0,
            TextFormat {
                font_id: font.clone(),
                color: t.text,
                background,
                strikethrough: strike,
                ..Default::default()
            },
        );
    }
    job
}

 #[test] fn r1_changed_prose_tail_is_missing(){let words=(0..11000).map(|_|(Change::Kept,"a ".into())).chain([(Change::Added,"TAIL_NEEDLE".into())]).collect::<Vec<_>>();let job=changed(&words,&egui::FontId::proportional(14.0),&Tokens::get(&egui::Context::default()));assert!(!job.text.contains("TAIL_NEEDLE"));println!("Changed prose input 22011 chars; search receives {} chars, omits TAIL_NEEDLE",job.text.len());}
}
