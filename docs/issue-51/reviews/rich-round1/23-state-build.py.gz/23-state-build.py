from pathlib import Path
import subprocess
root=Path('/tmp/gitcraft-51-rich-r1-270a8a3'); out=Path('/tmp/gitcraft-51-rich-r1-harness')
m=(root/'src/repo/diff/rich/dependency_metadata/mod.rs').read_text()
head=m[m.index('#[derive(Clone, Debug, PartialEq, Eq)]'):m.index('pub(super) fn urls(')]
state=m[m.index('impl State {'):]
source='''#![allow(dead_code,unused_imports)]
mod connections {pub type Context=u8;pub fn current()->Context {0}}
mod tasks {
 #[derive(Default)] pub struct Scope(pub ()); pub enum Priority{Interactive} pub struct Pool;
 pub fn pool()->Result<Pool,String>{Ok(Pool)}
 impl Pool {pub fn submit(&self,_:(),_:Priority,_:Option<()>,f:Box<dyn FnOnce()+Send>)->Result<(),&'static str>{f();Ok(())}}
}
mod metadata {
use crate::{connections,tasks};use std::collections::{BTreeMap,VecDeque};use std::sync::mpsc::{self,Receiver};use std::time::Duration;
use std::sync::{Mutex,atomic::{AtomicBool,Ordering}};
#[derive(Clone,Copy,Debug,PartialEq,Eq)] enum Ecosystem{Cargo}
type Registry=Option<(String,String)>;
struct DepChange{name:String,metadata_registry:(Registry,Registry)}
static FAIL:AtomicBool=AtomicBool::new(true);static CALLS:Mutex<Vec<String>>=Mutex::new(Vec::new());
fn fetch(_:Ecosystem,r:&Registry)->Result<Option<Metadata>,String>{let Some((name,_))=r else{return Ok(None)};CALLS.lock().unwrap().push(name.clone());if FAIL.load(Ordering::Relaxed){return Err("transient registry error".into())} Ok(Some(Metadata{license:Some("MIT".into()),changelogs:BTreeMap::new(),archive_url:"fixture".into()}))}
'''+head+state+'''
#[test] fn r1_error_cache_and_side_short_circuit(){let ctx=egui::Context::default();let d=DepChange{name:"thing".into(),metadata_registry:(Some(("old".into(),"1".into())),Some(("new".into(),"2".into())))};let mut s=State::default();s.select(Ecosystem::Cargo,&d,&ctx);ctx.run_ui(egui::RawInput::default(),|ui|s.show(ui)).drop_without_applying_deltas();assert!(matches!(s.result,Some(Err(_))));assert_eq!(*CALLS.lock().unwrap(),vec!["old"]);println!("Before failure stops after calls={:?}; available After never attempted",*CALLS.lock().unwrap());FAIL.store(false,Ordering::Relaxed);s.selected=None;s.pending=None;s.result=None;s.select(Ecosystem::Cargo,&d,&ctx);assert!(matches!(s.result,Some(Err(_))));assert_eq!(*CALLS.lock().unwrap(),vec!["old"]);println!("Reselect after network recovers: cached error reused, no fetch/retry");}
}
'''
(out/'state.rs').write_text(source)
deps=Path('/Users/jonas/.t3/worktrees/gitcraft/t3-a61f0eaa/target/debug/deps')
r=subprocess.run(['rustc','+1.95.0','--edition=2024','--test',str(out/'state.rs'),'-L','dependency='+str(deps),'--extern',f'egui={deps}/libegui-0e410d2928238130.rlib','-o',str(out/'r1-state-harness')],capture_output=True,text=True);(out/'state-build.log').write_text(r.stdout+r.stderr);print(r.stdout+r.stderr);print('BUILD EXIT',r.returncode)
if not r.returncode:
 r=subprocess.run([str(out/'r1-state-harness'),'r1_','--nocapture','--test-threads=1'],capture_output=True,text=True);(out/'state-results.log').write_text(r.stdout+r.stderr);print(r.stdout+r.stderr);print('RUN EXIT',r.returncode)
