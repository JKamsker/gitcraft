#![allow(dead_code,unused_imports)]
mod connections {pub type Context=u8;pub fn current()->Context {0}}
mod tasks {
 #[derive(Default)] pub struct Scope(pub ()); pub enum Priority{Interactive} pub struct Pool;
 pub fn pool()->Result<Pool,String>{Ok(Pool)}
 impl Pool {pub fn submit(&self,_:(),_:Priority,_:Option<()>,f:Box<dyn FnOnce()+Send>)->Result<(),&'static str>{f();Ok(())}}
}
mod metadata {
use crate::{connections,tasks};use std::collections::{BTreeMap,VecDeque};use std::sync::mpsc::{self,Receiver};use std::time::Duration;
use std::sync::{Mutex,atomic::{AtomicBool,Ordering}};
#[derive(Clone,Copy,Debug,PartialEq,Eq)] enum Ecosystem{Cargo}
type Registry=Option<(String,String)>;
struct DepChange{name:String,metadata_registry:(Registry,Registry)}
static FAIL:AtomicBool=AtomicBool::new(true);static CALLS:Mutex<Vec<String>>=Mutex::new(Vec::new());
fn fetch(_:Ecosystem,r:&Registry)->Result<Option<Metadata>,String>{let Some((name,_))=r else{return Ok(None)};CALLS.lock().unwrap().push(name.clone());if FAIL.load(Ordering::Relaxed){return Err("transient registry error".into())} Ok(Some(Metadata{license:Some("MIT".into()),changelogs:BTreeMap::new(),archive_url:"fixture".into()}))}
#[derive(Clone, Debug, PartialEq, Eq)]
pub(super) struct Metadata {
    pub license: Option<String>,
    pub changelogs: BTreeMap<String, String>,
    pub archive_url: String,
}
#[derive(Clone, Debug, PartialEq, Eq)]
struct Request {
    ecosystem: Ecosystem,
    old: Registry,
    new: Registry,
}
type Answer = Result<(Option<Metadata>, Option<Metadata>), String>;
struct Pending {
    rx: Receiver<Answer>,
    _scope: tasks::Scope,
    context: connections::Context,
}
#[derive(Default)]
pub(super) struct State {
    selected: Option<(String, Request)>,
    pending: Option<Pending>,
    cache: VecDeque<(Request, Answer)>,
    result: Option<Answer>,
}

impl State {
    pub fn select(&mut self, eco: Ecosystem, change: &DepChange, ctx: &egui::Context) {
        let request = Request {
            ecosystem: eco,
            old: change.metadata_registry.0.clone(),
            new: change.metadata_registry.1.clone(),
        };
        self.pending = None;
        self.selected = Some((change.name.clone(), request.clone()));
        self.result = self
            .cache
            .iter()
            .find(|(r, _)| *r == request)
            .map(|(_, a)| a.clone());
        if request.old.is_none() && request.new.is_none() {
            self.result = Some(Err("Metadata unavailable: the lockfile does not identify a supported public registry; no package name was sent".into()));
            return;
        }
        if self.result.is_some() {
            return;
        }
        let (tx, rx) = mpsc::channel();
        let scope = tasks::Scope::default();
        let repaint = ctx.clone();
        let work = request.clone();
        let submitted = tasks::pool().and_then(|pool| {
            pool.submit(
                scope.0.clone(),
                tasks::Priority::Interactive,
                None,
                Box::new(move || {
                    let answer = (|| {
                        Ok((
                            fetch(work.ecosystem, &work.old)?,
                            fetch(work.ecosystem, &work.new)?,
                        ))
                    })();
                    let _ = tx.send(answer);
                    repaint.request_repaint();
                }),
            )
            .map_err(str::to_owned)
        });
        match submitted {
            Ok(()) => {
                self.pending = Some(Pending {
                    rx,
                    _scope: scope,
                    context: connections::current(),
                })
            }
            Err(e) => self.result = Some(Err(e)),
        }
    }
    pub fn show(&mut self, ui: &mut egui::Ui) {
        if self
            .pending
            .as_ref()
            .is_some_and(|p| p.context != connections::current())
        {
            self.pending = None;
            self.result = Some(Err("Profile changed; select the package again".into()));
        }
        if let Some(pending) = &self.pending {
            match pending.rx.try_recv() {
                Ok(answer) => {
                    self.result = Some(answer.clone());
                    self.pending = None;
                    if let Some((_, request)) = &self.selected {
                        self.cache.push_back((request.clone(), answer));
                        if self.cache.len() > 8 {
                            self.cache.pop_front();
                        }
                    }
                }
                Err(mpsc::TryRecvError::Disconnected) => {
                    self.pending = None;
                    self.result = Some(Err("Package metadata task cancelled or stopped".into()));
                }
                Err(mpsc::TryRecvError::Empty) => {
                    ui.ctx().request_repaint_after(Duration::from_millis(100));
                }
            }
        }
        let Some((name, _)) = &self.selected else {
            return;
        };
        let name = name.clone();
        ui.horizontal(|ui| {
            ui.strong(format!("{name}: published licences and changelogs"));
            if ui.button("Close / cancel").clicked() {
                self.selected = None;
                self.pending = None;
                self.result = None;
            }
        });
        if self.pending.is_some() {
            ui.label("Reading the exact published versions (up to 12 seconds per request)…");
        }
        match &self.result {
            Some(Err(e)) => {
                ui.label(e);
            }
            Some(Ok((old, new))) => {
                let licence = |m: &Option<Metadata>| {
                    m.as_ref()
                        .map_or("not recorded as a supported public-registry package", |m| {
                            m.license
                                .as_deref()
                                .unwrap_or("not declared in published manifest")
                        })
                        .to_owned()
                };
                let changed = old
                    .as_ref()
                    .zip(new.as_ref())
                    .is_some_and(|(a, b)| a.license != b.license);
                ui.label(format!(
                    "Licence{}: {} → {}",
                    if changed { " changed" } else { "" },
                    licence(old),
                    licence(new)
                ));
                egui::ScrollArea::vertical().id_salt("dependency_metadata").max_height(240.0).show(ui, |ui| {
                    for (side,metadata) in [("Before",old),("After",new)] {
                        let Some(m)=metadata else { continue };
                        ui.hyperlink_to(format!("{side}: published archive"), &m.archive_url);
                        if m.changelogs.is_empty() { ui.label(format!("{side}: changelog unavailable — not included in the published package.")); }
                        for (path,text) in &m.changelogs { egui::CollapsingHeader::new(format!("{side} changelog: {path}")).id_salt((side,path)).show(ui, |ui| { ui.add(egui::Label::new(egui::RichText::new(text).monospace()).wrap()); }); }
                    }
                });
            }
            None => {}
        }
        ui.separator();
    }
}

#[test] fn r1_error_cache_and_side_short_circuit(){let ctx=egui::Context::default();let d=DepChange{name:"thing".into(),metadata_registry:(Some(("old".into(),"1".into())),Some(("new".into(),"2".into())))};let mut s=State::default();s.select(Ecosystem::Cargo,&d,&ctx);ctx.run_ui(egui::RawInput::default(),|ui|s.show(ui)).drop_without_applying_deltas();assert!(matches!(s.result,Some(Err(_))));assert_eq!(*CALLS.lock().unwrap(),vec!["old"]);println!("Before failure stops after calls={:?}; available After never attempted",*CALLS.lock().unwrap());FAIL.store(false,Ordering::Relaxed);s.selected=None;s.pending=None;s.result=None;s.select(Ecosystem::Cargo,&d,&ctx);assert!(matches!(s.result,Some(Err(_))));assert_eq!(*CALLS.lock().unwrap(),vec!["old"]);println!("Reselect after network recovers: cached error reused, no fetch/retry");}
}
