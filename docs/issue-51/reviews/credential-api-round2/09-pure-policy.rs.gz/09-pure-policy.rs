use std::path::Path;
#[path="/tmp/gitcraft-credential-direct-r2-source/src/git/credential_scope.rs"] mod credential_scope;
pub use credential_scope::{CredentialScope,CREDENTIAL_HELPER};
pub struct Credentials {pub username:String,pub password:String,pub scope:Option<CredentialScope>}
fn connection_read(dir:&Path,args:&[&str])->Result<String,String>{assert_eq!(dir,Path::new("/selected"));assert_eq!(args,["config","--null","--name-only","--get-regexp","^(credential|http)\\."]);Ok(["credential.helper","credential.https://host.invalid.username","credential.https://host.invalid/team/repo.helper","http.https://host.invalid/team/repo/info/refs.followredirects","credential.https://host.invalid.usehttppath"].join("\0"))}
#[path="/tmp/gitcraft-credential-direct-r2-source/src/git/command/credential_policy.rs"] mod credential_policy;
fn main(){
let scope=CredentialScope::for_url("https://host.invalid/team/repo","alice").unwrap();
for url in ["https://host.invalid/team/repo/","https://host.invalid//team/repo","https://host.invalid/team/repo%2F"]{assert!(scope.matches_url(url));}
assert!(CredentialScope::for_url("https://host.invalid/team/a%20b","alice").unwrap().matches_url("https://host.invalid/team/a b"));
assert!(CredentialScope::for_url("https://host.invalid/team/a%2Fb","alice").unwrap().matches_url("https://host.invalid/team/a/b"));
assert!(CredentialScope::for_url("https://bob@host.invalid/team/repo","alice").is_err());
assert!(CredentialScope::for_url("https://alice:embedded@host.invalid/team/repo","alice").is_err());
assert!(CredentialScope::for_url("https://al%69ce@host.invalid/team/repo","alice").is_ok());
println!("ordinary leading/trailing raw slash, encoded trailing slash, embedded space/slash and URL-account checks pass");
let encoded=CredentialScope::for_url("https://host.invalid/%2F","alice").unwrap();
let collapse=encoded.matches_url("https://host.invalid/");assert!(collapse);println!("ENCODED_SLASH_ROOT_COLLISION={collapse} normalized_endpoint={}",encoded.endpoint());
let c=Credentials::for_url("https://host.invalid/team/repo/","alice".into(),"DUMMY_TOKEN".into()).unwrap();
let p=credential_policy::credential_command_policy(Some(Path::new("/selected")),&c).unwrap();
let configs=p.arguments.chunks_exact(2).map(|x|{assert_eq!(x[0],"-c");x[1].as_str()}).collect::<Vec<_>>();
for val in ["credential.helper=","credential.username=alice","credential.https://host.invalid.username=alice","credential.https://host.invalid/team/repo.helper=","http.followRedirects=false","http.https://host.invalid/team/repo/info/refs.followredirects=false","credential.https://host.invalid.usehttppath=true"] {assert!(configs.contains(&val));}
assert_eq!(configs.last().copied(),Some(CREDENTIAL_HELPER));assert!(!p.arguments.join(" ").contains("DUMMY_TOKEN"));assert!(p.environment.iter().any(|(k,v)|*k=="GITCRAFT_GIT_PASSWORD"&&v=="DUMMY_TOKEN"));
println!("recorded policy resets enumerated helper keys, overrides enumerated usernames/HTTP keys, appends only scoped helper, keeps dummy token off argv");
}
