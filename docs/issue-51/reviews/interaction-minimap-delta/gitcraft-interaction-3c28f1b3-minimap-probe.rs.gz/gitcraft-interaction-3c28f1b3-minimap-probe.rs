#![allow(dead_code)]
mod a11y{use egui::{Response,WidgetInfo,WidgetType};pub trait Label{fn text(&self)->String;}impl Label for &str{fn text(&self)->String{self.to_string()}}pub fn a11y(r:&Response,t:WidgetType,l:impl Label){r.widget_info(||WidgetInfo::labeled(t,r.enabled(),l.text()));}#[path="/tmp/gitcraft-interaction-3c28f1b3-minimap-value.rs"]pub mod value;}
mod adapter{
use egui::{Align2,FontId,Rect,Sense,Stroke,StrokeKind,Ui,pos2};const ROW_PITCH:f32=20.;const LANES:usize=24;
#[derive(Clone,Default)]struct Bin{lanes:u32,head:bool,tag:bool,hit:bool,gap:bool}
struct State{bins:Vec<Bin>,rows:usize,offset:Option<f32>,drag_anchor:f32}
struct Graph{width:usize}struct RepoTab{history_minimap:State,graph:Graph,has_more:bool}
struct Tokens{dock:egui::Color32,text_dim:egui::Color32,text_faint:egui::Color32,success:egui::Color32,warning:egui::Color32,accent:egui::Color32}
impl Tokens{fn get(_: &egui::Context)->Self{Self{dock:egui::Color32::BLACK,text_dim:egui::Color32::GRAY,text_faint:egui::Color32::GRAY,success:egui::Color32::GREEN,warning:egui::Color32::YELLOW,accent:egui::Color32::BLUE}}}
fn offset_at(fraction: f32, rows: usize, viewport: f32, anchor: f32) -> f32 {
    (fraction.clamp(0.0, 1.0) * rows as f32 * ROW_PITCH - anchor)
        .clamp(0.0, (rows as f32 * ROW_PITCH - viewport).max(0.0))
}
impl RepoTab{fn prepare_minimap(&mut self,_:&egui::Context){}
    pub(super) fn history_minimap(&mut self, ui: &mut Ui, rect: Rect, offset: f32, viewport: f32) {
        self.prepare_minimap(ui.ctx());
        let t = Tokens::get(ui.ctx());
        let response = ui.interact(
            rect,
            ui.id().with("history-minimap"),
            Sense::click_and_drag(),
        );
        let label = "Loaded history minimap. Drag to scroll; arrow and Page Up/Down keys move the viewport. Blue HEAD, green tags, yellow search hits.";
        let p = ui.painter_at(rect);
        p.rect_filled(rect, 3.0, t.dock);
        p.text(
            pos2(rect.center().x, rect.top() + 3.0),
            Align2::CENTER_TOP,
            "History",
            FontId::proportional(10.0),
            t.text_dim,
        );
        let map = Rect::from_min_max(
            pos2(rect.left() + 4.0, rect.top() + 19.0),
            pos2(rect.right() - 4.0, rect.bottom() - 20.0),
        );
        if map.height() <= 0.0 || self.history_minimap.rows == 0 {
            crate::a11y::value::slider(&response, label, 0.0, 0.0..=0.0, ROW_PITCH, true);
            return;
        }
        let n = self.history_minimap.bins.len();
        let shown = self.graph.width.clamp(1, LANES);
        for (i, bin) in self.history_minimap.bins.iter().enumerate() {
            let y = map.top() + (i as f32 + 0.5) / n as f32 * map.height();
            let height = (map.height() / n as f32).max(1.0);
            for lane in 0..shown {
                if bin.lanes & (1 << lane) != 0 {
                    let x = map.left() + 3.0 + lane as f32 / shown as f32 * (map.width() - 13.0);
                    p.line_segment(
                        [pos2(x, y), pos2(x, y + height)],
                        Stroke::new(1.2, if bin.gap { t.text_faint } else { t.text_dim }),
                    );
                }
            }
            if bin.tag {
                p.circle_filled(pos2(map.right() - 5.0, y), 2.0, t.success);
            }
            if bin.hit {
                p.line_segment(
                    [pos2(map.left(), y), pos2(map.left() + 4.0, y)],
                    Stroke::new(2.0, t.warning),
                );
            }
            if bin.head {
                p.line_segment(
                    [pos2(map.right() - 8.0, y), pos2(map.right(), y)],
                    Stroke::new(2.0, t.accent),
                );
            }
        }
        let full_h = self.history_minimap.rows as f32 * ROW_PITCH;
        let top = (offset / full_h).clamp(0.0, 1.0);
        let bottom = ((offset + viewport) / full_h).clamp(top, 1.0);
        let visible = Rect::from_min_max(
            pos2(map.left(), map.top() + top * map.height()),
            pos2(
                map.right(),
                (map.top() + bottom * map.height()).max(map.top() + top * map.height() + 3.0),
            ),
        );
        p.rect_stroke(visible, 1.0, Stroke::new(1.5, t.accent), StrokeKind::Inside);
        let footer_label = if self.has_more {
            "Older unloaded ↓"
        } else {
            "History ends"
        };
        p.line_segment(
            [pos2(map.left(), map.bottom()), map.right_bottom()],
            Stroke::new(1.0, t.text_faint),
        );
        p.text(
            pos2(rect.center().x, rect.bottom() - 3.0),
            Align2::CENTER_BOTTOM,
            footer_label,
            FontId::proportional(8.0),
            t.text_dim,
        );
        if response.drag_started()
            && let Some(pointer) = response.interact_pointer_pos()
        {
            self.history_minimap.drag_anchor = if visible.contains(pointer) {
                ((pointer.y - map.top()) / map.height() * full_h - offset).clamp(0.0, viewport)
            } else {
                viewport / 2.0
            };
        }
        if (response.dragged() || response.clicked())
            && let Some(pointer) = response.interact_pointer_pos()
        {
            let anchor = if response.clicked() {
                viewport / 2.0
            } else {
                self.history_minimap.drag_anchor
            };
            self.history_minimap.offset = Some(offset_at(
                (pointer.y - map.top()) / map.height(),
                self.history_minimap.rows,
                viewport,
                anchor,
            ));
            response.request_focus();
            ui.ctx().request_repaint();
        }
        if response.has_focus() {
            let delta = ui.input(|i| {
                if i.key_pressed(egui::Key::ArrowDown) {
                    ROW_PITCH
                } else if i.key_pressed(egui::Key::ArrowUp) {
                    -ROW_PITCH
                } else if i.key_pressed(egui::Key::PageDown) {
                    viewport
                } else if i.key_pressed(egui::Key::PageUp) {
                    -viewport
                } else {
                    0.0
                }
            });
            if delta != 0.0 {
                self.history_minimap.offset =
                    Some((offset + delta).clamp(0.0, (full_h - viewport).max(0.0)));
            }
        }
        if let Some(at) = crate::a11y::value::slider(
            &response,
            label,
            self.history_minimap.offset.unwrap_or(offset),
            0.0..=(full_h - viewport).max(0.0),
            ROW_PITCH,
            true,
        ) {
            self.history_minimap.offset = Some(at);
            ui.ctx().request_repaint();
        }
        response.on_hover_text(format!("{} projected rows of loaded history. Drag to scroll; focused: arrows or Page Up/Down. Blue: HEAD · green: tags · yellow: search hits · grey: collapsed context. {}",self.history_minimap.rows,if self.has_more {"Older history is not loaded; scrolling to the boundary loads another page."} else {"All available history is loaded."}));
    }}

pub fn probe(has_more:bool){let ctx=egui::Context::default();ctx.enable_accesskit();let mut tab=RepoTab{history_minimap:State{bins:vec![Bin::default()],rows:100,offset:None,drag_anchor:0.},graph:Graph{width:1},has_more};let mut out=ctx.run_ui(egui::RawInput::default(),|ui|{tab.history_minimap(ui,Rect::from_min_size(pos2(0.,0.),egui::vec2(80.,200.)),40.,100.);});let mut sliders = 0; for(_,node)in &out.platform_output.accesskit_update.as_ref().unwrap().nodes{if node.role()==egui::accesskit::Role::Slider{sliders += 1;println!("has_more={has_more}: slider label={:?}, value={:?}, min={:?}, max={:?}",node.label(),node.numeric_value(),node.min_numeric_value(),node.max_numeric_value());assert_eq!(node.label(),Some("Loaded history minimap. Drag to scroll; arrow and Page Up/Down keys move the viewport. Blue HEAD, green tags, yellow search hits."));}}assert_eq!(sliders, 1); out.textures_delta.clear();}
}
fn main(){adapter::probe(false);adapter::probe(true);}
