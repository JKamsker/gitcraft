#![allow(dead_code)]
mod remote {use std::path::Path; #[derive(Clone)] pub enum Host{Ssh(String)} pub struct Target{pub host:Host,pub path:String} pub struct Request{pub cwd:Option<String>,pub script:String,pub env:Vec<(String,String)>,pub unset:Vec<String>,pub stdin:Option<Vec<u8>>,pub long:bool,pub timeout:Option<std::time::Duration>,pub test:bool,pub apart:bool} pub fn is_remote(p:&Path)->bool{p.to_string_lossy().starts_with("remote:")} pub fn sh_quote(s:&str)->String{format!("'{}'",s.replace('\'',"'\"'\"'"))}}
mod git {use std::path::{Path,PathBuf};use std::process::Command;use std::sync::RwLock;use crate::remote::{self,Target};
#[derive(Clone)]
pub struct Credentials {
    pub username: String,
    pub password: String,
    /// None is legacy/unbound state and is refused by all transient helpers.
    pub scope: Option<super::CredentialScope>,
}

#[path="/tmp/gitcraft-history-core-r2-harness/scope.rs"]mod credential_scope;pub use credential_scope::{CredentialScope,CREDENTIAL_HELPER};
pub(crate) mod hooks{const TRACE_VAR:&str="GIT_TRACE2_EVENT";const MARK:&str="@@gitcraft-hook-events@@";pub(super) fn traced_script_with_program(words: &str, program: &str) -> String {
    format!(
        concat!(
            ": {program} {words}\n",
            "t=\"${{T:+$T/hook-events}}\"\n",
            "if [ -n \"$t\" ] && : >\"$t\" 2>/dev/null; then {var}=\"$t\" {program} {words}\n",
            "else t=; {program} {words}; fi\n",
            "r=$?\n",
            "if [ -n \"$t\" ]; then\n",
            "  printf '\\n%s\\n' '{mark}' >&2; grep -F '\"child_' \"$t\" >&2; rm -f \"$t\"\n",
            "fi\n",
            "exit $r",
        ),
        program = program,
        var = TRACE_VAR,
        words = words,
        mark = MARK,
    )
}

}
#[path="/tmp/gitcraft-history-core-r2-harness/policy.rs"]mod credential_policy;use credential_policy::*;
static PROFILE_CONFIG: RwLock<Option<PathBuf>> = RwLock::new(None);

/// Has every git command from now on read `path` as its global config, or the user's own again
/// with `None`. It is still the global scope, so what a repository sets itself (`--local`,
/// `--worktree`) wins over it.
pub fn set_profile_config(path: Option<PathBuf>) {
    if let Ok(mut current) = PROFILE_CONFIG.write() {
        *current = path;
    }
}

/// The active profile's config file, when git reads it as the global config (see
/// [`set_profile_config`]).
pub fn profile_config() -> Option<PathBuf> {
    PROFILE_CONFIG.read().ok().and_then(|p| p.clone())
}

/// Whether `args` reads or writes the user's own global config: `git config --global …`
/// (signing settings, Mergiraf's set-up) or `git maintenance` (its list of repositories), which
/// must never land in the profile's file, which is written over.
fn user_global_config(args: &[&str]) -> bool {
    let rest = after_options(args);
    (rest.first() == Some(&"config") && rest.contains(&"--global"))
        // `maintenance start` / `register` write `maintenance.repo` to the global config.
        || (rest.first() == Some(&"maintenance")
            && matches!(rest.get(1), Some(&("start" | "register" | "unregister" | "stop"))))
}

/// `args` from the subcommand on: past the options before it (`-c x=y`, `-C dir`,
/// `--literal-pathspecs`…).
fn after_options<'a>(args: &'a [&'a str]) -> &'a [&'a str] {
    let mut rest = args;
    loop {
        match rest {
            ["-c" | "-C", _, tail @ ..] => rest = tail,
            [word, tail @ ..] if word.starts_with('-') => rest = tail,
            _ => return rest,
        }
    }
}

/// Points `cmd` at the active profile's config, unless `args` is about the user's own.
pub(super) fn with_profile(cmd: &mut Command, args: &[&str]) {
    if user_global_config(args) {
        return;
    }
    let path = PROFILE_CONFIG.read().ok().and_then(|p| p.clone());
    if let Some(path) = path {
        cmd.env("GIT_CONFIG_GLOBAL", path);
    }
}

pub(super) const GIT_ENV: [(&str, &str); 4] = [
    ("GIT_TERMINAL_PROMPT", "0"),
    ("GIT_OPTIONAL_LOCKS", "0"),
    ("GIT_EDITOR", "true"),
    ("LANGUAGE", "C"),
];

/// Interactive rebases set `sequence.editor` themselves; an inherited one would win.
pub(super) const GIT_ENV_REMOVED: [&str; 1] = ["GIT_SEQUENCE_EDITOR"];

/// A tab's explicit repository path selects its repository for both guards and
/// mutations. Inherited shell plumbing must not silently select another index,
/// namespace, object store or shallow boundary. Deliberate per-command overrides
/// are installed afterwards through `Extra::env` (private indexes, for example).
pub(super) const REPOSITORY_ENV_REMOVED: &[&str] = &[
    "GIT_DIR",
    "GIT_COMMON_DIR",
    "GIT_WORK_TREE",
    "GIT_INDEX_FILE",
    "GIT_OBJECT_DIRECTORY",
    "GIT_ALTERNATE_OBJECT_DIRECTORIES",
    "GIT_NAMESPACE",
    "GIT_SHALLOW_FILE",
    "GIT_REPLACE_REF_BASE",
    "GIT_CONFIG",
    "GIT_CONFIG_COUNT",
    "GIT_CONFIG_PARAMETERS",
    "GIT_ATTR_SOURCE",
];

/// Pure environment portion of the shared selected-repository command builder.
fn clear_repository_environment(cmd: &mut Command) {
    for name in REPOSITORY_ENV_REMOVED {
        cmd.env_remove(name);
    }
}

#[derive(Clone, Default)]
pub(super) struct Extra {
    normalize_repository: bool,
    owned_pre: Vec<String>,
    unset: Vec<&'static str>,
    output_limit: Option<usize>,
    stdout_file: Option<PathBuf>,
    pre: Vec<&'static str>,
    env: Vec<(&'static str, String)>,
    /// What git reads on its input; nothing when `None`.
    stdin: Option<Vec<u8>>,
    /// It may take minutes (a large bundle): on another machine, run where that is allowed.
    long: bool,
    /// It starts a program the user works in (a diff or merge tool) and waits until it closes.
    tool: bool,
    /// Find out which hook failed, if one does (see [`super::hooks`]).
    trace_hooks: bool,
    /// On another machine: a test of a parallel bisect (see [`run_for_test`]).
    test: Option<std::time::Duration>,
    /// How long it may run on another machine before it is stopped there.
    timeout: Option<std::time::Duration>,
}

/// How long a diff or merge tool started on another machine may stay open before it is stopped.
const TOOL_FOR: std::time::Duration = std::time::Duration::from_secs(12 * 3600);

pub(super) fn apply_command_extras(
    mut cmd: Command,
    _dir: Option<&Path>,
    extra: &Extra,
    args: &[&str],
) -> Command {
    for name in &extra.unset {
        cmd.env_remove(name);
    }
    cmd.args(&extra.pre).args(&extra.owned_pre);
    if extra.normalize_repository {
        normalize_connection_command(&mut cmd, args);
    }
    for (name, value) in &extra.env {
        cmd.env(name, value);
    }
    if extra
        .owned_pre
        .iter()
        .any(|arg| arg == "gitcraft-credential-transport")
    {
        let selected = cmd.get_program().to_owned();
        cmd.env("GITCRAFT_GIT_ORIGINAL", selected);
    }
    cmd.args(args);
    cmd
}

pub(super) const CONNECTION_REDIRECT_ENV: &[&str] = &[
    "GIT_DIR",
    "GIT_WORK_TREE",
    "GIT_COMMON_DIR",
    "GIT_INDEX_FILE",
    "GIT_OBJECT_DIRECTORY",
    "GIT_ALTERNATE_OBJECT_DIRECTORIES",
    "GIT_NAMESPACE",
    "GIT_CONFIG",
    "GIT_CONFIG_GLOBAL",
    "GIT_CONFIG_SYSTEM",
    "GIT_CONFIG_COUNT",
    "GIT_CONFIG_PARAMETERS",
    "GIT_CONFIG_NOSYSTEM",
];
fn normalize_connection_command(cmd: &mut Command, args: &[&str]) {
    for name in CONNECTION_REDIRECT_ENV {
        cmd.env_remove(name);
    }
    for (name, _) in std::env::vars_os() {
        let text = name.to_string_lossy();
        if text.starts_with("GIT_CONFIG_KEY_") || text.starts_with("GIT_CONFIG_VALUE_") {
            cmd.env_remove(name);
        }
    }
    // Intentional immutable profile config is reinstalled after inherited config is removed.
    with_profile(cmd, args);
}

pub(crate) struct PushTarget<'a> {
    pub address: &'a str,
    pub skip_hooks: bool,
    pub alias: &'a str,
    pub original_remote: &'a str,
    pub lfs_config: &'a [(String, String)],
    pub lfs_objects: &'a [String],
    pub receive_pack: &'a str,
}

fn reviewed_push_extra(
    dir: &Path,
    words: &[&str],
    target: PushTarget<'_>,
    hooks_path: String,
    creds: Option<&Credentials>,
) -> Result<Extra, String> {
    let PushTarget {
        address,
        alias: opaque,
        original_remote,
        lfs_config,
        receive_pack,
        ..
    } = target;
    let placeholder = format!("gitcraft-preflight-address://{opaque}");
    let mut values = vec![
        (format!("url.{address}.insteadOf"), placeholder.clone()),
        (format!("remote.{opaque}.url"), String::new()),
        (format!("remote.{opaque}.url"), placeholder.clone()),
        // An explicit pushurl disables pushInsteadOf for this private remote.
        // Otherwise a push-only rule for the placeholder prefix can bypass the
        // ordinary URL expansion proof while leaving its config stamp unchanged.
        (format!("remote.{opaque}.pushurl"), String::new()),
        (format!("remote.{opaque}.pushurl"), placeholder.clone()),
        (format!("remote.{original_remote}.url"), String::new()),
        (format!("remote.{original_remote}.url"), placeholder.clone()),
        (format!("remote.{original_remote}.pushurl"), String::new()),
        (format!("remote.{original_remote}.pushurl"), placeholder),
        ("core.hooksPath".into(), hooks_path),
    ];
    for (source, value) in lfs_config {
        if value.is_empty() {
            continue;
        }
        let target = source
            .strip_prefix(&format!("remote.{original_remote}."))
            .map(|key| format!("remote.{opaque}.{key}"))
            .unwrap_or_else(|| source.clone());
        values.push((target.clone(), value.clone()));
        if target != *source {
            values.push((source.clone(), value.clone()));
        }
    }
    if !receive_pack.is_empty() {
        values.push((format!("remote.{opaque}.receivepack"), receive_pack.into()));
    }
    const VARS: [(&str, &str); 16] = [
        ("GIT_CONFIG_KEY_0", "GIT_CONFIG_VALUE_0"),
        ("GIT_CONFIG_KEY_1", "GIT_CONFIG_VALUE_1"),
        ("GIT_CONFIG_KEY_2", "GIT_CONFIG_VALUE_2"),
        ("GIT_CONFIG_KEY_3", "GIT_CONFIG_VALUE_3"),
        ("GIT_CONFIG_KEY_4", "GIT_CONFIG_VALUE_4"),
        ("GIT_CONFIG_KEY_5", "GIT_CONFIG_VALUE_5"),
        ("GIT_CONFIG_KEY_6", "GIT_CONFIG_VALUE_6"),
        ("GIT_CONFIG_KEY_7", "GIT_CONFIG_VALUE_7"),
        ("GIT_CONFIG_KEY_8", "GIT_CONFIG_VALUE_8"),
        ("GIT_CONFIG_KEY_9", "GIT_CONFIG_VALUE_9"),
        ("GIT_CONFIG_KEY_10", "GIT_CONFIG_VALUE_10"),
        ("GIT_CONFIG_KEY_11", "GIT_CONFIG_VALUE_11"),
        ("GIT_CONFIG_KEY_12", "GIT_CONFIG_VALUE_12"),
        ("GIT_CONFIG_KEY_13", "GIT_CONFIG_VALUE_13"),
        ("GIT_CONFIG_KEY_14", "GIT_CONFIG_VALUE_14"),
        ("GIT_CONFIG_KEY_15", "GIT_CONFIG_VALUE_15"),
    ];
    if values.len() > VARS.len() {
        return Err("Too many pinned transport settings; no push was run.".into());
    }
    let mut extra = Extra {
        pre: Vec::new(),
        unset: PREFLIGHT_REMOVE.to_vec(),
        env: vec![
            ("GIT_CONFIG_COUNT", values.len().to_string()),
            ("GIT_NO_REPLACE_OBJECTS", "1".into()),
        ],
        ..Default::default()
    };
    for ((key, value), (key_var, value_var)) in values.into_iter().zip(VARS) {
        extra.env.extend([(key_var, key), (value_var, value)]);
    }
    preflight_credentials(dir, &mut extra, words, address, creds)?;
    Ok(extra)
}

fn preflight_credentials(
    dir: &Path,
    extra: &mut Extra,
    words: &[&str],
    address: &str,
    creds: Option<&Credentials>,
) -> Result<(), String> {
    let Some(creds) = creds else {
        return Ok(());
    };
    // Validate the captured account even when this is another reviewed endpoint.
    // An unbound or edited cached secret must not acquire a new endpoint scope.
    creds.helper_environment()?;
    if creds
        .scope
        .as_ref()
        .is_some_and(|scope| scope.matches_url(address))
    {
        let policy = credential_command_policy(Some(dir), creds, words)?;
        extra.normalize_repository = true;
        extra.owned_pre.extend(policy.arguments);
        extra.env.extend(policy.environment);
    }
    Ok(())
}

const PREFLIGHT_REMOVE: &[&str] = &[
    "GIT_DIR",
    "GIT_COMMON_DIR",
    "GIT_WORK_TREE",
    "GIT_INDEX_FILE",
    "GIT_OBJECT_DIRECTORY",
    "GIT_ALTERNATE_OBJECT_DIRECTORIES",
    "GIT_NAMESPACE",
    "GIT_SHALLOW_FILE",
    "GIT_CONFIG_PARAMETERS",
    "GIT_CONFIG",
    "GIT_CONFIG_COUNT",
    "GIT_ATTR_SOURCE",
];
pub(super) fn remote_request(target: &Target, extra: &Extra, args: &[&str]) -> remote::Request {
    let words: Vec<String> = extra
        .pre
        .iter()
        .copied()
        .chain(extra.owned_pre.iter().map(String::as_str))
        .chain(args.iter().copied())
        .map(remote::sh_quote)
        .collect();
    let credential_transport = extra
        .owned_pre
        .iter()
        .any(|arg| arg == "gitcraft-credential-transport");
    let pin = if credential_transport {
        CREDENTIAL_REMOTE_PIN
    } else {
        ""
    };
    let script = if extra.trace_hooks {
        let program = if credential_transport {
            "\"$GITCRAFT_GIT_ORIGINAL\""
        } else {
            "git"
        };
        format!(
            "{pin}{}",
            super::hooks::traced_script_with_program(&words.join(" "), program)
        )
    } else if credential_transport {
        format!("{pin}exec \"$GITCRAFT_GIT_ORIGINAL\" {}", words.join(" "))
    } else {
        format!("exec git {}", words.join(" "))
    };
    remote::Request {
        cwd: Some(target.path.clone()),
        script,
        env: GIT_ENV
            .iter()
            .map(|(n, v)| ((*n).to_owned(), (*v).to_owned()))
            .chain(extra.env.iter().map(|(n, v)| ((*n).to_owned(), v.clone())))
            .collect(),
        unset: GIT_ENV_REMOVED
            .iter()
            .chain(REPOSITORY_ENV_REMOVED.iter())
            .chain(
                extra
                    .normalize_repository
                    .then_some(CONNECTION_REDIRECT_ENV)
                    .into_iter()
                    .flatten(),
            )
            .chain(extra.unset.iter())
            .map(|n| (*n).to_owned())
            .collect(),
        stdin: extra.stdin.clone(),
        // A tool stays open as long as the user works in it, apart from ordinary git reads.
        long: extra.tool || extra.long || goes_over_network(args),
        timeout: extra
            .timeout
            .or(extra.test)
            .or_else(|| extra.tool.then_some(TOOL_FOR)),
        test: extra.test.is_some(),
        apart: false,
    }
}


fn goes_over_network(args:&[&str])->bool{args.contains(&"push")}
#[cfg(test)]mod tests {use super::*;
fn target<'a>(address:&'a str)->PushTarget<'a>{PushTarget{address,skip_hooks:false,alias:"reviewed-alias",original_remote:"origin",lfs_config:&[],lfs_objects:&[],receive_pack:""}}
fn env(command:&Command)->std::collections::BTreeMap<String,Option<String>>{command.get_envs().map(|(k,v)|(k.to_string_lossy().into_owned(),v.map(|v|v.to_string_lossy().into_owned()))).collect()}
#[test]fn matching_endpoint_preserves_private_config_original_subcommand_and_selected_executable(){
 let address="https://host.invalid/team/repo.git";let c=Credentials::for_url(address,"alice".into(),"DUMMY_ONLY".into()).unwrap();let words=["push","--porcelain","reviewed-alias","aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa:refs/heads/main"];
 let e=reviewed_push_extra(Path::new("/recorded/repo"),&words,target(address),"/owned/hooks".into(),Some(&c)).unwrap();
 let mut cmd=Command::new("/recorded/selected-git");cmd.arg("-C").arg("/recorded/repo").env("GIT_DIR","foreign");let cmd=apply_command_extras(cmd,None,&e,&words);let args=cmd.get_args().map(|s|s.to_string_lossy().into_owned()).collect::<Vec<_>>();
 assert!(args.ends_with(&words.map(str::to_owned)));assert_eq!(args[args.len()-words.len()-1],"gitcraft-credential-transport");assert!(!args.join(" ").contains("DUMMY_ONLY"));let env=env(&cmd);assert_eq!(env["GITCRAFT_GIT_ORIGINAL"].as_deref(),Some("/recorded/selected-git"));assert_eq!(env["GIT_DIR"],None);assert_eq!(env["GIT_CONFIG_COUNT"].as_deref(),Some("10"));assert_eq!(env["GIT_NO_REPLACE_OBJECTS"].as_deref(),Some("1"));
}
#[test]fn foreign_scheme_host_port_path_receive_no_transient_secret(){let c=Credentials::for_url("https://host.invalid/team/repo.git","alice".into(),"DUMMY_ONLY".into()).unwrap();for address in ["http://host.invalid/team/repo.git","https://other.invalid/team/repo.git","https://host.invalid:444/team/repo.git","https://host.invalid/team/other.git","https://host.invalid/team/repo.git/info/lfs"]{let e=reviewed_push_extra(Path::new("/recorded/repo"),&["push","reviewed-alias"],target(address),"/owned/hooks".into(),Some(&c)).unwrap();assert!(e.owned_pre.is_empty());assert!(!e.env.iter().any(|(k,_)|k.starts_with("GITCRAFT_")));}}
#[test]fn unbound_or_edited_account_refuses_before_policy(){let c=Credentials::for_url("https://host.invalid/team/repo.git","alice".into(),"DUMMY_ONLY".into()).unwrap();for c in [Credentials{scope:None,..c.clone()},Credentials{username:"bob".into(),..c.clone()}]{assert!(reviewed_push_extra(Path::new("/recorded/repo"),&["push"],target("https://foreign.invalid/repo"),"/owned/hooks".into(),Some(&c)).is_err());}}
#[test]fn alias_and_original_have_explicit_pushurl_and_original_hook_config(){let e=reviewed_push_extra(Path::new("/recorded/repo"),&["push"],target("https://host.invalid/repo"),"/owned/hooks".into(),None).unwrap();let map=e.env.iter().cloned().collect::<std::collections::BTreeMap<_,_>>();let n=map["GIT_CONFIG_COUNT"].parse::<usize>().unwrap();let pairs=(0..n).map(|i|(map[format!("GIT_CONFIG_KEY_{i}").as_str()].as_str(),map[format!("GIT_CONFIG_VALUE_{i}").as_str()].as_str())).collect::<Vec<_>>();for remote in ["reviewed-alias","origin"]{for field in ["url","pushurl"]{let k=format!("remote.{remote}.{field}");let values=pairs.iter().filter(|(key,_)|*key==k).map(|(_,v)|*v).collect::<Vec<_>>();assert_eq!(values,vec!["","gitcraft-preflight-address://reviewed-alias"]);}}assert!(pairs.contains(&("core.hooksPath","/owned/hooks")));}
#[test]fn remote_pin_and_counted_config_survive_both_trace_modes(){let c=Credentials::for_url("https://host.invalid/repo","alice".into(),"DUMMY_ONLY".into()).unwrap();let mut e=reviewed_push_extra(Path::new("remote:fixture"),&["push","reviewed-alias"],target("https://host.invalid/repo"),"/owned/hooks".into(),Some(&c)).unwrap();for trace in [false,true]{e.trace_hooks=trace;let q=remote_request(&remote::Target{host:remote::Host::Ssh("uncontacted.invalid".into()),path:"/repo".into()},&e,&["push","reviewed-alias"]);assert!(q.script.starts_with(CREDENTIAL_REMOTE_PIN));assert!(q.script.contains("\"$GITCRAFT_GIT_ORIGINAL\""));assert!(q.unset.contains(&"GIT_CONFIG_COUNT".into()));assert!(q.env.contains(&("GIT_CONFIG_COUNT".into(),"10".into())));assert!(!q.script.contains("DUMMY_ONLY"));}}
#[test]fn repository_redirects_are_removed_but_explicit_private_index_is_reinstalled(){let mut c=Command::new("/recorded/git");for key in REPOSITORY_ENV_REMOVED{c.env(key,"foreign");}clear_repository_environment(&mut c);let e=Extra{env:vec![("GIT_INDEX_FILE","/owned/private-index".into())],..Default::default()};let c=apply_command_extras(c,None,&e,&["status"]);let m=env(&c);for key in REPOSITORY_ENV_REMOVED{assert_eq!(m[*key],if *key=="GIT_INDEX_FILE"{Some("/owned/private-index".into())}else{None});}}
}
}
mod review {use std::sync::{Mutex,OnceLock};use std::sync::atomic::{AtomicU64,Ordering};use std::collections::BTreeMap;
#[derive(Clone,Copy,PartialEq,Eq)]enum Step{Pick,Drop} #[derive(Clone)]struct Commit{hash:String} #[derive(Clone)]struct Entry{commit:Commit,step:Step,message:String} #[derive(Clone)]struct RebaseEditor{branch_guard:Option<Vec<String>>,approval:Option<Approval>,head:String,onto:String,no_ff:bool,update_refs:bool,entries:Vec<Entry>}
#[derive(Clone, PartialEq, Eq)]
struct Approval {
    branch: Vec<String>,
    head: String,
    onto: String,
    no_ff: bool,
    update_refs: bool,
    entries: Vec<(String, Step, String)>,
}

impl RebaseEditor{    fn approval_key(&self, branch: &[String]) -> Approval {
        Approval {
            branch: branch.to_vec(),
            head: self.head.clone(),
            onto: self.onto.clone(),
            no_ff: self.no_ff,
            update_refs: self.update_refs,
            entries: self
                .entries
                .iter()
                .map(|e| (e.commit.hash.clone(), e.step, e.message.clone()))
                .collect(),
        }
    }
    pub fn approve(&mut self, branch: &[String]) -> Result<(), String> {
        if self
            .branch_guard
            .as_ref()
            .is_some_and(|original| original != branch)
        {
            return Err(
                "The checked-out branch changed since this editor opened. Cancel and start again."
                    .into(),
            );
        }
        self.branch_guard = Some(branch.to_vec());
        self.approval = Some(self.approval_key(branch));
        Ok(())
    }
    pub fn approved(&self, branch: &[String], head: &str) -> bool {
        self.head == head
            && self.branch_guard.as_deref() == Some(branch)
            && self
                .approval
                .as_ref()
                .is_some_and(|key| key == &self.approval_key(branch))
    }
    pub fn has_approval(&self) -> bool {
        self.approval.is_some()
    }

}fn with_rechecked_preparation(
    mut verify: impl FnMut() -> Result<(), String>,
    prepare: impl FnOnce() -> Result<(), String>,
) -> Result<(), String> {
    verify()?;
    prepare()?;
    verify()
}

const AUTH_ENDPOINT: &str = "[gitcraft-reviewed-auth:";
fn auth_endpoints() -> &'static Mutex<BTreeMap<u64, String>> {
    static ENDPOINTS: OnceLock<Mutex<BTreeMap<u64, String>>> = OnceLock::new();
    ENDPOINTS.get_or_init(Default::default)
}
pub(crate) fn remember_auth_endpoint(url: &str) -> String {
    static IDS: AtomicU64 = AtomicU64::new(1);
    let id = IDS.fetch_add(1, Ordering::Relaxed);
    if let Ok(mut endpoints) = auth_endpoints().lock() {
        while endpoints.len() >= 64 {
            if let Some(first) = endpoints.keys().next().copied() {
                endpoints.remove(&first);
            }
        }
        endpoints.insert(id, url.into());
    }
    // The log/status carries an opaque receipt, never URL userinfo/query values.
    format!("Authentication failed for the reviewed push target. {AUTH_ENDPOINT}{id}]")
}
pub(crate) fn take_auth_endpoint(error: &str) -> Option<String> {
    let id = error
        .split_once(AUTH_ENDPOINT)?
        .1
        .strip_suffix(']')?
        .parse::<u64>()
        .ok()?;
    auth_endpoints().lock().ok()?.remove(&id)
}
pub(crate) fn is_reviewed_auth_error(error: &str) -> bool {
    error.contains(AUTH_ENDPOINT)
}


#[cfg(test)]mod tests{use super::*;
fn editor()->RebaseEditor{RebaseEditor{branch_guard:Some(vec!["guard".into(),"refs/heads/A".into()]),approval:None,head:"a".repeat(40),onto:"b".repeat(40),no_ff:false,update_refs:false,entries:vec![Entry{commit:Commit{hash:"c".repeat(40)},step:Step::Pick,message:"one".into()},Entry{commit:Commit{hash:"d".repeat(40)},step:Step::Pick,message:"two".into()}]}}
#[test]fn retained_branch_cannot_rebind_even_when_head_is_equal(){let mut e=editor();let a=e.branch_guard.clone().unwrap();e.approve(&a).unwrap();let b=vec!["guard".into(),"refs/heads/B".into()];assert!(!e.approved(&b,&e.head));assert!(e.approve(&b).is_err());assert!(e.approved(&a,&e.head));assert!(!e.approved(&a,&"e".repeat(40)));}
#[test]fn approval_covers_target_flags_order_steps_hashes_and_messages(){let mut base=editor();let g=base.branch_guard.clone().unwrap();base.approve(&g).unwrap();for changed in 0..7{let mut e=base.clone();match changed{0=>e.onto="f".repeat(40),1=>e.no_ff=true,2=>e.update_refs=true,3=>e.entries.reverse(),4=>e.entries[0].step=Step::Drop,5=>e.entries[0].commit.hash="9".repeat(40),_=>e.entries[0].message="unapproved".into()};assert!(!e.approved(&g,&e.head));}}
#[test]fn coherent_preparation_does_not_authorize_moved_source(){use std::cell::Cell;for fail_after in [false,true]{let state=Cell::new("approved");let checks=Cell::new(0);let prepared=Cell::new(0);let result=with_rechecked_preparation(||{checks.set(checks.get()+1);if state.get()=="approved"{Ok(())}else{Err("changed".into())}},||{prepared.set(prepared.get()+1);if fail_after{state.set("later-coherent");}Ok(())});assert_eq!(checks.get(),2);assert_eq!(prepared.get(),1);assert_eq!(result.is_err(),fail_after);}}
#[test]fn prepare_failure_and_initial_guard_failure_refuse(){use std::cell::Cell;let prepared=Cell::new(false);assert!(with_rechecked_preparation(||Err("initial".into()),||{prepared.set(true);Ok(())}).is_err());assert!(!prepared.get());let checks=Cell::new(0);assert!(with_rechecked_preparation(||{checks.set(checks.get()+1);Ok(())},||Err("capture".into())).is_err());assert_eq!(checks.get(),1);}
#[test]fn auth_receipt_is_opaque_one_shot_bounded_and_never_returns_another_endpoint(){let url="https://actual.invalid/repo?DUMMY_PRIVATE";let first=remember_auth_endpoint(url);assert!(!first.contains(url));assert!(!first.contains("DUMMY_PRIVATE"));assert_eq!(take_auth_endpoint(&first).as_deref(),Some(url));assert!(take_auth_endpoint(&first).is_none());let stale=remember_auth_endpoint("https://old.invalid/repo");for _ in 0..64{remember_auth_endpoint("https://new.invalid/repo");}assert!(is_reviewed_auth_error(&stale));assert!(take_auth_endpoint(&stale).is_none());}
}
}

use git::{CredentialScope,hooks};

mod hover {use std::path::Path;use std::time::{Instant,Duration};use crate::remote;
mod git {pub fn draft_bytes(_: &std::path::Path,args:&[&str],_:&[(&'static str,String)],_:Vec<u8>,_:&[i32],active:&dyn Fn()->bool)->Result<Vec<u8>,String>{if !active(){return Err("cancelled before dispatch".into());}assert_eq!(args[0],"--no-lazy-fetch");assert_eq!(args[1],"--no-replace-objects");Ok(args.join(" ").into_bytes())}}
pub(crate) struct Reader<'a> {
    repo: &'a Path,
    active: &'a dyn Fn() -> bool,
    began: Instant,
}
impl<'a> Reader<'a> {
    pub fn new(repo: &'a Path, active: &'a dyn Fn() -> bool) -> Self {
        Self {
            repo,
            active,
            began: Instant::now(),
        }
    }
    pub fn active(&self) -> bool {
        (self.active)() && self.began.elapsed() < Duration::from_secs(120)
    }
    pub fn run(&self, args: &[&str], input: Vec<u8>, ok: &[i32]) -> Result<Vec<u8>, String> {
        let pre = self.command(args);
        git::draft_bytes(
            self.repo,
            &pre.iter().map(String::as_str).collect::<Vec<_>>(),
            &[],
            input,
            ok,
            &|| self.active(),
        )
        .map_err(|e| e.replace("Draft", "History investigation"))
    }
    /// The same immutable command policy is inspectable without starting Git.
    pub fn command(&self, args: &[&str]) -> Vec<String> {
        let hooks = format!(
            "core.hooksPath={}",
            if remote::is_remote(self.repo) || !cfg!(windows) {
                "/dev/null"
            } else {
                "NUL"
            }
        );
        let mut pre = vec![
            "--no-lazy-fetch",
            "--no-replace-objects",
            "--no-optional-locks",
            "-c",
            "core.fsmonitor=false",
            "-c",
            "core.untrackedCache=false",
            "-c",
            "gc.auto=0",
            "-c",
            "maintenance.auto=false",
            "-c",
            "commit.gpgSign=false",
            "-c",
            &hooks,
        ];
        pre.extend_from_slice(args);
        pre.into_iter().map(str::to_owned).collect()
    }
}

#[test]fn timeline_reader_policy_stays_no_fetch_physical_and_hook_free_for_every_read(){let yes=||true;let r=Reader::new(Path::new("/recorded/repo"),&yes);for args in [vec!["rev-list","--max-count=201","HEAD"],vec!["log","--no-walk=unsorted","a"],vec!["diff","--numstat","a","b"]]{let result=String::from_utf8(r.run(&args,vec![],&[0]).unwrap()).unwrap();assert!(result.contains("--no-lazy-fetch --no-replace-objects --no-optional-locks"));assert!(result.contains("core.fsmonitor=false"));assert!(result.contains("core.hooksPath=/dev/null"));}let no=||false;let r=Reader::new(Path::new("/recorded/repo"),&no);assert!(!r.active());assert!(r.run(&["log"],vec![],&[0]).is_err());}
}
mod scope {use std::sync::{Arc,atomic::{AtomicBool,Ordering}};
#[derive(Clone, Default)]
pub(crate) struct Cancellation(Arc<AtomicBool>, Option<Arc<Cancellation>>);

impl Cancellation {
    pub(crate) fn cancel(&self) {
        self.0.store(true, Ordering::Release);
    }
    pub(crate) fn is_cancelled(&self) -> bool {
        self.0.load(Ordering::Acquire)
            || self.1.as_ref().is_some_and(|parent| parent.is_cancelled())
    }
    pub(crate) fn child(&self) -> Self {
        Self(Arc::default(), Some(Arc::new(self.clone())))
    }
}

/// Only the tab owns this guard; jobs clone its token, never the guard.
#[derive(Default)]
pub(crate) struct Scope(pub(crate) Cancellation);
impl Drop for Scope {
    fn drop(&mut self) {
        self.0.cancel();
    }
}


#[test]fn dropping_hover_scope_stops_only_its_token_and_descendants(){let parent=Cancellation::default();let child=parent.child();let descendant=child.child();{let _scope=Scope(child.clone());assert!(!child.is_cancelled());}assert!(child.is_cancelled());assert!(descendant.is_cancelled());assert!(!parent.is_cancelled());}
}
