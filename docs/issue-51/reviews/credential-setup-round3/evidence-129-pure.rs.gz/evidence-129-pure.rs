#![allow(dead_code,unused_imports)]
mod harness {
use std::{path::{Path,PathBuf},process::Command};
#[derive(Clone,Debug)] pub struct Credentials { pub username:String,pub password:String,pub scope:Option<CredentialScope> }
#[path="/tmp/gitcraft-credential-setup-r3-0319-source/src/git/credential_scope.rs"] mod credential_scope;
pub use credential_scope::{CredentialScope,CREDENTIAL_HELPER};
pub(crate) mod git {pub use super::{CredentialScope,CREDENTIAL_HELPER};}
mod remote {pub fn is_remote(_: &std::path::Path)->bool { false }}
pub(crate) mod practice {pub fn is_repository(_: &std::path::Path)->bool {false}}
pub(crate) mod connections {
 #[derive(Clone)] pub struct Choices{pub ssh_key:String}
 #[derive(Clone)] pub struct Context {pub error:Option<String>,pub choices:Choices,pub git_config:Option<std::path::PathBuf>}
 pub fn current()->Context {Context{error:None,choices:Choices{ssh_key:String::new()},git_config:Some("/recorded/profile.gitconfig".into())}}
}
#[path="/tmp/gitcraft-credential-setup-r3-0319-source/src/git/command/credential_policy.rs"] mod credential_policy;
fn user_global_config(args: &[&str]) -> bool {
    let rest = after_options(args);
    (rest.first() == Some(&"config") && rest.contains(&"--global"))
        // `maintenance start` / `register` write `maintenance.repo` to the global config.
        || (rest.first() == Some(&"maintenance")
            && matches!(rest.get(1), Some(&("start" | "register" | "unregister" | "stop"))))
}

/// `args` from the subcommand on: past the options before it (`-c x=y`, `-C dir`,
/// `--literal-pathspecs`…).
fn after_options<'a>(args: &'a [&'a str]) -> &'a [&'a str] {
    let mut rest = args;
    loop {
        match rest {
            ["-c" | "-C", _, tail @ ..] => rest = tail,
            [word, tail @ ..] if word.starts_with('-') => rest = tail,
            _ => return rest,
        }
    }
}

/// Points `cmd` at the active profile's config, unless `args` is about the user's own.
pub(super) fn with_profile(cmd: &mut Command, args: &[&str]) {
    if user_global_config(args) {
        return;
    }
    let context = crate::connections::current();
    if context.error.is_some() {
        cmd.arg("-c").arg("=invalid-profile");
        return;
    }
    if !context.choices.ssh_key.is_empty() {
        cmd.env_remove("GIT_SSH_COMMAND")
            .env_remove("GIT_SSH")
            .env_remove("GIT_SSH_VARIANT");
    }
    let path = context.git_config;
    if let Some(path) = path {
        cmd.env("GIT_CONFIG_GLOBAL", path);
    }
}


pub(super) fn apply_command_extras(
    mut cmd: Command,
    dir: Option<&Path>,
    extra: &Extra,
    args: &[&str],
) -> Command {
    cmd.args(&extra.pre).args(&extra.owned_pre);
    if extra.normalize_repository && !dir.is_some_and(crate::practice::is_repository) {
        normalize_connection_command(&mut cmd, args);
    }
    for (name, value) in &extra.env {
        cmd.env(name, value);
    }
    if extra
        .owned_pre
        .iter()
        .any(|arg| arg == "gitcraft-credential-transport")
    {
        let selected = cmd.get_program().to_owned();
        cmd.env("GITCRAFT_GIT_ORIGINAL", selected);
    }
    cmd.args(args);
    cmd
}

pub(super) const CONNECTION_REDIRECT_ENV: &[&str] = &[
    "GIT_DIR",
    "GIT_WORK_TREE",
    "GIT_COMMON_DIR",
    "GIT_INDEX_FILE",
    "GIT_OBJECT_DIRECTORY",
    "GIT_ALTERNATE_OBJECT_DIRECTORIES",
    "GIT_NAMESPACE",
    "GIT_CONFIG",
    "GIT_CONFIG_GLOBAL",
    "GIT_CONFIG_SYSTEM",
    "GIT_CONFIG_COUNT",
    "GIT_CONFIG_PARAMETERS",
    "GIT_CONFIG_NOSYSTEM",
];
fn normalize_connection_command(cmd: &mut Command, args: &[&str]) {
    for name in CONNECTION_REDIRECT_ENV {
        cmd.env_remove(name);
    }
    for (name, _) in std::env::vars_os() {
        let text = name.to_string_lossy();
        if text.starts_with("GIT_CONFIG_KEY_") || text.starts_with("GIT_CONFIG_VALUE_") {
            cmd.env_remove(name);
        }
    }
    // Intentional immutable profile config is reinstalled after inherited config is removed.
    with_profile(cmd, args);
}


#[derive(Default)] struct Extra { pre:Vec<&'static str>,owned_pre:Vec<String>,env:Vec<(&'static str,String)>,normalize_repository:bool }

pub fn run(){
let creds=Credentials::for_url("https://host.invalid/team/repo/","alice".into(),"DUMMY_TOKEN".into()).unwrap();
let args=["push","private-alias","HEAD:refs/heads/main"];
let mut p=credential_policy::credential_command_policy(Some(Path::new("/not-a-real-repo")),&creds,&args).unwrap();
assert!(p.bind_git(Path::new("git")).is_err());p.bind_git(Path::new("/selected/git-A")).unwrap();
assert!(p.environment.iter().any(|(k,v)|*k=="GITCRAFT_GIT_ORIGINAL"&&v=="/selected/git-A"));
let mut extra=Extra{normalize_repository:true,owned_pre:p.arguments,env:p.environment,..Default::default()};
extra.env.extend([("GIT_CONFIG_COUNT","1".into()),("GIT_CONFIG_KEY_0","remote.private-alias.url".into()),("GIT_CONFIG_VALUE_0","https://host.invalid/team/repo".into())]);
let cmd=apply_command_extras(Command::new("/recorded/git"),Some(Path::new("/recorded/repo")),&extra,&args);
let env:std::collections::HashMap<_,_>=cmd.get_envs().map(|(k,v)|(k.to_string_lossy().into_owned(),v.map(|x|x.to_string_lossy().into_owned()))).collect();
assert_eq!(cmd.get_program(),"/recorded/git");
assert_eq!(env.get("GITCRAFT_GIT_ORIGINAL"),Some(&Some("/recorded/git".into())));
assert_eq!(env.get("GIT_DIR"),Some(&None));assert_eq!(env.get("GIT_CONFIG_PARAMETERS"),Some(&None));
assert_eq!(env.get("GIT_CONFIG_KEY_99"),Some(&None));assert_eq!(env.get("GIT_CONFIG_VALUE_99"),Some(&None));
assert_eq!(env.get("GIT_CONFIG_GLOBAL"),Some(&Some("/recorded/profile.gitconfig".into())));
assert_eq!(env.get("GIT_CONFIG_COUNT"),Some(&Some("1".into())));
assert_eq!(env.get("GIT_CONFIG_KEY_0"),Some(&Some("remote.private-alias.url".into())));
let argv=cmd.get_args().map(|a|a.to_string_lossy().into_owned()).collect::<Vec<_>>();assert!(argv.ends_with(&args.map(String::from)));assert!(!argv.join(" ").contains("DUMMY_TOKEN"));
println!("PASS exact apply_command_extras: fixed Git pin, inherited config removal, selected profile and intentional alias config preservation, original argv and no secret argv");
let scope=CredentialScope::for_url("https://host.invalid/team/repo","alice").unwrap();
for u in ["https://host.invalid/team/repo/","https://host.invalid//team/repo","https://host.invalid/team/repo%2F"]{assert!(scope.matches_url(u));}
for u in ["https://host.invalid/%2F","https://host.invalid/%2F%2F","https://host.invalid/%2F/"]{let c=Credentials::for_url(u,"alice".into(),"DUMMY".into()).unwrap();assert!(!c.scope.as_ref().unwrap().matches_url("https://host.invalid/"));assert!(c.helper_environment().unwrap().contains(&("GITCRAFT_CREDENTIAL_PATH","/".into())));}
assert!(Credentials::for_url("https://bob@host.invalid/repo","alice".into(),"DUMMY".into()).is_err());
assert!(Credentials::for_url("https://alice:pass@host.invalid/repo","alice".into(),"DUMMY".into()).is_err());
assert!(Credentials::for_url("https://al%69ce@host.invalid/repo","alice".into(),"DUMMY".into()).is_ok());
println!("PASS exact scope: raw/encoded slashes normalized without encoded-root collision; URL-account mismatch/password refused");
}
}
use harness::{practice,connections,git};
fn main(){harness::run()}
