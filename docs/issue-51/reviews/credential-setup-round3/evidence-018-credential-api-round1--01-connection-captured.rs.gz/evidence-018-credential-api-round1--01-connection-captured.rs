use std::path::Path; use std::time::Duration;
#[derive(Default)]struct Extra{normalize_repository:bool,stdin:Option<Vec<u8>>,timeout:Option<Duration>,output_limit:Option<usize>}
struct Ran{code:Option<i32>,stdout:Vec<u8>,stderr:Vec<u8>}
pub struct Captured{code:Option<i32>,stdout:String,stderr:String,raw:Vec<u8>}
mod remote{pub fn is_remote(_: &std::path::Path)->bool{false}}
fn unattended_extra(_:bool)->Extra{Extra::default()}
fn execute(_:Option<&Path>,e:&Extra,_:&[&str])->Result<Ran,String>{assert!(e.normalize_repository);assert_eq!(e.stdin.as_deref(),Some(&b"synthetic input"[..]));assert_eq!(e.output_limit,Some(128<<10));assert_eq!(e.timeout,Some(Duration::from_secs(10)));Ok(Ran{code:Some(1),stdout:b"out\xff".to_vec(),stderr:b"err\xfe".to_vec()})}
pub(crate) fn connection_captured(
    dir: &Path,
    args: &[&str],
    input: Option<&[u8]>,
) -> Result<Captured, String> {
    let mut extra = unattended_extra(cfg!(unix) || remote::is_remote(dir));
    extra.normalize_repository = true;
    extra.stdin = input.map(<[u8]>::to_vec);
    extra.timeout = Some(Duration::from_secs(10));
    extra.output_limit = Some(128 << 10);
    let out = execute(Some(dir), &extra, args)?;
    Ok(Captured {
        code: out.code,
        stdout: String::from_utf8_lossy(&out.stdout).into_owned(),
        stderr: String::from_utf8_lossy(&out.stderr).into_owned(),
        raw: out.stdout,
    })
}
fn main(){let o=connection_captured(Path::new("/synthetic"),&["config"],Some(b"synthetic input")).unwrap();assert_eq!(o.code,Some(1));assert_eq!(o.raw,b"out\xff");assert_eq!(o.stdout,"out\u{fffd}");assert_eq!(o.stderr,"err\u{fffd}");println!("nonzero status, raw stdout, lossy display stdout/stderr, input, normalization and limits preserved");}
