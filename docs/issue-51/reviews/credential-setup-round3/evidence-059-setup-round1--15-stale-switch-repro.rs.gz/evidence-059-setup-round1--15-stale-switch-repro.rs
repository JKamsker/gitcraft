
mod egui { pub struct Context; }
mod settings { pub mod network_page { pub fn valid_https(url:&str)->bool { url.starts_with("https://") && !url.chars().any(char::is_control) && url.len()<32768 } } }
mod diagnostics { pub mod crash {pub fn scrub(s:&str)->String{s.into()}} }
mod git {pub fn https_reject(_:&std::path::Path,_:&str)->Result<(),String>{Ok(())}}
mod model {
use crate::{egui,git};
#[derive(Debug)]struct Dialog(String);
impl Dialog {fn credentials(url:&str,_:bool)->Self{Self(url.into())}}
struct RepoTab {path:std::path::PathBuf,busy_op:Option<String>,credentials:Option<String>,status:Option<(String,bool)>,dialog:Option<Dialog>,pending:Option<Box<dyn FnOnce(&mut RepoTab,&egui::Context)>>}
impl RepoTab {
 fn then_or<T:Send+'static>(&mut self,_ctx:&egui::Context,_mutation:bool,_failed:impl FnOnce(String)->T+Send+'static,_work:impl FnOnce()->T+Send+'static,_then:impl FnOnce(&mut RepoTab,T,&egui::Context)+Send+'static) { let result=_work(); self.pending=Some(Box::new(move|tab,ctx|_then(tab,result,ctx))); }
    pub(super) fn switch_https(&mut self, url: String, ctx: &egui::Context) {
        if !crate::settings::network_page::valid_https(&url) {
            return;
        }
        if let Some(busy) = &self.busy_op {
            self.status = Some((
                format!("Wait until {busy} finishes before switching sign-ins"),
                true,
            ));
            return;
        }
        let path = self.path.clone();
        let original = url.clone();
        self.credentials = None;
        self.then_or(ctx,true,Err,move || git::https_reject(&path,&url),move |tab,result,_|match result {
            Ok(())=>{tab.status=Some(("Stored HTTPS sign-in rejected. Choose the correct account; profile-selected forge accounts can be changed in Settings → Profile.".into(),false));tab.dialog=Some(Dialog::credentials(&original,false));},
            Err(e)=>tab.status=Some((format!("Could not forget the stored sign-in: {}",crate::diagnostics::crash::scrub(&e)),true)),
        });
    }


}

impl RepoTab {
 pub fn check(){let ctx=egui::Context;let mut tab=RepoTab{path:"/fixture/repo".into(),busy_op:None,credentials:Some("PROFILE_A_FIXTURE".into()),status:None,dialog:None,pending:None};
 tab.switch_https("https://fixture.invalid/old-account".into(),&ctx);
 // Connection-edit invalidation clears this UI before an old continuation arrives.
 tab.credentials=None;tab.dialog=None;
 let complete=tab.pending.take().expect("queued completion");complete(&mut tab,&ctx);
 println!("STALE_HTTPS_COMPLETION_REOPENED_DIALOG={}",tab.dialog.as_ref().map(|d|d.0.as_str()).unwrap_or("none"));
 assert!(tab.dialog.is_some());}
}

pub fn run(){RepoTab::check()}
}
fn main(){model::run()}
