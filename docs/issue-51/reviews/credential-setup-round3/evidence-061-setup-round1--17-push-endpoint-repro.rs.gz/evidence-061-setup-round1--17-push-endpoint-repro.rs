#[derive(Debug)] struct Remote {name:String,url:String}
fn parse_remotes(out: &str) -> Vec<Remote> {
    let mut list: Vec<Remote> = Vec::new();
    for line in out.lines() {
        let Some((name, rest)) = line.split_once('\t') else {
            continue;
        };
        let url = rest.rsplit_once(" (").map_or(rest, |(url, _)| url);
        if !list.iter().any(|r| r.name == name) {
            list.push(Remote {
                name: name.to_owned(),
                url: url.to_owned(),
            });
        }
    }
    list
}

fn main(){let remotes=parse_remotes("origin\thttps://fetch.fixture.invalid/team/repo (fetch)\norigin\thttps://push.fixture.invalid/team/repo (push)\n");println!("INVENTORY_INPUT={remotes:?}");assert_eq!(remotes.len(),1);assert!(remotes[0].url.contains("fetch.fixture.invalid"));}