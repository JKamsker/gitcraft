#![allow(dead_code,unused_imports)]
use std::path::Path;
#[derive(Clone,Debug)]pub struct Credentials{pub username:String,pub password:String,pub scope:Option<CredentialScope>}
#[path="/tmp/gitcraft-credential-setup-r3-0319-source/src/git/credential_scope.rs"]mod credential_scope;
pub use credential_scope::{CredentialScope,CREDENTIAL_HELPER};
mod git{pub use crate::CredentialScope;}
mod connections{#[derive(Clone)]pub struct Context; pub fn current()->Context{Context}}
fn after_options<'a>(args: &'a [&'a str]) -> &'a [&'a str] {
    let mut rest = args;
    loop {
        match rest {
            ["-c" | "-C", _, tail @ ..] => rest = tail,
            [word, tail @ ..] if word.starts_with('-') => rest = tail,
            _ => return rest,
        }
    }
}

pub fn is_auth_error(err: &str) -> bool {
    let e = err.to_lowercase();
    [
        "terminal prompts disabled",
        "could not read username",
        "could not read password",
        "authentication failed",
        "invalid username or password",
        "http basic: access denied",
        "the requested url returned error: 401",
        "the requested url returned error: 403",
    ]
    .iter()
    .any(|s| e.contains(s))
}

mod endpoints{use super::*; #[derive(Clone)]pub(crate) struct RouteBinding{pub args:Vec<String>,pub routes:Vec<String>}
#[derive(Clone)]
pub(crate) struct AuthFailure {
    pub context: crate::connections::Context,
    pub endpoints: Vec<String>,
    pub confirmed: bool,
    pub binding: Option<RouteBinding>,
    pub lfs: bool,
}
fn safe_http_url(value: &str) -> Option<String> {
    let (scheme, rest) = value.split_once("://")?;
    if !matches!(scheme, "https" | "http") {
        return None;
    }
    let (authority, tail) = rest
        .split_once('/')
        .map_or((rest, String::new()), |(a, p)| (a, format!("/{p}")));
    let authority = authority.rsplit('@').next()?;
    let clean = format!("{scheme}://{authority}{tail}");
    crate::git::CredentialScope::for_url(&clean, "endpoint-check").ok()?;
    Some(clean)
}
impl AuthFailure {
    pub fn needs_separate_account(&self) -> bool {
        if self.lfs {
            return true;
        }
        let Some(binding) = &self.binding else {
            return false;
        };
        if super::after_options(&binding.args.iter().map(String::as_str).collect::<Vec<_>>())
            .first()
            == Some(&"lfs")
        {
            return true;
        }
        self.confirmed
            && self.endpoints.iter().any(|url| {
                !binding.routes.iter().any(|route| {
                    crate::git::CredentialScope::for_url(url, "endpoint-check")
                        .is_ok_and(|scope| scope.matches_url(route))
                })
            })
    }
    /// An explicit URL reported by Git/LFS takes precedence over configured candidates.
    /// Otherwise the UI requires a destination choice; it never guesses a fetch URL.
    pub fn from_error(error: &str, attempted: &[String]) -> Self {
        // Only canonical Git auth records and explicit LFS auth-error records count.
        // Untrusted remote banners/help links cannot confirm a destination.
        let mut reported = Vec::new();
        for line in error.lines() {
            let line = line.trim();
            let quoted = line
                .strip_prefix("fatal: Authentication failed for '")
                .and_then(|v| v.strip_suffix('\''))
                .or_else(|| {
                    line.strip_prefix("fatal: unable to access '")
                        .and_then(|v| v.split_once("':"))
                        .filter(|(_, e)| super::is_auth_error(e))
                        .map(|(u, _)| u)
                });
            let lfs = line
                .strip_prefix("LFS: ")
                .filter(|_| {
                    line.to_ascii_lowercase()
                        .contains("authentication required")
                })
                .and_then(|v| v.split_whitespace().next());
            if let Some(url) = quoted.or(lfs).and_then(safe_http_url)
                && !reported.contains(&url)
            {
                reported.push(url);
            }
        }
        let confirmed = reported.len() == 1;
        let mut endpoints = reported;
        if !confirmed {
            for url in attempted.iter().filter_map(|u| safe_http_url(u)) {
                if !endpoints.contains(&url) {
                    endpoints.push(url);
                }
            }
        }
        Self {
            context: crate::connections::current(),
            endpoints,
            confirmed,
            binding: None,
            lfs: error.lines().any(|line| {
                line.trim_start().starts_with("LFS:")
                    || line.contains("git-lfs")
                    || line.contains("Git LFS")
            }),
        }
    }
}

pub fn run(){
let route="https://git.invalid/repo".to_owned();
let mut f=AuthFailure::from_error("remote: See https://docs.invalid/help\nfatal: Authentication failed for 'https://git.invalid/repo'",&[route.clone()]);assert!(f.confirmed);assert_eq!(f.endpoints,[route.clone()]);
f.binding=Some(RouteBinding{args:vec!["push".into(),"origin".into()],routes:vec![route.clone()]});assert!(!f.needs_separate_account());
let mut foreign=AuthFailure::from_error("fatal: Authentication failed for 'https://lfs.invalid/old'",&[route.clone()]);foreign.binding=f.binding.clone();assert!(foreign.needs_separate_account());
let mut conflict=AuthFailure::from_error("fatal: Authentication failed for 'https://git.invalid/repo'\nfatal: Authentication failed for 'https://lfs.invalid/old'",&[route.clone()]);conflict.binding=f.binding.clone();
assert!(!conflict.confirmed);assert!(!conflict.lfs);assert!(conflict.endpoints.contains(&"https://lfs.invalid/old".into()));assert!(!conflict.needs_separate_account());
println!("PASS F6 docs-before-fatal preservation and single foreign refusal");
println!("REPRO F4b: conflicting canonical Git/foreign endpoint records -> confirmed=false, lfs=false, needs_separate_account=false; foreign endpoint remains selectable with ordinary Git route proof");
}
}
fn main(){endpoints::run()}
