#![allow(dead_code)]
mod git {#[derive(Default)]pub struct Commit{pub hash:String,pub parents:Vec<String>,pub refs:Vec<String>}}
#[path="/tmp/gitcraft-visual-content-r2-source/src/graph.rs"]mod graph;
fn main(){for parents in [64usize,512,4096]{let commits=vec![git::Commit{hash:"tip".into(),parents:(0..parents).map(|i|format!("{i:040x}")).collect(),..Default::default()}];let at=std::time::Instant::now();let g=graph::layout(&commits);assert_eq!(g.rows.len(),1);assert_eq!(g.width,parents);println!("listed_commits=1 parents={parents} lanes={} output_parent_text_bytes={} deterministic_lane_scan_visits={} elapsed_ms={}",g.width,parents*41,parents*(parents-1),at.elapsed().as_millis());}}
