#![allow(dead_code)]
mod git { #[derive(Default,Clone)] pub struct Commit {pub hash:String,pub parents:Vec<String>,pub refs:Vec<String>} pub mod postcards {pub const LIMIT:usize=200;} }
#[path="/tmp/gitcraft-visual-content-r2-source/src/graph.rs"] mod graph;
mod postcards {
pub struct Snapshot {pub name:String,pub date:String,pub range:String,pub commits:Vec<crate::git::Commit>,pub messages:Vec<String>,pub contributors:Vec<String>,pub anonymized:bool}
#[path="/tmp/gitcraft-visual-content-r2-source/src/repo/postcards/render.rs"] pub mod render;
pub fn run() {
 for parents in [1usize, 97, 198] {
  let mut commits=vec![crate::git::Commit{hash:"merge".into(),parents:(0..parents).map(|i|format!("p{i}")).collect(),refs:Vec::new()}];
  for i in 0..parents {commits.push(crate::git::Commit{hash:format!("p{i}"),parents:vec!["root".into()],refs:Vec::new()});}
  commits.push(crate::git::Commit{hash:"root".into(),parents:vec![],refs:Vec::new()});
  let graph=crate::graph::layout(&commits);
  let snapshot=Snapshot{name:"Bounded maximum release".into(),date:"2026-11-08".into(),range:"root..merge".into(),messages:vec!["A subject".into();commits.len()],commits,contributors:vec![],anonymized:false};
  let (image,png)=render::render(&snapshot,&||true).unwrap();
  let decoded=image::load_from_memory(&png).unwrap().to_rgba8();
  let spacing=13.0f32.min(500.0/(graph.width.saturating_sub(1).max(1) as f32));
  let mut visible=0;
  for (i,row) in graph.rows.iter().enumerate() {
   let x=(40.0+row.col as f32*spacing) as u32;let y=(152+i*27) as u32;
   assert!(x<553);assert_ne!(decoded.get_pixel(x,y).0,[21,27,39,255],"missing parents={parents} row={i} col={}",row.col);visible+=1;
  }
  assert!(render::render(&snapshot,&||false).is_err());
  println!("parents={parents} commits={visible} graph_width={} image={:?} png_bytes={} cancellation=refused",graph.width,image.size,png.len());
 }
}
}
fn main(){postcards::run()}
