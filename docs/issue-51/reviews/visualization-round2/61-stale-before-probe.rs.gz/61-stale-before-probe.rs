use std::sync::atomic::{AtomicUsize,Ordering};
static CUES:AtomicUsize=AtomicUsize::new(0);
mod egui{pub struct Context;impl Context{pub fn request_repaint(&self){}}}
mod settings{pub struct Settings{pub celebration_motion:bool,pub celebration_sound:bool} impl Settings{pub fn get(_: &crate::egui::Context)->Self{Self{celebration_motion:false,celebration_sound:true}}}}
mod audio{pub enum Cue{Celebration}pub fn play(_:Cue){crate::CUES.fetch_add(1,std::sync::atomic::Ordering::Relaxed);}}
mod repo{
#[derive(Default)]pub struct Branch{pub name:String,pub target:String}
#[derive(Default)]pub struct Refs{pub head:String,pub local:Vec<Branch>,pub tags:Vec<Branch>,pub remotes:Vec<(String,Vec<Branch>)>}
pub struct Commit{pub hash:String,pub parents:Vec<String>}
pub struct RepoTab{pub refs:Refs,pub history:Vec<Commit>,pub reads:u64,pub celebration:celebration::State}
mod celebration{use crate::egui;
// Production module comment omitted for embedding.
use super::RepoTab;
use std::time::{Duration, Instant};

#[derive(Clone)]
enum Event {
    FirstCommit,
    ReleaseTag { name: String, target: String },
    Merge { before: String, require_merge: bool },
}

#[derive(Default)]
pub(super) struct State {
    candidate: Option<Event>,
    observed: Option<String>,
    pending: Vec<(u64, Event, Option<String>)>,
    visible: Option<(&'static str, Instant)>,
}

impl RepoTab {
    pub(super) fn celebration_begin(
        &mut self,
        label: &str,
        ops: &[Vec<String>],
        ctx: &egui::Context,
    ) {
        self.celebration.candidate = None;
        self.celebration.observed = None;
        let settings = crate::settings::Settings::get(ctx);
        if !settings.celebration_motion && !settings.celebration_sound {
            return;
        }
        let command = |name: &str| {
            ops.iter()
                .find(|op| op.first().is_some_and(|arg| arg == name))
        };
        self.celebration.candidate = if command("commit").is_some()
            && self.refs.head.is_empty()
            && self.history.is_empty()
            && self.refs.local.is_empty()
            && self.refs.tags.is_empty()
            && self
                .refs
                .remotes
                .iter()
                .all(|(_, branches)| branches.is_empty())
        {
            Some(Event::FirstCommit)
        } else if let Some(name) = label.strip_prefix("Create release tag ") {
            command("tag")
                .filter(|op| {
                    !op.iter()
                        .any(|arg| matches!(arg.as_str(), "-d" | "--delete"))
                })
                .and_then(|op| op.last())
                .filter(|_| !self.refs.tags.iter().any(|b| b.name == name))
                .map(|target| Event::ReleaseTag {
                    name: name.into(),
                    target: target.clone(),
                })
        } else if (command("merge").is_some_and(|op| {
            !op.iter()
                .any(|arg| matches!(arg.as_str(), "--abort" | "--quit"))
        }) || label == "Continue merge"
            || command("pull").is_some_and(|op| op.iter().any(|a| a == "--no-rebase")))
            && !self.refs.head.is_empty()
        {
            Some(Event::Merge {
                before: self.refs.head.clone(),
                require_merge: command("pull").is_some(),
            })
        } else {
            None
        };
    }

    pub(super) fn celebration_needs_head(&self) -> bool {
        matches!(
            self.celebration.candidate,
            Some(Event::FirstCommit | Event::Merge { .. })
        )
    }
    pub(super) fn celebration_observed_head(&mut self, head: String) {
        self.celebration.observed = (!head.is_empty()).then_some(head);
    }

    pub(super) fn celebration_done(&mut self, success: bool) {
        if let Some(event) = self.celebration.candidate.take().filter(|_| success) {
            let observed = self.celebration.observed.take();
            if matches!(event, Event::ReleaseTag { .. }) || observed.is_some() {
                self.celebration
                    .pending
                    .push((self.reads + 1, event, observed));
            }
        }
    }

    pub(super) fn celebration_loaded(&mut self, read: u64, ctx: &egui::Context) {
        let pending = std::mem::take(&mut self.celebration.pending);
        for (min_read, event, observed) in pending {
            if read < min_read {
                self.celebration.pending.push((min_read, event, observed));
                continue;
            }
            self.confirm_celebration(event, observed, ctx);
        }
    }

    fn confirm_celebration(&mut self, event: Event, observed: Option<String>, ctx: &egui::Context) {
        let label = match event {
            Event::FirstCommit
                if observed.as_ref().is_some_and(|hash| {
                    self.history
                        .iter()
                        .any(|c| &c.hash == hash && c.parents.is_empty())
                }) =>
            {
                "First commit created"
            }
            Event::ReleaseTag { name, target }
                if self
                    .refs
                    .tags
                    .iter()
                    .any(|b| b.name == name && b.target == target) =>
            {
                "Release tag created"
            }
            Event::Merge {
                before,
                require_merge,
            } if observed.as_ref().is_some_and(|hash| {
                hash != &before
                    && self.history.iter().any(|c| {
                        &c.hash == hash
                            && (!require_merge
                                || (c.parents.len() > 1 && c.parents.first() == Some(&before)))
                    })
            }) =>
            {
                "Merge completed"
            }
            _ => return,
        };
        let settings = crate::settings::Settings::get(ctx);
        if settings.celebration_sound {
            crate::audio::play(crate::audio::Cue::Celebration);
        }
        if settings.celebration_motion && !reduced(ctx) {
            self.celebration.visible = Some((label, Instant::now()));
            ctx.request_repaint();
        }
    }

}
fn reduced(_: &egui::Context)->bool{false}
}
pub fn probe(){
 let ctx=crate::egui::Context;
 let mut tab=RepoTab{refs:Refs{head:"old-ui-head".into(),..Default::default()},history:Vec::new(),reads:0,celebration:Default::default()};
 // A preceding operation has already created this merge, but its reload is delayed.
 let actual_before="already-merged";
 let actual_after="already-merged";
 tab.celebration_begin("Pull",&[vec!["pull".into(),"--no-rebase".into()]],&ctx);
 tab.celebration_observed_head(actual_after.into());
 tab.celebration_done(true);
 tab.refs.head=actual_after.into();
 tab.history=vec![Commit{hash:actual_after.into(),parents:vec!["old-ui-head".into(),"topic".into()]}];
 tab.celebration_loaded(1,&ctx);
 println!("actual_before={actual_before} actual_after={actual_after} ui_before=old-ui-head no_op=true celebration_cues={}",crate::CUES.load(std::sync::atomic::Ordering::Relaxed));
 assert_eq!(actual_before,actual_after);assert_eq!(crate::CUES.load(std::sync::atomic::Ordering::Relaxed),1);
}}
fn main(){repo::probe();}
