#![allow(dead_code)]
use std::{sync::{Arc,Mutex},collections::BTreeMap,time::Duration};
use egui::{ViewportId,Pos2,Rect};
mod eframe {pub struct Frame;}
mod reducer {
 use super::*;
 struct Windows {current:ViewportId,parked:BTreeMap<ViewportId,()>,quit_requested:bool,root_hidden:bool}
 struct App {windows:Windows}
 impl App {
 fn window_has_dialog(&self)->bool{false}
 fn tick_model(&mut self,ctx:&egui::Context,_:Option<&eframe::Frame>){self.close_root_with_children(ctx);}
 include!("close_policy.rs");
 }
 struct Desktop {app:Arc<Mutex<App>>}
 impl Desktop {include!("desktop_logic.rs");}
 pub fn check(){
  let ctx=egui::Context::default();let owner=Arc::new(Mutex::new(App{windows:Windows{current:ViewportId::ROOT,parked:BTreeMap::from([(ViewportId::from_hash_of("live-child"),())]),quit_requested:false,root_hidden:false}}));let mut desktop=Desktop{app:owner.clone()};let mut raw=egui::RawInput::default();let info=raw.viewports.entry(ViewportId::ROOT).or_default();info.minimized=Some(true);info.events.push(egui::ViewportEvent::Close);let mut frame=eframe::Frame;
  let out=ctx.run_logic(&raw,|ctx|desktop.logic(ctx,&mut frame));assert!(out.viewport_commands[&ViewportId::ROOT].contains(&egui::ViewportCommand::CancelClose));println!("PASS exact Desktop logic + close reducer cancels hidden-root Close when coordinator is available.");
  let held=owner.lock().unwrap();let out=ctx.run_logic(&raw,|ctx|desktop.logic(ctx,&mut frame));assert!(!out.viewport_commands.get(&ViewportId::ROOT).is_some_and(|v|v.contains(&egui::ViewportCommand::CancelClose)));drop(held);println!("CONFIRMED TEAR-R1-1 remains: exact Desktop logic emits no CancelClose while coordinator is held; eframe accepts this Close.");
  owner.lock().unwrap().windows.quit_requested=true;let out=ctx.run_logic(&raw,|ctx|desktop.logic(ctx,&mut frame));assert!(!out.viewport_commands.get(&ViewportId::ROOT).is_some_and(|v|v.contains(&egui::ViewportCommand::CancelClose)));println!("PASS explicit Quit is not cancelled on available-owner path.");
 }
}
include!("bounded_size.rs");
include!("drop_target.rs");
fn main(){
 reducer::check();
 let source=ViewportId::ROOT;let target=ViewportId::from_hash_of("2x");let local=Rect::from_min_size(Pos2::ZERO,egui::vec2(400.,20.));let origin=egui::pos2(800.,50.);let physical=local.translate(origin.to_vec2())*2.;let strips=BTreeMap::from([(target,physical)]);assert_eq!(drop_target(source,egui::pos2(1700.,120.),&strips),Some(target));assert_eq!(drop_target(target,egui::pos2(1700.,120.),&strips),None);assert_eq!(bounded_size(egui::vec2(5000.,4000.),Some(egui::vec2(1280.,720.))),egui::vec2(1216.,656.));assert_eq!(bounded_size(egui::vec2(f32::NAN,0.),Some(egui::vec2(640.,480.))),egui::vec2(576.,416.));println!("PASS exact drop_target and bounded_size functions: common physical-coordinate hit, source exclusion, finite/NaN bounds.");
}
