    pub(super) fn close_root_with_children(&mut self, ctx: &egui::Context) {
        if !self.windows.quit_requested
            && self.windows.current == ViewportId::ROOT
            && (!self.windows.parked.is_empty() || self.window_has_dialog())
            && ctx.input(|i| i.viewport().close_requested())
        {
            ctx.send_viewport_cmd(egui::ViewportCommand::CancelClose);
            if !self.window_has_dialog() {
                ctx.send_viewport_cmd(egui::ViewportCommand::Visible(false));
                self.windows.root_hidden = true;
            }
        }
    }
