#![allow(dead_code)]
mod queue {
use std::{collections::VecDeque,path::{Path,PathBuf}};
#[derive(Default)]
pub(super) struct PatchQueue {
    waiting: VecDeque<(PathBuf, PathBuf)>,
    current: Option<(PathBuf, PathBuf)>,
}
trait PatchTargets {
    fn busy(&mut self, repo: &Path) -> Option<bool>;
    fn outcome(&mut self, repo: &Path) -> Option<Result<(), String>>;
    fn apply(&mut self, repo: &Path, file: &Path) -> Result<(), String>;
}
impl PatchQueue{
    pub(super) fn push(&mut self, file: PathBuf, repo: PathBuf) {
        self.waiting.push_back((file, repo));
    }
    pub(super) fn is_empty(&self) -> bool {
        self.waiting.is_empty() && self.current.is_none()
    }
    fn advance_with(&mut self, targets: &mut impl PatchTargets) -> Vec<String> {
        let mut said = Vec::new();
        loop {
            if let Some((file, repo)) = self.current.clone() {
                let Some(busy) = targets.busy(&repo) else {
                    self.current = None;
                    said.push(closed(&file));
                    continue;
                };
                match targets.outcome(&repo) {
                    None if busy => return said,
                    None | Some(Ok(())) => self.current = None,
                    Some(Err(e)) => {
                        self.current = None;
                        said.push(self.failed(&file, &repo, &e));
                    }
                }
            }
            let Some((file, repo)) = self.waiting.pop_front() else {
                return said;
            };
            let Some(busy) = targets.busy(&repo) else {
                said.push(closed(&file));
                continue;
            };
            if busy {
                self.waiting.push_front((file, repo));
                return said;
            }
            match targets.apply(&repo, &file) {
                Ok(()) => self.current = Some((file, repo)),
                Err(e) => said.push(format!("{} wasn't applied: {e}", name_of(&file))),
            }
        }
    }
    fn failed(&mut self, file: &Path, repo: &Path, err: &str) -> String {
        let before = self.waiting.len();
        self.waiting.retain(|(_, r)| r != repo);
        let left = before - self.waiting.len();
        let mut said = format!("{} failed: {err}", name_of(file));
        if left > 0 {
            said.push_str(&format!(
                " (so the {left} {} dropped after it {} not applied)",
                if left == 1 { "patch" } else { "patches" },
                if left == 1 { "was" } else { "were" }
            ));
        }
        said
    }
}
fn closed(file: &Path) -> String {
    format!(
        "{} wasn't applied: its repository's tab was closed",
        name_of(file)
    )
}
fn name_of(path: &Path) -> String {
    path.file_name()
        .map(|n| n.to_string_lossy().into_owned())
        .unwrap_or_else(|| path.display().to_string())
}
struct Recorded {busy:bool,owner:u8,outcomes:VecDeque<Result<(),String>>,calls:Vec<(PathBuf,PathBuf,u8)>,consumed:usize}
impl PatchTargets for Recorded {
 fn busy(&mut self,_:&Path)->Option<bool>{Some(self.busy)}
 fn outcome(&mut self,_:&Path)->Option<Result<(),String>>{let x=self.outcomes.pop_front();if x.is_some(){self.consumed+=1;self.busy=false;}x}
 fn apply(&mut self,r:&Path,f:&Path)->Result<(),String>{self.calls.push((r.into(),f.into(),self.owner));self.busy=true;Ok(())}
}
pub fn check(){
 let r=PathBuf::from("/recorded/live");let mut q=PatchQueue::default();q.push("one.patch".into(),r.clone());q.push("two.patch".into(),r.clone());let mut t=Recorded{busy:true,owner:1,outcomes:VecDeque::new(),calls:vec![],consumed:0};assert!(q.advance_with(&mut t).is_empty());assert!(t.calls.is_empty());t.busy=false;assert!(q.advance_with(&mut t).is_empty());assert_eq!(t.calls.len(),1);t.owner=2;t.outcomes.push_back(Ok(()));assert!(q.advance_with(&mut t).is_empty());assert_eq!(t.calls.len(),2);assert_eq!(t.calls[1].2,2);assert_eq!(t.consumed,1);assert!(q.advance_with(&mut t).is_empty());assert_eq!(t.calls.len(),2);t.outcomes.push_back(Ok(()));assert!(q.advance_with(&mut t).is_empty());assert!(q.is_empty());assert_eq!(t.consumed,2);println!("PASS exact PatchQueue recording adapter: busy wait, two completions consumed once, next patch follows moved session.");
 let mut q=PatchQueue::default();q.push("failing.patch".into(),r.clone());q.push("same-session.patch".into(),r.clone());q.push("other-session.patch".into(),"/recorded/other".into());let mut t=Recorded{busy:false,owner:1,outcomes:VecDeque::new(),calls:vec![],consumed:0};assert!(q.advance_with(&mut t).is_empty());t.outcomes.push_back(Err("recorded failure".into()));let said=q.advance_with(&mut t);assert_eq!(said.len(),1);assert!(said[0].contains("so the 1 patch"));assert_eq!(t.calls.len(),2);assert_eq!(t.calls[1].0,PathBuf::from("/recorded/other"));println!("PASS exact PatchQueue error path leaves out failed-session successors while preserving other-session queued work.");
}
}
fn main(){queue::check();}
