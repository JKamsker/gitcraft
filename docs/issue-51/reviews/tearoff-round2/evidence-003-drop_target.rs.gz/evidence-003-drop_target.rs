fn drop_target(
    source: ViewportId,
    point: Pos2,
    strips: &BTreeMap<ViewportId, Rect>,
) -> Option<ViewportId> {
    strips
        .iter()
        .find(|(id, rect)| **id != source && rect.contains(point))
        .map(|(&id, _)| id)
}
