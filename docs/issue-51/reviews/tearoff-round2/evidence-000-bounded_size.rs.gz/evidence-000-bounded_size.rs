fn bounded_size(size: egui::Vec2, monitor: Option<egui::Vec2>) -> egui::Vec2 {
    let limit = monitor
        .filter(|s| s.is_finite() && s.x > 128.0 && s.y > 128.0)
        .map(|s| s - egui::vec2(64.0, 64.0))
        .unwrap_or(egui::vec2(1920.0, 1080.0));
    let minimum = egui::vec2(360.0, 240.0).min(limit);
    if size.is_finite() {
        size.clamp(minimum, limit)
    } else {
        egui::vec2(1200.0, 800.0).clamp(minimum, limit)
    }
}
