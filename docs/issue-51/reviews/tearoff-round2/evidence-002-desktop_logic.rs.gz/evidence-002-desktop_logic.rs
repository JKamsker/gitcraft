    fn logic(&mut self, ctx: &egui::Context, frame: &mut eframe::Frame) {
        if let Ok(mut app) = self.app.try_lock() {
            app.tick_model(ctx, Some(frame));
        } else {
            ctx.request_repaint_after(Duration::from_millis(50));
        }
    }
