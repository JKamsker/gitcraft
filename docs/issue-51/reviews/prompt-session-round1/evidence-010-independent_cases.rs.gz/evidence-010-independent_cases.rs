use super::*;
#[test]
fn exact_checkpoint_ref_predicate_misses_normal_entire_hook_publication() {
 let refs=format!("refs/heads/entire/checkpoints/v1\0{}\n","b".repeat(40));
 assert!(!checkpoint_publication("refs/heads/main","refs/heads/main",&"a".repeat(40),&"a".repeat(40),&refs));
 println!("regular code push has no warning even with a local checkpoint ref; hook behavior reviewed statically");
}
#[test]
fn compact_codex_apply_patch_is_displayed_without_hunk_path_or_ranges() {
 let raw=br#"{"v":1,"agent":"codex","cli_version":"0.42.0","type":"user","ts":"2026-11-08T00:00:00Z","content":"fix file"}
{"v":1,"agent":"codex","cli_version":"0.42.0","type":"assistant","ts":"2026-11-08T00:00:01Z","content":[{"type":"tool_use","name":"apply_patch","input":{"patch":"*** Begin Patch\n*** Update File: file\n@@\n-old\n+new\n*** End Patch"}}]}
"#;
 let (steps,notices)=parse::checkpoint_transcript(raw,Path::new("/synthetic/root"),0);
 assert_eq!(steps.len(),2);assert!(notices.is_empty());
 assert_eq!(steps[1].kind,"Tool");assert_eq!(steps[1].path,None);assert!(!steps[1].exact);
 assert!(steps.iter().all(|s|s.at.is_none()));
 println!("compact Codex: prompt + bare tool name, no edit/path/time despite stored patch");
}
#[test]
fn compact_claude_absolute_path_from_other_worktree_has_no_hunk_path() {
 let raw=br#"{"v":1,"agent":"claude-code","cli_version":"0.42.0","type":"assistant","ts":"2026-11-08T00:00:01Z","content":[{"type":"tool_use","name":"Edit","input":{"file_path":"/recorded/worktree/file","old_string":"old","new_string":"new"}}]}"#;
 let (s,_)=parse::checkpoint_transcript(raw,Path::new("/current/worktree"),0);
 assert_eq!(s.len(),1);assert_eq!(s[0].path,None);assert!(s[0].exact);
 println!("compact Claude from recorded worktree: edit bytes retained but no relative file path");
}
#[test]
fn codex_delete_patch_call_is_dropped_entirely() {
 let raw=br#"{"type":"session_meta","timestamp":"2026-11-08T00:00:00Z","payload":{"cwd":"/synthetic/root"}}
{"type":"response_item","timestamp":"2026-11-08T00:00:01Z","payload":{"type":"custom_tool_call","name":"apply_patch","input":"*** Begin Patch\n*** Delete File: file\n*** End Patch"}}
"#;
 let (s,n)=parse::checkpoint_transcript(raw,Path::new("/synthetic/root"),0);
 assert!(s.is_empty());assert!(n.is_empty());
 println!("valid Codex Delete File tool invocation disappears with no notice");
}
#[test]
fn final_paragraph_with_prose_is_incorrectly_accepted_as_exact_trailer() {
 assert_eq!(entire::trailers("subject\n\nOrdinary prose here\nEntire-Checkpoint: abc123def456"),["abc123def456"]);
 println!("prose final paragraph accepted as an exact checkpoint trailer");
}
#[test]
fn changed_span_includes_unchanged_interior_lines() {
 let old="old-first\nkeep1\nkeep2\nkeep3\nkeep4\nkeep5\nkeep6\nkeep7\nkeep8\nold-last\n";
 let new=old.replace("old-first","new-first").replace("old-last","new-last");
 let ranges=changed_matches(old,old,&new,true);
 assert_eq!(ranges,[Span{start:1,end:10,old:true}]);
 println!("before-side range attributes unchanged interior lines 2..9 to the edit");
}

#[test]
fn compact_user_text_blocks_without_type_are_silently_lost() {
 let raw=br#"{"v":1,"agent":"claude-code","cli_version":"0.42.0","type":"user","ts":"2026-11-08T00:00:00Z","content":[{"id":"u1","text":"fix file"}]}"#;
 let (s,n)=parse::checkpoint_transcript(raw,Path::new("/synthetic/root"),0);
 assert!(s.is_empty());assert!(n.is_empty());
 println!("documented compact user text block has no type field: prompt disappears");
}
#[test]
fn unchanged_interior_yields_candidate_for_another_steps_separate_hunk() {
 let old=format!("old-first\n{}old-last\n",(1..=38).map(|i|format!("keep{i}\n")).collect::<String>());
 let tool_after=old.replace("old-first","new-first").replace("old-last","new-last");
 let mut a=Step::new("Tool","Edit endpoints only".into(),None);
 a.path=Some("file".into());a.exact=true;
 a.ranges=changed_matches(&old,&old,&tool_after,true);
 let mut e=Evidence::default();e.sessions.push(Session{source:"synthetic".into(),relation:"candidate".into(),steps:vec![a]});
 assert_eq!(hunk_steps(&e,"file",(20,20),true),[(0,0)]);
 println!("endpoint-only edit is returned for a separate parent-line-20 hunk it did not change");
}
