// Package transcript converts native agent transcripts into the Entire Transcript
// Format (also called compact or unified transcripts), decodes that format
// into typed lines (Decode, Parse), and folds transcript records into it
// (Fold, Folder). The format is specified in README.md. This
// API is versioned with the CLI and may change; consumers should pin a version.
package transcript

import (
	"bytes"
	"encoding/json"
	"fmt"
	"strings"
)

// Options provides metadata fields written to every output line, and picks
// the conversion where the transcript's format alone does not.
type Options struct {
	// Agent is written to every line, e.g. "claude-code". Claude Code and
	// Cursor share a JSONL line format, so for that format Agent also selects
	// the accounting: "claude-code" emits per-call usage (model, fresh input,
	// cache and output tokens), and any other value converts as Cursor, with
	// legacy per-message input and output counts.
	Agent      string
	CLIVersion string // e.g. "0.42.0"
	StartLine  int    // checkpoint_transcript_start (0 = no truncation)
}

// transcriptLine is the uniform output format for every line in transcript.jsonl.
// Field order is guaranteed by encoding/json (struct declaration order).
type transcriptLine struct {
	V                int             `json:"v"`
	Agent            string          `json:"agent"`
	CLIVersion       string          `json:"cli_version"`
	Type             string          `json:"type"`
	TS               json.RawMessage `json:"ts,omitempty"`
	ID               string          `json:"id,omitempty"`
	Model            string          `json:"model,omitempty"`
	InputTokens      int64           `json:"input_tokens,omitempty"`
	OutputTokens     int64           `json:"output_tokens,omitempty"`
	CacheReadTokens  int64           `json:"cache_read_tokens,omitempty"`
	CacheWriteTokens int64           `json:"cache_write_tokens,omitempty"`
	// Pointers preserve reported zero splits; nil means the split is unknown.
	CacheWrite5mTokens *int64          `json:"cache_write_5m_tokens,omitempty"`
	CacheWrite1hTokens *int64          `json:"cache_write_1h_tokens,omitempty"`
	ReasoningTokens    int64           `json:"reasoning_tokens,omitempty"`
	Content            json.RawMessage `json:"content"`
}

// newTranscriptLine returns a transcriptLine pre-filled with the shared
// metadata fields that are identical on every output line.
func newTranscriptLine(opts Options) transcriptLine {
	return transcriptLine{
		V:          1,
		Agent:      opts.Agent,
		CLIVersion: opts.CLIVersion,
	}
}

// applyCallUsage sets the per-call model and usage fields of an assistant line
// from u.
func applyCallUsage(line *transcriptLine, u *CallUsage) {
	line.Model = u.Model
	line.InputTokens = u.InputTokens
	line.OutputTokens = u.OutputTokens
	line.CacheReadTokens = u.CacheReadTokens
	line.CacheWriteTokens = u.CacheWriteTokens
	line.CacheWrite5mTokens = u.CacheWrite5mTokens
	line.CacheWrite1hTokens = u.CacheWrite1hTokens
	line.ReasoningTokens = u.ReasoningTokens
}

// userTextBlock is a text block within user message content.
type userTextBlock struct {
	ID   string `json:"id,omitempty"`
	Text string `json:"text"`
}

// Convert converts a full.jsonl transcript into the condensed transcript.jsonl format.
// The output format puts version, agent, and cli_version on every line,
// merges streaming assistant fragments with the same message ID, and inlines
// tool results into the preceding assistant's tool_use blocks:
//
//	{"v":1,"agent":"claude-code","cli_version":"0.42.0","type":"user","ts":"...","content":"..."}
//	{"v":1,"agent":"claude-code","cli_version":"0.42.0","type":"assistant","ts":"...","id":"msg_xxx","content":[{"type":"text","text":"..."},{"type":"tool_use","id":"...","name":"...","input":{...},"result":{"output":"...","status":"..."}}]}
func Convert(content []byte, opts Options) ([]byte, error) {
	// Formats that need detection on raw content before line truncation:
	// - Single-object formats (OpenCode, Gemini): SliceFromLine would cut
	//   a JSON object mid-value. They handle StartLine as a message-index offset.
	// - Codex: session_meta header is only on the first line, and the choice
	//   between its item and response_item paths is made on the whole
	//   rollout. Codex slices by physical line itself, after seeding its usage
	//   baseline from the skipped lines.
	if isOpenCodeFormat(content) {
		return compactOpenCode(content, opts)
	}

	if isGeminiFormat(content) {
		return compactGemini(content, opts)
	}

	// pi: detect on the raw header line. compactPi handles StartLine itself.
	if isPiFormat(content) {
		return compactPi(content, opts)
	}

	if isCodexFormat(content) {
		return compactCodex(content, opts)
	}

	truncated := SliceFromLine(content, opts.StartLine)
	if truncated == nil {
		truncated = []byte{}
	}

	if isCopilotFormat(truncated) {
		return compactCopilot(truncated, opts)
	}

	if isDroidFormat(truncated) {
		return compactDroid(truncated, opts)
	}

	return compactJSONL(truncated, opts)
}

// ConvertWithBoundary compacts the entire transcript — ignoring opts.StartLine for
// the purpose of truncation — and returns the full compact bytes together with
// the boundary: the line index in the compact output at which this checkpoint's
// data (the content from opts.StartLine onward in the raw transcript) begins.
//
// Storing the full compact transcript on every checkpoint makes each checkpoint
// self-contained: the session is reconstructable from any single surviving
// checkpoint, and downstream readers segment this checkpoint's slice as
// fullCompactLines[boundary:]. boundary is 0 when StartLine <= 0 (the first
// checkpoint of a session, whose data starts at the beginning).
//
// boundary is derived as lineCount(full) - lineCount(delta), where delta is the
// existing per-checkpoint sliced compaction (Convert with the original
// StartLine). This reuses each format's existing, independently-tested slicing
// behavior (line offsets for JSONL/Copilot/Droid/pi/Codex, message-index for
// OpenCode/Gemini) rather than threading source indices through every emitter.
//
// A single compact line can carry content from both sides of StartLine when its
// source straddles the boundary — most notably same-ID streaming assistant
// fragments, which compaction merges into one line. No integer line offset can
// split within a line, so the boundary rounds toward inclusion: such a merged
// line is counted as part of this checkpoint's slice. fullCompactLines[boundary:]
// therefore never drops this checkpoint's content, but its first line may repeat
// up to one merged line that began in the previous checkpoint. Downstream
// segmenters must tolerate this bounded head overlap. See the straddle case in
// TestFullWithBoundary_StraddlingAssistantFragments_RoundsToInclusion.
//
// Likewise, a tool result can arrive after StartLine for a call made before
// it, even after a later prompt. The full conversion inlines it into that
// earlier line, which is before the boundary; the delta, which lacks the
// call, drops it.
func ConvertWithBoundary(content []byte, opts Options) (full []byte, boundary int, err error) {
	fullOpts := opts
	fullOpts.StartLine = 0
	full, err = Convert(content, fullOpts)
	if err != nil {
		return nil, 0, err
	}
	if opts.StartLine <= 0 {
		return full, 0, nil
	}

	delta, err := Convert(content, opts)
	if err != nil {
		return nil, 0, err
	}

	boundary = countCompactLines(full) - countCompactLines(delta)
	if boundary < 0 {
		boundary = 0
	}
	return full, boundary, nil
}

// countCompactLines counts newline-terminated lines in compact output. The exact
// convention does not matter for CompactFull as long as it is applied uniformly
// to both the full and delta outputs (the boundary is their difference).
func countCompactLines(b []byte) int {
	return bytes.Count(b, []byte{'\n'})
}

// droppedTypes are JSONL entry types that carry no parser-relevant data.
var droppedTypes = map[string]bool{
	"progress":              true,
	"file-history-snapshot": true,
	"queue-operation":       true,
	"system":                true,
}

// userAliases maps JSONL type/role values to the canonical "user" kind.
// Covers Claude Code ("user", "human") and Cursor ("user" via "role" field).
var userAliases = map[string]bool{
	TypeUser: true,
	"human":  true,
}

// normalizeKind returns the canonical entry kind ("user" or "assistant") for a
// JSONL transcript line. It checks the "type" field, then falls back to "role".
// Returns "" for unrecognised or dropped entries.
func normalizeKind(raw map[string]json.RawMessage) string {
	kind := unquote(raw["type"])
	if kind == "" {
		kind = unquote(raw["role"])
	}

	if droppedTypes[kind] {
		return ""
	}
	if userAliases[kind] {
		return TypeUser
	}
	if kind == TypeAssistant {
		return TypeAssistant
	}
	return ""
}

// linePreprocessor transforms a parsed JSONL line before conversion.
type linePreprocessor func(map[string]json.RawMessage) map[string]json.RawMessage

// parsedEntry is an intermediate representation of a JSONL line, consumed by
// JSONLAdapter.
type parsedEntry struct {
	kind         string // "user" or "assistant"
	ts           json.RawMessage
	id           string            // message ID (assistant only)
	userID       string            // prompt ID (user only, e.g. Claude's promptId)
	inputTokens  int               // API input tokens (assistant only)
	outputTokens int               // API output tokens (assistant only)
	model        string            // message model (assistant only)
	usage        *CallUsage        // per-call usage, nil when absent or malformed (assistant only)
	content      json.RawMessage   // stripped assistant content array, or nil
	toolUseIDs   []string          // IDs of the tool_use blocks in content
	userText     string            // extracted user text
	userImages   []json.RawMessage // image blocks from user messages
	toolResults  []toolResultEntry // user tool_result entries
}

// compactJSONL converts JSONL transcripts (Claude Code, Cursor) into the
// transcript.jsonl format.
// Claude Code and Cursor share a line format, so opts.Agent picks the adapter.
func compactJSONL(content []byte, opts Options) ([]byte, error) {
	a := NewCursorAdapter()
	if opts.Agent == agentClaudeCode {
		a = NewClaudeAdapter()
	}
	return foldJSONL(content, opts, a)
}

// foldJSONL runs a over the whole transcript and folds the records. Taking the
// adapter from the exported constructors keeps checkpoints and live streams on
// one adapter and one fold.
func foldJSONL(content []byte, opts Options, a *JSONLAdapter) ([]byte, error) {
	records := a.Feed(content)
	records = append(records, a.Flush()...)
	out, err := Fold(records, opts)
	if err != nil {
		return nil, fmt.Errorf("folding transcript records: %w", err)
	}
	return out, nil
}

// userContentBlocks builds a user line's content: a text block carrying the
// prompt ID (kept even when empty if there are no images), then the images
// verbatim.
func userContentBlocks(e parsedEntry) (json.RawMessage, error) {
	var blocks []json.RawMessage
	if e.userText != "" || len(e.userImages) == 0 {
		b, err := json.Marshal(userTextBlock{ID: e.userID, Text: e.userText})
		if err != nil {
			return nil, fmt.Errorf("marshaling user text block: %w", err)
		}
		blocks = append(blocks, b)
	}
	blocks = append(blocks, e.userImages...)

	contentJSON, err := json.Marshal(blocks)
	if err != nil {
		return nil, fmt.Errorf("marshaling user content: %w", err)
	}
	return contentJSON, nil
}

// appendLine marshals a transcriptLine and appends it (with newline) to result.
func appendLine(result *[]byte, line transcriptLine) {
	b, err := json.Marshal(line)
	if err != nil {
		return
	}
	*result = append(*result, b...)
	*result = append(*result, '\n')
}

// parseLine converts a single JSONL line into a parsedEntry.
// Returns ok=false for dropped/malformed lines.
func parseLine(lineBytes []byte, preprocess linePreprocessor) (parsedEntry, bool) {
	var raw map[string]json.RawMessage
	if err := json.Unmarshal(lineBytes, &raw); err != nil {
		return parsedEntry{}, false
	}

	if preprocess != nil {
		raw = preprocess(raw)
	}

	kind := normalizeKind(raw)
	if kind == "" {
		return parsedEntry{}, false
	}

	e := parsedEntry{
		kind: kind,
		ts:   raw["timestamp"],
	}

	msg := parseMessage(raw)

	switch kind {
	case TypeAssistant:
		if msg != nil {
			e.id = unquote(msg["id"])
			if contentRaw, ok := msg["content"]; ok {
				e.content, e.toolUseIDs = stripAssistantContent(contentRaw)
			}
			e.inputTokens, e.outputTokens = extractUsageTokens(msg)
			e.model = unquote(msg["model"])
			e.usage = extractCallUsage(msg)
		}

	case TypeUser:
		e.userID = unquote(raw["promptId"])
		if msg != nil {
			if contentRaw, ok := msg["content"]; ok {
				uc := extractUserContent(contentRaw)
				e.userText = uc.text
				e.userImages = uc.images
				e.toolResults = uc.toolResults
			}
		}
		// Enrich tool results with metadata from toolUseResult.
		if turRaw, ok := raw["toolUseResult"]; ok {
			var tur map[string]json.RawMessage
			if json.Unmarshal(turRaw, &tur) == nil {
				e.toolResults = enrichToolResults(e.toolResults, tur)
			}
		}
	}

	return e, true
}

// mergeAssistantEntries combines two assistant entries with the same message ID.
// Content arrays are concatenated; the later timestamp and token counts win
// (streaming fragments report cumulative usage, so the last fragment is final).
func mergeAssistantEntries(a, b parsedEntry) parsedEntry {
	merged := a
	merged.ts = b.ts
	if b.inputTokens > 0 {
		merged.inputTokens = b.inputTokens
	}
	if b.outputTokens > 0 {
		merged.outputTokens = b.outputTokens
	}

	var aBlocks, bBlocks []json.RawMessage
	_ = json.Unmarshal(a.content, &aBlocks) //nolint:errcheck // best-effort merge
	_ = json.Unmarshal(b.content, &bBlocks) //nolint:errcheck // best-effort merge
	all := append(aBlocks, bBlocks...)      //nolint:gocritic // intentional append to new slice
	if data, err := json.Marshal(all); err == nil {
		merged.content = data
	}

	return merged
}

// buildToolResult constructs the compact result object for a tool_use block,
// including optional rich metadata (file, matchCount) when available.
func buildToolResult(tr toolResultEntry) json.RawMessage {
	b, err := json.Marshal(toolResult(tr))
	if err != nil {
		return nil
	}
	return b
}

// toolResult converts a parsed tool result into the compact result shape.
func toolResult(tr toolResultEntry) *ToolResult {
	r := &ToolResult{
		Output:     tr.output,
		Status:     ToolStatusSuccess,
		MatchCount: tr.matchCount,
	}
	if tr.isError {
		r.Status = ToolStatusError
	}
	if tr.file != nil {
		r.File = &ToolResultFile{
			FilePath: tr.file.filePath,
			NumLines: tr.file.numLines,
		}
	}
	if tr.agentID != "" {
		r.Agent = &ToolResultAgent{ID: tr.agentID}
	}
	return r
}

// extractUsageTokens extracts input_tokens and output_tokens from a Claude
// message's "usage" object. Returns (0, 0) if usage is absent or malformed.
func extractUsageTokens(msg map[string]json.RawMessage) (inputTokens, outputTokens int) {
	usageRaw, ok := msg["usage"]
	if !ok {
		return 0, 0
	}
	var usage struct {
		InputTokens  int `json:"input_tokens"`
		OutputTokens int `json:"output_tokens"`
	}
	if json.Unmarshal(usageRaw, &usage) != nil {
		return 0, 0
	}
	return usage.InputTokens, usage.OutputTokens
}

// extractCallUsage parses a Claude message's whole "usage" object. It returns
// nil if usage is absent or malformed. The cache-write split is kept only when
// both durations are reported.
func extractCallUsage(msg map[string]json.RawMessage) *CallUsage {
	usageRaw, ok := msg["usage"]
	if !ok || string(bytes.TrimSpace(usageRaw)) == "null" {
		return nil
	}
	var usage struct {
		Input         int64 `json:"input_tokens"`
		CacheRead     int64 `json:"cache_read_input_tokens"`
		CacheWrite    int64 `json:"cache_creation_input_tokens"`
		Output        int64 `json:"output_tokens"`
		CacheCreation *struct {
			FiveMinutes *int64 `json:"ephemeral_5m_input_tokens"`
			OneHour     *int64 `json:"ephemeral_1h_input_tokens"`
		} `json:"cache_creation"`
	}
	if json.Unmarshal(usageRaw, &usage) != nil {
		return nil
	}
	u := &CallUsage{
		InputTokens:      usage.Input,
		OutputTokens:     usage.Output,
		CacheReadTokens:  usage.CacheRead,
		CacheWriteTokens: usage.CacheWrite,
	}
	if c := usage.CacheCreation; c != nil && c.FiveMinutes != nil && c.OneHour != nil {
		u.CacheWrite5mTokens, u.CacheWrite1hTokens = c.FiveMinutes, c.OneHour
	}
	return u
}

// isEmptyContentArray returns true if raw is a JSON empty array (`[]`).
func isEmptyContentArray(raw json.RawMessage) bool {
	var arr []json.RawMessage
	return json.Unmarshal(raw, &arr) == nil && len(arr) == 0
}

func hasToolResults(e parsedEntry) bool {
	return len(e.toolResults) > 0
}

type toolResultEntry struct {
	toolUseID string
	output    string
	isError   bool
	// Rich metadata extracted from toolUseResult (optional).
	file       *toolResultFile // Read/Edit: file path and line count
	matchCount int             // Grep: number of matching files
	agentID    string          // the subagent the call launched
}

// toolResultFile carries structured file metadata from Read/Edit tool results.
type toolResultFile struct {
	filePath string
	numLines int // 0 if not available (e.g. Edit results)
}

// enrichToolResults extracts structured metadata from a toolUseResult envelope
// and attaches it to the corresponding tool result entries.
//
// Claude Code's toolUseResult has different shapes per tool:
//   - Bash:  {stdout, stderr, interrupted, ...}
//   - Read:  {type:"text", file:{filePath, numLines, content, ...}}
//   - Grep:  {numFiles, numLines, filenames, content, mode}
//   - Edit:  {filePath, oldString, newString, structuredPatch, ...}
//   - Agent, and Skill when forked: {agentId, status, ...}
func enrichToolResults(results []toolResultEntry, tur map[string]json.RawMessage) []toolResultEntry {
	// Bash-style: stdout provides the output text.
	if stdout := unquote(tur["stdout"]); stdout != "" {
		switch len(results) {
		case 0:
			// Keep compatibility with transcripts that only include toolUseResult.
			results = append(results, toolResultEntry{output: stdout})
		case 1:
			results[0].output = stdout
		}
	}

	// Read-style: file object with filePath and numLines.
	if fileRaw, ok := tur["file"]; ok {
		var file struct {
			FilePath string `json:"filePath"`
			NumLines int    `json:"numLines"`
		}
		if json.Unmarshal(fileRaw, &file) == nil && file.FilePath != "" {
			applyToSingleResult(results, func(tr *toolResultEntry) {
				tr.file = &toolResultFile{filePath: file.FilePath, numLines: file.NumLines}
			})
		}
	}

	// Edit-style: top-level filePath.
	if filePath := unquote(tur["filePath"]); filePath != "" {
		applyToSingleResult(results, func(tr *toolResultEntry) {
			// Edit results don't have numLines.
			tr.file = &toolResultFile{filePath: filePath}
		})
	}

	// Agent-style: the launched subagent's ID.
	if agentID := unquote(tur["agentId"]); agentID != "" {
		applyToSingleResult(results, func(tr *toolResultEntry) {
			tr.agentID = agentID
		})
	}

	// Grep-style: numFiles as match count.
	if numFilesRaw, ok := tur["numFiles"]; ok {
		var n int
		if json.Unmarshal(numFilesRaw, &n) == nil && n > 0 {
			applyToSingleResult(results, func(tr *toolResultEntry) {
				tr.matchCount = n
			})
		}
	}

	return results
}

// applyToSingleResult applies fn to the first (and expected only) tool result.
// toolUseResult is a single-tool envelope, so this is only meaningful when
// there's exactly one result entry.
func applyToSingleResult(results []toolResultEntry, fn func(*toolResultEntry)) {
	if len(results) == 1 {
		fn(&results[0])
	}
}

// parseMessage extracts and parses the "message" field from a JSONL transcript
// line. All JSONL agents nest content inside a "message" object.
func parseMessage(raw map[string]json.RawMessage) map[string]json.RawMessage {
	msgRaw, ok := raw["message"]
	if !ok {
		return nil
	}
	var msg map[string]json.RawMessage
	if json.Unmarshal(msgRaw, &msg) == nil {
		return msg
	}
	return nil
}

// userContent holds the extracted parts of a user message content array.
type userContent struct {
	text        string
	images      []json.RawMessage
	toolResults []toolResultEntry
}

// extractUserContent separates user message content into text, images, and tool_result entries.
// IDE context tags (e.g. <user_query>, <ide_opened_file>) are stripped from user text.
func extractUserContent(contentRaw json.RawMessage) userContent {
	var str string
	if json.Unmarshal(contentRaw, &str) == nil {
		return userContent{text: StripIDEContextTags(str)}
	}

	var blocks []json.RawMessage
	if json.Unmarshal(contentRaw, &blocks) != nil {
		return userContent{}
	}

	var uc userContent

	for _, blockRaw := range blocks {
		var block map[string]json.RawMessage
		if json.Unmarshal(blockRaw, &block) != nil {
			continue
		}
		blockType := unquote(block["type"])

		switch blockType {
		case "tool_result":
			var isErr bool
			if raw, ok := block["is_error"]; ok {
				_ = json.Unmarshal(raw, &isErr) //nolint:errcheck // best-effort
			}
			uc.toolResults = append(uc.toolResults, toolResultEntry{
				toolUseID: unquote(block["tool_use_id"]),
				output:    unquote(block["content"]),
				isError:   isErr,
			})

		case "image":
			uc.images = append(uc.images, blockRaw)

		case ContentTypeText:
			stripped := StripIDEContextTags(unquote(block[ContentTypeText]))
			if stripped != "" {
				uc.text += stripped + "\n\n"
			}
		}
	}

	uc.text = strings.TrimSpace(uc.text)
	return uc
}

// stripAssistantContent drops thinking blocks and trims tool_use blocks to
// their compact fields. It also returns the tool_use blocks' IDs.
func stripAssistantContent(contentRaw json.RawMessage) (json.RawMessage, []string) {
	var str string
	if json.Unmarshal(contentRaw, &str) == nil {
		return contentRaw, nil
	}

	var blocks []map[string]json.RawMessage
	if json.Unmarshal(contentRaw, &blocks) != nil {
		return contentRaw, nil
	}

	var toolUseIDs []string
	result := make([]map[string]json.RawMessage, 0, len(blocks))
	for _, block := range blocks {
		blockType := unquote(block["type"])

		if blockType == "thinking" || blockType == "redacted_thinking" {
			continue
		}

		if blockType == ContentTypeToolUse {
			if id := unquote(block["id"]); id != "" {
				toolUseIDs = append(toolUseIDs, id)
			}
			stripped := make(map[string]json.RawMessage)
			copyField(stripped, block, "type")
			copyField(stripped, block, "id")
			copyField(stripped, block, "name")
			copyField(stripped, block, "input")
			result = append(result, stripped)
			continue
		}

		result = append(result, block)
	}

	b, err := json.Marshal(result)
	if err != nil {
		return contentRaw, nil
	}
	return b, toolUseIDs
}

// copyField copies a single key from src to dst if it exists.
func copyField(dst, src map[string]json.RawMessage, key string) {
	if v, ok := src[key]; ok {
		dst[key] = v
	}
}

// unquote JSON-decodes a raw message as a string. Returns "" on failure.
func unquote(raw json.RawMessage) string {
	var s string
	if json.Unmarshal(raw, &s) == nil {
		return s
	}
	return ""
}
