#![allow(dead_code)]
mod remote { pub fn is_remote(_: &std::path::Path)->bool {panic!("inert: production load not allowed")} }
mod safe_read {pub fn read_inside(_: &std::path::Path,_: &str,_:u64)->Option<Vec<u8>> {panic!("inert: filesystem adapter not allowed")}}
mod git {
 pub mod investigations {pub fn oid(s:&str)->bool {matches!(s.len(),40|64)&&s.bytes().all(|x|x.is_ascii_hexdigit())}}
 pub fn forecast_bytes(_: &std::path::Path,_:&[&str],_:&[(&'static str,String)],_:&[i32],_:&dyn Fn()->bool)->Result<Vec<u8>,String>{panic!("inert: Git execution forbidden")}
 pub mod prompt_session;
}
