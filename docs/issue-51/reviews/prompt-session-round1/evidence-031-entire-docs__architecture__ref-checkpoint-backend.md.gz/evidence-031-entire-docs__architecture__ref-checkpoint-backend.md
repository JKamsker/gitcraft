# Ref-Based Checkpoint Backend (git-refs)

This document explains the **git-refs** checkpoint backend as a system: how it stores checkpoints, how it pushes and fetches them, how it coexists with the legacy **git-branch** backend, and how it is selected through configuration.

It is the companion to [Sessions and Checkpoints](sessions-and-checkpoints.md), which covers the domain model (sessions, checkpoints, IDs) shared by both backends. Read that first for the checkpoint tree layout, checkpoint-ID linking, and the compact-transcript format; this doc focuses on what is specific to the ref-based store.

## Why a second backend

The original backend stores every committed checkpoint as a subtree of a single long-lived branch, `entire/checkpoints/v1` (the **git-branch** backend). That branch is a serialization point: every condensation rewrites its tip, every push races on one ref, and the whole history travels together.

The **git-refs** backend instead keeps **one git ref per checkpoint**:

```
refs/entire/checkpoints/<shard>/<id>
```

Each ref points at a commit whose **tree root is that checkpoint's contents** (`metadata.json`, `0/`, `1/`, `tasks/…`) — the same subtree the git-branch backend splices *under* `<id[:2]>/<id[2:]>/` in the v1 tree. Independent refs mean checkpoints are written, pushed, and fetched independently: no shared tip to contend on, and a reader can fetch exactly the one checkpoint it needs instead of the whole branch.

Both backends are **git-backed** — they store the committed record in the repo's own object store — and never touch the working branch's history.

## Backend taxonomy: primary and mirrors

Checkpoint storage is pluggable. The topology is a single **primary** plus zero or more **mirrors**:

- **Primary** — the source of truth. It serves all reads and writes, and the full checkpoint lifecycle (resume bootstrap, `doctor` reconcile, `explain` tree reads, push, cleanup) drives *its* record.
- **Mirror** — an independent backend that receives best-effort **write fan-out** only. Reads never come from a mirror.

Backends register in `checkpoint/registry.go`. Each carries a `gitBacked` capability:

| Capability | Meaning | Can be primary? | Can be mirror? |
|------------|---------|-----------------|----------------|
| `gitBacked: true` | Stores the committed record in this repo's git object store | Yes | Yes |
| `gitBacked: false` | Stores elsewhere (e.g. a filesystem store) | No — mirror-only | Yes |

Only a git-backed backend can be the primary, because the lifecycle paths above operate through the repo and its refs; a non-git-backed backend has no such ref to drive them. The two built-in backends — `git-branch` and `git-refs` — are **both** git-backed and are registered directly in the built-in registry map. The `Register()` entry point is for non-git-backed (mirror-only) backends and is used in practice only by test-only backends, so a production binary can never select an unregistered one.

A **one-of-each-type** rule permits two distinct git-backed backends in the same topology. Note, though, that the branch→refs migration deliberately does **not** run `git-branch` as a mirror of `git-refs`. Cross-format compatibility comes from read routing — every reader (CLI, entire.io, entire-api) reads refs first and falls back to the branch — not from dual-writing the same checkpoint into both backends (see [Migration and coexistence](#migration-and-coexistence)). Mirroring stays available as a general mechanism, primarily for non-git-backed targets (e.g. a filesystem store).

## Ref layout and sharding

```
refs/entire/checkpoints/<shard>/<id>
```

- `<id>` is the full checkpoint ID (12-hex or ULID) and is always the leaf, so the ref round-trips: `RefName(id)` builds it and `ParseRef(name)` recovers the ID (`checkpoint/refs_naming.go`).
- `<shard>` is `id.ShardFor()` — the **last two characters** of the ID, for **both** formats.

A single positional rule (independent of ID kind) keeps ref naming impossible to compute inconsistently between callers, and the suffix distributes checkpoints evenly for either format:

- A **legacy hex** ID is random throughout, so its last two chars are as good as any.
- A **ULID**'s leading chars encode a millisecond timestamp (barely varying between nearby checkpoints) while its trailing chars are random — so sharding on the suffix keeps buckets even *and* keeps the ID itself lexicographically time-sortable.

`ParseRef` validates that the shard in a ref name matches the ID's own `ShardFor()` and that the tail is exactly `<shard>/<id>` (no extra path segments), so a malformed or foreign ref is rejected rather than resolved to the wrong bucket. `RefName` errors on an empty or unrecognized ID rather than emitting `refs/entire/checkpoints//`.

> **Note:** this is the git-refs namespace only. The git-branch backend keeps its own independent **first-two-chars** tree layout (`<id[:2]>/<id[2:]>/`) inside the v1 branch. The two sharding schemes are deliberately different and do not interact.

## ID formats

Checkpoint IDs come in two shapes; the store determines which is minted:

- **git-branch primary** → 12-char hex IDs.
- **git-refs primary** → 26-char ULIDs (Crockford base32, lexicographically time-sortable).

IDs are minted by `checkpoint.GenerateCheckpointID`, which picks the format from the configured primary. Never call `id.Generate()` / `id.GenerateULID()` directly from a write path. The full rationale for the two formats, `DisplayShort`, and `id.MaxIDLength` lives in [Sessions and Checkpoints → Checkpoint ID Linking](sessions-and-checkpoints.md#checkpoint-id-linking).

## Write path

The git-refs store (`gitRefsStore`, `checkpoint/refs_store.go`) shares the checkpoint-subtree machinery with the git-branch store via an embedded `*treeWriter`. Both build the exact same checkpoint subtree; they differ only in the **base path** they write it at and in **where the result is committed**. The git-branch store writes each checkpoint under its shard prefix `<id[:2]>/<id[2:]>/` inside the single `v1` tree, so many checkpoints share one tree. The git-refs store writes with **no prefix** (an empty base path), so the checkpoint subtree *is* the root of that checkpoint's own commit tree, and the commit is the tip of a per-checkpoint ref rather than a subtree of the v1 branch.

Every persistent write (`WriteSession`, and the `Backfill*` operations for transcript / summary) follows the same shape:

1. **Resolve the ref's current tip.** Creates (`WriteSession`) use the local-only `refBase`: a missing ref → `(ZeroHash, nil)`, so the first write to a checkpoint becomes an **orphan commit**. The `Backfill*` operations use `refBaseForBackfill`, which first on-demand fetches a locally-missing ref (when a ref fetcher is configured — the checkpoint may have been written or migrated on another machine); a ref still absent after the fetch surfaces as `ErrCheckpointNotFound` rather than orphaning, and a fetch failure surfaces as a real error, never as absence. A real lookup failure (IO/corruption) is surfaced, never silently treated as "new checkpoint".
2. **Build the updated checkpoint subtree** from the existing tree plus the new content (shared `treeWriter` logic).
3. **Create a commit** with the current tip as parent (orphan on first write, parented thereafter), so each checkpoint accretes its **own per-checkpoint history**.
4. **Point the ref at the new commit** (`setRef`) and **enqueue it for push**.

Enqueue is best-effort: a write that lands locally but fails to enqueue must not fail condensation. The ref is still local and correct; only its remote sync is deferred until the next write to the same checkpoint re-enqueues it (see the push queue below).

## Push and fetch

Because reads can *fetch* refs on demand and there is no single branch tip to push, the git-refs backend cannot simply "push everything" at pre-push time. Deleting local refs after pushing would also hurt local workflows. Instead it tracks exactly which checkpoints changed, in a **push-discovery queue**, and pushes those.

### Push-discovery queue

`checkpoint/pushqueue.go` — a flock-protected JSONL file in the git **common dir** (so every worktree sharing the object store enqueues into one queue):

- `entire-checkpoint-push-queue.jsonl`: one `{"ref": …, "hash": …}` record per queued generation of a ref. `hash` is the ref's tip when it was queued. Records written by older versions have no `hash`.
- `entire-checkpoint-push-queue.lock`: the flock.

Semantics:

- **EnqueueRef** reads the ref's current tip and appends `(ref, hash)` under the lock. A ref it cannot resolve is still queued, without a hash, because a ref that misses the queue is never pushed. Enqueuing an already-present or already-pushed ref is safe (reads de-dup, the push is idempotent).
- **Reads keep the latest generation of each ref.** When a ref appears on several lines, the last line's hash wins and the ref keeps its first-seen position. A record whose hash does not parse keeps the ref, without a hash, instead of being dropped.
- **DrainEntries** returns those entries *without* removing them, and compacts the file in place when it held redundant lines (so a long-lived session that keeps re-enqueuing the same ref cannot grow the file unboundedly). **Drain** does the same and returns only the ref names.
- **Peek** reads the queue without compacting it. `entire checkpoint list --outgoing` lists it and `entire status` counts it after dropping refs missing locally, the same split pre-push makes, so both name what the next push sends. For a large queue, that split lists `refs/entire/checkpoints/` once, reading refs through go-git and falling back to `git for-each-ref` when go-git's walk fails (one empty or unreadable loose ref file, or a malformed `packed-refs` line, anywhere under `refs/` aborts it). It looks up separately only the queued refs the listing omits (a broken ref file, a symbolic ref the go-git listing leaves unresolved, or a shard stored in different case), so a failed or partial listing never turns a present ref into a stale one. A short queue is looked up ref by ref, because the listing's cost follows every ref it reads. The outgoing listing and pre-push's check of the user's own push take each waiting ref's commit from the go-git listing when it ran. The `for-each-ref` fallback only decides which refs exist, because git reads a ref file with trailing data as its hash where go-git reads the zero hash, so commits then come from per-ref lookups.
- **RemoveEntries** deletes exact `(ref, hash)` entries, and pre-push calls it only **after a confirmed push**. A newer generation of the same ref, queued while the push ran, survives. An interrupted or failed push therefore leaves its entries queued for the next pre-push, so the queue degrades toward "will retry", never toward silent loss. **Remove** deletes every entry for the given ref names; `entire checkpoint delete` uses it to drop a checkpoint outright.

Rewrites are atomic (temp file + rename under the lock) so a concurrent reader never sees a half-written queue.

### Pre-push flow

`ManualCommitStrategy.PrePush` (`strategy/manual_commit_push.go`) branches on `checkpoint.PrimaryIsRefs(cfg)`. When the primary is git-refs it:

1. **Drains** the queue (`DrainEntries`).
2. **Partitions** the entries by reading each ref's current tip: refs that exist locally are ready to push at that tip, stale ones (the ref is gone) are dropped from the queue, and unreadable ones (any lookup error other than "not found") stay queued while pre-push prints one line saying how many. An upload that names its refs (`entire checkpoint push`) also leaves the others **waiting**, and a named ref pinned to a commit that is no longer its tip **changed**. Waiting and changed refs stay queued and are not failures: they are not retried, rotated, or counted (see the checkpoint push policy below).
3. **Batch-pushes** the ready refs a chunk at a time, one network round-trip per chunk of at most `checkpointRefPushChunkSize` (200) refs, each as the exact `hash:ref` it read (`pushRefChunks` → `batchPushCheckpointRefs`, `strategy/push_common.go`), so the push sends the tip it read even if a session writes the ref meanwhile. Each chunk's entries are **removed** from the queue (`RemoveEntries`) as soon as it lands. A chunk is also one `git push` command line, which Windows caps at 32,767 characters: at ~95 characters per refspec, pushing the whole queue at once failed before git started past ~340 refs, and 200 stays well under it.
4. On a chunk failure (typically a non-fast-forward rejection), carries on with the next chunk, then **falls back to per-ref recovery** (`pushCheckpointRefWithRecovery`) for the failed chunks' refs only, removing from the queue only the entries whose refs land.

Recovery fetches the remote ref, replays the exact commit the push tried to send onto it, and installs the result only if the local ref still points at that commit (compare-and-swap). If a session wrote the ref in the meantime, that write wins: it stays the local ref and stays queued, and a later push delivers it. The flush treats that ref as superseded, not failed, so it does not count toward the consecutive-failure stop or the reported failures.

Confirmed remote policy/hook rejections skip fetch/replay: replay cannot fix a
policy block and would needlessly rewrite local commits if the ref already exists
remotely. Other failures still attempt recovery; a failed recovery preserves the
original push error as the primary cause with its fetch/replay error wrapped
alongside it, rather than assuming divergence. Confirmed remote rejections surface
one bounded warning per flush naming a ref and Git's reason
(including push-protection guidance). The warning explicitly labels the reason as
one example because other queued refs may have different failures (all are logged).
Terminal diagnostics preserve Git's line breaks and indentation; log errors stay
single-line. Both forms use the existing output cap and push-target URL masking,
without additional secret redaction of the remote's diagnostic output. Plain non-fast-forward recovery stays quiet;
SSH authentication failures retain their dedicated hint. Failures remain queued
and **never fail the user's git push**.

The batch is bounded too. Before chunking, one `git push` carried the whole queue with no deadline, so a large backlog over a slow uplink or a stalled connection held the user's `git push` for as long as the upload took. In the pre-push path the batch now shares the fallback's `checkpointFlushBudget`, and stops before its next chunk once that budget is spent or `maxConsecutiveChunkPushFailures` chunks fail in a row; it always attempts the first chunk. Chunks are what keep the bound from discarding work: landed chunks leave the queue at once, so a backlog larger than one budget drains over several pushes instead of being cut at the same point by each. A batch the budget cuts — between chunks or mid-chunk — ends the flush there ("Stopped pushing: budget … exhausted"): the per-ref fallback does not run on a spent budget, and a chunk cut mid-push rotates to the back of the queue. The chunk size adapts to the link (`PushQueue.ChunkSizeHint`, stored in `entire-checkpoint-push-chunk-size` in the git common dir): a chunk the budget cut before anything landed quarters it, down to one ref, and any batch in which every attempted chunk landed doubles it back toward 200. Without that, a link too slow to land one full chunk within the budget would cut the same chunk on every push and never make progress. The explicit pushes (`PushQueuedCheckpointRefs` for migration, `entire checkpoint push`) leave the batch unbounded, because the user asked for that upload and is waiting on it; they push full chunks and neither read nor change the remembered size. Under the pre-push hook, OpenSSH also gets `ConnectTimeout=60` (`withBatchModeSSH`), so an unreachable host fails within a minute instead of spending the budget on a kernel connect timeout; other ssh clients are left alone, since they may reject `-o`. A command-line `-o` beats `~/.ssh/config`, so this also replaces a `ConnectTimeout` set there (one set in `GIT_SSH_COMMAND` or `core.sshCommand` is kept); an HTTPS remote has no such bound, so on Linux, where the kernel connect timeout (~127s) outlasts the budget, an unreachable HTTPS host reports a spent budget rather than "Couldn't reach".

A remote that cannot be reached at all ends the flush after one attempt. When nothing has landed and a chunk's git output carries a connect-phase failure from ssh or curl (`remote.UnreachableRemoteLine`: unresolvable host, failed connect), later chunks and the per-ref fallback would each fail the same way after their own connect timeout, so the flush stops, prints that one line — credentials redacted, control bytes stripped, capped — and leaves the whole queue in order. The match is deliberately narrow: no bare strerror text (curl's is localized), no mid-transfer timeouts (the host was reachable), and no `remote:` lines (a reachable remote's own hook failing to resolve a host). A miss only costs the old path, the bounded fallback.

The fallback is bounded. It runs under a `checkpointFlushBudget` context deadline — so an expired budget cuts a ref that is already hung rather than waiting out its own `checkpointPushBudget` first — and additionally stops after `maxConsecutiveRefPushFailures` refs fail in a row. Either way it never aborts before at least one ref has been attempted. A remote that is refusing or unreachable fails every ref the same way, and each ref in the fallback costs at least one network round-trip, so walking a large queue to the end turns one failed push into an apparently hung one for minutes or hours. Skipped refs stay queued and go out on the next push, and a success resets the consecutive count so one blocked checkpoint does not strand the refs queued behind it. The abort prints one line naming what stopped the retry and how many refs remain.

An early abort also rotates that flush's failed entries to the back of the queue (`PushQueue.Rotate`, which matches exact `(ref, hash)` entries, so a newer generation queued meanwhile keeps its place). The queue drains in first-seen order, so without it a prefix that always fails — five checkpoints blocked by a ruleset, say — is retried in the same order on every push and the healthy refs behind it are never attempted at all. Rotation is skipped after an interruption, where the failures say nothing about the refs.

Two diagnostics make a wholesale failure readable. Each failed chunk's error is logged before the fallback runs: the per-ref retries re-derive a *rejection* reason, but a transport failure — an unreachable remote, a stalled connection — matches none of them, so without that line the cause reached neither the terminal nor `.entire/logs`. And `remote.Fetch` now annotates its error with git's own output — redacted and capped by the same `errWithGitOutput` helper the push path uses — instead of the strategy layer substituting that output for the error, which reported a contentless `fetch failed:` per ref whenever git was killed before writing anything.

### Checkpoint push policy

Each clone has a checkpoint push policy, stored as one word in `entire/checkpoint-push-policy` in the git common dir and set with `entire configure --checkpoint-push-policy`:

- `automatic` (also when unset): pre-push sends every queued ref, as above.
- `manual`: pre-push sends nothing and prints how many checkpoints are waiting. `entire checkpoint push <id>[@<commit>]` or `--all` uploads the named refs through the same flush. With `@<commit>`, the ref is sent only while that commit is still its tip, so a version the user did not look at never uploads. The zero hash is not a pin, and one ref named with two different commits is refused. Each named ref reports `uploaded`, `changed`, `failed` (including a queued ref that could not be read, or a flush that failed before reaching it), or `not_waiting`.

`manual` needs the git-refs backend. git-branch delivery does not read the policy and `entire checkpoint push` cannot send its checkpoints, so `configure` refuses `manual` unless git-refs is the primary backend, counting a `--checkpoint-backend` given in the same run.

The policy is per clone because the push queue is: a per-worktree setting would let one worktree upload what another holds back. Automatic delivery (`flushCheckpointRefsQueue`, and `PushQueuedCheckpointRefs` for the migration push) reads it from the opened repository's common dir before OPF and again inside the flush, so a new automatic caller cannot upload under `manual` by skipping the check. Under `manual`, `PushQueuedCheckpointRefs` returns `ErrCheckpointPushHeldByPolicy` rather than reporting an empty queue, so the migration's push-now says the refs are held. `entire checkpoint push` does not read it: naming the refs is the decision.

A missing file means `automatic`. The read fails closed: an empty file, a symlink, or a value this binary does not recognize (for example from a newer version) uploads nothing on automatic paths, and pre-push names the file to fix. The policy is never read through `settings.Load`, whose callers on the push path fall back to defaults on a load error and would turn `manual` into `automatic`. It is its own file rather than a key in `entire/preferences.json` because released binaries rewrite that file without the keys they do not model, which would silently release a `manual` clone. A file of its own keeps the policy, but an older binary does not read it: its pre-push uploads everything waiting. A second install, an agent sandbox or a rollback in the same clone is enough, and nothing in a newer binary can prevent it. The refusal of a user's own push (below) is decided from this file and git's ref list alone, never from the checked-out branch's settings, so it holds on a branch whose settings do not load, that has Entire disabled (`entire disable`, or `"enabled": false` in committed settings), or that predates `.entire/`.

Under `manual`, `entire session attach` on a pushed commit prints the `entire checkpoint push <id>` line instead of uploading. Attach reads the policy once, so delivery does what its confirmation said. If the checkpoint could not be queued, attach fails and says so rather than calling it waiting; running it again queues it. A legacy checkpoint that was never migrated is copied into its own ref by the attach write, so it waits like any other. On the git-branch backend the policy does not apply.

Under `manual`, or when the policy cannot be read, pre-push also refuses a user's own push that sends checkpoint content itself: `--mirror`, an explicit `refs/entire/checkpoints/*` refspec, `entire/checkpoints/v1`, or any line whose commit is the current version of a waiting checkpoint: a commit or expression (`<commit>:refs/heads/copy`, `<name>~0:...`), or a branch or tag (annotated or not) created at that commit. Under automatic the check stops after one policy read. Git has already chosen what to send when the hook runs, so the whole push is aborted and the error names one ref. Deleting a remote checkpoint ref sends nothing and is allowed. The check runs before `push_sessions` and the checkpoint sync remote gate, because it concerns what the user's push sends, to any remote. It needs the ref list git passes on the hook's stdin; a pre-push line that predates it cannot be checked, and pre-push says so while checkpoints are waiting, before the same gates. When the current line cannot save the list (no usable `TMPDIR`), it runs Entire with `ENTIRE_PRE_PUSH_STDIN_REFS=0`, and under a holding policy with checkpoints waiting the push is refused, since it might be a `--mirror`. `git push --no-verify` skips the hook and so bypasses the refusal. So does sending an older version of a checkpoint, a new commit built from its tree, or a branch whose new commits sit on top of its commit: the check matches checkpoint ref names and current versions, not content or ancestry.

Without a terminal, `entire checkpoint push` accepts only `<id>@<commit>`; `--all` and a bare ID need `interactive.CanPromptInteractively()`. With no arguments it lists what is waiting and exits 0; with `--json` and no arguments it refuses and points at `entire checkpoint list --outgoing --json`. It exits 0 when every named checkpoint was uploaded or had already been uploaded (`not_waiting`), and non-zero for `changed`, `failed` or `not_found` (no checkpoint with that ID here). With `--json`, a failure before any result is reported as `{"error": ...}` on stdout. This is a speed bump for agents, not a control: anything running as the user can edit the policy file, push `refs/entire/*` with `--no-verify`, or set `ENTIRE_TEST_TTY=1`, the test override `interactive.CanPromptInteractively()` honors in every build. A check that must hold against the user's own agent cannot live in the CLI.

With OPF enabled, `entire checkpoint push <id>` still runs the OPF gate over the whole queue, not only the named refs. A large checkpoint that was not named can then trip an OPF cap and keep the named one from uploading. The rewrite also moves each waiting ref to a new tip, so a pinned `<id>@<commit>` taken before it reports `changed` and sends nothing on the first try. This affects only OPF users (deprecated) on `manual`.

While the policy is unset, a user's `git push` from a terminal (`interactive.CanPromptInteractively()`) with checkpoints waiting asks once: automatic, manual, or not now. It is asked before the policy is read for that push, so choosing manual already holds it. The answer is saved only if no policy was chosen while the question waited, so a newer `entire configure` or another worktree's answer wins; the back-off keys stay in clone preferences, where losing one only brings the question back. "Not now" uploads that push as usual, saves nothing, and asks again on the next push; no answer within `checkpointPushQuestionTimeout` (longer than the commit-linking prompt's, because this is a three-way choice) counts as "not now" and stops the question for 7 days on this clone (`checkpoint_push_question_backoff_until`). A malformed back-off brings the question back. OPF users are not asked, since OPF can ask its own question on a push (unless `prompt_default` answers for it); they get a one-time deprecation line instead (`opf_deprecation_notice_shown`). Commit linking asks during `git commit`, so a push never shows two Entire questions. `entire enable` on git-refs names `--checkpoint-push-policy manual` while the policy reads as automatic.

### Non-force, fast-forward-only

All checkpoint-ref pushes are **fast-forward-only — never a force push.** There is no server-side ref protection, so a force push risks silently clobbering a checkpoint written elsewhere. Per-checkpoint refs normally advance by fast-forward (append-only per-checkpoint history), so this is the common case.

When a push *is* rejected as non-fast-forward — genuine divergence, e.g. the same checkpoint was written on two machines — recovery **fetches the remote ref and replays the local-only commits on top** (`recoverCheckpointRef`), then retries. After the replay the local ref is a fast-forward over the remote, so the retry is *still* non-force and the remote commit is preserved as an ancestor rather than overwritten. A genuine cherry-pick conflict (both sides rewrote the same file, e.g. root `metadata.json`) leaves the ref queued — degrading to the safe state, never forcing.

**The deliberate exception: `entire checkpoint delete`.** Deleting a checkpoint
pushes `:<ref>` with `--force-with-lease=<ref>:<oid>`, where `<oid>` is what
`ls-remote` reported moments earlier. That is a non-fast-forward update by
definition, so it is confined to the one ref, runs only on an explicit user
command (agents are told never to run it unprompted), and is leased so a copy
another clone pushed since the probe is never removed unseen. Each remote is
resolved to one concrete URL first (push destination, `checkpoint_remote` push
and fetch URLs, and every read candidate's fetch and first push URL), so the
probe, the lease, and the push address the same repository.

The local ref is deleted (compare-and-swap) and dropped from the push queue
before any remote: pre-push drains the queue and pushes refs that exist locally,
so remote-first ordering would let a concurrent push put it back. Each remote's
per-checkpoint ref (not its `v1` branch) is then re-checked once with
`ls-remote` and its delete retried if a push had already re-landed it. A lease
that fails as stale is re-probed: when the ref is already gone (the same
repository reached through a second URL spelling, say) the outcome is
"absent", not a failure. A remote that refuses is reported with an
`entire checkpoint delete <id> --remote <name>` retry command; the local copy is
not restored, and a remote-only delete (no local copy) is allowed. The ID is
also recorded in the git common dir's deleted-checkpoints list
(`entire-deleted-checkpoints.json`), which `prepare-commit-msg` uses to drop the
ID's trailer on an amend, which migration and the copy on write skip, and
which makes `entire session attach` refuse to add a session to the checkpoint. Other clones still holding
the ref can push it back; remote tombstones are deferred. So can a clone
whose local `v1` still holds a pre-switch checkpoint deleted elsewhere: the
delete reaches only remotes' `v1`, and a write there copies the stale copy into
its own ref (see [Migration and coexistence](#migration-and-coexistence)),
which the next push uploads.

A checkpoint on the `v1` branch is deleted per remote by fetching that
remote's branch tip into a temporary ref, committing the subtree's removal on
it, and pushing with a lease on the fetched tip (a fast-forward). Local `v1`
commits are never pushed by a delete, so unpushed data stays local. The remote-tracking `v1` ref of each named
remote whose fetch URL is the target is advanced to the pushed tip (or to the
fetched tip when the checkpoint was already gone there) so read fallbacks and
migration stop seeing the checkpoint. The content remains in the branch's
history. The local `v1` removal is a commit the next pre-push sends to every
`v1` push destination, so on the git-branch primary a delete that leaves one
out is refused before any write if it holds a copy or cannot be reached. After
pushing the removal to a destination, local `v1` is rebuilt on the pushed
commit (unpushed local commits replayed) so the branches do not diverge, but
only when the two removal commits are the whole divergence, and only for the
first destination reached.

### On-demand fetch (reads and backfill writes)

A checkpoint written on another machine has no local ref. When a read — or a backfill write's base resolution (`refBaseForBackfill`) — misses locally and a **ref fetcher** is configured, `resolveRefMaybeFetch` fetches that one ref from the remote and retries once. It carefully distinguishes:

- **genuinely absent** (remote has no such checkpoint) → maps to `ErrCheckpointNotFound`;
- **a real failure** (IO, network, context cancellation) → returned as-is, never swallowed as "not found".

### List and remote discovery

`List` at the storage level enumerates **local refs** and reads each root summary. That alone is not enough on a **second device**: a checkpoint written elsewhere has no local ref, so a purely local `List` shows zero even though the checkpoint exists on the remote. Reads already fetch a *known* ID on demand (above), but `List` is a *discovery* problem — it has to learn which checkpoints exist before anything can read them.

To close that gap `List` supports **opt-in remote discovery**:

- The caller marks the context with `WithRemoteListDiscovery` (set only on explicit, user-facing enumeration — `entire checkpoint list` and the branch `explain` view — never the per-turn commit hook, so routine local listings stay network-free).
- A **remote ref lister** injected by the CLI runs `git ls-remote refs/entire/checkpoints/*` — **names only, no object transfer** — against the checkpoint remote(s) (see the scoping below).
- Each advertised ref that has no local ref yet is added to the result as a not-yet-hydrated `CheckpointInfo`. Its `CreatedAt` is recovered from the ULID timestamp in the ref name, so it sorts by real recency without a fetch; the rest of its contents are **hydrated lazily on the next read** via the on-demand ref fetch (and, on the branch `explain` / `checkpoint list` path, eagerly for the truncated display set so `--session` filters see real SessionIDs).

**Surfacing vs discovery:** storage-level `List` can return remote-only stubs, but the branch view (`getBranchCheckpoints`) only surfaces a discovered checkpoint when an `Entire-Checkpoint` trailer for that ID is present in the scanned local commit range. Discovery therefore helps only after the user has pulled the branch commits that carry those trailers — it does not invent branch entries from remote refs alone.

**Where enumeration looks:** with a dedicated `checkpoint_remote` configured it queries the resolved checkpoint URL (`remote.FetchURL`, which can fall through to origin in edge cases) — unchanged single-target behavior. With **none** configured it ls-remotes **every checkpoint read candidate** — the elected checkpoint sync remote, then `origin` when it differs (`strategy.CheckpointReadRemotes`) — and **merges the listings**, a union deduped by ref name, so a second machine discovers refs-native checkpoints in the default setup without any dedicated store. Merging, not first-non-empty, is deliberate: per-checkpoint refs land on whichever remote the pre-push hook fired for, so *disjoint* refs on origin coexisting with refs on the elected remote are realistic, and first-non-empty would shadow one side. Each candidate gets its own short timeout so a hung elected remote cannot starve the legacy tier. One candidate failing logs at debug and does not block the others; when every candidate fails, the lister returns the first error so `List` warns on stderr and then stays local-only. Discovery is **best-effort and additive**: partial failure still returns the merged reachable results, while total failure remains visible without failing the whole listing. URL resolution and `ls-remote` run from the worktree root so repo-local git config applies.

**Listing timeout:** both paths give each `ls-remote` 5 seconds by default (`checkpointRefListTimeout`); on the candidate path that budget also covers resolving the candidate's URL. `strategy_options.checkpoint_ref_list_timeout_seconds` replaces the default for remotes that answer slowly, such as ones that advertise many refs: `ls-remote` sends no `ref-prefix` for the `refs/entire/checkpoints/*` pattern, so the remote advertises every ref and git filters them locally. `settings.CheckpointRefListTimeoutValue` ignores values that are not positive numbers and caps the rest at 2 minutes, one full checkpoint read fetch (`remote.ReadFetchTimeout`), because the value usually comes from a committed `settings.json`. The option lives under `strategy_options` so older CLIs ignore it: their strict loader rejects unknown top-level keys, which would make a committed `settings.json` unloadable for them.

## Kind routing and coexistence

`checkpoint.Open` returns a `kindRoutingStore` (`checkpoint/routing_store.go`) that resolves id-keyed reads — and backfill writes — across **both** git backends by the checkpoint's ID kind, so a repo running git-refs and git-branch side by side (or mid-migration) handles either format without reconfiguring:

| ID kind | Read from | Rationale |
|---------|-----------|-----------|
| **ULID** | git-refs only, never the branch | ULIDs are only ever minted under git-refs |
| **hex**, git-branch primary | branch only | branch is authoritative for hex |
| **hex**, git-refs primary | refs first, then git-branch fallback | a hex checkpoint may still sit on the pre-migration v1 branch, or have been migrated into refs |

- `List` **unions both** backends and de-dups by ID (the same checkpoint can appear in both during coexistence), keeping the most recent.
- The `firstResolved` helper tries stores in priority order; a non-final store that reports absent *or* errors falls through to the next, so a transient git-refs fetch error cannot hide a checkpoint that resolves on the branch. The final store's result (hit, absent, or error) is returned verbatim.
- The optional `AuthorReader` capability (`explain` relies on it) is preserved and routed by the same rules when both read stores provide it.
- **Creates (`Session`) are not kind-routed.** They target the configured primary (+ mirrors); the minted ID already matches the primary's format.
- **Backfills (`SessionSummary`, `SessionTranscript`, `Tasks`) are kind-routed.** They update an *existing* checkpoint, which may live in either backend, so they follow the read order above, falling through to the next store only on `ErrCheckpointNotFound` (stricter than reads — a hard error aborts rather than risking a forked write). Under a git-refs primary, a hex checkpoint the refs store does not have (after its on-demand fetch, when one is wired) is first copied from `v1` into its own ref (see [Migration and coexistence](#migration-and-coexistence)) and the backfill lands there. Only a checkpoint that cannot be copied, because it is absent from `v1` or deleted from this clone, falls through to the branch. A backfill landing on the primary still fans out to mirrors; one landing on a fallback store skips mirrors (mirrors follow the primary) and logs the routing decision.
- **Reserved writes (`ReservedSession`) route by ID.** Condensation and attach write an ID that may have been reserved under the other primary. A ULID under a git-branch primary goes to refs, where reads look for it. A hex ID under a git-refs primary goes through the primary, copied from `v1` first when only `v1` has it, so a session reserved before the switch, or attached to a pre-switch commit, is pushed. A hex checkpoint deleted from this clone is written to the branch instead, so it does not come back as a ref.

All general read paths — resume, explain, blame, why, tokens, attach — inherit this routing for free through `checkpoint.Open`; there is no per-command config knob.

## Configuration and rollout

Backend selection lives in the `checkpoints` block of settings (`settings/checkpoints.go`):

```json
{
  "checkpoints": {
    "primary": { "type": "git-refs" }
  }
}
```

- `primary.type` is required. When the whole block is absent, the layer defaults to the **git-branch** backend with no mirrors — so existing repos are unchanged.
- **A first-time `entire enable` writes `git-refs` explicitly, with no prompt.** Both setup paths do it — the interactive flow and the non-interactive `--agent` flow — via `resolveFirstRunCheckpointBackend` / `firstRunCheckpointBackendDefault` (`setup.go`). There is deliberately **no setup question**: storage topology is not answerable at first-run, so the recommended backend is written silently and `git-branch` is reachable only by typing `--checkpoint-backend branch`. The one case that writes nothing is an active `ENTIRE_CHECKPOINTS_PRIMARY`, since the env fully replaces the settings block and persisting a default would only record diverging config.
- `settings.local.json`'s `checkpoints` block **replaces** the one in `settings.json` wholesale (this is a selection config, not a deep-merged document).
- Config loading is **fail-soft**: a missing file, a whole-file JSON syntax error, or unrelated invalid fields all resolve to "no config" → default git-branch. It errors *only* when a present `checkpoints` block is itself invalid.
- Unknown fields are rejected (`DisallowUnknownFields`) to surface typos. The trade-off: adding a `checkpoints` field is a coordinated rollout — ship the reader before any writer emits the field.

### Environment override

`ENTIRE_CHECKPOINTS_PRIMARY` (and the optional comma-separated `ENTIRE_CHECKPOINTS_MIRRORS`) **fully replace** any settings block — env wins over file, matching other `ENTIRE_*` overrides. This is how e2e/CI and rollout drive a specific backend without editing settings; the CI test-canary job runs a matrix over `[git-branch, git-refs]` via this variable. The env override is selection-only (no per-backend config blocks).

### Rollout states

The switch is a **primary flip**, not a dual-write phase. There is no "run both backends in parallel" step — see [Migration and coexistence](#migration-and-coexistence) for why read routing makes it unnecessary.

| State | `primary` | Behavior |
|-------|-----------|----------|
| **Config-less fallback** | `git-branch` | Hex checkpoints on the `v1` branch; unchanged legacy behavior for repos set up before the git-refs default. A repo reaches this state only by predating that default (or by having its `checkpoints` block removed) — a first-time `entire enable` always writes an explicit primary |
| **Refs-only** | `git-refs` | New checkpoints are ULIDs written as per-checkpoint refs; pre-existing hex/`v1` checkpoints stay readable via the read-routing fallback |

## Migration and coexistence

The read-routing rules above are what make a hex-on-branch repo and a ULID-in-refs repo the same repo: nothing needs to move for both formats to be readable, so the branch→refs switch is a primary flip with **no dual-write step**.

Concretely, flipping the primary to git-refs means new checkpoints are ULIDs stored as per-checkpoint refs, while every checkpoint already written to the `v1` branch stays exactly where it is and keeps resolving through the branch fallback. This works because **every reader routes the same way — refs first (for both ID formats), branch fallback for the legacy format** — not just the CLI but also entire.io and entire-api. So a repo can move to refs-only on the remote without keeping the `v1` branch alive for any reader's benefit.

A mixed fleet works, with one limitation:

- A **modern** CLI (or the server) on git-refs primary reads everything: ULID/refs checkpoints directly, and older hex/`v1` checkpoints via the fallback.
- An **old** CLI keeps writing hex checkpoints to the `v1` branch, and everyone modern still reads those. Reading ULID/refs checkpoints requires a CLI with git-refs support; an old CLI does not see them.

This is why running `git-branch` as a *mirror* of git-refs is **not** part of the migration: it would dual-write every checkpoint into both backends to keep `v1` populated, but no reader needs that — read routing already covers both formats, and an old client not reading the new format is an accepted consequence rather than something to paper over. It is now a **silent** one: the `checkpoint_min_version` policy that used to turn it into an explicit "upgrade" nudge was removed with the checkpoint policy feature, and nothing replaced it. An old CLI in a refs-primary repo sees a partial history and is told nothing.

When checkpoints *are* actively migrated from the branch into refs (`entire doctor migrate-checkpoints` while git-branch is still primary), they are written under `RefName(hexID)` — i.e. **hex-named refs** — which is why a hex ID under a git-refs primary is looked up in refs first and only then falls back to the branch. Migration takes each checkpoint from whichever `v1` copy changed it last, the same rule as the write-time copy below (`pickCheckpointCopy`). When two copies both changed it, it asks a person in a terminal which copy to keep; without one it writes no ref for that checkpoint, lists it and exits 1. The choice is recorded on this clone only, in `entire-legacy-checkpoint-choices.json` in the git common dir, keyed by checkpoint with the kept and passed-over copies' subtrees, so a re-run does not ask again while the copies stay the same. It is never pushed or read from a ref, so a remote cannot answer the question. Migration reads the same copies as the write path, through the checkpoint read-remote chain.

After the switch, a checkpoint that stayed on `v1` is migrated one at a time, the first time something writes to it: an attach to a pre-switch commit, a condensation of a session that reserved its ID before the switch, or a backfill. The write copies the checkpoint's `v1` subtree into its own hex-named ref, normalized exactly as migration writes it (`importBranchCheckpoint`), and then writes through the primary, which queues the ref for push. Nothing advances the local `v1` under git-refs, while a plain `git fetch` still advances its remote-tracking copy, so the copy takes the checkpoint from whichever of those copies changed it last: the other must still hold it as it was where the two branches split. When both changed it since then and the remote has no ref for it, either copy would hide the other's sessions once pushed, so nothing is copied and the write fails with `ErrLegacyCheckpointDiverged`. Post-commit then prints one `[entire]` line: the session's work stays pending and is saved with the next commit's checkpoint, while the commit keeps a trailer for a checkpoint without it. Attach and summary saves name the fix. The fix is `entire doctor migrate-checkpoints`, which after the switch only resolves these checkpoints: ones with no ref whose copies diverged. It visits checkpoints on every copy the read-remote chain names, asks for the remote's ref first (failing closed when the remote cannot be reached), otherwise asks a person which copy to keep, and writes only into an absent ref (`ResolveDivergedLegacyCheckpoints`), so a ref written after the switch is never regressed. The post-commit notice prints once per commit and only reaches a person at a terminal, so `entire doctor`'s scan also lists these checkpoints, from local copies only. Without the copy the write would land on `v1`, which git-refs pre-push never sends. The copy skips checkpoints on this clone's deleted list and never touches a ref that already exists locally, including one that appears while the copy runs, since that ref may be ahead of `v1`. A checkpoint nothing writes to stays on `v1` and keeps resolving through the branch fallback.

Before copying, the write asks the remote whether the checkpoint already has a ref, so a second clone builds on the ref the first one pushed. Attach fetches the ref itself first. Condensation's store asks with the bounded, non-interactive hook probe (`OpenOptions.LegacyCopyRefFetcher`), and a backfill on a store with a ref fetcher probes the ref before reporting it missing. When the remote cannot be asked, nothing is copied and the write fails: attach says so, and condensation leaves the session pending for a later commit, session stop or `entire doctor`. Two clones that both copy the same checkpoint before either pushes still produce refs with unrelated histories. Push recovery then replays one clone's commits over the other's, path by path with the last writer winning (`cherryPickOnto`), and a session written to the same index on both sides is lost.

## Key files

| File | Responsibility |
|------|----------------|
| `checkpoint/registry.go` | Backend registry, `gitBacked` capability, built-in `git-branch`/`git-refs` |
| `checkpoint/open.go` | `Open` topology resolution, `PrimaryIsRefs`, `kindRoutingStore` wiring |
| `checkpoint/refs_naming.go` | `RefName` / `ParseRef`, `CheckpointRefPrefix` |
| `checkpoint/refs_store.go` | `gitRefsStore` — per-checkpoint write/read, on-demand fetch |
| `checkpoint/pushqueue.go` | Flock JSONL push-discovery queue |
| `checkpoint/routing_store.go` | `kindRoutingStore` — id-kind read, backfill and reserved-write routing across both backends; copies a `v1`-only hex checkpoint into its ref on write |
| `checkpoint/migrate.go` | Branch→refs migration (`MigrateBranchToRefs`) and the per-checkpoint import it shares with the copy on write (`importBranchCheckpoint`) |
| `checkpoint/id/id.go` | `ShardFor`, `Kind`/`KindOf`, ID generation |
| `settings/checkpoints.go` | `checkpoints` block parsing + env override |
| `strategy/manual_commit_push.go` | Pre-push: drain queue, batch push, per-ref recovery |
| `strategy/checkpoint_push_policy.go` | Checkpoint push policy gate, `PushCheckpoints` for `entire checkpoint push` |
| `strategy/checkpoint_push_question.go` | First-push policy question, its back-off, and the OPF deprecation line |
| `strategy/push_common.go` | `batchPushCheckpointRefs`, `pushCheckpointRefWithRecovery`, fetch+replay |
| `strategy/checkpoint_delete*.go` | `entire checkpoint delete`: read-only plan, leased per-remote deletes |
| `checkpoint/deleted_list.go` | Local deleted-checkpoints list in the git common dir |

## Known limitations and deferred work

- **Storage-level `List` is local-only by default**, with **opt-in remote discovery** for user-facing enumeration (see [List and remote discovery](#list-and-remote-discovery)): an `ls-remote` of `refs/entire/checkpoints/*` surfaces checkpoints written on another machine, hydrated lazily on read. It queries the dedicated `checkpoint_remote` when one is configured, else the checkpoint read candidates with merged listings, and is kept off the per-turn hook hot path.
- **The "ULIDs never land on the branch" invariant is not yet enforced at write time.** A config flip or a missing `ENTIRE_CHECKPOINTS_PRIMARY` in an amending environment could, in principle, condense a ULID checkpoint onto the `v1` branch, which readers (routing ULIDs to refs only) would then fail to find. Because git-branch is *not* a mirror of git-refs (see [Migration and coexistence](#migration-and-coexistence)), a ULID reaching the git-branch write path is unambiguously a bug — so enforcing this is a straightforward reject at that write path, not a topology-role-aware check.
