# Sessions and Checkpoints

## Overview

Entire CLI creates checkpoints for AI coding sessions. The system is agent-agnostic - it works with Claude Code, Codex, Antigravity, OpenCode, Cursor, Factory AI Droid, Copilot CLI, or any tool that triggers Entire hooks.

This document covers the domain model shared by both checkpoint storage backends. For how the **git-refs** backend stores checkpoints as one ref per checkpoint — its layout, push/fetch model, read routing, and configuration — see [Ref-Based Checkpoint Backend](ref-checkpoint-backend.md).

## Domain Model

### Session

A **Session** is a unit of work: one agent conversation, from its first hook
to session end. Its live state is `session.State` (`session/state.go`),
persisted per session at `.git/entire-sessions/<id>.json` and shared across
worktrees:

```go
type State struct {
    SessionID        string          // agent-provided session identifier
    BaseCommit       string          // commit the pending work sits on; moves with HEAD
    WorktreeID       string          // internal git worktree name; empty for the main worktree
    Phase            Phase           // lifecycle phase (see Session State below)
    StartedAt        time.Time
    StepCount        int             // steps recorded in this session
    FilesTouched     []string        // files modified, created, or deleted by the session
    LastCheckpointID id.CheckpointID // checkpoint from the most recent condensation
    AgentType        types.AgentType
    // ...
}
```

### Checkpoint

A **Checkpoint** is the permanent record of a session's work, linked to a code
commit by its `Entire-Checkpoint` trailer. Its root metadata is
`checkpoint.CheckpointSummary` (an alias of `api/checkpoint`), stored at
`<id[:2]>/<id[2:]>/metadata.json`; per-session content sits beside it:

```go
type CheckpointSummary struct {
    CheckpointID     id.CheckpointID    // stable identifier (12-hex or ULID; see Checkpoint ID Linking)
    Strategy         string
    Branch           string
    CommitSHA        string
    CheckpointsCount int
    FilesTouched     []string
    Sessions         []SessionFilePaths // one entry per session in the checkpoint
    // ...
}
```

### Where Checkpoint State Lives

A checkpoint is only ever written in one form: the persistent record on `entire/checkpoints/v1` (or a per-checkpoint ref under the git-refs backend), linked to a code commit by its `Entire-Checkpoint` trailer. Work in progress between commits is not written to git at all; it lives in session state and the session's local metadata directory:

| State | Where | Contents |
|------|-------|----------|
| Pending (between commits) | `.git/entire-sessions/<id>.json` and `.entire/metadata/<id>/` | Step count, touched files and their blob hashes, task records; sanitized transcript copy and prompts |
| Persistent (after commit) | `entire/checkpoints/v1` or `refs/entire/checkpoints/...` | Metadata, redacted transcripts, commit reference |

Most persistent checkpoints are written when a commit condenses a session, but some have no commit: eager condensation at session end, `entire doctor` and the session sweeper, and snapshots from the hidden `entire checkpoint create`. Doctor and sweep's ID-based salvage records the session's stored branch, refreshed at turn end only in its recorded home worktree (otherwise retaining the last recorded value), using its recorded worktree's repository when still registered and sharing the caller's resolved Git common directory; a removed or replaced worktree falls back to the caller's repository without borrowing its branch. Commit-driven condensation continues to record the committing worktree's HEAD branch. Snapshots exist for sessions that change no files (research, planning, review), which no other path checkpoints; see [implementation contracts](../development/checkpoint-implementation.md).

## Interface

### Session Access

Active session state is read from `.git/entire-sessions/` through
`session.StateStore`; committed checkpoint/session content is read through the
checkpoint facade (`checkpoint.Open(ctx, repo, opts)`, which resolves the ref
topology and wires the blob fetcher).

### Checkpoint Storage (Low-Level)

`checkpoint.Open` returns a `*Stores` facade whose `Persistent` field is the permanent record on `entire/checkpoints/v1` (a `PersistentStore`). This is the pluggable surface. There is no git-backed store for intra-session state: turn ends record into session state instead (see [Turn-End State](#turn-end-state)).

The store presents a generic surface — `Read`, `Write` (a sealed request union), and `List`:

```go
type PersistentStore interface {
    Read(ctx, checkpointID id.CheckpointID) (*CheckpointSummary, error)
    List(ctx) ([]CheckpointInfo, error)
    ReadSessionContent(ctx, checkpointID id.CheckpointID, sessionIndex int) (*SessionContent, error)
    Write(ctx, req WriteRequest) error    // Session / ReservedSession / SessionTranscript / SessionSummary
    // ...session reads
}
```

Writes go through the request union rather than per-operation methods, so a mirror/fan-out store just forwards the request value:

```go
// Condensation, stop-time transcript backfill, async summary
stores.Persistent.Write(ctx, checkpoint.Session{CheckpointID: id, /* ... */})
stores.Persistent.Write(ctx, checkpoint.SessionSummary{CheckpointID: id, Summary: s})
```

`Session`/`SessionTranscript` are defined types over the option structs (`WriteOptions`/`UpdateOptions`).

Token usage and skill events live in the leaf `agent/types` package (so the
contract doesn't pull in the full `agent` package):

```go
type TokenUsage struct {
    InputTokens         int         `json:"input_tokens"`
    CacheCreationTokens int         `json:"cache_creation_tokens"`
    CacheReadTokens     int         `json:"cache_read_tokens"`
    OutputTokens        int         `json:"output_tokens"`
    APICallCount        int         `json:"api_call_count"`
    SubagentTokens      *TokenUsage `json:"subagent_tokens,omitempty"`
}
```

### Strategy-Level Operations

Strategies compose low-level primitives into higher-level workflows.

**Manual-commit** has condensation logic:

```go
// CondenseSession reads the session's pending state and transcript and writes a committed checkpoint.
func (s *ManualCommitStrategy) CondenseSession(
    repo *git.Repository,
    checkpointID id.CheckpointID,
    state *SessionState,
) (*CondenseResult, error)
```

## Storage

| Type | Location | Contents |
|------|----------|----------|
| Session State | `.git/entire-sessions/<id>.json` | Active session tracking |
| Persistent (git-branch) | `entire/checkpoints/v1` branch, sharded `<id[:2]>/<id[2:]>/` | Metadata + commit reference |
| Persistent (git-refs) | `refs/entire/checkpoints/<shard>/<id>`, one ref per checkpoint | Metadata + commit reference |

The persistent store is pluggable: `git-branch` stores every committed checkpoint as a subtree of a single `entire/checkpoints/v1` branch, while `git-refs` stores one ref per checkpoint. New setups write an explicit backend choice via `entire enable` (`git-refs` recommended and pre-selected); a repo with no checkpoints config still resolves to `git-branch` (the config-less fallback), so pre-existing repos keep their behavior. Both are git-backed and share the same checkpoint tree layout; they differ only in where that tree is committed. This document describes the git-branch layout; for the ref-based backend — its ref naming, sharding, push/fetch model, read routing, and configuration — see [Ref-Based Checkpoint Backend](ref-checkpoint-backend.md).

### Session State

Location: `.git/entire-sessions/<session-id>.json`

Stored in git common dir (shared across worktrees). Tracks active session info.

The state records `Branch` — the branch HEAD pointed at on the session's last turn
(captured each turn start, so it follows branches created/renamed after the
session began). `entire resume` (bare, no arg) uses it to list stopped sessions
and map each back to its branch; for sessions recorded before the field existed
it falls back to deriving the branch from the session's last checkpoint ID found
in branch-only commit trailers.

`entire session adopt` moves an active session from a source repo or worktree
into the current worktree. Adoption preserves the live transcript path, validates
that the source state still belongs to the requested source worktree, rewrites
the session's branch/worktree/base metadata to the target, clears target-local
checkpoint windows and checkpoint IDs, and snapshots the target's current file
changes so the next commit can link to the adopted session.

Condensation reads a declared task transcript path whole into the checkpoint, so
adoption validates each one (`validateAdoptTaskTranscript`). The path must be
absolute and lie in the session directory of the session's agent, under its
active home or under the session's trusted `AgentHome` (see
[Recorded agent homes](../development/filesystem-safety.md#recorded-agent-homes));
a session recorded without an agent type takes it from the agent that owns its
transcript. Agents implementing `agent.TaskTranscriptMatcher` (Claude Code,
Codex, Droid) also require the path to name that task's transcript in their
layout. A path that fails is cleared, logged, and counted in adopt's output.
The checks are lexical: symbolic links are still followed when the transcript
is read. Subagent inventory paths get the same check, and their resolved paths
are cleared until Codex verifies the rollout again. A cleared task falls back to
the Claude-layout lookup (`agent-<id>.jsonl`) and, for Codex, the verified
inventory; a cleared Droid Worker transcript is not recovered.

#### Commit-to-session linking

The commit hooks (prepare-commit-msg / post-commit) resolve which sessions a
commit belongs to via `findSessionsForCommitLinking`
(`strategy/session_identity.go`): the **worktree-matched set** (every session
with pending content in the commit's worktree — concurrent sessions interleave
by design) **plus the identity-matched session** when the committing process's
ancestry names one that path matching missed.

**Identity matching**: reuses the owner fingerprint liveness already
records — `SessionState.Owner`, a `proclive.Identity` captured on every turn
start by `captureSessionOwner` (the first non-transient ancestor of the hook:
agents run hooks as children, possibly via `sh -c`, and proclive skips
shells, the `entire` binary itself, and the Go toolchain). At commit time the
hook snapshots its ancestry once (`proclive.CurrentAncestry`) and asks
`Ancestry.Depth(owner)` per candidate: was this commit's process spawned,
however indirectly, by that session's agent? Snapshotting once matters — the
shared store holds one state file per session, so a per-candidate walk would
repeat the hostname, boot-id, and proc reads dozens of times per commit.
Host, boot, and start-time guards mean a recycled PID or an identity recorded
on another machine can never match. The nearest ancestor wins, so a nested
agent is attributed over the outer agent that spawned it; only sessions
matching at the same depth (one agent process hosting several sessions) fall
back to the most recently interacting one. On platforms proclive cannot introspect (Windows),
identity matching reports nothing and linking falls back to worktree
matching. This makes an agent-made commit link to
its own session **in any worktree**, with no bookkeeping to drift. Any session
matched outside its home worktree is **guest-linked**, whether it came from
identity matching or the pre-existing single-worktree fallback below: it
condenses and links, but never mutates worktree-coupled state (`BaseCommit`)
— that follows only the session's own worktree HEAD.

**Edits are recorded per worktree** (`State.OtherWorktrees`). An agent
launched in one worktree fires its hooks there even when it edits another by
absolute path. At turn end the files the main transcript says the agent
edited are grouped by the registered worktree they are in
(`SplitEditsByWorktree`; the deepest for nested ones; edits outside every
worktree, in `.git`/`.entire`, or already matching that worktree's HEAD don't
count). The hook's own worktree records as it always has; every other
worktree's files go to that worktree's entry (files, hashes, and its HEAD as
the entry's base), keyed by git worktree ID so `git worktree move` keeps it.
Git reuses a removed worktree's ID for the next one of the same name, so each
entry also carries the marker Entire keeps in that worktree's git admin
directory (`<common>/worktrees/<id>/entire-incarnation`), which move keeps
and remove deletes. An entry whose marker no longer matches belongs to the
removed worktree: it links nothing, the next edit there starts a fresh one,
and turn-end pruning drops it.
A worktree other than the home records only transcript-named files, never
the rest of its status, so someone else's uncommitted work there is never
claimed. One turn is one step and carries its tokens once, however many
worktrees it touched.

At commit time a session is judged by its record of the committing worktree
(`enterWorktreeView`): that entry stands in for the home's files, hashes and
base while prepare-commit-msg and post-commit run. A session that edited the
worktree from elsewhere joins its linking set, but links only a commit that
contains those files, on the no-TTY fast path too, unless process ancestry
identifies it as the committer. A commit clears only the committing
worktree's files (carry-forward stays within it); files still waiting in any
worktree keep the session pending and the next checkpoint self-contained
(`carryForwardRemainingFiles`), and the stored transcript is released only
when nothing is pending anywhere. Entries for worktrees git no longer lists
are pruned at turn end, at session end, and before a commit-less salvage
(`CondenseSessionByID`), so a worktree removed after the last turn doesn't
keep an ended session pending or fold its files into the salvage. Known effects: when one window is split across
commits in two worktrees, the second checkpoint repeats the transcript (and
transcript-derived tokens) from the start, as split commits always have, and
hook-reported tokens go to the first; files written only through shell
commands never appear in the transcript and aren't recorded for another
worktree; an older CLI that rewrites the state drops the entries.

**A linked home is known by its marker** (`State.WorktreeIncarnation`, the
same `entire-incarnation` marker; "" for the main worktree). It is stamped
when the session starts, adopts into a linked worktree, or, for a session
homed before markers were kept, at its next turn at home. Hooks judge a
worktree against it (`homeAt`) rather than by path alone: the worktree
holding the marker is the home even after `git worktree move` — provided
git's own record of it (`<admin>/gitdir`) names that worktree, so a copy
isn't, and the recorded path is no longer a worktree — and one git added at
the home's path after removing it is not. A moved home is followed: commit
linking matches it as the home in memory, and post-commit and turn start
store the new path under the session's lock, keeping `WorktreeID`. A
re-added worktree's commits don't match the old session by path or as a
sibling; identity can still link it, as a guest (`State.HomeNotHere`). When
the session's own turn starts there (its agent resumed in it), it is
re-homed: the removed worktree's pending files and hashes are dropped, the
checkpoint window advances to the current transcript end with no steps
pending, the marker and base are the new worktree's, and background tasks
launched before then (`RehomedAt`) claim nothing there; tokens are kept.
Adopting from a re-added source home drops the removed one's files. When
the marker can't be checked (a git or filesystem failure) the path rule
applies, so a transient error never stops the home linking; only a marker
that differs, or a missing one in the worktree's admin directory, counts as
proof for re-homing or dropping files. Turn-end recording (`homedAt`),
caller resolution's worktree tier, and status/review counts stay path-based:
they rely on turn start having followed or re-homed first. A sibling
worktree's hook that runs between a move and the moved home's next hook
still reads the stored transcript copy from the hook's own worktree.

**Only the final trailer block links a saved commit** (`LinkedCheckpoints` in
post-commit, attach and `explain --generate`). The message's last paragraph,
after trailing blank and comment lines, links the commit when git's trailer
grammar reads it as a trailer block (`trailers.ParseAllCheckpointsFromFinalTrailerBlock`):
every line is a trailer (`Key: value`, with optional spaces before the colon),
an indented continuation of one, or a comment line; a block holding a line git
generates (`Signed-off-by: `, `(cherry picked from commit `) may also hold
other lines, as long as trailers make up at least a quarter of it. The subject
paragraph never counts, and only a line that is exactly an
`Entire-Checkpoint:` trailer names a checkpoint. An ID anywhere else (pasted,
quoted, indented, or mentioned in prose) is not the commit's link. The reader
is Go, not `git interpret-trailers`, so a listing pays no subprocess per
commit.

- **Git config.** All of git's comment config is read by one function
  (`gitCommentConfig`): `core.commentChar`, `core.commentString` (aliases; the
  last one set wins), `commit.cleanup` and `commit.status` in one
  `git config` call, plus `git --version` only under
  `core.commentChar=auto`, whose rule changed in git 2.51. Only the
  configured values count; the hooks cannot see `git commit --cleanup=<mode>`.
  A saved commit is read first without a comment prefix, and with the
  configured one (`#` under `auto`, as git's trailer grammar reads it) only
  when that finds nothing and the message names a checkpoint. Prepare-commit-msg
  reads the config once and reuses it in each step that needs it (squash,
  redo, amend, stamping), as `git commit` itself reads its config once; it
  and post-commit likewise ask for the git dir once. A failed read is not
  kept, so the next step asks again. Each hook is its own process, so
  prepare-commit-msg and post-commit each read for themselves.
- **Read-only views.** `explain <commit>`, `explain --commit`, the branch
  listing, the export and the review re-run guard read with `#` and no git
  config (`CommitCheckpoint`): the final trailer block's last ID, or the
  first ID anywhere when that block names none, since a squash commit can
  carry its squashed commits' trailers in the body. `explain --checkpoint`
  lists a commit under every ID that view reads from it (`CommitCheckpoints`).
  Other read-only lookups (resume, status, attribution, review context,
  dispatch, pending-checkpoint listings) still scan the whole message on
  purpose: a squash merge made on a forge lists every squashed commit's
  trailer in its body, and these lookups must find all of them. They never
  write, so a body mention can make them show a checkpoint but cannot
  redirect a commit's work into one; code that writes resolves through
  `LinkedCheckpoints`.
- **Stamp.** Prepare-commit-msg reads the draft as git will record it
  (`preparedFinalTrailers`): git opens the editor unless the hooks run with
  `GIT_EDITOR=:`, the comment prefix is the configured one or, under `auto`,
  the one git picks for this message (read back from git's comment block when
  `commit.status` lets git write one), everything from git's scissors line
  down is cut, and comment lines are dropped only when git's cleanup drops
  them. An ID in that draft's final trailer block counts as already stamped
  (`stampedTrailer`) only when prepare recorded stamping it: each ID it stamps
  (one it generates, or a session's reserved one) goes into
  `entire-stamped-trailers.json` in the per-worktree git dir until the next
  post-commit, which consumes it. The trailer an amend restores names an
  existing checkpoint and is not recorded: post-commit condenses into it for
  its owner without a stamp, and a record a cancelled amend left would let a
  later commit naming it skip its own trailer. Prepare writes a trailer only once
  its stamp is recorded (`recordStampedTrailer`). A draft that already names
  another ID (pasted into `-m`, `-F` or a template) gets prepare's own trailer
  after it.
- **Placement.** Every trailer prepare writes (stamped, restored on amend,
  inherited) goes above git's comment block in an editor message, so
  `commit -v` cannot cut it off with the diff: the run of comment lines that
  ends the message below a blank line, or the scissors line
  (`addCheckpointTrailerAboveComments`). When that block would stay in the
  commit below the trailer where git's trailer grammar does not skip it
  (`auto` picked another prefix and the cleanup mode keeps comment lines), the
  trailer goes below the block instead. A message git does not open in the
  editor keeps its comment lines as written, so the trailer is appended.
- **Explanation.** Below the stamped trailer prepare writes a comment saying
  how to unlink the commit, only when git opens the editor and its cleanup
  drops comment lines; otherwise git would record it. It never quotes the
  session's prompt: the hooks cannot see `git commit --cleanup=<mode>`, so a
  mode given there records the comment.
- **Empty message.** Commit-msg removes Entire's trailer when the message
  holds nothing else git will record (`hasUserContent`), so git aborts the
  commit: comment lines count as git's cleanup treats them, everything from the
  scissors line down never counts, and neither do `Signed-off-by:` lines,
  which git's empty check skips.
- **Condensation target.** Post-commit condenses into the last stamped ID the
  commit links (`pickCondensationTarget`). A stamped ID that a paragraph added
  below it (an editor, a `commit-msg` hook) moved out of the final trailer
  block still counts: the stamp record, not its position, makes it the commit's.
  Without one (an amend that kept or restored its trailer, a sequence
  operation) it condenses only into the last linked ID
  whose checkpoint exists, and only for the session that owns it
  (`stampedByAnotherCommit`). It never creates a checkpoint prepare did not
  stamp, so a teammate's checkpoint this clone has not fetched is never
  created with local work. A message reused from another commit (`-C`, `-c`,
  `--amend`) keeps its trailer and gets no stamp, so reusing a foreign one
  leaves the commit unlinked; `entire attach` can link it.

**Squashes inherit their trailers** (`inheritSquashedCheckpointTrailers`). A
commit made while `git merge --squash` is in progress (SQUASH_MSG present in
the per-worktree git dir) contains the squashed commits' work, so the
checkpoints the squashed commits link are carried into the message's final
trailer block when that block, read as git will record the message, lacks them
(a copy indented in the body, as git seeds an editor squash message, does not count) when a staged path is one a squashed commit
changed; a file touched up before committing still counts. The squashed commits
are the ones SQUASH_MSG's unindented `commit <sha>` headers name (git indents
their messages, so a body line naming a commit is not one), and each one's
checkpoints are read from the recorded commit as `LinkedCheckpoints` reads it,
so a checkpoint its body only mentions is not inherited. An abandoned squash can leave
SQUASH_MSG behind; staged work on other paths therefore inherits nothing, and inherited trailers in Git's seeded message are
removed. git only reports source `squash` when its seeded message is accepted;
a squash committed with `-m` reports `message`, which used to run ordinary
matching and either refuse or mint a fresh, empty checkpoint. Inherited
trailers are links to checkpoints that already exist. Matching still runs, so
work a session holds at squash time is stamped as its own trailer, joined to
the inherited ones so they stay in the final trailer block, and post-commit condenses only into the trailer prepare
stamped (`pickCondensationTarget`). Prepare also records the inherited IDs in
the per-worktree git dir, tied to the commit's parent
(`recordInheritedTrailers`), so post-commit never writes into an inherited
one, even when its checkpoint is not in this clone's store yet; a write into
a checkpoint the session did not stamp for this commit is refused
(`stampedByAnotherCommit`). Merge commits stay unlinked by design; the
merged commits keep their own trailers.

**Redone commits inherit their trailers too** (`inheritReplacedCommitsTrailers`).
After `git reset` and new commits, the dropped commits are read from HEAD's
reflog, not ORIG_HEAD (which unstaging or a stash overwrites): walking back from
the newest entry, resets that did not move HEAD are skipped, and the tip the
last real reset left is where the dropped work starts. Dropped means only that
tip reaches it: commits HEAD, a remote or another branch still reach (merged-in
main, a teammate's commit an undone rebase brought in) are never inherited,
while a backup branch pointing at the tip itself does not count. A dropped
commit's checkpoints, read as `LinkedCheckpoints` reads them, are carried into
the new message's final trailer block when every staged file it
changed has exactly the content it had at that tip (read from the index git is
preparing the commit in, so `git commit -a` and path-limited commits compare
what they commit), so an agent's ten commits
redone as three logical ones keep every checkpoint, each on the commit that now
holds its files, while one coincidentally identical file (a lockfile, an empty
`__init__.py`, the same deletion) among rewritten ones inherits nothing. Commits
made since the reset keep the redo open only while each of them redid some of
the dropped work; any other ref operation (checkout, merge, rebase, pull) ends
it. Folding with `git reset --soft HEAD~1 && git commit --amend` inherits the
folded commit's trailers too. Inherited trailers are links, exactly as for a
squash, and are recorded so post-commit never condenses into one. Unlike a
squash, the staged files a redo inherited for are no evidence of new session
work: the reset put them back in the worktree and the next turn end records
them as touched again, though the session did nothing new to them. A staged
path counts as held only when the newest dropped commit that changed it
carries a checkpoint this clone has (a trailer whose capture failed still
links, but holds nothing) and the staged mode matches too. Session matching
ignores held paths, so a commit that only redoes linked work gets no fresh
trailer, and one that also stages other session work gets one for that work.
Session matching reads the same rename-free staged paths the redo compared.
Prepare records the held paths beside the inherited IDs. After a redo that
stamps nothing and so condenses nothing, post-commit drops them from
the touched files of this worktree's sessions when the commit holds the
recorded content, as carry-forward would; other touched files, steps and
transcript growth stay pending. When a fresh trailer is stamped, post-commit
judges overlap without the redo, so a session that only redid work may fold
into it: that keeps every stamped trailer resolvable (a stale ACTIVE or a
read-only session can depend on it). The mid-turn agent fast path likewise
still stamps on a partial redo: transcripts miss edits made through shell
commands, so it cannot rule new work out. In both, a redundant checkpoint is
preferred to a lost or dangling link.

**Worktree matching** (always computed; the sole mechanism for commits with
no recorded agent in their ancestry — human commits, detached runners): exact
`WorktreePath` match first, then sessions from a sibling worktree of the same
repo, provided they resolve to a single worktree. Imported sessions (`Kind=imported`) never link —
they are historical records. When candidates span several worktrees, sessions
that interacted within the last 15 minutes are preferred; if a single live
worktree remains it links, otherwise the hook declines with a stderr hint
naming `entire session adopt` (two genuinely live sessions in different
worktrees are never guessed between). This liveness filter intentionally turns
some cases the old code declined outright into a best-candidate link. The
15-minute `recentSessionWindow` is therefore a correctness tradeoff: a session
in a long-running build or tool call can age out, allowing the remaining recent
worktree to win.

Under `go test`, the session state store refuses to open outside the temp
root (both `session.NewStateStore` and `NewStateStoreForWorktree`), so a test
missing repo isolation fails loudly instead of leaking fixture sessions into
a real repo's `.git/entire-sessions` — leaked fixtures once hijacked commit
linking and produced a dangling `Entire-Checkpoint` trailer.

**Background zombie sweep.** The session-start hook checks the shared
session-state directory for zombies — non-ended sessions whose owning agent
process has exited (including the common IDLE case), and ENDED sessions that
still hold uncondensed checkpoint data more than 24h after ending (younger ones
are left alone so PostCommit carry-forward keeps its chance). When any exist,
it spawns a detached
`__sweep_sessions` process (throttled to one spawn per repo per window via a
flock-serialized marker in the git common dir) that finalizes/condenses them
using the same engines as `entire doctor --force`, condense-only: the sweep
has no interactive condense deadline and never initiates a discard — ended
sessions with nothing pending (`State.HasPendingWork`) are left to `entire doctor`
(and the existing orphan cleanup). The 7-day stale-session
purge bounds the sweep's window: a zombie that stays unfixed past 7 days is
removed by the purge, not the sweep. See `cmd/entire/cli/session_sweep.go`.

### Turn-End State

A turn end (`SaveStep`) writes no git objects. It records the turn into session state and leaves the transcript on local disk:

- `StepCount` is incremented, `FilesTouched` gains the turn's modified, new and deleted paths, and `TouchedFileHashes` records the git blob hash of each modified or new regular file (hashed with `git hash-object`, so clean filters apply exactly as `git add` would) and `""` for each deleted path. A path whose hash is unknown — hashing failed, a symlink, or a path that arrived through a task record, a per-tool hook, or a Codex child-file merge (`MergeUnhashedFilesTouched`, which also drops any hash an earlier step recorded for it) — has no entry and falls back to name matching. Paths this turn named that neither exist nor are recorded deletions are dropped from `FilesTouched` as phantoms.
- The turn's paths come from the transcript analyzer plus `git status` (`DetectFileChanges`): modified and deleted tracked files, and untracked files absent from the prompt-start baseline (`PrePromptState.UntrackedFiles`). An untracked file already in that baseline counts as modified when its stat data no longer matches `PrePromptState.UntrackedFileStats`, since git status reports it as untracked either way and a shell edit leaves no trace in the transcript. The stat data is what git's index compares: size, modification time, inode and status-change time. The change time catches a same-size rewrite that restores the modification time (`cp -p`, `touch -r`); Windows exposes no change time, so only size and modification time are compared there. The stat pass runs inside `UserPromptSubmit`, so it is bounded: above 10,000 untracked files it records no stats, and it stops after 500ms with what it has. Edits to the files it left out are not detected, as with state written before stats existed.
- `.entire/metadata/<session-id>/` holds the sanitized transcript copy (`full.jsonl`) and `prompt.txt`. These are local, git-ignored files; nothing is redacted or committed until condensation.

```
.entire/metadata/<session-id>/
├── full.jsonl           # Sanitized transcript copy, rewritten every Stop
└── prompt.txt           # Checkpoint-scoped user prompts
```

Hashing runs before the session lock is taken (`hashTouchedFiles`), and the results are applied inside it (`applyTouchedFileHashes`). Multiple concurrent sessions each keep their own state file and metadata directory, so nothing interleaves.

**Pending work.** Whether a session has anything to condense is one predicate, `State.HasPendingWork()` (`session/state.go`): steps, touched files, or task content. Condensation triggers, session-end eager condensation, orphan cleanup, the session sweep, and `entire doctor` all key on it. It ignores `FullyCondensed`; the session sweep, `IsCondensableEndedSession`, and doctor's ENDED classification exclude fully condensed sessions themselves.

**Commit decisions.** Linking is by name (`strategy/content_overlap.go`): a commit (or the index, in prepare-commit-msg) that carries any touched path links the session, whether the file is modified, deleted, or new and whatever its content, because a user editing an agent-created file before committing it is far more common than one overwriting it. The one exception is a new file at a path the session recorded as deleted (someone else re-created it). Recorded hashes decide carry-forward instead. After a partial commit, `filesWithRemainingAgentChanges` keeps each path whose agent version is not yet committed, and carry-forward (`carryForwardRemainingFiles`) leaves those paths in state with `StepCount=1` and transcript offsets reset to 0, so the next commit's checkpoint contains the full transcript again.

**Legacy shadow branches.** Older CLIs stored each turn as a commit on a shadow branch named `entire/<commit[:7]>-<worktreeHash[:6]>`. Nothing reads or writes them any more, and they are not deleted automatically. `entire doctor` reports them and `entire doctor --force` deletes them (plain `entire clean` does too, but also clears the state of sessions based on HEAD, dropping their pending work); the bare `entire/<hex>` form (indistinguishable from a human branch named after a short SHA) is only removed by `entire clean --all` (behind its confirmation) or by uninstall. `git branch -D` refuses a branch checked out in a worktree, so such a branch is kept.

**Transcript sanitization (before redaction).** Entire never modifies the agent's
own transcript, but the copy it stores goes through the agent's optional
`agent.TranscriptSanitizer` first, at the point Entire takes custody (the Stop path
in `lifecycle.go`, before `.entire/metadata/<session>/full.jsonl` is written). Codex
implements it to strip encrypted reasoning payloads and compaction blobs, which are
bound to the originating session and cannot be replayed out of a checkpoint.

Sanitization always runs before redaction, but the paths differ in whether image externalization happens at all:

| Path | Pipeline | Where |
|---|---|---|
| Stop (local copy) | sanitize only | `lifecycle.go` sanitizes before `full.jsonl` is written to `.entire/metadata/`; nothing is redacted because nothing is committed |
| Post-commit condensation | sanitize → externalize → redact | `prepareTranscriptForStorage` in `manual_commit_condensation.go` |
| Stop finalize (full-session rewrite) | sanitize → externalize → redact | `manual_commit_hooks.go`, before `extractSessionImages` |

**Image externalization runs only on the committed paths** (condensation and finalize). Assets and the `assets/manifest.json` index exist only under committed checkpoints.

Where all three steps run, each must precede the next. Sanitizing first avoids
externalizing images out of items that are about to be discarded — that would store
an asset whose referencing transcript line disappears moments later — and avoids
redacting megabytes of ciphertext only to throw it away; base64 is the pathological
input for the entropy layer, so a large Codex rollout otherwise costs tens of seconds
per Stop *and* per commit. Externalizing before redaction is required because base64
is high-entropy and redaction would otherwise flag and destroy it.

The sanitize transform is idempotent, so a downstream write path can call it without
knowing whether an upstream path already did (`checkpoint.sanitizeForAgentType` is
the store's own belt-and-braces call).

One coupling to respect when changing this: `SessionState.CheckpointTranscriptSize` is a growth baseline compared against the size of the stored `full.jsonl` copy in `sessionHasNewContent` (`storedTranscriptSize`), so it must be measured in the same (sanitized) coordinate — see `CondenseResult.TranscriptSizeBaseline`. A raw baseline against a sanitized copy makes the comparison false forever and the session silently stops condensing.

### Task Records (Subagent Work)

A subagent invocation (Claude Code's Task tool) is captured through a durable
**task record** — `session.TaskRecord` (json `task_records`) on session state
(`session/state.go`): `ToolUseID`, `AgentID`, `StartedAt`, `SubagentType`,
`TaskDescription`, `DeclaredTranscriptPath`, `Files`, `TokenUsage`,
`TokenUsageFromTranscript`, `CompletedAt` (zero = still in flight). Mid-turn
the record is a **pointer, not a payload**: the subagent's transcript stays
wherever the agent wrote it, and the record remembers how to find it — the
transcript path the agent's stop hook declared (Claude Code's
`agent_transcript_path`), with the agent-layout convention as fallback. Nothing
is written to git for task work mid-turn; the payload is materialized at
condensation (below).

**Task token usage.** When the completing event carries no usage, completion
computes it from the subagent's transcript and, except for Codex (whose child
usage comes from its rollout inventory), sets `TokenUsageFromTranscript`.
That read can be short: Claude Code fires `SubagentStop` before the agent's last
API call is in its transcript, and a background agent woken again by a child it
launched stops more than once while only its first stop completes the record.
Condensation therefore recounts a completed record's usage from the raw
transcript it reads for storage (before redaction, which could rewrite the
message IDs usage is deduplicated by), so `task.json`'s usage matches the
stored transcript. It keeps the recorded usage for agent-reported usage (Codex's
inventory usage, where nil is deliberate), live records (their usage would be
partial and stored again once complete), external agents (their usage comes
from what their binary's `read-transcript` returns), and a recount with fewer
API calls than recorded (a different or unparseable file). A re-wake after a
commit has already condensed and removed the record is not captured.

**Producers.**

- **Background launch**: Claude Code reports the launch mode in the Agent tool's PostToolUse `tool_response` (`status: "async_launched"` with `isAsync`, versus `"completed"` for foreground), which the parser carries as `agent.Event.SubagentLaunch`. That report wins; `tool_input.run_in_background` (a boolean or a boolean string) is only the fallback, because Claude Code usually runs Agent calls in the background without the model passing it. A background PostToolUse fires at the launch acknowledgment, seconds after dispatch, so the launch only records an in-flight record (with the `agentId` from the response) and captures nothing. `SubagentType`/`TaskDescription` are captured here because `SubagentStop`'s payload carries none of them.
- **Workflow agent launch** (subagent-start, non-final): agents a Claude Code Workflow launches have no Agent call of their own — the Workflow's PostToolUse reports a run ID, not agents — so Claude Code's `SubagentStart` hook (installed with matcher `workflow-subagent`; other agent types are ignored at parse time too) records each one's in-flight record, keyed by its `agent_id` as both `ToolUseID` and `AgentID`. The launch is `SubagentLaunchIdempotent`: an existing record for that key is kept rather than replaced, so a repeated `SubagentStart` cannot reset the record while it is still in session state; once condensation has materialized and removed a completed record, a late repeat would start a new live one. Their transcripts live in `subagents/workflows/<runId>/agent-<id>.jsonl`. The stop's `agent_transcript_path` is used only when it is exactly that file for this session and agent inside the parent's session directory, with no link below it; otherwise it is dropped and the layout lookup applies. That file's run becomes the event's `SubagentRunID`: a resumed run reuses its agents' IDs, so its launch can find the earlier run's completed record and add none, and the stop then completes a record of its own (keyed `<agent_id>`, or `<agent_id>-<runId>` while that key is taken) unless a record already holds the same run's transcript, which makes it a repeated stop. The transcript resolvers (`paths.ResolveSubagentTranscriptPath`) probe every run for an agent ID; the session's `subagent_tokens` total counts only the runs the transcript (or, at import, the turn's transcript prefix) launched, named by the Workflow launch's structured `toolUseResult.runId` (`taskType: local_workflow`) or, as a fallback, its result's `Run ID:` lines (`paths.WorkflowRunAgentTranscripts`). A Workflow launched from inside a subagent names its run in that subagent's transcript, not the parent's, so its agents get task records but are not counted in the parent session's `subagent_tokens` — the same limit nested `Agent` subagents have.
- **Forked skill launch** (post-task, non-final): a Claude Code skill with `context: fork` runs in an agent that Claude Code reports only in the Skill call's PostToolUse result (`status: "forked"`, `agentId`). Entire installs `PostToolUse[Skill]` → `post-task`, which records the launch under the Skill call's `tool_use_id` with that agent ID; the agent's `SubagentStop` completes it by agent ID. A result with `background: false` completes the record at once with files from the transcript only (`SubagentFilesFromTranscript`: no pre-task baseline exists for a Skill call); a missing `background` is treated as running. The agent can stop again when a background child wakes it; only the first stop updates the record.
- **Foreground completion** (post-task, non-final): PostToolUse fires at true completion, so the record is created-and-completed in one step, files and transcript path attached. Claude Code's foreground `SubagentStop` arrives just *before* this PostToolUse, when no record exists yet, and is a no-op.
- **SubagentStop (final, authoritative)**: the real completion signal for background tasks. Claude Code's payload carries `agent_id` but no `tool_use_id`, so `handleSubagentStopFinal` finds the record by `AgentID` (`FindTaskRecordByAgentID`, a live record before a completed one) and adopts its `ToolUseID`, which keys exactly-once completion and the checkpoint's `tasks/<tool_use_id>/` tree. It then completes the live record, bypassing any "no changes, skip" instinct: a read-only subagent (reviewer, search agent) still produced a transcript worth materializing. File attribution comes from the subagent's own transcript, never from a whole-worktree diff that would sweep in the parent's concurrent edits. Untracked files are the exception (`unrecordedNewFilesSinceLaunch`): a file created since launch (absent from the pre-task baseline) that no session in the worktree has recorded is claimed too, so a file a shell command created is not lost. Once the parent's next prompt starts it sits in that prompt's untracked baseline, and no later turn end would claim it. The accepted trade is that a file the user created while the parent was idle is claimed as well, which only adds a session link to the commit that carries it; files the parent's own turns or another session recorded are excluded. The claim is skipped when another background task in the worktree (`TaskRecord.Background`, set at every in-flight launch, which includes OpenCode's deferred launches, and by every background stop, including one that creates its record) ran during this one, still live or completed after this task's launch: a new file could then be either task's, and the first to stop would take both. Shell-side modifications of tracked files and deletions are still under-captured here; the parent's next turn end picks up modified tracked files through git status. A record already completed (duplicate/racing Final event) is skipped. Known gap: a subagent continued with `SendMessage` gets a second `SubagentStart`/`SubagentStop` under the same `agent_id` but no new Agent call, so its stop finds the completed record and the resumed run's edits are not attributed to the task.
- **SessionEnd sweep** (`completeLiveTaskRecords`): a session closing with
  tasks still in flight completes every remaining live record, strictly
  **before** `endSessionNow` marks `PhaseEnded` and eagerly condenses, so the
  condense materializes them.
- **Factory Droid Workers** upsert (`UpsertCompletedTaskRecord`): a worker
  spans multiple turns, so repeat completions merge files into the same record
  instead of claiming exactly-once.
- **OpenCode task tool**: `subagent-start` (parent task part bound to the child
  session) records the in-flight marker via `DeferredCompletion`;
  `subagent-stop` (`tool.execute.after`) completes the record through the
  Final path with `CompletionWithoutLaunch`, so a start the plugin never saw
  still completes. It declares no transcript: the capture exports the child
  through `agent.SubagentTranscriptFetcher` (`opencode export`) after its skip
  checks, declares it, and takes exact tokens from it — one export per stop. Child sessions fire no
  lifecycle hooks of their own. A child resumed through the task tool's
  `task_id` backs one record per call: the plugin's call start
  (`Event.SubagentStartedAt`, which becomes the record's `StartedAt`) cuts the
  declared export to that call's messages, so earlier calls' files and tokens
  are not attributed twice. A background task (`background: true`) fires its
  `subagent-stop` from the child's own idle rather than from the tool hook,
  which returns at launch; nested calls (`subagent_depth > 1`) are recorded on
  the top-level session. The SessionEnd sweep's capture of a task still in
  flight fetches the same way, so that record keeps its files and tokens; a
  failed fetch completes it transcript-unavailable and condensation tries
  again. The record key is the task part's `callID`, mapped to a path-safe
  key when it is not one. Some providers number calls per conversation, so a
  later call can reuse a `callID` whose start the plugin then deduplicates:
  its stop is matched to the records under that `callID` by child and call
  start (`completionRecordKey`), and a new call gets a key of its own,
  `<callID>-<child>[-<started_at ms>]`, rather than being skipped as a
  duplicate (see the OpenCode `AGENT.md`).

**Exactly-once completion.** Completion goes through
`strategy.CompleteTaskRecord`: one `MutateSessionState` closure marks
`CompletedAt` exactly once (a racing duplicate sees false and skips), attaches
the extraction results (files, token usage, declared transcript path) to the
claimed record, and merges files into the session's `FilesTouched`. Completion
happens **last**, after successful extraction, so a failed capture leaves the
record live for the SessionEnd sweep to retry. Late-arrival guard: a
`SubagentStop` whose parent session state is missing entirely skips outright —
re-creating state would resurrect a zombie session; state present but
`PhaseEnded` → complete the record, then eagerly condense
(`CondenseAndMarkFullyCondensed`) so it doesn't linger as post-condensation
data. Hard-killed agents get the same terminal state from the exited-owner
sweep (`finalizeExitedSessions`, run inside `entire doctor` and the session sweeper — not `entire status`, which is read-only), which
completes live records before ending the session — the transcript-so-far
still reaches a permanent checkpoint.

**Materialization (condensation).** `materializeTaskRecords`
(`manual_commit_condensation.go`) resolves each record's transcript — declared
path first, agent-layout fallback, and last an agent re-export through
`agent.SubagentTranscriptFetcher` for agents whose subagents are fetchable
sessions (OpenCode: a completed task whose stop hook's export failed; live
records are not re-exported, and all re-exports share one budget) —
runs the same sanitize → externalize →
redact pipeline the session transcript gets
(`prepareTaskTranscriptForStorage`), and writes
`tasks/<tool-use-id>/{agent-<agent-id>.jsonl, task.json}` inside the parent
session's checkpoint, on both persistent backends via the shared
`applySessionWrite`. An unresolvable, unreadable, or empty transcript still
gets a `task.json` carrying a stable, path-free
`transcript_unavailable_reason` — the record is never silently dropped.
Records with an empty/unsafe `ToolUseID` or `AgentID` are skipped with a
warning, never allowed to wedge condensation.

**Reading them back.** `checkpoint.TaskReader` (`ListTasks`,
`ReadTaskTranscript`; part of `PersistentStore`) reads the records through
one tree reader shared by both git backends (`task_reader.go`), re-validating
the directory name and `task.json`'s `agent_id` since both are pushed data.
`entire checkpoint explain --json` lists them under `tasks`, and
`--transcript --task <tool_use_id|agent_id>` streams one transcript.

**Self-contained checkpoints.** Live records are materialized too: each
condensation stores the transcript-so-far, so a mid-task commit carries a
partial transcript and a later checkpoint carries the full one — the same
self-containment rule the compact transcript follows. Live records survive
condensation for retry; completed records are removed only after a successful
write (`removeCompletedTaskRecords`, run from `resetCheckpointWindow`).

**Trigger currency.** "Does this session have task content?" is `State.HasTaskContent()` (`len(TaskRecords) > 0`), one of the inputs to `State.HasPendingWork()`, so a records-only session (no steps, empty parent transcript) still condenses. `checkpoint list --pending` lists records with `Running`/`Completed` verbs: inside the next-checkpoint preview for sessions in this worktree, and as `[Task]` rows for other sessions on HEAD.

The Claude Code post-todo hook records nothing and is no longer installed; installs prune it from configs older CLIs wrote, and its subcommand stays registered so those configs keep working. TodoWrite inside a subagent no longer produces an incremental checkpoint.

**Commit linkage while idle.** A background subagent's `git commit` normally
lands between the parent session's turns, while the session is IDLE — the
fast-path trailer decision (`tryAgentCommitFastPath`,
`strategy/manual_commit_hooks.go`) used to trust only ACTIVE sessions, so
these commits shipped with no `Entire-Checkpoint` trailer at all. An IDLE
session with a fresh in-flight task record (`idleWithLiveTaskRecord`, each
record bounded by its `StartedAt` age against
`activeSessionInteractionThreshold`, 24h) is now linkable too, so a subagent
that dies without a completion signal doesn't leave the session trusted
forever. A completed record confers no trust: its subagent can no longer be
the committer, and completion merged its files into `FilesTouched`, so the
ordinary overlap check links a commit that carries them. Trusting completed
records let a read-only reviewer's session condense into other sessions'
commits. The same predicate feeds `shouldCondenseWithOverlapCheck`'s
overlap-check bypass, so the trigger and the condensation trust share one
rule. The trailer's content guarantee is the materializer itself: the
commit's condensation stores each record's transcript-so-far under the
checkpoint's `tasks/` subtree (where one is on disk; an agent whose live
transcript needs a re-export, OpenCode, gets it once the task completes), so
no separate commit-time capture is needed. When another session also claims
the committed files and the session (IDLE, or ACTIVE while its background
subagent runs) has none of its own, it condenses only if a live record
modified a committed file (`liveTaskFilesInCommit`):
per the transcript on disk, or, for an agent with none yet, its own report
(`agent.LiveSubagentFileReporter`) within 10s for all of a commit's
sessions together (condensation's re-exports keep their own 30s per
session). The check reads the whole running call, so while it
runs, a later commit of the same file by another session credits the session
again even when the subagent added nothing since.
Ordinary idle commits with no task records are unaffected — they stay exactly
as before.

### Committed Checkpoints

Branch: `entire/checkpoints/v1`

Committed checkpoints sync to exactly one git remote — the elected checkpoint
sync remote, resolved in this order:

1. `strategy_options.checkpoint_push_remote` if set — fail-closed when it
   names a remote that is not configured (checkpoint sync is disabled until
   fixed, since this is explicit user intent).
2. The **captured** election, if its remote is still configured — fail-soft
   otherwise (capture is automatic state, so a renamed/removed remote falls
   through instead of disabling sync).
3. `origin`, if configured.
4. The sole configured remote.
5. The first remote in `.git/config` order.

**Capture** is how the election follows the user's actual push habit with
zero configuration: during pre-push, when the push target agrees with the
branch's declared push destination (`branch.<name>.pushRemote` →
`remote.pushDefault` → `branch.<name>.remote` — the config a bare `git push`
resolves through) and differs from the current election, that remote is
persisted as the captured election (git common dir,
`entire-checkpoint-sync-remotes.json`, list-shaped for the future multi-remote
set), a one-line stderr notice announces the change, and the same push carries
the checkpoints. Declaration alone never elects (the config-at-rest bug that
got the static tracking tier dropped in `74e239a9` — it turned pushes to every
other remote into silent no-ops, e.g. `git clone -o base` pushing a separately
added `origin`); a bare push to an undeclared remote never elects either (the
pre-single-remote transcript leak). Phase-1 rules: at most one captured
remote, and the first still-configured capture sticks — a mixed-habit repo whose branches push
two remotes must not flip the election per push. An explicit
`checkpoint_push_remote` always outranks and disables capture. See
`strategy/checkpoint_sync_capture.go`.

For the fork setup where `origin` is an unpushable base repo, capture elects
the fork automatically on the first tracked push; `checkpoint_push_remote`
remains the explicit override.

`entire enable` offers a named-remote picker during interactive **first-time**
setup when multiple remotes need resolution. It uses the existing election and
destination checks; it does not introduce another election tier. Keeping the
current selection writes no override — which is why a bare re-enable in a
configured repo never prompts: the conditions would be unchanged on the next
run, and there would be no way to say "stop asking" short of pinning a remote.
Selecting a different remote, or supplying `--checkpoint-push-remote <name>`
(the path for changing the destination later, and for repairing a saved remote
that no longer exists), persists an explicit override in the clone-local
settings file. The write preserves unrelated settings and is verified through
the effective settings loader before reporting success. On fresh enable, agent
selection precedes remote selection; both happen before hook/settings setup
side effects. Persistence happens after setup's settings saves but before
destination-dependent checkpoint initialization.

The picker is skipped for valid explicit or elected dedicated destinations,
disabled checkpoint pushing, a rejected local settings layer (the choice could
not be saved), and non-interactive invocations; `esc` at the picker means the
same as keeping the current destination. An explicit remote flag is still
honored without prompting and does not enable disabled pushing. Destination
selection does not migrate, publish, or delete existing remote checkpoint data.
Alternatives that still resolve to dedicated storage are not offered as
ordinary named destinations. The closing destination report runs after every
successful enable, with or without a terminal. It names the destination and
follows it with a privacy notice: checkpoints contain the agent transcripts, a
public destination makes them public, redaction is best effort, and how to stop
uploads or move them to a private repository. An unusable destination is
reported instead of the notice, unless pushes still upload to a dedicated
`checkpoint_remote`, which the remote election does not gate; the notice then
follows the report. How the destination was chosen, fan-out, and
alternatives are reported only when the destination was touched (explicit flag,
picker shown, or `--checkpoint-remote`); the multi-remote ambiguity note covers
the rest.

The pre-push hook carries checkpoint data only when the push targets the
elected remote; pushes to any other remote or to a raw URL sync nothing, on
both the git-branch and git-refs backends (git-refs leaves its push queue
intact for the next elected-remote push). The dedicated `checkpoint_remote`
URL mode is exempt — it addresses a separate metadata store directly. `entire
status` shows the sync destination and how many checkpoints have not reached
it yet. Git-refs push failures never block the user's push: refs stay queued, and
confirmed remote rejections show one bounded warning with the remote's reason
rather than being mislabeled as divergence (see [pre-push flow](ref-checkpoint-backend.md#pre-push-flow)).

A gated push is not fully silent: when checkpoints are waiting for the
elected remote, the hook prints a two-line stderr hint naming the elected
destination, the waiting count, and the `checkpoint_push_remote` setting
(pointed at `.entire/settings.local.json` — a remote name is a per-clone
fact) that re-routes sync to the remote being pushed. The hint stays quiet
when the election was explicit (`checkpoint_push_remote` is already set),
when the push target is a raw URL rather than a configured remote, when
nothing is waiting, when the election failed (the fail-closed case logs a
warning instead), and when the push target is not the branch's declared push
destination — a deploy target or a one-off `git push upstream` must never be
recommended as the checkpoint sync remote, which would publish transcripts
there. With capture taking a declared destination on the first agreeing push,
what remains for the hint is a declared remote capture will not elect because
one is already in force (phase-1 first-capture-sticks), where naming the
setting is genuinely the only way to re-route. See `hintGatedCheckpointSync` in
`strategy/checkpoint_sync_remote.go`.

**Reads follow the election.** Where writes confine to one remote, reads
consult an ordered candidate chain: the elected sync remote first, then
`origin` as a **read-only legacy tier** — every pre-election repo has its
checkpoint data on origin, and a fresh clone may lack the local settings that
elected something else. `strategy.CheckpointReadRemotes` (and
`CheckpointReadRemotesWithElection`, which bundles the election result for
callers that need both) resolves the chain, failing *open* to `[origin]` when
the election fails — failing reads closed would only prevent *finding* data.
Every checkpoint-data read iterates the chain per operation (metadata-branch
fetches, tracking-ref readers, per-checkpoint ref fetches, blob hydration).
Metadata-branch fetches refresh every candidate's tracking ref because branch
existence alone does not prove that branch contains the requested checkpoint;
they succeed when any candidate fetch succeeds.
Other reads try candidates in order, advancing on missing data or transport
failure and surfacing the first candidate's error when all fail. Local-ref
advancement stays **elected-remote-only** — `EnsurePrimaryRef`, the
metadata-fetch advance step, and `promoteRemoteTrackingPrimary` never act on
the legacy tier, keyed on the explicit election result rather than the chain's
first entry (a stale origin feeding `SafelyAdvanceLocalRef` would replay local
v1 onto stale history — the issue-#1374 hazard). Legacy
data on origin is therefore served through origin's *tracking ref* (resume's
final metadata tier and the store's tracking-ref fallback), never by moving
local refs. A repository with no remotes keeps its "checkpoint absent"
classification, which requires positive evidence on every axis (a successful
empty `git remote` listing, a live context, readable settings without a
`checkpoint_remote` key).

Metadata only, sharded by checkpoint ID. Supports **multiple sessions per checkpoint**:

```
<id[:2]>/<id[2:]>/
├── metadata.json        # CheckpointSummary (aggregated stats)
├── 0/                   # First session (0-based indexing)
│   ├── metadata.json    # Session-specific Metadata
│   ├── full.jsonl       # Agent transcript, sanitized + redacted (CLI resume/explain)
│   ├── transcript.jsonl # Full compacted session (slice at compact_transcript_start)
│   ├── prompt.txt       # Checkpoint-scoped user prompts
│   └── content_hash.txt # sha256 of full.jsonl (dedup short-circuit)
├── 1/                   # Second session
│   ├── metadata.json
│   ├── full.jsonl
│   └── ...
├── 2/                   # Third session...
└── tasks/<tool-use-id>/ # Subagent task records, materialized at condensation
    ├── agent-<agent-id>.jsonl # Subagent transcript, sanitized + redacted (omitted when unavailable)
    └── task.json        # Record metadata (files, tokens, timings, unavailable reason); description redacted at write
```

**Compact transcript (`transcript.jsonl`):** generated best-effort from
`full.jsonl` via `transcript/compact` on every committed write and on
transcript replacement during finalization. Like `full.jsonl`, it stores the
**full compacted session** on every checkpoint (via `compact.FullWithBoundary`),
so each checkpoint is self-contained — the session is reconstructable from any
single surviving checkpoint, robust to a mid-history checkpoint being lost,
reverted, or dropped during a rebase. This checkpoint's slice begins at the
session metadata's `compact_transcript_start` (a line offset into
`transcript.jsonl`, in compact-output coordinates — distinct from
`checkpoint_transcript_start`, which indexes raw `full.jsonl` lines).
Consumers segment this checkpoint's content as `compactLines[compact_transcript_start:]`.
The marker rounds toward inclusion when a streaming message straddles the
boundary (compaction merges same-ID fragments into one line that cannot be
split), so the slice never drops this checkpoint's content but its head may
repeat at most one merged line from the previous checkpoint — segmenters must
tolerate that bounded overlap. For an external agent that compacts its own
format, the marker is the number of leading lines its compaction of the raw
prefix shares byte-for-byte with the full compaction, which keeps the same
inclusion rule when the plugin merges lines across the boundary. A nil/absent `compact_transcript_start` marks a
legacy checkpoint whose `transcript.jsonl` holds only its own delta (pre-change
CLI versions); read it as-is from line 0.

It is written into the checkpoint tree and pushed alongside `full.jsonl`. The
root `metadata.json` `sessions[].transcript` pointer keeps targeting
`full.jsonl`; when a compact transcript was generated the session entry also
carries a `compact_transcript` path pointing at `transcript.jsonl` (omitted
otherwise) so external readers can find it next to `full.jsonl`.
CLI read paths (resume/explain) read `full.jsonl` by filename. Compact
generation is best-effort: failures are logged but never fail the checkpoint
write. It is also **skipped when the compacted output exceeds the 50MB blob cap**
— unlike `full.jsonl`, `transcript.jsonl` is not chunked, so a very long session
whose full compaction exceeds the cap will lack a compact transcript on those
checkpoints. This is a known limitation; `full.jsonl` remains authoritative and
the compact transcript is regenerable from it.

**Root-level metadata.json (`CheckpointSummary`):**
```json
{
  "cli_version": "0.0.0-dev",
  "checkpoint_id": "abc123def456",
  "strategy": "manual-commit",
  "branch": "main",
  "checkpoints_count": 3,
  "files_touched": ["file1.txt", "file2.txt"],
  "sessions": [
    {
      "metadata": "/ab/c123def456/0/metadata.json",
      "transcript": "/ab/c123def456/0/full.jsonl",
      "compact_transcript": "/ab/c123def456/0/transcript.jsonl",
      "content_hash": "/ab/c123def456/0/content_hash.txt",
      "prompt": "/ab/c123def456/0/prompt.txt"
    }
  ],
  "token_usage": {
    "input_tokens": 1500,
    "cache_creation_tokens": 200,
    "cache_read_tokens": 800,
    "output_tokens": 500,
    "api_call_count": 3
  }
}
```

`checkpoints_count` in the root summary is the aggregate displayed "steps" count: the sum of per-session prompt-window counts. Despite the historical name, it is not a count of checkpoint records.

**Session-level metadata.json (`Metadata`, abbreviated):**
```json
{
  "checkpoint_id": "abc123def456",
  "session_id": "2025-12-01-8f76b0e8-b8f1-4a87-9186-848bdd83d62e",
  "strategy": "manual-commit",
  "created_at": "2025-12-01T12:34:56Z",
  "branch": "main",
  "checkpoints_count": 3,
  "save_step_count": 3,
  "files_touched": ["file1.txt", "file2.txt"],
  "redaction": {
    "replacements": 3,
    "layers": {"entropy": 2, "betterleaks": 1, "custom": 1, "pii": 0},
    "custom_rules_active": 2,
    "pii": {"EMAIL": 0}
  }
}
```

`redaction` records what redaction replaced in the session's `full.jsonl`: placeholders written and matches per detection layer, never the values or custom rule names (see [Redaction counts in checkpoint metadata](../security-and-privacy.md#redaction-counts-in-checkpoint-metadata)). `full.jsonl` holds the whole session up to this checkpoint, so the counts grow across a session's checkpoints; take each session's latest checkpoint instead of adding them up. The example is abbreviated: every layer that ran is listed, with 0 when it found nothing. It is absent on checkpoints from older CLIs. The root `CheckpointSummary` carries the sum over its sessions under the same key, omitted when any session stored a transcript without counts.

In session metadata, `checkpoints_count` is the displayed prompt-window count for that session. `save_step_count` records the session's turn-end steps (`StepCount`) and is the conservative "real checkpoint work happened" signal; it is omitted when zero (for example, commit-only/fallback sessions). `save_step_count` is not aggregated into the root `CheckpointSummary`.

When condensing multiple concurrent sessions:
- All sessions are stored in numbered subdirectories using 0-based indexing (`0/`, `1/`, `2/`, ...)
- Each `session_id` is assigned a stable index; subsequent writes for the same session reuse the same numbered folder
- New `session_id` values are appended at the next index, so higher-numbered folders correspond to more recently introduced sessions, not necessarily the chronologically latest activity
- `sessions` array in `CheckpointSummary` maps each session to its file paths
- `files_touched` is merged from all sessions

`entire session attach <id> [--commit <rev>]` (default HEAD) picks how to
link from two facts about the target commit, the same for HEAD and `--commit`
(`planAttachLink`):
- the commit already carries an `Entire-Checkpoint` trailer: the session joins
  that checkpoint, and history is unchanged. If a remote branch holds the
  commit, the checkpoint is pushed now (there may be no later push of the
  commit to carry it); otherwise it goes with the next git push;
- a remote branch already holds the commit: the link is recorded in a new
  checkpoint (or joins one an earlier attach recorded for it) and the commit
  is left unchanged, so nothing needs a force-push;
- no remote holds it: the trailer is added, rewriting the commit and every
  commit after it up to HEAD (`attachRewriteChain`, `rewriteWithTrailer`).
  The replay reuses each tree, author and message through `git commit-tree`
  and moves the branch with a compare-and-swap `update-ref`, so the worktree
  and index are untouched and no commit hooks run; session state naming the
  old commits is remapped through `PostRewrite`. Merges after the target, a
  target off the current branch, and an operation in progress (rebase, merge,
  cherry-pick, revert, bisect) are refused, as is a commit with a non-UTF-8
  encoding or extra headers, which `commit-tree` can't reproduce. "No remote
  holds it" means no remote-tracking ref of any remote contains the commit,
  and none of the remotes the branch pushes to (its upstream and push remotes,
  else `origin`, else every remote) has a branch containing it: attach fetches
  those and asks each directly, fetching only branches whose tips aren't local
  (single-branch clones don't track every branch). If one can't be reached it
  refuses rather than rewrite a commit it couldn't check. The checkpoint of a
  pushed commit goes to the branch's remote even when only another remote
  (upstream in a fork) holds the commit.

Before writing anything attach prints what it will do (`attachWarning`): the
commits it rewrites, or the remote that holds the commit and that the
transcript is pushed now, plus author and rebase caveats. It asks on a
terminal; without one (an agent, a script) it changes nothing and exits
non-zero unless `--force` is passed, and agent-help tells agents to show the
user that output and pass `--force` only once they agree.

A session can be attached to several commits. Each checkpoint records the
turns since the session's previous checkpoint: the window starts at the
state's `CheckpointTranscriptStart` (recorded as the checkpoint's
`checkpoint_transcript_start`, with prompts, turn count and token usage
scoped to it), and an ended session's offset then advances to the transcript
end in the agent's own position metric. A running session's offset belongs to
its hooks and is left alone. The state's `TokenUsage` stays the whole
session's. Re-attaching a session to the checkpoint that already holds it is a
no-op.

A recorded link is `linked_commits` on the root `CheckpointSummary`: a list of
`{sha, repo}` objects (`repo` is `<forge>/<owner>/<repo>` from the remote that
holds the commit, possibly empty). Unlike the import anchor below it is an
**attributing** link: the server credits a verified entry as it would a
trailer. The CLI can't verify who recorded a link (anyone who can push checkpoints
can name any commit), so `explain` and `blame`/`why` label commits and lines
found through one as unverified recorded links, and lookups ignore checkpoints
dated in the future. Unlike a trailer it names one exact commit, so it does not follow a
later rebase or amend of that commit; attach says so, and the remedy is to
attach the session to the new commit. The server
verifies it only when the authenticated checkpoint pusher is the commit's
author (otherwise it is stored as an unverified attachment; attach warns when
the local git author differs). Rewrites of the checkpoint keep existing entries
(`unionLinkedCommits`). Readers consult trailers first and fall back to
`checkpoint.CheckpointsLinkedToWithStubs` (`explain <commit>`, `blame`/`why`,
and attach itself), which also reads git-refs stubs discovered on a remote
that were minted no earlier than a day before the commit. Attach
pushes the checkpoint itself through the pre-push path, since no later push may
carry it, and confirms the remote's ref now matches before reporting success:
for a pushed commit the checkpoint is the only record of the link, so a skipped
or rejected push (push_sessions off, remote gating) is an error. A second
attach to a linked commit finds the checkpoint through every copy, fetches it
into the local store through the availability guard, and joins it. Git hooks keep writing trailers while a commit is made; nothing in
Entire rewrites a commit that a remote already holds. A CLI that predates the
field drops it if it rewrites that checkpoint's root metadata.

Checkpoints written by the import path — `entire import <agent>` and `entire
enable`'s optional history import — additionally carry a `commit_sha`
(omitempty) on both the session `Metadata` and the root `CheckpointSummary`,
set to the default branch's head at import time — origin's tip is preferred
(the commit the server already knows about), falling back to the local branch
tip, then HEAD. Each candidate must resolve to an actual commit object, and an
import that finds none (an empty repository, say) is refused before anything is
written rather than producing anchorless checkpoints; onboarding reports the
same condition and skips its optional import instead of failing `entire
enable`. When the transcript itself
records the commit(s) a turn made (Claude Code `gitOperation` records), the
turn's checkpoint instead anchors to the last such commit that resolves and is
reachable from the resolved link anchor (the default-branch head when
resolvable) — see `turnAnchorResolver` (`agentimport/turn_anchor.go`);
otherwise (older transcripts, or a recorded commit that's been
squashed/rebased away) it falls back to the default-branch head as described
above. It is an anchor for UI display only, not an attribution signal — an
imported session's local `session.State.BaseCommit` stays empty — and
pre-existing imported checkpoints are not backfilled with it.

### Checkpoint ID Linking

The checkpoint ID is the **stable identifier** that links user commits to metadata across branches.

**Format:** one of two shapes — do **not** assume a fixed width:
- **Legacy 12-hex** random ID (e.g., `a3b2c4d5e6f7`) — the git-branch store's format.
- **26-char ULID** (Crockford base32, e.g., `01KVBJCWYA4YW6J5M9GP655HZN`) — minted only
  under the git-refs checkpoint store. A ULID's leading chars encode a millisecond
  timestamp (so it is lexicographically time-sortable) and its tail is random; front
  prefixes are therefore ambiguous — trim ULIDs from nowhere / show them in full for
  display (see `id.CheckpointID.DisplayShort`), and use `id.MaxIDLength`, not a
  hardcoded 12, when reasoning about maximum width.

Both formats are validated by `id.KindOf` / `id.Validate`; readers accept either.

**Read routing (`checkpoint.Open` → `kindRoutingStore`):** id-keyed reads resolve
across both git backends by the checkpoint's format, so a repo running git-refs
and git-branch side by side (or mid-migration) reads either format without
reconfiguring:
- A **ULID** is read from the git-refs store only — never the branch.
- A **hex** ID is read from the active (configured) primary first; when the
  primary is git-refs it also falls back to the git-branch store (a hex checkpoint
  may still sit on the pre-migration v1 branch, or have been migrated into refs).
- `List` unions both backends. **Creates (`Session`) are not kind-routed** — they
  go to the configured primary (+ mirrors); the minted ID already matches the
  primary. **Backfills** (summary/transcript) update an existing
  checkpoint and ARE kind-routed: they follow the read order, falling through to
  the next store only on `ErrCheckpointNotFound`.

**Generation:**
- Minted by `checkpoint.GenerateCheckpointID`, which picks the format from the
  configured primary store (ULID under git-refs, 12-hex otherwise). Do not call
  `id.Generate()` / `id.GenerateULID()` directly from a checkpoint write path.
- Generated during condensation (post-commit hook)

**Usage:**

1. **User commit trailer**:
   - `Entire-Checkpoint: a3b2c4d5e6f7` added to user's commit message
   - Added by `prepare-commit-msg` hook (user can remove)

2. **Directory sharding** on `entire/checkpoints/v1`:
   - Path: `<id[:2]>/<id[2:]>/` (e.g., `a3/b2c4d5e6f7/`)
   - First 2 chars = shard (256 possible shards)
   - Remaining 10 chars = directory name

3. **Commit subject** on `entire/checkpoints/v1`:
   - Format: `Checkpoint: a3b2c4d5e6f7`
   - Makes `git log entire/checkpoints/v1` readable

**Bidirectional Lookup:**

```
User commit → Metadata:
  1. Extract "Entire-Checkpoint: a3b2c4d5e6f7" from commit message
  2. Read entire/checkpoints/v1 tree at a3/b2c4d5e6f7/

Metadata → User commits:
  Given checkpoint ID a3b2c4d5e6f7
  → Search branch history for commits with "Entire-Checkpoint: a3b2c4d5e6f7"
```

Note: Commit subjects on `entire/checkpoints/v1` (e.g., `Checkpoint: a3b2c4d5e6f7`)
are for human readability in `git log` only. The CLI always reads from the tree at HEAD.

**Example Flow:**

```
                    User creates commit
                           ↓
           prepare-commit-msg hook adds trailer
                           ↓
┌──────────────────────────────────────────────────┐
│ Commit on main branch:                           │
│   "Implement login feature                       │
│                                                   │
│   Entire-Checkpoint: a3b2c4d5e6f7"               │
└──────────────────────────────────────────────────┘
                           ↓
                  post-commit hook runs
                           ↓
      Condense session → entire/checkpoints/v1
                           ↓
┌──────────────────────────────────────────────────┐
│ Commit on entire/checkpoints/v1:                 │
│   Subject: "Checkpoint: a3b2c4d5e6f7"            │
│                                                   │
│   Tree: a3/b2c4d5e6f7/                           │
│     ├── metadata.json                            │
│     │   (checkpoint_id: "a3b2c4d5e6f7")          │
│     ├── 0/                                       │
│     │   ├── full.jsonl                           │
│     │   ├── transcript.jsonl                     │
│     │   └── prompt.txt                           │
│     └── ...                                      │
│                                                   │
│   Trailers:                                      │
│     Entire-Session: 2026-01-20-uuid              │
│     Entire-Strategy: manual-commit               │
└──────────────────────────────────────────────────┘
```

The checkpoint ID creates a **bidirectional link**: user commits can find their metadata, and metadata can find the commits that reference it.

### Deleting a Checkpoint

`entire checkpoint delete <id>` removes one checkpoint from this clone and from
every checkpoint remote that holds it (`--remote` narrows that, `--local-only`
skips remotes without contacting them, `--dry-run` only reports). The summary
names every holder a narrowed delete left alone. Mechanics are in the
[ref backend](ref-checkpoint-backend.md#non-force-fast-forward-only) reference.
What it means for the domain model:

- **Sessions and checkpoints are many-to-many, and each checkpoint carries the
  session's full compacted transcript.** Deleting one checkpoint removes almost
  none of a long session's content: any remaining checkpoint of that session
  can rebuild it. The command lists other local checkpoints of the same
  sessions (a local, capped scan) and deletes none of them; the session stays
  visible on entire.com while any remain.
- **Token totals.** Each session entry stores the token delta since the previous
  condensation, so removing a checkpoint subtracts its delta from server-side
  session sums. Local `SessionState` token offsets, usage and baselines are
  never touched: resetting any of them would make the next checkpoint
  re-count tokens surviving checkpoints already carry.
- **Session state.** States holding the ID lose `LastCheckpointID` (and its
  commit hash), a matching `CondensationAttempt`, and the ID in
  `TurnCheckpointIDs`, so an amend cannot restore the trailer and a pending
  condensation cannot re-create the checkpoint. Clearing `LastCheckpointID`
  makes an ended state eligible for cleanup. A session that has not ended
  blocks the delete unless `--force` is passed.
- **Commits keep their trailers.** `explain` on such a commit reports
  "checkpoint not found (deleted with `entire checkpoint delete`)" when the ID
  is on this clone's deleted-checkpoints list, and a plain not-found otherwise.
  Every `prepare-commit-msg` outside a rebase, cherry-pick or revert (not only
  an amend) drops every whole `Entire-Checkpoint` line after the subject whose
  ID is on that list (wherever git would see a trailer), an amend never
  preserves a deleted ID, and squash/redo inheritance skips those IDs; new
  agent work in an amend gets a fresh ID.
- **The `v1` branch keeps history.** A checkpoint (of any ID kind; a git-branch
  mirror stores ULIDs there too) is removed from the branch tip; its content
  stays in the branch history on every remote.
- **On the git-branch primary, a delete must not leave a v1 push destination
  holding the copy.** The local removal is a `v1` commit, and the next
  pre-push fast-forwards every destination (each pushurl of the sync remote,
  or the dedicated `checkpoint_remote` URL derived from any remote) to it,
  deleting those copies too. `--local-only` probes only those destinations; a
  delete whose selection leaves one out is refused before anything is written
  when that destination holds a `v1` copy (remedy: also delete there, or use
  the git-refs backend) or cannot be reached (remedy: retry once reachable).
  Known limitations: a push to a not-yet-elected remote can elect it on the
  spot (capture) and send `v1` there; such a remote is not checked. A
  dedicated `checkpoint_remote` URL derived from a remote spelling this clone
  cannot authenticate to probes as unreachable, so the refusal ("retry when
  reachable") persists until that spelling works. With
  `push_sessions` disabled nothing is pushed, but re-enabling it later carries
  the removal to the sync remote.
- **Local and remote `v1` stay in one line.** After the removal is pushed to
  a `v1` push destination, local `v1` is rebuilt on that pushed commit (local
  unpushed checkpoints replayed on top), so the next push is a fast-forward. This happens only
  when the two removal commits are the whole difference: a remote that was
  ahead or rewritten before the delete is left for pre-push to reconcile, and with several pushurls only the first destination is
  adopted, so the others can still diverge.
- **`--local-only` copies can come back into view.** On git-refs, a read
  (explain, backfill) that misses locally fetches the remote copy and recreates
  the local ref. On git-branch, reads do not refetch a deleted local copy.
  Remote-tracking `v1` refs that hold the checkpoint are listed in the plan;
  they move only when that remote's copy is deleted.
- **Server side.** The CLI deletes the git data; removing indexed rows on
  entire.io is the backend's job when it observes the ref delete.

### Package Structure

```
strategy/
├── strategy.go          # Shared argument/result types (PendingCheckpoint, StepContext, ...)
├── manual_commit.go     # ManualCommitStrategy and its constructor

session/
├── state.go             # Active session state (StateStore, .git/entire-sessions/)
├── phase.go             # Session phase state machine (ACTIVE, IDLE, ENDED, etc.)

checkpoint/
├── aliases.go           # Re-exported store interfaces, write requests, CheckpointSummary, etc.
├── open.go              # Open() facade: resolves topology, wires stores + fetchers
├── registry.go          # Backend registry + gitBacked capability (git-branch, git-refs)
├── routing_store.go     # kindRoutingStore: id-kind read routing across both backends
├── fanout.go            # Mirror write fan-out (primary + best-effort mirrors)
├── generate.go          # GenerateCheckpointID (format follows the configured primary)
├── persistent.go        # git-branch persistent store (entire/checkpoints/v1)
├── persistent_write.go  # git-branch write path (treeWriter, subtree splicing)
├── refs_store.go        # git-refs persistent store (one ref per checkpoint)
├── refs_naming.go       # RefName / ParseRef, CheckpointRefPrefix, sharding
├── pushqueue.go         # git-refs push-discovery queue (flock JSONL)
├── fsstore/             # Filesystem mirror backend (non-git-backed, mirror-only)
├── id/                  # CheckpointID type, Kind/KindOf, ShardFor, generation
│   └── id.go
```

Strategies use the `checkpoint.Open` facade and store primitives - backend and storage details are encapsulated.

## Strategy Role

Strategies determine checkpoint timing and type:

| Event | Checkpoint Type |
|-------|----------------|
| On Turn End | Recorded in session state (no checkpoint) |
| On Task Complete | Task record on session state → materialized at condensation |
| On User Commit | Condense → Committed |

## Pending Checkpoints

Each `PendingCheckpoint` includes `SessionID` and `SessionPrompt` to help identify which checkpoint belongs to which session when multiple sessions are interleaved.

`checkpoint list --pending` lists work that is not a checkpoint yet, plus resume points. Turn-end work has no identity until a commit condenses it, so the listing leads with a **preview of the next checkpoint** (`ManualCommitStrategy.PreviewNextCheckpoint`): one entry per session in this worktree with pending work (`State.HasPendingWork`; fully condensed ended sessions are left out, as PostCommit skips them), showing the turns since the last checkpoint (`StepCount`), the files touched, its task records, and the prompts since the last checkpoint (prompt.txt, then the agent's transcript extractor from `CheckpointTranscriptStart`). The preview reads session state and local metadata only; it never prepares a transcript. In `--json` a preview is an id-less element with `"is_next_checkpoint": true` and a `next_checkpoint` object; the command help documents the shape.

After the preview, a `PendingCheckpoint` row is one of two things:

- a **task record** of a session based on HEAD, live or completed but not yet materialized by condensation — omitted for a session that already has a preview, since the preview lists its task records; or
- a **logs-only resume point** — a commit on the current branch whose `Entire-Checkpoint` trailer resolves to a checkpoint that *is* already condensed onto `entire/checkpoints/v1`, listed so its session transcript can be restored from there (file state would need a git checkout).

"Pending" describes the listing, not a guarantee that the work behind every row is un-condensed: `ListLogsOnlyPendingCheckpoints` builds the second kind by scanning branch history against committed checkpoint storage.

Either shape can be listed, but the CLI cannot restore working files to it: the file-restoring path (`Rewind`, `PreviewRewind`, `CanRewind`) was removed along with the `rewind` commands. `RestoreLogsOnly` still writes a checkpoint's session logs into the agent's session directory for `entire resume`, and leaves the worktree alone.

## Concurrent Sessions

Multiple AI sessions can run concurrently on the same base commit:

1. **Notice on start** - When a session starts while other sessions in the same worktree have pending steps or task content on the same base commit (`CountOtherActiveSessionsWithCheckpoints`), an informational message is shown
2. **Both proceed** - Each session keeps its own state file, touched files, and metadata directory
3. **Condensation** - On commit, every session whose touched files overlap the commit is condensed into the same checkpoint, each in its own numbered subfolder

---

## Appendix: Legacy Names

| Current | Legacy |
|---------|--------|
| Manual-commit | Shadow |
