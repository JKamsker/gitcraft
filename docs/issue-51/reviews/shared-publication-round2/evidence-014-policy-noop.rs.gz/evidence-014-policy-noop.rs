#![allow(dead_code)]
use std::{path::Path,collections::BTreeMap,cell::Cell};
const FILE_LIMIT:usize=8*1024*1024;
fn valid_path(_: &str)->Result<(),String>{Ok(())}
mod git{pub mod recovery{pub struct Pin{pub physical:String}pub struct Identity{pub host:Option<String>,pub root_pin:Option<Pin>,pub common:String}pub fn pinned_worktree(_: &std::path::Path,_:&dyn Fn()->bool)->Result<Identity,String>{Ok(Identity{host:None,root_pin:Some(Pin{physical:"/inert-recorded".into()}),common:String::new()})}pub fn pinned_parent(_: &std::path::Path,_:&std::path::Path,_:&str,_:&Pin)->Result<((),String),String>{panic!("equal bytes bypassed policy before parent was requested")}}}
mod native_files{
use std::{path::Path,collections::BTreeMap,sync::Arc};
#[derive(Clone,PartialEq,Eq)]pub struct Policy(pub &'static str);impl Policy{pub fn validate(&self)->Result<(),String>{Err("unsupported recorded policy".into())}}
pub type Policies=BTreeMap<String,Policy>;
pub enum CommitOutcome{Committed,Unknown(String)}
pub struct Directory;impl Directory{pub fn from_file(_:std::path::PathBuf,_:())->std::io::Result<Self>{unreachable!()}}
pub struct Snapshot{pub bytes:Vec<u8>,pub policy:Policy}impl Snapshot{pub fn read(_: &Directory,_:&str,_:usize)->Result<Option<Self>,String>{unreachable!()}}
pub struct Replacement;impl Replacement{pub fn prepare(_:Arc<Directory>,_:String,_:Option<Snapshot>,_:Option<&[u8]>,_:Option<&Policy>,_:Option<&str>)->Result<Self,String>{unreachable!()}pub fn evidence(&self)->String{unreachable!()}pub fn publish(&mut self)->Result<(),String>{unreachable!()}pub fn verify_installed(&self)->Result<(),String>{unreachable!()}pub fn rollback(&mut self)->Result<(),String>{unreachable!()}}
}
use native_files::{CommitOutcome,Policies};
type Contents=BTreeMap<String,Option<(String,Vec<u8>)>>;
fn native_apply(
    repo: &Path,
    before: &Contents,
    after: &Contents,
    policies: &Policies,
    check: &dyn Fn() -> Result<(), String>,
    commit: &dyn Fn(&str) -> Result<CommitOutcome, String>,
    restored_policy: Option<&Policies>,
    active: &dyn Fn() -> bool,
) -> Result<String, String> {
    use native_files::{Directory, Replacement, Snapshot};
    use std::sync::Arc;
    let identity = crate::git::recovery::pinned_worktree(repo, active)?;
    if identity.host.is_some() {
        return Err("Working-folder publication requires a native macOS/Linux checkout; no remote file changed".into());
    }
    let pin = identity.root_pin.as_ref().ok_or("Missing root identity")?;
    let mut items = Vec::new();
    for (path, target) in after {
        valid_path(path)?;
        let expected = before.get(path).ok_or("Missing before-file snapshot")?;
        if expected == target {
            continue;
        }
        let (held, name) = crate::git::recovery::pinned_parent(
            Path::new(&pin.physical),
            Path::new(&identity.common),
            path,
            pin,
        )?;
        let parent = Path::new(&pin.physical)
            .join(path)
            .parent()
            .ok_or("Missing parent")?
            .to_owned();
        let directory = Arc::new(Directory::from_file(parent, held).map_err(|e| e.to_string())?);
        let old = Snapshot::read(&directory, &name, FILE_LIMIT)?;
        if old.as_ref().map(|s| &s.bytes) != expected.as_ref().map(|(_, bytes)| bytes)
            || old.as_ref().map(|s| &s.policy) != policies.get(path)
        {
            return Err(format!(
                "{path} contents or full access policy changed since preview"
            ));
        }
        let policy = restored_policy
            .and_then(|p| p.get(path))
            .or_else(|| old.as_ref().map(|s| &s.policy))
            .cloned();
        if target.is_some() && restored_policy.is_some_and(|saved| !saved.contains_key(path)) {
            return Err(format!(
                "{path} has no saved full access policy; legacy mode-only undo is unavailable; no file changed"
            ));
        }
        if let Some(policy) = &policy {
            policy.validate()?;
        }
        items.push(Replacement::prepare(
            directory,
            name,
            old,
            target.as_ref().map(|(_, bytes)| bytes.as_slice()),
            policy.as_ref(),
            target.as_ref().map(|(mode, _)| mode.as_str()),
        )?);
    }
    let evidence = items
        .iter()
        .map(Replacement::evidence)
        .collect::<Vec<_>>()
        .join("; ");
    let result = (|| {
        check()?;
        for item in &mut items {
            if !active() {
                return Err("Working-folder publication cancelled".into());
            }
            check()?;
            item.publish()?;
        }
        check()?;
        for item in &items {
            item.verify_installed()?;
        }
        commit(&evidence)
    })();
    match result {
        Ok(CommitOutcome::Committed) => Ok(format!("Native recovery entries retained: {evidence}")),
        Ok(CommitOutcome::Unknown(message)) => Err(format!(
            "{message}. Publication is uncertain: current materialization and all original/candidate entries retained; no rollback attempted. Recovery: {evidence}"
        )),
        Err(error) => {
            let failures = items
                .iter_mut()
                .rev()
                .filter_map(|item| item.rollback().err())
                .collect::<Vec<_>>();
            if failures.is_empty() {
                Err(format!(
                    "{error}. Owned changes restored create-only. Recovery entries retained: {evidence}"
                ))
            } else {
                Err(format!(
                    "{error}. Attention required: {}. All recovery entries retained: {evidence}",
                    failures.join("; ")
                ))
            }
        }
    }
}
fn main(){
let before:Contents=[("f".into(),Some(("100644".into(),b"same".to_vec())))].into();let current:Policies=[("f".into(),native_files::Policy("current policy"))].into();
let saved:Policies=[("f".into(),native_files::Policy("saved different/unsupported policy"))].into();
for (label,policy) in [("different saved policy",saved),("missing legacy saved policy",Policies::new())]{let called=Cell::new(false);let result=native_apply(Path::new("/inert-recorded"),&before,&before,&current,&||Ok(()),&|_|{called.set(true);Ok(CommitOutcome::Committed)},Some(&policy),&||true);assert!(result.is_ok());assert!(called.get());println!("{label}: success and metadata commit dispatched without validating/restoring policy");}
}
