from pathlib import Path
import hashlib,json
s=Path('/tmp/gitcraft-shared-r2-825d-source/src/git/drafts/working_transaction.rs').read_text();a=s.index('fn native_apply(');b=s.index('\npub(super) fn apply(',a);f=s[a:b]
head=r'''#![allow(dead_code)]
use std::{path::Path,collections::BTreeMap,cell::Cell};
const FILE_LIMIT:usize=8*1024*1024;
fn valid_path(_: &str)->Result<(),String>{Ok(())}
mod git{pub mod recovery{pub struct Pin{pub physical:String}pub struct Identity{pub host:Option<String>,pub root_pin:Option<Pin>,pub common:String}pub fn pinned_worktree(_: &std::path::Path,_:&dyn Fn()->bool)->Result<Identity,String>{Ok(Identity{host:None,root_pin:Some(Pin{physical:"/inert-recorded".into()}),common:String::new()})}pub fn pinned_parent(_: &std::path::Path,_:&std::path::Path,_:&str,_:&Pin)->Result<((),String),String>{panic!("equal bytes bypassed policy before parent was requested")}}}
mod native_files{
use std::{path::Path,collections::BTreeMap,sync::Arc};
#[derive(Clone,PartialEq,Eq)]pub struct Policy(pub &'static str);impl Policy{pub fn validate(&self)->Result<(),String>{Err("unsupported recorded policy".into())}}
pub type Policies=BTreeMap<String,Policy>;
pub enum CommitOutcome{Committed,Unknown(String)}
pub struct Directory;impl Directory{pub fn from_file(_:std::path::PathBuf,_:())->std::io::Result<Self>{unreachable!()}}
pub struct Snapshot{pub bytes:Vec<u8>,pub policy:Policy}impl Snapshot{pub fn read(_: &Directory,_:&str,_:usize)->Result<Option<Self>,String>{unreachable!()}}
pub struct Replacement;impl Replacement{pub fn prepare(_:Arc<Directory>,_:String,_:Option<Snapshot>,_:Option<&[u8]>,_:Option<&Policy>,_:Option<&str>)->Result<Self,String>{unreachable!()}pub fn evidence(&self)->String{unreachable!()}pub fn publish(&mut self)->Result<(),String>{unreachable!()}pub fn verify_installed(&self)->Result<(),String>{unreachable!()}pub fn rollback(&mut self)->Result<(),String>{unreachable!()}}
}
use native_files::{CommitOutcome,Policies};
type Contents=BTreeMap<String,Option<(String,Vec<u8>)>>;
'''
main=r'''
fn main(){
let before:Contents=[("f".into(),Some(("100644".into(),b"same".to_vec())))].into();let current:Policies=[("f".into(),native_files::Policy("current policy"))].into();
let saved:Policies=[("f".into(),native_files::Policy("saved different/unsupported policy"))].into();
for (label,policy) in [("different saved policy",saved),("missing legacy saved policy",Policies::new())]{let called=Cell::new(false);let result=native_apply(Path::new("/inert-recorded"),&before,&before,&current,&||Ok(()),&|_|{called.set(true);Ok(CommitOutcome::Committed)},Some(&policy),&||true);assert!(result.is_ok());assert!(called.get());println!("{label}: success and metadata commit dispatched without validating/restoring policy");}
}
'''
e=Path('/tmp/gitcraft-shared-r2-825d-evidence');(e/'policy-noop.rs').write_text(head+f+main);(e/'adapter-seams.json').write_text(json.dumps({'exact_native_apply_sha256':hashlib.sha256(f.encode()).hexdigest(),'inert_doubles':'All filesystem/recovery dependencies stubbed; no native method or filesystem I/O can execute; exact native_apply body and supplied equal content maps only.'},indent=2)+'\n')
