//! Local evidence for staging-time coupling. Historical frequency is a hint, never a rule.
use super::{Reader, oid};
use std::{
    collections::{BTreeMap, BTreeSet},
    path::Path,
};
const COMMITS: usize = 600;
const BULK: usize = 20;
#[derive(Clone, Debug)]
pub(crate) struct Record {
    pub id: String,
    pub subject: String,
    pub files: BTreeSet<String>,
}
#[derive(Clone, Debug, Default)]
pub(crate) struct History {
    pub records: Vec<Record>,
    pub skipped: usize,
    pub limited: bool,
    pub notes: Vec<String>,
}
#[derive(Clone, Debug)]
pub(crate) struct Hint {
    pub source: String,
    pub companion: String,
    pub source_changes: usize,
    pub evidence: Vec<(String, String)>,
}
fn generated(path: &str) -> bool {
    path.split('/').any(|p| {
        matches!(
            p,
            "vendor" | "node_modules" | "target" | "dist" | "generated" | ".next" | "build"
        )
    }) || path.ends_with(".lock")
        || matches!(path, "package-lock.json" | "yarn.lock" | "pnpm-lock.yaml")
        || path.ends_with(".min.js")
        || path.ends_with(".min.css")
        || path.ends_with(".map")
        || path.ends_with(".g.cs")
}
fn header(fields: &[&[u8]], i: usize) -> bool {
    fields.get(i) == Some(&&b""[..])
        && fields.get(i + 1) == Some(&&b""[..])
        && fields
            .get(i + 2)
            .is_some_and(|b| std::str::from_utf8(b).is_ok_and(oid))
        && fields.get(i + 4) == Some(&&b""[..])
        && fields.get(i + 5) == Some(&&b""[..])
}
fn parse(bytes: &[u8]) -> Result<History, String> {
    if bytes.last() != Some(&0) {
        return Err("Truncated coupling history".into());
    }
    let fields = bytes.split(|b| *b == 0).collect::<Vec<_>>();
    let mut out = History::default();
    let mut i = 0;
    while i + 1 < fields.len() {
        if !header(&fields, i) {
            if fields[i].is_empty() {
                i += 1;
                continue;
            }
            return Err("Malformed coupling history header".into());
        }
        let id = std::str::from_utf8(fields[i + 2])
            .map_err(|_| "Invalid history ID")?
            .to_owned();
        let subject = String::from_utf8_lossy(fields[i + 3])
            .chars()
            .take(300)
            .collect::<String>();
        i += 6;
        let mut files = BTreeSet::new();
        let mut first = true;
        let mut unsupported = false;
        while i + 1 < fields.len() && !header(&fields, i) {
            let raw = if first {
                first = false;
                fields[i].strip_prefix(b"\n").unwrap_or(fields[i])
            } else {
                fields[i]
            };
            i += 1;
            if raw.is_empty() {
                continue;
            }
            let Ok(path) = std::str::from_utf8(raw) else {
                unsupported = true;
                continue;
            };
            if path.chars().any(char::is_control)
                || path.starts_with('/')
                || path
                    .split('/')
                    .any(|p| matches!(p, "" | "." | ".." | ".git"))
            {
                unsupported = true;
                continue;
            }
            files.insert(path.to_owned());
        }
        let title = subject.to_ascii_lowercase();
        if unsupported
            || files.len() > BULK
            || files.is_empty()
            || title.starts_with("generated ")
            || title.starts_with("regenerate ")
            || title.starts_with("auto-generated")
            || files.iter().filter(|p| generated(p)).count() * 2 >= files.len()
        {
            out.skipped += 1;
            continue;
        }
        files.retain(|p| !generated(p));
        out.records.push(Record { id, subject, files });
        if out.records.len() + out.skipped > COMMITS + 1 {
            return Err("Coupling history exceeded commit budget".into());
        }
    }
    Ok(out)
}
// Eligibility comes from the same immutable HEAD used by the history cache.
// Deleted paths, old rename names, links and gitlinks cannot be actionable hints.
fn eligible_paths(tree: &[u8]) -> Result<BTreeSet<String>, String> {
    if !tree.is_empty() && tree.last() != Some(&0) {
        return Err("Truncated pinned coupling tree".into());
    }
    let mut paths = BTreeSet::new();
    for entry in tree.split(|b| *b == 0).filter(|e| !e.is_empty()) {
        let tab = entry
            .iter()
            .position(|b| *b == b'\t')
            .ok_or("Malformed pinned coupling tree")?;
        let header = std::str::from_utf8(&entry[..tab]).map_err(|_| "Invalid pinned tree entry")?;
        let fields = header.split(' ').collect::<Vec<_>>();
        if fields.len() != 3 || !oid(fields[2]) {
            return Err("Invalid pinned tree object".into());
        }
        if !matches!(fields[0], "100644" | "100755") || fields[1] != "blob" {
            continue;
        }
        let Ok(path) = std::str::from_utf8(&entry[tab + 1..]) else {
            continue;
        };
        if path.chars().any(char::is_control)
            || path
                .split('/')
                .any(|part| matches!(part, "" | "." | ".." | ".git"))
            || generated(path)
        {
            continue;
        }
        paths.insert(path.to_owned());
    }
    Ok(paths)
}
fn retain_current_paths(history: &mut History, current: &BTreeSet<String>) {
    let mut omitted = BTreeSet::new();
    for record in &mut history.records {
        record.files.retain(|path| {
            let keep = current.contains(path);
            if !keep {
                omitted.insert(path.clone());
            }
            keep
        });
    }
    if !omitted.is_empty() {
        history.notes.push(format!("{} historical paths are absent or ineligible at the pinned HEAD and omitted from actionable hints. Rename identities are not guessed.", omitted.len()));
    }
}
pub(crate) fn load(repo: &Path, head: &str, active: &dyn Fn() -> bool) -> Result<History, String> {
    if !oid(head) {
        return Err("Coupling needs a pinned committed HEAD".into());
    }
    let reader = Reader::new(repo, active);
    let bytes = reader.run(
        &[
            "log",
            "-n601",
            "--no-merges",
            "--no-ext-diff",
            "--no-textconv",
            "--no-renames",
            "--no-show-signature",
            "--format=%x00%x00%H%x00%s%x00%x00",
            "--name-only",
            "-z",
            head,
            "--",
        ],
        vec![],
        &[0],
    )?;
    let mut history = parse(&bytes)?;
    if history.records.len() + history.skipped > COMMITS {
        history.limited = true;
        history.records.truncate(COMMITS);
    }
    let all = history
        .records
        .iter()
        .flat_map(|r| r.files.iter().cloned())
        .collect::<BTreeSet<_>>();
    if all.len() > 10000 {
        return Err("Coupling history exceeds 10000 distinct paths".into());
    }
    let mut input = Vec::new();
    for p in &all {
        input.extend_from_slice(p.as_bytes());
        input.push(0);
    }
    let attrs = reader.run(
        &[
            "check-attr",
            &format!("--source={head}"),
            "-z",
            "linguist-generated",
            "generated",
            "--stdin",
        ],
        input,
        &[0],
    );
    match attrs {
        Ok(bytes)=>{
            let fields=bytes.split(|b|*b==0).filter(|f|!f.is_empty()).collect::<Vec<_>>();
            if fields.len()%3!=0{return Err("Malformed generated-file attributes".into());}
            let mut excluded=BTreeSet::new();for triple in fields.chunks_exact(3){if matches!(triple[2],b"set"|b"true"){let path=std::str::from_utf8(triple[0]).map_err(|_|"Invalid attribute path")?;excluded.insert(path.to_owned());}}
            history.records.retain_mut(|record|{let generated=record.files.intersection(&excluded).count();if generated*2>=record.files.len(){history.skipped+=1;return false;}record.files.retain(|p|!excluded.contains(p));true});
        },
        Err(_)=>history.notes.push("Generated attributes could not be read at this commit; known generated paths and commit subjects were excluded. Git 2.43+ supports pinned attribute queries.".into())
    }
    let tree = reader.run(
        &["ls-tree", "-r", "-z", "--full-tree", head, "--"],
        vec![],
        &[0],
    )?;
    retain_current_paths(&mut history, &eligible_paths(&tree)?);
    if reader.run(&["rev-parse", "--is-shallow-repository"], vec![], &[0])? == b"true\n" {
        history.limited = true;
        history
            .notes
            .push("Shallow repository: older cochanges are unavailable locally.".into());
    }
    history.notes.push("Sample: latest 600 nonmerge commits. Bulk changes (>20 files), generated commit subjects, generated paths and generated attributes are excluded. Only regular, nongenerated files present at the pinned HEAD are actionable. At least three shared changes and 60% source confidence are required; this is historical association, not proof of a missing change.".into());
    Ok(history)
}
pub(crate) fn rank(
    history: &History,
    staged: &BTreeSet<String>,
    changed: &BTreeSet<String>,
) -> Vec<Hint> {
    let mut hints = Vec::new();
    for source in staged.iter().take(200) {
        let records = history
            .records
            .iter()
            .filter(|r| r.files.contains(source))
            .collect::<Vec<_>>();
        if records.len() < 3 {
            continue;
        }
        let mut together = BTreeMap::<String, Vec<(String, String)>>::new();
        for record in &records {
            for path in &record.files {
                if path != source && !changed.contains(path) {
                    together
                        .entry(path.clone())
                        .or_default()
                        .push((record.id.clone(), record.subject.clone()));
                }
            }
        }
        for (companion, evidence) in together {
            if evidence.len() >= 3 && evidence.len() * 100 >= records.len() * 60 {
                hints.push(Hint {
                    source: source.clone(),
                    companion,
                    source_changes: records.len(),
                    evidence,
                });
            }
        }
    }
    hints.sort_by(|a, b| {
        (b.evidence.len() * a.source_changes)
            .cmp(&(a.evidence.len() * b.source_changes))
            .then_with(|| b.evidence.len().cmp(&a.evidence.len()))
            .then_with(|| a.companion.cmp(&b.companion))
    });
    hints.truncate(20);
    hints
}

#[cfg(test)] mod frozen_pure {use super::*;
    #[test]
    fn pure_cochange_current_tree_omits_deleted_renamed_and_nonregular_companions() {
        let id = "a".repeat(40);
        let tree = format!(
            "100644 blob {id}\tserializer.rs\0100644 blob {id}\tcurrent.fixture\0100644 blob {id}\trenamed.fixture\0120000 blob {id}\tlink.fixture\0160000 commit {id}\tsubmodule\0100644 blob {id}\tgenerated/out.rs\0"
        );
        let eligible = eligible_paths(tree.as_bytes()).unwrap();
        let files = BTreeSet::from(
            [
                "serializer.rs",
                "current.fixture",
                "deleted.fixture",
                "old-name.fixture",
                "link.fixture",
                "submodule",
                "generated/out.rs",
            ]
            .map(str::to_owned),
        );
        let mut history = History {
            records: (0..3)
                .map(|n| Record {
                    id: format!("{n:040x}"),
                    subject: format!("change {n}"),
                    files: files.clone(),
                })
                .collect(),
            ..Default::default()
        };
        retain_current_paths(&mut history, &eligible);
        let staged = BTreeSet::from(["serializer.rs".into()]);
        let hints = rank(&history, &staged, &staged);
        assert_eq!(hints.len(), 1);
        assert_eq!(hints[0].companion, "current.fixture");
        assert_eq!(hints[0].source_changes, 3);
        assert_eq!(
            hints[0].evidence,
            (0..3)
                .map(|n| (format!("{n:040x}"), format!("change {n}")))
                .collect::<Vec<_>>()
        );
        assert!(!history.notes.is_empty());
        assert!(eligible_paths(b"truncated").is_err());
    }

}
