#![allow(dead_code)]
use std::{path::Path,cell::RefCell,rc::Rc};
type Route=Rc<dyn Fn(&[&str],&[u8])->Result<Vec<u8>,String>>;
thread_local! {static ROUTE:RefCell<Option<Route>>=RefCell::new(None);}
pub struct Reader<'a>{active:&'a dyn Fn()->bool}
impl<'a> Reader<'a>{
 pub fn new(_: &'a Path,active:&'a dyn Fn()->bool)->Self{Self{active}}
 pub fn active(&self)->bool{(self.active)()}
 pub fn run(&self,args:&[&str],input:Vec<u8>,_:&[i32])->Result<Vec<u8>,String>{if !self.active(){return Err("recording cancellation".into())} ROUTE.with(|r|r.borrow().as_ref().ok_or("No recording route: external execution forbidden")?(args,&input))}
}
pub fn oid(s:&str)->bool{matches!(s.len(),40|64)&&s.bytes().all(|b|b.is_ascii_hexdigit())}
mod symbols;
mod cochange;
mod git {pub mod investigations {pub use crate::{Reader,oid};pub mod dossier {#[derive(Clone,Debug)]pub struct Seed{pub commit:String,pub path:String,pub line:usize}}}}
mod forge {
 #[derive(Clone,Copy,PartialEq,Eq)]pub enum Forge{GitHub,GitLab,Gitea,Forgejo}
 pub struct Hosting{pub forge:Forge,pub path:String,pub host:String,pub web:String}
 fn location(_: &str)->Option<(String,String)>{None}
 mod http{pub struct Api;impl Api{pub fn history_get(&self,_:&str,_:&dyn Fn()->bool)->Result<serde_json::Value,String>{Err("NETWORK FORBIDDEN".into())}}}
 mod cli{pub fn history_api(_: &super::Hosting,_:&str,_:&dyn Fn()->bool)->Result<serde_json::Value,String>{Err("NETWORK FORBIDDEN".into())}}
 mod gitea{pub fn history_api(_: &super::Hosting)->super::http::Api{super::http::Api}}
 #[path="/tmp/gitcraft-history-content-r2-harness/forge_history.rs"]mod history;
}
fn install(route:impl Fn(&[&str],&[u8])->Result<Vec<u8>,String>+'static){ROUTE.with(|r|*r.borrow_mut()=Some(Rc::new(route)));}
fn history(answer:symbols::Answer)->symbols::Biography{match answer{symbols::Answer::History(h)=>h,_=>panic!("history required")}}
#[test]
fn independent_recorded_full_symbol_rewrites_backward_and_forward(){
 let ids=(1..=3).map(|n|format!("{n:040x}")).collect::<Vec<_>>();
 let blobs=(11..=13).map(|n|format!("{n:040x}")).collect::<Vec<_>>();
 let bodies=vec!["fn calc() -> i32 { 1 }", "fn calc() -> i32 { 2 }", "fn calc() -> i32 { let items = [12, 37]; items.iter().sum() }"];
 let selected0=ids[0].clone();let head=ids[2].clone();let ids0=ids.clone();
 install(move |a,_|{
  let result=match a {
   ["rev-parse","--verify","--end-of-options",name]=>format!("{}\n",if name.starts_with(&ids[0]){&ids[0]}else{&ids[2]}).into_bytes(),
   ["rev-parse","--verify","HEAD"]=>format!("{}\n",ids[2]).into_bytes(),
   ["rev-list",..]=>format!("{}\n{}\n{}\n",ids[2],ids[1],ids[0]).into_bytes(),
   ["--literal-pathspecs","ls-tree","-z",at,"--",path]=>{assert_eq!(*path,"a.rs");let i=ids.iter().position(|v|v==at).unwrap();format!("100644 blob {}\ta.rs\0",blobs[i]).into_bytes()},
   ["cat-file","-s",blob]=>bodies[blobs.iter().position(|v|v==blob).unwrap()].len().to_string().into_bytes(),
   ["cat-file","blob",blob]=>bodies[blobs.iter().position(|v|v==blob).unwrap()].as_bytes().to_vec(),
   ["diff-tree",..]=>b"M\0a.rs\0".to_vec(),
   ["show","-s","--format=%P",at,"--"]=>{let i=ids.iter().position(|v|v==at).unwrap();if i==0 {b"\n".to_vec()}else{ids[i-1].as_bytes().to_vec()}},
   ["show","-s","--no-show-signature",_,at,"--"]=>format!("Author\x001700000000\x00subject {at}\x00").into_bytes(),
   ["cat-file","commit",at]=>{assert_eq!(*at,ids[0]);format!("tree {}\nauthor Fixture <f@invalid> 1 +0000\n\nRoot\n","f".repeat(40)).into_bytes()},
   _=>return Err(format!("UNRECORDED {a:?}"))
  };Ok(result)
 });
 for selected in [&selected0,&head]{let h=history(symbols::investigate(Path::new("/recording-only"),selected,"a.rs","calc",None,256,&||true).unwrap());assert!(!h.limited,"{h:?}");assert_eq!(h.steps.iter().filter(|s|s.event=="Created").map(|s|&s.commit).collect::<Vec<_>>(),vec![&ids0[0]]);assert_eq!(h.steps.iter().filter(|s|s.event.contains("Body edited")).count(),2);assert!(!h.steps.iter().any(|s|s.event.contains("Deleted")));}
 println!("Full production investigate route: backward/forward 1→2/full rewrite; one original creation, two edits, no death");
}
#[test]
fn independent_recorded_shallow_boundary_is_not_a_creation(){
 let head="3".repeat(40);let cut="2".repeat(40);let absent="1".repeat(40);let blob="b".repeat(40);let body="fn calc() -> i32 { 1 }";
 install(move |a,_|Ok(match a {
  ["rev-parse",..]=>format!("{head}\n").into_bytes(),
  ["rev-list",..]=>format!("{head}\n{cut}\n").into_bytes(),
  ["--literal-pathspecs","ls-tree",..]=>format!("100644 blob {blob}\ta.rs\0").into_bytes(),
  ["cat-file","-s",_]=>body.len().to_string().into_bytes(),
  ["cat-file","blob",_]=>body.as_bytes().to_vec(),
  ["diff-tree",..]=>b"M\0other.rs\0".to_vec(),
  ["show","-s","--format=%P",_,"--"]=>b"\n".to_vec(),
  ["show","-s","--no-show-signature",_,_,"--"]=>b"Author\0001700000000\000Unrelated cutpoint\0".to_vec(),
  ["cat-file","commit",_]=>format!("tree {}\nparent {absent}\nauthor Fixture <f@invalid> 1 +0000\n\nUnrelated cutpoint\n","f".repeat(40)).into_bytes(),
  _=>return Err(format!("UNRECORDED {a:?}"))
 }));
 let h=history(symbols::investigate(Path::new("/recording-only"),"HEAD","a.rs","calc",None,256,&||true).unwrap());assert!(h.limited);assert!(h.steps.iter().any(|s|s.event=="Earlier shallow boundary (creation unproven)"));assert!(!h.steps.iter().any(|s|s.event=="Created"));assert!(h.notes.iter().any(|s|s.contains("shallow")));
 println!("Production investigate route consumes stored parent even when recorded traversal %P is empty; no false creation");
}
#[test]
fn independent_recorded_cochange_load_pins_current_tree_and_preserves_evidence(){
 let head="a".repeat(40);let exact=head.clone();let count=Rc::new(RefCell::new(0));let observed=count.clone();
 install(move|a,_|Ok(match a{
  ["log",..]=>{assert!(a.contains(&head.as_str()));let mut b=vec![];for i in 1..=3{b.extend_from_slice(format!("\0\0{i:040x}\0change {i}\0\0\0\nserializer.rs\0compat.fixture\0old-name.fixture\0current.fixture\0").as_bytes())}b},
  ["check-attr",source,..]=>{assert_eq!(*source,format!("--source={head}"));vec![]},
  ["ls-tree","-r","-z","--full-tree",tip,"--"]=>{assert_eq!(*tip,head);*observed.borrow_mut()+=1;format!("100644 blob {head}\tserializer.rs\0100755 blob {head}\tcurrent.fixture\0100644 blob {head}\trenamed.fixture\0120000 blob {head}\tcompat.fixture\0").into_bytes()},
  ["rev-parse","--is-shallow-repository"]=>b"false\n".to_vec(),
  _=>return Err(format!("UNRECORDED {a:?}"))
 }));
 let h=cochange::load(Path::new("/recording-only"),&exact,&||true).unwrap();assert_eq!(*count.borrow(),1);let staged=std::collections::BTreeSet::from(["serializer.rs".into()]);let hints=cochange::rank(&h,&staged,&staged);assert_eq!(hints.len(),1);assert_eq!(hints[0].companion,"current.fixture");assert_eq!(hints[0].source_changes,3);assert_eq!(hints[0].evidence.len(),3);assert!(h.notes.iter().any(|n|n.contains("2 historical paths")));println!("Production load requests pinned HEAD tree: absent/renamed/link companion omitted; current executable-file companion retains exact 3/3 evidence");
}

mod navigation;
