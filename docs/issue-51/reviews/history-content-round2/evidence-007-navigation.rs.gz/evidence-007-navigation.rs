use egui::{Ui,Key};
#[derive(Default)] struct Ghost(bool); impl Ghost {fn drawing(&self)->bool{self.0}}
struct Saved(bool);impl Saved{fn active(&self)->bool{self.0}fn position(&self,raw:usize)->Option<usize>{match raw{0=>Some(0),1..=10=>Some(1),11=>Some(2),_=>None}}fn next(&self,raw:usize,down:bool)->Option<usize>{if down{(raw<11).then_some(11)}else{(raw>0).then_some(0)}}}
#[derive(Debug,PartialEq)] enum Action{Select(usize)}
struct RepoTab{saved_views:Saved,ghost:Ghost,timeline_view:Option<()>,scroll_to:Option<usize>,selected:Option<usize>,commits:Vec<()>}
impl RepoTab{fn diff_beside_graph(&self,_:&egui::Context)->bool{false}
    pub(super) fn graph_projection_displayed(&self) -> bool {
        self.saved_views.active() && !self.ghost.drawing() && self.timeline_view.is_none()
    }
    pub(super) fn take_graph_scroll_row(&mut self) -> Option<usize> {
        let raw = self.scroll_to.take_if(|_| !self.ghost.drawing())?;
        Some(if self.graph_projection_displayed() {
            self.saved_views.position(raw).unwrap_or(raw)
        } else {
            raw
        })
    }

    /// Up and down select the row above or below the selected one.
    /// `ringed`: the row Tab reaches, where they start while nothing is selected.
    fn arrow_keys(&mut self, ui: &Ui, ringed: Option<usize>, acts: &mut Vec<Action>) {
        // Alt+↑ / Alt+↓ go from change to change of the diff shown below the graph.
        let below = self.diff_beside_graph(ui.ctx());
        let (up, down) = ui.input(|i| {
            let plain = !(below && i.modifiers.alt);
            (
                plain && i.key_pressed(Key::ArrowUp),
                plain && i.key_pressed(Key::ArrowDown),
            )
        });
        let current = self.selected.or(ringed).unwrap_or(0);
        let next = if self.graph_projection_displayed() && (up || down) {
            self.saved_views.next(current, down)
        } else if up {
            Some(current.saturating_sub(1))
        } else if down {
            Some((current + 1).min(self.commits.len().saturating_sub(1)))
        } else {
            None
        };
        if let Some(next) = next {
            acts.push(Action::Select(next));
            self.scroll_to = Some(next);
        }
    }

}
fn tab()->RepoTab{RepoTab{saved_views:Saved(true),ghost:Ghost::default(),timeline_view:None,scroll_to:None,selected:Some(0),commits:vec![();12]}}
#[test] fn independent_mode_matrix_maps_scroll_only_when_projection_is_displayed(){for active in [false,true]{for ghost in [false,true]{for timeline in [false,true]{let mut t=tab();t.saved_views.0=active;t.ghost.0=ghost;t.timeline_view=timeline.then_some(());t.scroll_to=Some(11);let expected=active&&!ghost&&!timeline;assert_eq!(t.graph_projection_displayed(),expected);assert_eq!(t.take_graph_scroll_row(),if ghost{None}else if expected{Some(2)}else{Some(11)});if ghost{assert_eq!(t.scroll_to,Some(11))}else{assert_eq!(t.scroll_to,None)}}}}}
#[test] fn independent_headless_exact_arrow_method_uses_timeline_raw_rows(){let ctx=egui::Context::default();let mut t=tab();let frame=|t:&mut RepoTab,pressed:bool|{let mut actions=vec![];let mut out=ctx.run_ui(egui::RawInput{events:vec![egui::Event::Key{key:Key::ArrowDown,physical_key:None,pressed,repeat:false,modifiers:Default::default()}],..Default::default()},|ui|{t.arrow_keys(ui,None,&mut actions)});out.textures_delta.clear();actions};assert_eq!(frame(&mut t,true),vec![Action::Select(11)]);frame(&mut t,false);t.timeline_view=Some(());assert_eq!(frame(&mut t,true),vec![Action::Select(1)]);assert_eq!(t.scroll_to,Some(1));}
