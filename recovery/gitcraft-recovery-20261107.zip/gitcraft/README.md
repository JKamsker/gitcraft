# gitcraft

A visual git client: a simplified yet powerful take on the usual graph-based git GUIs.
Rust + [egui/eframe](https://github.com/emilk/egui), the same technical stack of the ArtCraft suite, so it builds on Windows, Linux and macOS and stays light and fast. It drives the installed `git` command line,
so your config, credentials and hooks apply as usual.

![gitcraft: branches, remotes and worktrees on the left, the graph with branch pills and relative dates, uncommitted changes on the right and the integrated terminal below](docs/screenshot.png)

## Practice git

Choose **Practice git…** on the start page or in the command palette. Each attempt opens a
new, clearly marked local throwaway repository: resolve a merge conflict, merge diverged
branches, rescue a detached HEAD, or undo an already published commit. The last scenario uses
a local bare `origin`, so pushing it contacts no server. The goal banner explains the task,
offers a hint and checks the real repository when you click **Check goal**. Reopening the tab
keeps its scenario. Setup and checks run in the background and never alter an existing repo.

Practice folders live in the system temporary directory. They are kept when you close the
tab; your system may delete them, so copy a folder elsewhere if you want to keep it. Starting
another attempt makes a fresh repository. The scenarios are local even when you also work in
WSL or over SSH. Git operations and terminals opened from a practice tab ignore inherited Git
repository overrides, profiles and global Git configuration. This keeps your caller's working
tree and Git settings out of the exercise. A practice terminal is still an ordinary shell:
commands you explicitly run can access other folders.

Pause the pointer over git words such as **HEAD**, **upstream**, **fast-forward** or **rebase**
to see a short glossary explanation. This also works in menus, the manual and graph labels.
Glossary tips stay out of the way while typing, scrolling or dragging.

## Features

**Repositories and tabs**

- Start page: checks that `git` is installed; open, create (`git init`) or clone a repository;
  recent repositories.
- Clone options: shallow history with a chosen depth, blobless partial clones, and selected
  folders (one path per line). With blobless and sparse combined, only checked-out file
  contents download initially. In an open
  repository, **Sparse checkout…** in the palette offers a folder tree, or a return to a full
  checkout. Root files and files immediately inside parent folders are always included. It
  refuses uncommitted, untracked or ignored files and asks before replacing custom non-cone
  patterns. Move ignored files outside the working tree first; Git can delete them during
  sparse changes, even when an ordinary status looks clean.
  Partial clones show a download notice; opening a historical file or diff whose contents
  are missing asks before Git downloads them. The server must support partial clones.
  These options run on the repository's machine, including WSL and SSH.
- Browser-like tabs, one per repository (Ctrl+T, Ctrl+W, middle-click; Ctrl+Shift+T reopens a
  closed one). Open tabs, recents, theme and settings are remembered.
- Profiles, as in GitKraken: switch between them from the title bar (or the palette). Each has
  its own open tabs, recent repositories, theme, git author, commit signing, SSH key and forge
  accounts (Settings → Profile); the other settings pages are shared. Switching closes this profile's tabs and opens the
  other one's (refused while a tab has unfinished work).
- Changes made elsewhere (editor, terminal) show up by themselves: the folder is watched.
- Repositories on another machine, in a WSL distribution or over SSH: the window stays here and
  git runs there (see below).

**Remote repositories (WSL, SSH)**

- Start page → _Remote_ (or the palette's _Open remote repository_): pick a WSL distribution
  or an SSH host (the hosts of `~/.ssh/config` are offered), and the repository's folder there
  (`/home/me/repo` or `~/repo`), typed or found with _Browse…_, which lists that machine's
  folders and marks its repositories. A `\\wsl.localhost\…` folder chosen with _Open_ is a WSL
  repository too, and `gitcraft ssh://host/path/to/repo` opens one from the command line.
- The window never waits for that machine: everything asked of it is asked in the background,
  and a slow or unreachable machine only shows as work still going on (anything asked of it
  from the window's thread is refused rather than run, and a test drives the window against a
  WSL repository to keep it so).
- git, and every file read or written in the repository (diffs of the working tree, staging
  lines, the conflict editor, `.gitignore`, rebase todo lists), runs on that machine, with its
  own git, config, credentials and hooks. Nothing has to be installed there but git and a POSIX
  `sh` with the tools any Linux, BSD or macOS has: `mktemp -d` (each shell's temporary
  folder), `base64 -d` (what a command reads, a patch or a file's new contents), `cat` and
  `wc` (passing output back), `stat` (GNU or BSD: noticing changes), and `ps` with `awk`
  (stopping a command that hung, and all it started).
- A few shells per machine are kept open (`ssh -T host sh`, `wsl.exe -d distro --exec sh`), so a
  command costs one round trip, not a new connection; history is read page by page in them
  too. SSH signs in as it does in a terminal (keys, an agent, `~/.ssh/config`;
  `GITCRAFT_SSH_CONFIG` names another config): what it asks — a password, a key's
  passphrase, whether to trust a host seen for the first time — is asked in the window (ssh
  runs gitcraft as its `SSH_ASKPASS`). A password or passphrase typed is kept for that machine
  while gitcraft runs, so the other shells don't ask again, and forgotten as soon as ssh says
  it was wrong. Tick **Remember connection** to keep it after a restart too: once ssh has
  signed in with it (a wrong one is never saved), it is saved encrypted in the system's
  credential store (Windows Credential Manager, the macOS Keychain, the Secret Service on
  Linux), never in gitcraft's own files, and forgotten when it stops working or with
  **Forget saved SSH sign-ins** in the command palette (or Settings → Git).
- Names with a `\` in them (Linux allows one) work like any other.
- Network operations (fetch, pull, push, clone) run in shells of their own, so the reads never
  wait behind them. A command that hangs is stopped there, with what it started, after 5
  minutes (30 for network operations).
- Changes made there show up by themselves: the repository is looked at every few seconds
  (every 15 while the window isn't focused).
- The terminal opens a shell on that machine, in the repository, whatever the login shell
  (bash, zsh, fish, csh…). Pull requests and builds use `gh` / `glab` of this machine, told
  which repository, and only for github.com, gitlab.com or a host they're signed in to.
  Forgejo and Gitea are asked from this machine too, with this machine's login for the host.
- Over SSH, programs of this machine can't open the files (reveal in the file manager, open in
  editor, Mergiraf). In WSL they can, through `\\wsl.localhost`.
- Settings that write this machine's global git config (commit signing, Mergiraf) don't apply
  there, nor do a profile's author and signing: that machine's own git config does (the commit
  box says `· global (SSH · host)`).

**Graph**

- Every branch, coloured lanes, ↑/↓ to move. History loads 1500 commits at a time as you scroll.
- _Activity_ in the toolbar (or _Activity calendar_ / _Contributor statistics_ in Ctrl+P)
  opens a day/month calendar and author statistics. Click a day, drag across days, choose a
  month, or enter an inclusive date range; choose author or committer dates. Click a listed
  commit to open its detail, and an author to see their commits. Days use each timestamp’s
  recorded timezone. Authors are resolved together against one consistent Git mailmap;
  unavailable configured map sources stop analysis without fetching. Statistics show commits,
  distinct paths, active days and the first/last activity in the selected period. Each reachable
  commit counts once across local/remote branches, tags and HEAD; stash and app-only refs
  are excluded. Renames touch both paths and merges compare files against their first parent.
  Analysis runs in the background with Cancel and Refresh. Coverage says when history is
  shallow or partial: initially 5,000 commits, _Scan more history_ up to 100,000, with a
  64 MiB snapshot limit and a 16 MiB page limit. Date filtering uses the scanned history,
  including backdated authors. File counts read trees, not file contents. Analysis requires
  Git with `--no-lazy-fetch` support and never downloads missing objects; missing trees or
  metadata are reported as errors. Refresh takes a new reference snapshot; it does not fetch.
- Branch and tag pills in their own column left of the graph, on each branch's tip only, joined
  to their commit: white text, a laptop icon when the branch is local, a cloud when a remote has
  it at that commit (`x` and `origin/x` make one pill), a pull-request icon when one is open,
  `+N` when more refs share the commit, the author's avatar and how long ago it was ("2 hours
  ago"). Author, date and hash columns are optional (Settings).
- Description takes the flexible width. Branch / Tag fits visible pills and shrinks when none
  are in view; dragging its border keeps a fixed width. Restore _Fit visible branch / tag
  pills_ from the header's menu. Faint branch names (or _detached_) identify lanes whose tips
  are offscreen. Long summaries end in an ellipsis; hover the description to read its original
  message, loaded in the background. Messages over the 256 KiB tooltip limit open in the detail
  pane by selecting the commit.
- Ctrl+Alt+1/2/3 (Cmd+Alt on macOS) focuses the sidebar, graph or diff, and detail pane;
  an outline shows the active pane. In the detail pane, j/k selects files in display order,
  opening their folders and scrolling them into view; Space stages or unstages, Enter opens
  the diff. Conflicted files require the explicit Resolve/Mark resolved controls. In a text
  diff, F7/Shift+F7 picks the next/previous change; S/U acts on the current hunk and D asks
  before discarding it (Ctrl+Z restores it). These keys stay with text fields, terminals,
  menus and dialogs while those have focus. Held action keys do not repeat operations.
- Drag the column borders in the header to resize. Right-click the header to pick the columns,
  make the graph column compact (lanes closer together), or _Reset columns_ to their first
  widths.
- The checked-out branch's pill is solid, the others a darker shade. Double-click a pill to
  check that branch (or tag) out; hover `+N` to list every pill of the commit and double-click
  the one you want.
- Each commit's summary, followed by the rest of its message, faded and cut to fit.
- An _Uncommitted changes_ row on top while the working tree is dirty.
- Search (Ctrl+F) through messages, authors and hashes of all history, or switch to _Code_ to
  find the commits that added or removed a piece of text in a file (`git log -S`); Enter /
  Shift+Enter jump between results, loading older history when needed.
- Right-click a commit: create a branch, a tag or a worktree on a new branch there, check it
  out, interactive rebase onto it,
  cherry-pick, revert, reset the current branch to it (soft / mixed / hard, confirmed), the menu
  of each branch on it, copy the hash, message or branch name. Right-click a branch's pill to get
  check out, fast-forward, merge, rebase and interactive rebase for that branch on top.
- Compare: Ctrl+click a second commit (or _Compare with…_ in the commit menu, the changes row
  standing for the working tree) to list the files that differ between the two and open each
  diff. On a branch, _Changes x adds to main_ shows only what it changed since the two diverged,
  as a pull request shows it, and _Compare main with x_ every difference; a checkbox switches
  between the two. The right pane says how many commits each side has that the other hasn't.
- Patches: _Create patch from commit…_ saves a commit as a file (`git format-patch`). _Apply
  patch…_ (the latest commit's menu, the changes row's menu or the palette) turns one from
  `git format-patch` into commits (`git am`) and puts any other diff on the working tree
  (`git apply`). Ctrl+Z undoes either.
- Git bundles: **Export Git bundle…** in the palette saves selected refs, with an optional
  excluded base commit for an incremental range. Ref tips are pinned to the dialog's snapshot;
  a moved ref asks you to reopen it. Output is a new local file; existing files are preserved.
  **Inspect / import local Git bundle…** shows incoming refs, prerequisite commits and Git's
  verification result before importing. Edit each new destination (branches, tags or
  `refs/bundles/…`); collisions stop the whole ref transaction. Import does not check out or
  merge incoming work. SSH and WSL repositories receive a temporary copy for verification and
  import; file pickers and saved bundles always refer to this machine's disk. Supports v2/v3
  bundles and matching SHA-1/SHA-256 repositories, up to 128 MiB and 1000 header entries, with
  a two minute deadline per Git stream. Requires Git 2.36 or newer. Larger exchanges can use
  Git in the terminal. In partial clones, inspection and import require Git's explicit
  `--no-lazy-fetch` support; older Git refuses them instead of fetching from the remote.
- Interactive rebase: the commits to rewrite, newest on top; pick, reword (edit the message in
  place), squash, fix up or drop each one, move them up and down, then _Start rebase_. Ctrl+Z
  undoes it. Rebase weather updates after each reorder or action change: a sun applies cleanly,
  a storm has conflicts (hover for file names and Mergiraf's check), and a cloud is waiting, becomes
  empty or cannot be predicted. Later commits remain unknown after a conflict. Forecasts use Git defaults and
  attributes from each simulated parent tree; global/info attributes, custom merge drivers
  and hooks are excluded. They leave refs, the index and working files alone, and require
  `--attr-source` and `merge-tree --write-tree --merge-base` support; older Git shows why weather
  is unavailable. Edits cancel stale checks, and automatic Git and Mergiraf commands have
  deadlines. Mergiraf checks copies only and does not apply its answers.
- Quick edits from a commit's menu, for commits of the checked-out branch: _Edit commit
  message_, _Drop commit_, _Move commit up_ / _down_, each a rebase without the editor and undone
  with Ctrl+Z. What can't be done (a merge, merges after the commit) is greyed out with why.

**Branches, remotes, worktrees, stashes, tags** (left)

- Local branches with ahead/behind; right-click: check out (or in a new worktree), fast-forward,
  merge into / (interactively) rebase onto the current branch, push, create a pull request,
  rename, delete (here, or here and on the remote in one go)…
- Hide a branch from the graph with the eye on its row (on hover), or _Solo_ some from their
  menu to see only those; the graph then has just the commits of the branches it shows and the
  checked-out one. _Viewing 12 of 55_ at the top says how many it shows, with _Show all_. Kept
  per repository.
- Remotes: add, edit (name and URL), fetch one, remove; their branches below each.
- Worktrees: a yellow dot in place of the folder icon marks the others with uncommitted changes,
  here and in the switcher. Add (existing or new branch), open in the same tab (the tab then shows the branch, a searchable switcher and a button to close the worktree, and what you left keeps running; can be turned off in Settings) or a new one, open a terminal there, lock, remove,
  prune.
- Submodules (shown when the repository has any): each with its commit and whether it is
  modified, not initialised or out of date. Update one or all (`git submodule update --init
  --recursive`), open one in a new tab (or double-click it), show it in its folder. _Keep
  submodules up to date_ in Settings → Git updates them after every checkout, pull, merge and
  rebase.
- Stashes: stash (with a message, untracked files included), see what a stash holds, apply, pop,
  drop.
- Pull / merge requests of GitHub (through `gh`), GitLab (through `glab`), Forgejo and Gitea
  (through their API; Codeberg is Forgejo): list, open in the browser, check out, create from a
  branch. On GitHub, Forgejo and Gitea a click opens one in the big area: description, checks,
  commits, conversation and changed files; comment, review (with comments on lines, pending until
  sent), reply, apply suggested changes, dismiss reviews and merge. Forgejo's and Gitea's API can't
  resolve conversations, so that stays on their web page. _Open in worktree_ (in a request's menu,
  and above the changed files of an open pull request) opens the worktree its branch is checked
  out in, or makes one beside the repository first: on the local branch, on a new one tracking
  the remote branch, or fetched from the forge for a fork that isn't a remote here.
- Gerrit: _Push for review_ picks a fetched target branch and optional topic, validates every
  commit's `Change-Id`, and submits to `refs/for/<branch>`. Graph rows link to the change.
  Amending preserves its `Change-Id`; submit again for a new patch set.
- Tags: create (light or annotated, optionally pushed), push, delete locally or on the remote.

**Changes and commits** (right)

- Conflicted / unstaged / staged lists with stage, unstage, discard and mark-resolved buttons,
  _Stage all_ / _Unstage all_; right-click a file to open it, open it in your editor, show it in
  its folder, see its history or blame, or ignore it (the file, its extension or its folder go
  into `.gitignore`; a tracked file stops being tracked).
- _Path_ / _Tree_ at the top of the pane lists the files of the changes, a commit, a comparison
  or a pull request flat with their paths, or as a tree of their folders; a folder folds with a
  click and says how many files it holds. The choice is remembered.
- Part of a file: _Stage hunk_, _Discard hunk_ and _Unstage hunk_ on each hunk of its diff, or
  click the changed lines you want (Shift+click for a range) and stage, unstage or discard only
  those. Discarding can be undone with Ctrl+Z.
- Commit box (Ctrl+Enter; with nothing staged it stages everything), _Amend last commit_
  (warns when the commit is already pushed), the identity you commit as (and whether it is the
  repository's own, the profile's or the global one), and saved identities or profile authors
  to switch a repository to; _Use the profile's author_ takes the repository's own out again.
- Undo / redo (Ctrl+Z / Ctrl+Y) of commits, amends, merges, rebases, pulls, resets,
  cherry-picks, reverts, checkouts, branch create / rename / delete, tags and stashes.

**Diffs and conflicts** (centre)

- Unified or side by side (a new file takes the whole width, with no empty old side), syntax
  colours, the changed part of each line marked, whitespace changes optional, images shown
  before / after. Esc closes.
- **Syntax** in a diff compares syntax through an installed [Difftastic](https://difftastic.wilfred.me.uk/)
  (`difft`), so reindentation and wrapping do not obscure the tokens that changed. It is a reading
  mode: turn off Syntax to stage changes or see formatting edits. Unsupported languages, parse
  errors, a missing tool or a comparison over its limits show the patch with an explanation.
  Difftastic runs where the repository is (locally, in WSL or over SSH), off the window thread.
- A file kept in Git LFS shows as its LFS objects before and after, with their sizes, rather
  than the text of the pointer git stores. With git-lfs installed, the palette (Ctrl+P) of a
  repository that uses LFS has _LFS: Fetch_ and _LFS: Pull_.
- The arrows in a diff's header (F7 / Shift+F7, or Alt+↓ / Alt+↑) jump to the next and previous
  change. The strip beside the scrollbar marks where the changes are, removals red and additions
  green; click a mark to jump to its change, or anywhere else on the strip to scroll there.
- The _Diff_ / _File_ switch shows the whole file as it is after the change instead (before it,
  for a deleted file), coloured and with line numbers.
- A Markdown file's diff has an eye button that renders it: the changes block by block (removed
  ones red, added ones green, the rest as they are) or, with _File_, the whole file. Images of
  the repository show as they are on each side of the change; any other image is a link, so a
  file can't make gitcraft contact a server.
- Code takes the colours of the theme VS Code (or Insiders, VSCodium) is using, read from its
  settings and extensions, when it is dark or light like gitcraft's; a setting turns it off.
- Conflicts open in a three-pane editor: each conflict's two sides with _Ours_, _Theirs_ and
  _Both_ buttons, and the result below (editable). _Use mine_ / _Use theirs_ for a whole file.
- With [Mergiraf](https://mergiraf.org) installed, _Solve with Mergiraf_ lets it solve the
  conflicts it can from the syntax of the code; the rest stay to choose, and nothing is saved
  before you check the result. Settings → Git installs it in one click and can have git merge
  with it everywhere ([docs/mergiraf.md](docs/mergiraf.md)). gitcraft only runs the `mergiraf`
  program: it neither bundles nor links Mergiraf (GPL-3.0), so gitcraft's licence is unchanged.
- A merge, rebase, cherry-pick, revert or patch stopped on conflicts shows a banner with
  _Abort_; the commit box finishes it (_Continue rebase_ during a rebase, _Continue patch_ while
  `git am` applies one).
- File history (every commit that changed the file, following renames; click one for its diff
  or the file as it was, beside the list), blame (who last changed each line, newer changes
  marked brighter; click to go to the commit) and the whole file at a commit (_View file_ in a
  file's menu).
- _View all files_ under a commit's files lists every file of the commit, not only those it
  changed; click one to read it as it was in that commit.

**Toolbar, terminal, app**

- Undo, redo, Fetch, Pull and Push (with incoming / outgoing counts), new branch, stash, terminal,
  search, open the folder (Explorer / Finder, your editor), refresh (F5).
- Pull's arrow (or a right-click on it) sets what it does: fast-forward, merging when the branch
  has diverged; fast-forward only; or rebase. Also in Settings, and the menu has _Fetch all_.
- Background fetch every few minutes (Settings; 0 turns it off).
- HTTPS sign-in: when a remote wants a username and password (or token) and no credential helper
  provides them, a dialog asks and the operation runs again. They stay in memory for the tab;
  git's own credential helper, if there is one, stores them. Cloning asks the same way.
- Terminal panel with tabs: PowerShell, cmd, Git Bash, WSL… on Windows, your shells elsewhere, in a
  real pseudo-terminal (ConPTY on Windows) with colours, scrollback, mouse selection and copy
  (Ctrl+C with a selection, Ctrl+Shift+C or right-click).
- Command palette (Ctrl+P): every action and branch, fuzzy matched.
- Manual (F1, or the book in the title bar): what each part does and every keyboard shortcut.
- Avatars: on a GitHub repository, the authors' GitHub accounts (through `gh` when installed, else
  GitHub's API); on Forgejo and Gitea, the accounts the host ties the commits to; on GitLab, the
  host's avatar API; elsewhere Gravatar (a hash of the email).
  Cached on disk; can be turned off.
- Settings (Ctrl+, or the gear in the title bar), in pages listed on the left: the profile in
  use and what is its own, zoom, branch column width, graph columns, avatars, notifications,
  update check (with a Check for updates button), background fetch, keeping submodules up to
  date, editor command, default shell and terminal font size, saved identities, SSH sign-ins,
  and every keyboard shortcut. Ctrl+F searches all pages at once (Esc clears it); Alt+↑ /
  Alt+↓ go through the pages.
- Previews beside the settings: point at a setting and a panel on the right (above the page in
  a narrow window) draws what it does with the values set now, as the app draws it. The branch
  column measured on a small graph with long branch names cut to fit, the columns at their
  widths, standard and compact lanes side by side, the lane colours, each way of pulling as a
  before-and-after graph, the terminal with the shell's prompt at its font size, unified and
  side-by-side diffs, context or the whole file, files in folders or in one list, code colours,
  avatars, and the whole window in a theme.
- Commit signing in Settings → Commit signing: the format (OpenPGP, SSH or X.509), signing key
  and program, and whether commits and tags are signed by default. These are your global git
  config's `gpg.format`, `user.signingkey`, `gpg.program` (`gpg.ssh.program`, `gpg.x509.program`),
  `commit.gpgSign` and `tag.gpgSign`, shown as they are set and written back there; git does
  the signing as usual. A profile can sign its own way instead (Settings → Profile).
- Settings → Profile → **Profile's connections** chooses an SSH private key and named GitHub,
  GitLab and Forgejo/Gitea accounts. Empty account names preserve the CLI's normal behavior.
  **Check account** checks the selected GitHub/GitLab user in the background. No global CLI
  account is switched, and tokens are never saved in gitcraft's settings or generated config.
  - GitHub: select an existing `gh` username and server. Requires a `gh` version supporting
    `auth token --user` (multi-account support, gh 2.40 or later). An optional account config
    folder is passed as `GH_CONFIG_DIR`.
  - GitLab: enter the expected `glab` username and server. `glab` has one account per host in a
    config folder; for two accounts on the same server choose separate folders and sign in
    with `GLAB_CONFIG_DIR` set accordingly. The token's actual owner is checked before use;
    a mismatch stops the operation. A host-wide OS keyring slot cannot hold two accounts at
    once; use the CLI's supported separate configuration/file-storage setup for that case.
    OAuth sessions refresh only through that selected CLI configuration after its stored
    login name matches. Gitcraft re-reads the refreshed access token, verifies its owner,
    and pins that exact token for the operation; expiry during an operation fails rather
    than refreshing into another identity. A missing stored login name requires CLI sign-in.
  - Forgejo/Gitea: enter the login **name** from `tea login add --name …`. It is bound to that
    login's HTTPS server; a missing/refused login does not fall back to another identity.
  - HTTPS Git pushes use the same selected accounts through host-scoped credential helpers.
    Helpers resolve credentials only when Git asks for that HTTPS server, and never store
    them. CLI errors and unsupported versions fail without exposing token output.
  - The SSH private key is separate from the signing key. `core.sshCommand` uses a helper that selects it
    with `IdentitiesOnly=yes`, checks the effective host configuration and refuses additional
    `IdentityFile` entries instead of falling back to another account. Proxy and host options
    remain in use. Equivalent tilde and SSH token paths are expanded by OpenSSH itself.
    The generated profile sets `ssh.variant=auto` so an inherited PuTTY configuration cannot
    change the wrapper's port arguments; repository-local transports are still detected by
    Git, and a repository's explicit `ssh.variant` still wins. Ambiguous/control-character
    identity paths are refused before starting the transport. If a repository explicitly
    selects a PuTTY variant while retaining this OpenSSH helper, incompatible options are
    refused before probing or connecting; use `ssh.variant=auto`/`ssh`, or that repository's
    own matching PuTTY command.
  - Background jobs retain the initiating profile's account choices and an immutable config
    snapshot across profile edits, switching or deletion. Git in WSL/SSH repositories keeps
    that machine's own credentials; forge commands run here with this profile's account.
- How a profile's git author, signing and connection choices reach git: gitcraft writes them to a config file of the
  profile's (in its data folder, `profiles/<id>.gitconfig`) that includes your own global config
  first and then sets the profile's values, and runs git with `GIT_CONFIG_GLOBAL` pointing at a leased immutable copy
  (git 2.32 or later), so an in-flight operation keeps its original profile. So the profile wins over `~/.gitconfig`, and a repository's own config
  (`git config --local`, `--worktree`) wins over the profile, as it does over `~/.gitconfig`.
  `git config --global` from gitcraft still reads and writes your own file. The built-in
  terminal keeps your own config.
- Looks on GitHub for a newer release on every start, of the main channel (releases) or the dev
  channel (a prerelease of every change to `dev`). It downloads it in the background and parks it
  on disk; "Update now" in the banner then swaps it in place of the running version and restarts.
  A copy gitcraft can't replace (a .deb or .rpm, an all-users install) offers the release page
  instead. Looking and downloading can each be turned off.
- Toasts, and a desktop notification when a long operation ends while the window is in the
  background.
- Themes (Settings → Appearance, the palette icon in the title bar, or _Theme:_ in the command
  palette), each profile its own:
  - 40 built in: gitcraft's Dark, Medium Gray and Light (PhotoCraft's Pro palettes), High
    Contrast Dark and Light, and the published palettes of Catppuccin (Mocha, Macchiato, Frappé,
    Latte), Tokyo Night (Night, Storm, Day), Rosé Pine (main, Moon, Dawn), Kanagawa (Wave,
    Dragon, Lotus), Everforest (Dark, Light), Dracula, Nord, Gruvbox (Dark, Light), Solarized
    (Dark, Light), One Dark and One Light, GitHub (Dark, Light), Ayu (Dark, Mirage, Light),
    Monokai, Monokai Pro, Night Owl, Material Palenight, Tomorrow Night, Horizon and
    SynthWave '84. A theme colours everything: panels, text, the graph's lanes and pills, diffs
    and the terminal's 16 colours. WCAG AA checks (4.5:1) cover built-in text colours on their
    panel and row backgrounds, text-field hints, graph descriptions and status badges. Button
    and branch-pill labels are checked against their fills. Accent text is separate from the
    button fill so both remain readable. Status tints adapt to the
    selected or hovered background. Imported themes and custom colour values keep their
    author's choices; derived pill shading can change to keep white labels readable.
  - A gallery of thumbnails; pointing at one shows the whole window in it before choosing.
  - _Follow VS Code_: the interface takes the workbench colours of the theme VS Code (or
    Insiders, VSCodium) is using, and changes with it.
  - Themes from the internet: _Import theme file…_ takes a VS Code colour theme (`.json`, from an
    extension's `themes` folder or sites such as vscodethemes.com), a Base16 or Base24 scheme
    (`.yaml`, e.g. the tinted-theming collection) or a theme saved by gitcraft, and copies it
    into gitcraft's `themes` folder.
  - Your own: _Save a copy to edit_ writes the theme in use, every colour by name, as a file in
    that folder (`extends` names a theme to start from, so a file can set only an accent). Edit
    it in any editor and the window follows as you save; a file that doesn't read says why
    under the buttons.
  - For any theme: your own accent colour, rounder or square corners, and the graph's lanes in
    the theme's hues, gitcraft's classic ones or colour-blind-safe ones (Okabe–Ito).

## Download

Ready-made builds for Windows, Linux (x86-64) and macOS (Apple silicon and Intel) are on the
[releases page](https://github.com/Vancete/gitcraft/releases). Git must be installed. New
releases are built for Windows and Linux only for now: the release workflow's macOS job is off
until GitHub's macOS runners pick it up again, so on a Mac build from source (below) meanwhile.

- **Windows:** `gitcraft-…-setup.exe` installs it for your user (no administrator rights), with a
  Start menu entry, an optional desktop icon, _Open in gitcraft_ on folders and an uninstaller.
  The `.zip` is the same program without installing.
- **Linux:** `gitcraft-….deb` (Debian, Ubuntu, Mint…) and `gitcraft-….rpm` (Fedora, openSUSE…)
  install it with its applications menu entry, from the software centre or with
  `sudo apt install ./gitcraft-….deb` / `sudo dnf install ./gitcraft-….rpm`.
  `gitcraft-….AppImage` runs on any distribution: make it executable (`chmod +x`) and run it;
  _Add gitcraft to the applications menu_ on its start page (or in Settings) adds a menu entry,
  which follows the AppImage when you replace it with a newer one. The `.tar.gz` holds the bare
  binary and a `.desktop` file.
- **macOS** (11 or later): open `gitcraft-…-macos-universal.dmg` and drag gitcraft to
  Applications; the `.zip` holds the same app. It isn't notarized by Apple, so the first time
  macOS refuses to open it: go to _System Settings › Privacy & Security_ and click _Open
  Anyway_, or run `xattr -dr com.apple.quarantine /Applications/gitcraft.app`. git comes with
  the Xcode command line tools (`xcode-select --install`) or Homebrew.

A release is built by `.github/workflows/release.yml` whenever a `v*` tag is pushed
(`packaging/windows/gitcraft.iss` for the installer, `packaging/linux/build-appimage.sh` for the
AppImage, `[package.metadata.deb]` / `[package.metadata.generate-rpm]` in `Cargo.toml` for the
packages, `packaging/macos/build-app.sh` for the universal app, its `.dmg` and `.zip`).

## Build and run

```bash
cargo run --release                   # start
cargo run --release -- path/to/repo   # open a repository directly
cargo test
```

Linux needs the usual eframe system packages (e.g. `libxkbcommon-dev`, `libgtk-3-dev` for the
file dialogs, `libdbus-1-dev` for notifications). Pull requests need the GitHub CLI (`gh`) or
GitLab CLI (`glab`), logged in.

Forgejo and Gitea need no tool of their own. gitcraft uses a login the user already has for the
host, and never stores one: `GITEA_SERVER_URL` + `GITEA_SERVER_TOKEN` when they name that server,
else a login of `tea` (`tea login add`, which works with Forgejo too), else what git's credential
helper keeps for `https://host` (a password or an access token). Public repositories can be read
without any. codeberg.org and hosts named like `forgejo…` / `gitea…` are recognised, as are the
hosts `tea` is logged in to; for any other server, tell git's config which forge it is:

```bash
git config --global gitcraft.git.example.org.forge forgejo   # every repository on that host
git config gitcraft.forge gitea                               # just this repository
```

The value is one of `github`, `gitlab`, `forgejo` or `gitea`.

### Gerrit

Hosts named `gerrit.…` and `*.googlesource.com` are recognised. For another host, set
`git config gitcraft.forge gerrit` (or `git config --global gitcraft.review.example.org.forge gerrit`).
The workflow uses `origin`, or the first remote when there is no origin, and git's existing
transport and credentials. Fetch first, then choose _Push for review_ in the toolbar, command
palette, or a branch's Push action. The dialog previews the exact commit and review ref.
The optional topic travels as a Git push option, so punctuation cannot become Gerrit options.

Install your server's `commit-msg` hook using its own instructions, and amend existing commits
that lack a `Change-Id`. gitcraft validates the complete series above the fetched target,
including commits outside the visible graph. Missing, malformed or duplicate IDs stop the push.
This flow submits linear series based on the target; fetch and rebase first when the target has
diverged. Merge commits are refused. It never changes the branch's upstream or force pushes.

Use _Amend last commit_ to update a reviewed change. Its original `Change-Id` is preserved even
when replacing the description; changing it to another ID is refused. _Push for review_ again
uploads the new patch set. The arrow on a graph row and _Open Gerrit change_ in its menu open
a project-qualified change search, which also works without knowing the change number.
Googlesource links use its corresponding `-review` host.
For SSH, the default web URL uses HTTPS without the SSH port. Override the review web address
(including a reverse-proxy prefix) with `git config gitcraft.gerritUrl https://review.example.org/gerrit`.

### Testing against a real Forgejo and Gitea

The Forgejo / Gitea code has tests that go through a pull request's whole life on real servers:
detection, opening, the list, reading it in full, fetching its changes, comments, pending reviews,
replies, dismissals, suggested changes and merging. `ci/forge-server.sh` downloads a release
(checksum verified), starts it on 127.0.0.1 with SQLite and two users, and writes their tokens to an
env file; CI does the same for the latest and the oldest supported releases (`.github/workflows/ci.yml`).

```bash
ci/forge-server.sh forgejo 3000 forges.env   # FORGEJO_VERSION=… for another release
ci/forge-server.sh gitea 3001 forges.env     # GITEA_VERSION=…
set -a; . ./forges.env; set +a
cargo test --lib forge::gitea::live -- --ignored --nocapture
```

A plain `cargo test` skips them.

### Remote repositories, against real machines

The tests of `src/remote/live_tests.rs` run only when given a machine:

```sh
GITCRAFT_TEST_SSH='build-host:~/repos/some-repo' cargo test live_tests -- --nocapture  # reads it
GITCRAFT_TEST_WSL=Ubuntu cargo test live_tests -- --nocapture  # works in a scratch repo in /tmp
GITCRAFT_TEST_WSL=Ubuntu cargo test never_holds_up_the_window  # drives the window against one
```

`cargo run --example ui_shot` ends by saying how many commands for another machine were asked
from the window's thread (each is a bug: refused, it would have frozen the window).

### Looking at the UI headlessly

`examples/ui_shot.rs` drives the app without a window (egui_kittest) and saves PNGs:

```bash
cargo run --example ui_shot -- path/to/repo /tmp/shot click:500,266 shot key:Escape shot
```

Steps: `click:x,y`, `dclick:x,y`, `rclick:x,y`, `cclick:x,y` (with Ctrl / Cmd), `sclick:x,y`
(with Shift), `drag:x1,y1,x2,y2`, `hover:x,y`, `wheel:x,y,dy` (negative scrolls down), `leave`,
`open:path` (another repository in a new tab),
`key:Name`, `ckey:Name` (with Ctrl / Cmd), `type:text`, `wait:ms`, `shot`. The README screenshot
was made this way, on a demo repository.

## Layout

| File                     | Job                                                                                |
| ------------------------ | ---------------------------------------------------------------------------------- |
| `src/git.rs`             | `git` CLI wrapper and output parsing (refs, log, status, stashes, remotes, search) |
| `src/graph.rs`           | lane layout for the commit graph                                                   |
| `src/forge/mod.rs`       | the forges behind one `Provider` trait: which one hosts a remote, list, create, avatars, the page of one |
| `src/forge/github/`      | GitHub through `gh`: list, `gh pr view`, GraphQL threads, comments, reviews, merges |
| `src/forge/gitlab.rs`    | GitLab through `glab`: list and create                                             |
| `src/forge/gitea/`       | Forgejo and Gitea through their REST API: list, the page of one, comments, reviews, merges; finding the login |
| `src/forge/http.rs`      | the REST client for forges without a command-line tool                             |
| `src/forge/cli.rs`       | running `gh` / `glab`                                                              |
| `ci/forge-server.sh`     | a throwaway Forgejo or Gitea for the live tests (`src/forge/gitea/live.rs`)        |
| `src/pull_request/mod.rs` | one pull request in full, whatever the forge: details, checks, comments, changes, safe markdown |
| `src/pr_post/mod.rs` | what goes out: the `Target` trait each forge implements, and what they share (suggestions, merge rules) |
| `src/pr_threads.rs` | review threads, the pending review and permissions                          |
| `src/avatars.rs`         | avatars from GitHub, Forgejo / Gitea, GitLab or Gravatar, cached on disk           |
| `src/update.rs`          | new-release check                                                                  |
| `src/desktop_entry.rs`   | applications menu entry for the AppImage                                           |
| `src/shell_path.rs`      | on macOS, the login shell's PATH for the commands gitcraft starts                  |
| `src/remote/` | repositories in WSL or over SSH: their paths, the shells kept open there, their files |
| `src/settings/`          | user settings, profiles, the settings pages, the theme gallery and the previews    |
| `src/manual.rs`          | the manual (F1): features and keyboard shortcuts                                   |
| `src/theme/`             | colour tokens, fonts, egui style; themes: catalogue, palettes, theme files         |
| `src/icons.rs`           | embedded Lucide SVG icons, tinted                                                  |
| `src/terminal.rs`        | integrated terminal: pty, VT parsing (`vt100`), painting, keys, selection          |
| `src/repo/mod.rs`        | one repository tab: state, background git work, undo / redo, toolbar               |
| `src/repo/sidebar.rs`    | branches, remotes, worktrees, stashes, pull requests, tags                         |
| `src/repo/pr_view.rs` | a pull request in the big area, its changed files on the right |
| `src/repo/pr_review.rs` | comments and reviews being written, and the threads on lines of a diff |
| `src/repo/pr_merge.rs` | the box that merges a pull request |
| `src/repo/pinned_sections.rs` | sidebar section headers that stay in view and jump to their section |
| `src/repo/branch_tree.rs` | branch names and file paths as a tree of folders, and its rows |
| `src/repo/columns.rs` | widths of the graph's columns: what a drag changes and what gets squeezed |
| `src/repo/worktree_tab.rs` | worktrees in the same tab: parked views, the tab's chip and switcher |
| `src/repo/graph_view.rs` | commit graph, pills, search bar, commit menu                                       |
| `src/repo/detail.rs`     | commit / stash detail, changes and commit box                                      |
| `src/repo/diff.rs`       | diff loading, pairing and the diff view (unified, split, images)                   |
| `src/repo/highlight.rs`  | syntax colours (syntect)                                                           |
| `src/vscode_theme.rs`    | VS Code's current colour theme as a syntect theme                                  |
| `src/repo/conflict.rs`   | three-pane conflict editor                                                         |
| `src/mergiraf.rs` | Mergiraf, run as the user's own command when it is installed |
| `src/repo/rebase.rs`     | interactive rebase editor and its todo list                                        |
| `src/repo/file_view.rs`  | a file's history, blame and contents at a commit                                   |
| `src/repo/file_text.rs`  | a whole file at a commit, coloured, for the file view and diffs                    |
| `src/repo/dialogs.rs`    | branch, tag, stash, remote, worktree, pull request and confirm dialogs             |
| `src/repo/widgets.rs`    | shared painted widgets (panel headers, file rows, avatars, tabs)                   |
| `src/app.rs`             | window shell: tabs, start page, cloning, palette, settings, toasts                 |

Assets and their licences: [ATTRIBUTION.md](ATTRIBUTION.md).

## License

MIT OR Apache-2.0, at your option ([LICENSE-MIT](LICENSE-MIT), [LICENSE-APACHE](LICENSE-APACHE)).
