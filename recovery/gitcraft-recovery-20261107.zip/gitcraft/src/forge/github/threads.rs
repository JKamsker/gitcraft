//! What only GitHub's GraphQL API tells about a pull request: review threads with their state,
//! the pending review of the person logged in, and what they may do.

use std::path::Path;

use serde_json::{Value, json};

use super::{gh_with_input, login};
use crate::pr_threads::{PrExtras, Thread, ThreadComment};
use crate::pull_request::{DiffSide, at, items, parse_time};

const QUERY: &str = "query($owner: String!, $name: String!, $number: Int!, $after: String) {
  viewer { login }
  repository(owner: $owner, name: $name) {
    mergeCommitAllowed squashMergeAllowed rebaseMergeAllowed deleteBranchOnMerge viewerPermission
    pullRequest(number: $number) {
      id headRefOid viewerCanMergeAsAdmin
      headRepository { nameWithOwner }
      pending: reviews(first: 1, states: PENDING) { nodes { id } }
      reviewThreads(first: 100, after: $after) {
        pageInfo { hasNextPage endCursor }
        nodes {
          id isResolved isOutdated path line originalLine diffSide startLine startDiffSide
          viewerCanResolve viewerCanUnresolve viewerCanReply
          comments(first: 100) {
            pageInfo { hasNextPage }
            nodes { id body createdAt url state author { login } }
          }
        }
      }
    }
  }
}";

/// Reads all of it for the pull request `number` of `owner/name`.
pub fn fetch(repo: &Path, host: &str, path: &str, number: u64) -> Result<PrExtras, String> {
    let (owner, name) = path.split_once('/').ok_or("unexpected repository name")?;
    // A push between two pages would put threads of two commits together: it's read again.
    for _ in 0..2 {
        if let Some(extras) = fetch_pages(repo, host, owner, name, number)? {
            return Ok(extras);
        }
    }
    Err("The pull request changed while it was read. Load it again.".to_owned())
}

/// All pages of it, or `None` if they weren't all of the same commit.
fn fetch_pages(
    repo: &Path,
    host: &str,
    owner: &str,
    name: &str,
    number: u64,
) -> Result<Option<PrExtras>, String> {
    let mut extras: Option<PrExtras> = None;
    let mut after: Option<String> = None;
    loop {
        let payload = json!({
            "query": QUERY,
            "variables": { "owner": owner, "name": name, "number": number, "after": after },
        });
        let mut args = vec!["api", "graphql", "--input", "-"];
        if host != "github.com" {
            args.extend(["--hostname", host]);
        }
        let out = gh_with_input(repo, &args, Some(&payload.to_string()))?;
        let (page, next_page) = parse(&out)?;
        after = next_page;
        extras = match extras {
            None => Some(page),
            Some(mut all) => {
                if !add_page(&mut all, page) {
                    return Ok(None);
                }
                Some(all)
            }
        };
        if after.is_none() {
            return Ok(extras);
        }
    }
}

/// Adds the threads of a further page, if it's of the same commit as the first.
fn add_page(all: &mut PrExtras, page: PrExtras) -> bool {
    if page.head_oid != all.head_oid {
        return false;
    }
    all.threads.extend(page.threads);
    true
}

/// The page of threads `json` holds, and where the next one starts if there is one.
pub(crate) fn parse(json: &str) -> Result<(PrExtras, Option<String>), String> {
    let v: Value =
        serde_json::from_str(json).map_err(|e| format!("unexpected output of gh: {e}"))?;
    let repository = v
        .pointer("/data/repository")
        .ok_or("GitHub doesn't know this repository")?;
    let pr = repository
        .get("pullRequest")
        .filter(|pr| !pr.is_null())
        .ok_or("GitHub doesn't know this pull request")?;
    let allowed = |key: &str| {
        repository
            .get(key)
            .and_then(Value::as_bool)
            .unwrap_or(false)
    };
    let threads = pr.pointer("/reviewThreads");
    let has_next = threads
        .and_then(|t| t.pointer("/pageInfo/hasNextPage"))
        .and_then(Value::as_bool)
        .unwrap_or(false);
    let viewer = at(&v, "/data/viewer/login");
    let head_repo = at(pr, "/headRepository/nameWithOwner");
    let pending = at(pr, "/pending/nodes/0/id");
    let next_page = threads
        .and_then(|t| t.pointer("/pageInfo/endCursor"))
        .and_then(Value::as_str)
        .filter(|_| has_next)
        .map(str::to_owned);
    let extras = PrExtras {
        pr_id: at(pr, "/id").to_owned(),
        viewer: (!viewer.is_empty()).then(|| viewer.to_owned()),
        permission: at(repository, "/viewerPermission").to_owned(),
        merge_allowed: allowed("mergeCommitAllowed"),
        squash_allowed: allowed("squashMergeAllowed"),
        rebase_allowed: allowed("rebaseMergeAllowed"),
        delete_branch_on_merge: allowed("deleteBranchOnMerge"),
        head_repo: (!head_repo.is_empty()).then(|| head_repo.to_owned()),
        pending_review: (!pending.is_empty()).then(|| pending.to_owned()),
        head_oid: at(pr, "/headRefOid").to_owned(),
        can_bypass_rules: pr
            .get("viewerCanMergeAsAdmin")
            .and_then(Value::as_bool)
            .unwrap_or(false),
        threads: items(pr, "/reviewThreads/nodes")
            .iter()
            .map(thread)
            .collect(),
    };
    Ok((extras, next_page))
}

fn thread(v: &Value) -> Thread {
    let number = |key: &str| v.pointer(key).and_then(Value::as_u64);
    let flag = |key: &str| v.pointer(key).and_then(Value::as_bool).unwrap_or(false);
    Thread {
        id: at(v, "/id").to_owned(),
        path: at(v, "/path").to_owned(),
        line: number("/line").or_else(|| number("/originalLine")),
        start_line: number("/startLine"),
        side: if at(v, "/diffSide") == "LEFT" {
            DiffSide::Left
        } else {
            DiffSide::Right
        },
        outdated: flag("/isOutdated"),
        resolved: flag("/isResolved"),
        can_resolve: flag("/viewerCanResolve"),
        can_unresolve: flag("/viewerCanUnresolve"),
        can_reply: flag("/viewerCanReply"),
        starts_left: at(v, "/startDiffSide") == "LEFT",
        more_comments: flag("/comments/pageInfo/hasNextPage"),
        comments: items(v, "/comments/nodes")
            .iter()
            .map(|c| ThreadComment {
                id: at(c, "/id").to_owned(),
                author: login(c, "/author/login"),
                at: parse_time(at(c, "/createdAt")).unwrap_or(0),
                body: at(c, "/body").to_owned(),
                url: at(c, "/url").to_owned(),
                pending: at(c, "/state") == "PENDING",
            })
            .collect(),
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn reads_what_the_page_needs_to_be_careful() {
        let extras = parse(
            r#"{"data": {"viewer": {"login": "me"}, "repository": {"pullRequest": {
                "id": "PR", "headRefOid": "abc", "viewerCanMergeAsAdmin": true,
                "reviewThreads": {"nodes": [{
                    "id": "T", "path": "a.rs", "line": 3, "startLine": 2, "diffSide": "RIGHT",
                    "startDiffSide": "LEFT",
                    "comments": {"pageInfo": {"hasNextPage": true}, "nodes": []}
                }]}
            }}}}"#,
        );
        let (extras, _) = extras.unwrap_or_default();
        assert_eq!(extras.head_oid, "abc");
        assert!(extras.can_bypass_rules);
        assert!(extras.threads[0].starts_left);
        assert!(extras.threads[0].more_comments);
    }

    /// What GitHub answered for the throwaway repository: one thread from a bot, one comment of
    /// the viewer in a pending review.
    const ANSWER: &str = r#"{"data": {
        "viewer": {"login": "JKamsker"},
        "repository": {
            "mergeCommitAllowed": true, "squashMergeAllowed": true, "rebaseMergeAllowed": false,
            "deleteBranchOnMerge": true, "viewerPermission": "ADMIN",
            "pullRequest": {
                "id": "PR_abc",
                "headRepository": {"nameWithOwner": "JKamsker/gitcraft-review-test"},
                "pending": {"nodes": [{"id": "PRR_pending"}]},
                "reviewThreads": {
                    "pageInfo": {"hasNextPage": true, "endCursor": "CURSOR"},
                    "nodes": [
                        {"id": "PRRT_1", "isResolved": false, "isOutdated": false, "path": "src/calc.py",
                         "line": 9, "originalLine": 9, "diffSide": "RIGHT", "startLine": 9,
                         "viewerCanResolve": true, "viewerCanUnresolve": false, "viewerCanReply": true,
                         "comments": {"nodes": [
                            {"id": "PRRC_1", "body": "Clearer:\n\n```suggestion\nx\n```",
                             "createdAt": "2026-11-02T21:46:30Z", "url": "https://g/1",
                             "state": "SUBMITTED", "author": {"login": "github-actions"}},
                            {"id": "PRRC_2", "body": "Mine", "createdAt": "2026-11-02T21:47:12Z",
                             "url": "https://g/2", "state": "PENDING", "author": {"login": "JKamsker"}}
                         ]}},
                        {"id": "PRRT_2", "isResolved": true, "isOutdated": true, "path": "a.py",
                         "line": null, "originalLine": 3, "diffSide": "LEFT", "startLine": null,
                         "viewerCanResolve": false, "viewerCanUnresolve": true, "viewerCanReply": false,
                         "comments": {"nodes": [
                            {"id": "PRRC_3", "body": "Old", "createdAt": "2026-11-02T21:00:00Z",
                             "url": "https://g/3", "state": "SUBMITTED", "author": null}
                         ]}}
                    ]
                }
            }
        }
    }}"#;

    fn parsed() -> PrExtras {
        parse(ANSWER).unwrap_or_default().0
    }

    #[test]
    fn reads_who_may_do_what() {
        let extras = parsed();
        assert_eq!(extras.pr_id, "PR_abc");
        assert_eq!(extras.viewer.as_deref(), Some("JKamsker"));
        assert!(extras.can_write());
        assert!(extras.merge_allowed && extras.squash_allowed && !extras.rebase_allowed);
        assert!(extras.delete_branch_on_merge);
        assert_eq!(
            extras.head_repo.as_deref(),
            Some("JKamsker/gitcraft-review-test")
        );
        assert_eq!(extras.pending_review.as_deref(), Some("PRR_pending"));
    }

    #[test]
    fn reads_threads_and_their_comments() {
        let extras = parsed();
        let thread = &extras.threads[0];
        assert_eq!(thread.id, "PRRT_1");
        assert_eq!(
            (thread.path.as_str(), thread.line),
            ("src/calc.py", Some(9))
        );
        assert_eq!(thread.side, DiffSide::Right);
        assert!(!thread.resolved && !thread.outdated);
        assert!(thread.can_resolve && !thread.can_unresolve && thread.can_reply);
        assert_eq!(thread.comments.len(), 2);
        assert_eq!(thread.comments[0].author, "github-actions");
        assert!(!thread.comments[0].pending);
        assert!(thread.comments[1].pending);
    }

    #[test]
    fn an_outdated_thread_keeps_the_line_it_was_on() {
        let extras = parsed();
        let thread = &extras.threads[1];
        assert_eq!(thread.line, Some(3));
        assert_eq!(thread.side, DiffSide::Left);
        assert!(thread.resolved && thread.outdated && thread.can_unresolve);
        assert_eq!(thread.comments[0].author, "ghost");
    }

    #[test]
    fn finds_the_comments_waiting_in_the_pending_review() {
        let extras = parsed();
        let waiting: Vec<&str> = extras
            .pending_comments()
            .map(|(_, comment)| comment.id.as_str())
            .collect();
        assert_eq!(waiting, ["PRRC_2"]);
    }

    #[test]
    fn knows_when_there_are_more_threads() {
        let next = parse(ANSWER).ok().and_then(|(_, next)| next);
        assert_eq!(next.as_deref(), Some("CURSOR"));
    }

    #[test]
    fn pages_of_another_commit_are_not_put_together() {
        let mut all = parsed();
        let same = parsed();
        assert!(add_page(&mut all, same));
        assert_eq!(all.threads.len(), 4);
        let pushed = PrExtras {
            head_oid: "newer".to_owned(),
            ..parsed()
        };
        assert!(!add_page(&mut all, pushed));
        assert_eq!(all.threads.len(), 4);
    }

    #[test]
    fn a_pull_request_that_does_not_exist_is_an_error() {
        let answer = r#"{"data": {"viewer": {"login": "a"}, "repository": {"pullRequest": null}}}"#;
        assert!(parse(answer).is_err());
        assert!(parse("oops").is_err());
    }
}
