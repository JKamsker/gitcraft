#!/bin/bash
set -euo pipefail
export CARGO_HOME=/workspace/.cargo
export RUSTUP_HOME=/workspace/.rustup
export PATH="$CARGO_HOME/bin:$PATH"
export CARGO_BUILD_JOBS=4
export XDG_CACHE_HOME=/workspace/.gitcraft-env/cache
mkdir -p "$XDG_CACHE_HOME"
cd /workspace/gitcraft
if ! command -v rustup >/dev/null; then
  curl --fail --show-error --silent https://sh.rustup.rs -o /tmp/gitcraft-rustup.sh
  sh /tmp/gitcraft-rustup.sh -y --no-modify-path --default-toolchain 1.95.0 --profile minimal --component rustfmt,clippy
fi
rustup toolchain install 1.95.0 --profile minimal --component rustfmt,clippy
cargo +1.95.0 fetch --locked
cargo +1.95.0 test --locked --no-run
cargo +1.95.0 build --locked --bin gitcraft --example ui_shot
