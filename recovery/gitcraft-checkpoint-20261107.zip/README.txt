Gitcraft source checkpoint, 2026-11-07

The bundle records complete Git history for30 source/review/evidence refs. A fresh bare restore was verified against every ref. No build caches, system credentials or generated authentication files are included. All completed units were already pushed to GitHub.

Restore the latest validated combined source in a NEW working environment:
  git clone -b codex/remaining-features gitcraft-source-checkpoint-20261107.bundle gitcraft
  cd gitcraft
  git remote rename origin checkpoint
  git remote add origin https://github.com/JKamsker/gitcraft.git
  git fetch origin

Latest historically validated integration is ab68bdedd387236c03f26f839572860d405a2f7f:22 eligible ideas,945passed/3baselineignored/948registered, fmt and strict Clippy PASS. Current environment cannot fork reliably; fresh exact checks failed with EAGAIN even under safe process isolation. Do not treat historical results as a completed final gate.

Standalone candidate codex/integration-standalone396b02e contains reviewed9bb source but is unvalidated combined code. Other WIP source branches and historical commits are not approved for execution or merge; some historical recovery code caused an earlier outage. Continue from named current refs and task metadata; never rerun recovery/checkpoint_worktrees.py or old process-selector probes.

ONE final PR is required. No final PR exists. Do not use CI until all implementation, clean final history, local checks and independent adversarial reviews are complete. All new commits must use Jonas Kamsker <11245306+JKamsker@users.noreply.github.com>, matching028242cd4bc3. Preserve published branches; final clean per-feature history is still pending.72 eligible named ideas are in scope,22 are integrated and41 remain queued; read implementation-queue.json for exact active work.

Future runtime needs Git2.52, Rust1.95 toolchain, real difftastic0.72, private Cargo targets and bounded compilation/test concurrency. Use a proper child reaper from the start and check zombie growth. The old workspace has over31000 unreaped terminated children; no existing init process was mutated. A working execution environment or platform repair is required before resuming gates.
